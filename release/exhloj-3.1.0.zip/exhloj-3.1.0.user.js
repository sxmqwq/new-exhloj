// ==UserScript==
// @name         Extend HLOJ
// @namespace    exhloj-local
// @version      3.1.0
// @description  HLOJ 训练助手：题源与难度、比赛、练习统计、用户资料和 Rating。
// @homepageURL  https://github.com/sxmqwq/new-exhloj
// @supportURL   https://github.com/sxmqwq/new-exhloj/issues
// @updateURL    https://raw.githubusercontent.com/sxmqwq/new-exhloj/main/dist/exhloj.user.js
// @downloadURL  https://raw.githubusercontent.com/sxmqwq/new-exhloj/main/dist/exhloj.user.js
// @author       Extend HLOJ Dev Team (original); Local restoration
// @match        *://oj.hailiangedu.com/*
// @match        *://www.nfls.com.cn/*
// @match        *://oifha.com/*
// @match        *://*.oifha.com/*
// @run-at       document-end
// @noframes
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_xmlhttpRequest
// @connect      localhost
// @connect      127.0.0.1
// @connect      www.luogu.com.cn
// @connect      codeforces.com
// @connect      qoj.ac
// @connect      yuantiji.ac
// @connect      cpret.online
// @connect      oier.api.baoshuo.dev
// ==/UserScript==

/*
 * 安装：先停用旧 Extend HLOJ，再将本文件安装到 Tampermonkey，刷新 OJ。
 * 入口：右上角菜单的「Extend HLOJ」；油猴菜单亦可打开设置。
 * 范围：core 的设置、缓存导入导出、事件系统；ui 的圆角、作业、榜单、
 *       Markdown 复制、头像链接、权限查看、CPH / CP Editor；
 *       captcha 本地 SVG 识别；remote-problem 题源/难度/翻译/题解/导出；
 *       contest-helper 比赛导出与可选报名；juan-monitor 练习统计与本地快照；user 本地资料和 Rating。
 * 请求：当前 OJ 的页面 JSON（GET）；导出附件时 POST 获取下载链接，报名时 POST attend；
 *       自动报名默认关闭。保存头像及发送 CPH / CP Editor 时才执行对应 POST。
 *       题意搜索只在点击后向所选的原题机 / CPRet 发送输入框内容，候选经确认后才保存为本地题源；
 *       验证码识别不联网、不自动提交登录；不访问原插件后端。
 *       user 按需 GET 榜单、用户名或 OIerDb 官方公开数据；资料编辑与 Rating 结算只保存到本地，无指定 UID 的管理员限制。
 * 缓存使用明文 JSON。旧版 AES 密文不在本版导入范围内；不读取旧 token/密码。
 * 此文件按原 1.16.1 的功能重制，内嵌 marked / DOMPurify / KaTeX / marked-katex-extension 和离线拼音字典 pinyin-pro（第三方许可证随 ZIP 提供）；
 * 无远程代码依赖，使用本仓库的固定更新地址。更新现有脚本会保留存储。
 * 若作为新脚本安装，请停用旧版，并按需导入之前的 JSON 备份。
 */

(() => {
  'use strict';
  const page = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
  if (window.top !== window.self) return;
  if (!(location.hostname === 'oj.hailiangedu.com' ||
      location.host === 'www.nfls.com.cn:10611' || /(^|\.)oifha\.com$/.test(location.hostname))) return;
  if (document.documentElement.dataset.exhlojCoreUi) return;
  document.documentElement.dataset.exhlojCoreUi = '3.1.0';

  const VERSION = '3.1.0';
  const SETTINGS_KEY = 'exhloj.coreui.settings.v1';
  const CACHE_KEY = 'exhloj.coreui.cache.v1';
  const CAPTCHA_KEY = 'exhloj.local.captcha.history';
  const LIMIT = 2 * 1024 * 1024;
  const LEGACY_KEYS = ['exhloj.problemOriginCache', 'exhloj.juan', 'exhloj.enabledPlugins',
    'exhloj.weeklyRoundsData', 'exhloj.user', 'exhloj.userStoreVersion', 'exhloj.nfls', 'exhloj.remoteOrigins',
    'exhloj.ratedcontests', 'exhloj.ratedcontests.version', 'model.user.display-name', 'model.user.display-ccflevel'];
  const MENU_OPTIONS = {
    hideEmptyDiscussion: ['隐藏零讨论', true], hideEmptySolution: ['隐藏零题解', true],
    showUnknownSimilarity: ['权限未知时显示比赛查重', false],
    showUnknownHomeworkSimilarity: ['权限未知时显示作业查重', false],
    hideNavProblems: ['隐藏题库', true], hideNavTraining: ['隐藏训练', true],
    hideNavDiscussion: ['隐藏讨论', true], hideNavRecords: ['隐藏评测记录', true],
    profileInfoEntry: ['显示「用户信息」入口', true],
  };
  const RANKING_OPTIONS = {
    rankingAlignLeft: ['右侧统计信息靠左排列', false],
    rankingHideBio: ['隐藏个人简介', false],
  };
  const OPTIONS = {
    rounded: ['卡片圆角与布局', true], homework: ['作业标题与附件', true],
    scoreboard: ['榜单奖牌、标题链接与最早提交标记', true],
    markdown: ['复制题面 / 题解 Markdown', true], cph: ['发送到 CPH', true], editor: ['发送到 CP Editor', true],
    avatar: ['头像链接设置入口', true], permissions: ['查看用户权限', true],
    cleanMenu: ['隐藏失效菜单链接', true],
    ...MENU_OPTIONS, ...RANKING_OPTIONS,
  };
  const DEFAULTS = { ui: true, captcha: true, remote: true, contestHelper: true, homeworkPlanner: true, juanMonitor: true,
    userModule: true, userDisplay: 'no-change', userCCF: false,
    helperDelay: 250, helperPageLimit: 100, helperRequestLimit: 2000, contestFiles: true, contestDetails: false,
    autoAttend: false, autoAttendInterval: 60, autoAttendTargets: '', autoAttendTitle: '', autoAttendRules: '',
    juanDomains: '', juanRecords: true, juanContests: true, juanHomeworks: true, juanPeriod: 7,
    captchaHide: true, captchaRemember: false,
    remoteAuto: true, remoteContest: 'hide', remoteColor: 'text', options: Object.fromEntries(
    Object.entries(OPTIONS).map(([key, value]) => [key, value[1]])), cphPort: 27121, editorPort: 10045 };
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const clone = value => JSON.parse(JSON.stringify(value));
  function stored(key, fallback) {
    try {
      const value = GM_getValue(key, null);
      if (value === null || value === undefined) return clone(fallback);
      return typeof value === 'string' ? JSON.parse(value) : value;
    } catch { return clone(fallback); }
  }
  function save(key, value) { GM_setValue(key, JSON.stringify(value)); }
  function normalizeSettings(value) {
    if (!isObject(value)) throw new Error('设置必须是 JSON 对象');
    const result = clone(DEFAULTS);
    for (const key of ['ui', 'captcha', 'remote', 'captchaHide', 'captchaRemember', 'remoteAuto', 'contestHelper', 'homeworkPlanner', 'juanMonitor',
      'contestFiles', 'contestDetails', 'autoAttend', 'juanRecords', 'juanContests', 'juanHomeworks', 'userModule', 'userCCF']) {
      if (typeof value[key] === 'boolean') result[key] = value[key];
    }
    if (['hide', 'shortcut', 'show'].includes(value.remoteContest)) result.remoteContest = value.remoteContest;
    if (['text', 'background', 'none'].includes(value.remoteColor)) result.remoteColor = value.remoteColor;
    if (['no-change', 'display-realname', 'display-realname-color', 'display-username', 'display-username-color', 'display-username-realname', 'display-username-realname-color'].includes(value.userDisplay)) result.userDisplay = value.userDisplay;
    for (const [key, min, max] of [['helperDelay', 100, 5000], ['helperPageLimit', 1, 1000], ['helperRequestLimit', 10, 10000], ['autoAttendInterval', 10, 86400]]) {
      if (value[key] === undefined) continue;
      if (!Number.isInteger(value[key]) || value[key] < min || value[key] > max) throw new Error(`${key} 必须是 ${min}–${max} 的整数`);
      result[key] = value[key];
    }
    for (const key of ['autoAttendTargets', 'autoAttendTitle', 'autoAttendRules', 'juanDomains']) {
      if (typeof value[key] === 'string') result[key] = value[key].trim().slice(0, 4000);
    }
    if (result.autoAttend) {
      if (!result.autoAttendTargets) throw new Error('启用自动报名时必须填写目标');
      for (const line of result.autoAttendTargets.split(/[\s,]+/).filter(Boolean)) {
        const [domain, kind, extra] = line.split('/'); domainList(domain);
        if (extra || !['contest', 'homework'].includes(kind)) throw new Error('报名目标格式应为 域ID/contest 或 域ID/homework');
      }
    }
    if ([0.25, 1, 3, 7, 30, 90, 365].includes(+value.juanPeriod)) result.juanPeriod = +value.juanPeriod;
    for (const key of Object.keys(OPTIONS)) {
      if (typeof value.options?.[key] === 'boolean') result.options[key] = value.options[key];
    }
    // 旧版本只有一个开关；升级和导入旧备份时保留两个入口原有的状态。
    if (typeof value.options?.cph === 'boolean' && value.options.editor === undefined) result.options.editor = value.options.cph;
    for (const key of ['cphPort', 'editorPort']) {
      if (value[key] === undefined) continue;
      if (!Number.isInteger(value[key]) || value[key] < 1 || value[key] > 65535) {
        throw new Error('端口必须是 1–65535 的整数');
      }
      result[key] = value[key];
    }
    return result;
  }
  let settings;
  try { settings = normalizeSettings(stored(SETTINGS_KEY, DEFAULTS)); }
  catch { settings = clone(DEFAULTS); }
  function enabled(key) { return settings.ui && settings.options[key]; }
  function ui() { return page.UiContext || {}; }
  function user() { return page.UserContext || {}; }
  function pageName() { return document.documentElement.dataset.page || ''; }
  function domainId() { return ui().domain?._id || location.pathname.match(/^\/d\/([^/]+)/)?.[1] || 'system'; }
  function translate(text) {
    try { return page.Hydro?.utils?.i18n?.(text) || text; } catch { return text; }
  }
  function el(tag, attrs = {}, text) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
    if (text !== undefined) node.textContent = String(text);
    return node;
  }
  function button(text, action, attrs = {}) {
    return el('button', { type: 'button', class: 'button exhloj-local-button', 'data-exh-action': action, ...attrs }, text);
  }
  function notify(message, error = false) {
    console[error ? 'warn' : 'info']('[Extend HLOJ]', message);
    let box = $('#exhloj-local-toast');
    if (!box) { box = el('div', { id: 'exhloj-local-toast', role: 'status', 'aria-live': 'polite' }); document.body.append(box); }
    box.textContent = message;
    box.dataset.error = String(error);
    box.hidden = false;
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => { box.hidden = true; }, 4500);
  }
  async function task(work) {
    try { return await work(); } catch (error) { notify(error.message || String(error), true); }
  }

  // 每个事件的最近一次广播可被后注册的模块接收；无监听器时也可安全广播。
  const listeners = new Map(), lastEvents = new Map(), models = new Map();
  function broadcast(name, value) {
    lastEvents.set(name, value);
    for (const fn of listeners.get(name) || []) Promise.resolve().then(() => fn(value)).catch(console.error);
  }
  function on(name, fn) {
    if (!listeners.has(name)) listeners.set(name, new Set());
    listeners.get(name).add(fn);
    if (lastEvents.has(name)) Promise.resolve().then(() => fn(lastEvents.get(name))).catch(console.error);
    return () => listeners.get(name)?.delete(fn);
  }
  const core = Object.freeze({ version: VERSION, getDomainId: domainId, pageName,
    getUserId: () => user()._id || 0, broadcast, on,
    inject(name, value) { if (!models.has(name)) models.set(name, []); models.get(name).push(value); },
    getModel: name => [...(models.get(name) || [])],
    getTimeByObjectId: id => /^[\da-f]{24}$/i.test(String(id)) ? new Date(parseInt(id.slice(0, 8), 16) * 1000) : null,
  });

  const baseStyle = el('style', { id: 'exhloj-local-style' });
  // Hydro moves the sticky heading and its cloned colgroup into a second table.
  const rankingTable = ':is([data-fragment-id="ranking"] table.data-table,.main table.data-table:has(>colgroup>col.col--rp)):not(.col--bio *)';
  const rankingCells = `:is(${rankingTable}>colgroup,${rankingTable}>:is(thead,tbody)>tr)>`;
  baseStyle.textContent = `
    #exhloj-local-toast{position:fixed;bottom:25px;left:50%;transform:translateX(-50%);z-index:2147483647;
      background:#234537;color:white;padding:12px 20px;border-radius:8px;max-width:90vw;box-shadow:0 4px 20px #0003}
    #exhloj-local-toast[data-error="true"]{background:#842d2d}
    #exhloj-local-dialog{color:#263445;background:#fff;border:1px solid #c7d0d9;border-radius:12px;
      width:min(840px,92vw);max-height:85vh;padding:0;box-shadow:0 10px 50px #0004;box-sizing:border-box;
      font:14px/1.6 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei","Noto Sans CJK SC",sans-serif}
    #exhloj-local-dialog[open]{display:flex;flex-direction:column}
    #exhloj-local-dialog::backdrop{background:#0006}
    #exhloj-local-dialog header{display:flex;align-items:center;justify-content:space-between;padding:16px 22px;flex-shrink:0;gap:12px}
    #exhloj-local-dialog h2{margin:0;font-size:21px}#exhloj-local-dialog h3{margin:20px 0 10px}
    #exhloj-local-dialog .exhloj-dialog-body{padding:12px 22px 22px;overflow:auto;min-height:0;font-size:14px;line-height:1.7}
    .exhloj-panel-brand{font-size:12px;color:#66788a;margin-bottom:3px}
    .exhloj-panel-nav{display:flex;flex-wrap:wrap;gap:4px;padding:0 18px 12px;border-bottom:1px solid #e3e9ef;flex-shrink:0}
    #exhloj-local-dialog .exhloj-panel-tab{border:0;border-radius:7px;padding:7px 12px;background:transparent;color:#52667a;cursor:pointer;font:inherit}
    #exhloj-local-dialog .exhloj-panel-tab[aria-current=page]{background:#eaf2fb;color:#185b94;font-weight:700}
    #exhloj-local-dialog .exhloj-panel-tab:hover{background:#f0f5fa}
    .exhloj-panel-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:16px 0}
    #exhloj-local-dialog .exhloj-panel-card{border:1px solid #dce5ee;border-radius:10px;padding:18px;background:#fff;color:#263445;text-align:left;font:inherit;cursor:pointer;min-width:0}
    #exhloj-local-dialog .exhloj-panel-card:hover{border-color:#6c9ec9;background:#f6faff}
    #exhloj-local-dialog .exhloj-panel-card strong{display:block;font-size:16px;margin-bottom:5px}
    #exhloj-local-dialog .exhloj-panel-card span{display:block;color:#66788a;font-size:13px;line-height:1.7}
    #exhloj-local-dialog .exhloj-panel-card:disabled{opacity:.55;cursor:default}
    .exhloj-panel-summary{padding:12px 15px;background:#f4f7fa;border-radius:8px;color:#52667a}
    .exhloj-panel-footer{font-size:12px;color:#66788a;display:flex;gap:16px;flex-wrap:wrap;margin-top:20px}
    @media(max-width:520px){#exhloj-local-dialog header{padding:14px 16px}#exhloj-local-dialog .exhloj-dialog-body{padding:10px 16px 18px}.exhloj-panel-grid{grid-template-columns:1fr;gap:9px}.exhloj-panel-nav{padding:0 12px 9px}#exhloj-local-dialog .exhloj-panel-tab{padding:6px 10px}}
    #exhloj-local-dialog label{display:block;margin:9px 0}#exhloj-local-dialog input[type=checkbox]{margin-right:9px}
    [data-exh-menu-hidden]{display:none!important}
    html.exhloj-ranking-left ${rankingCells}.col--user{width:clamp(7rem,17vw,11rem)!important}
    html.exhloj-ranking-left ${rankingCells}:is(.col--rp,.col--detail,.col--ac,.col--bio){text-align:left!important}
    html.exhloj-ranking-no-bio ${rankingCells}.col--bio{display:none!important}
    html.exhloj-ranking-left.exhloj-ranking-no-bio ${rankingCells}.col--ac{width:auto!important}
    @media(max-width:600px){html.exhloj-ranking-left ${rankingCells}.col--ac{width:auto!important}}
    #exhloj-profile-entry{display:inline-flex;align-items:center;vertical-align:middle;box-sizing:border-box;width:auto;min-height:28px;margin:2px 4px;padding:2px 10px;border:1px solid #cbd8e2;border-radius:5px;background:#eff5f8;color:#284e69;font:inherit;font-size:13px;line-height:1.4;white-space:nowrap;cursor:pointer}
    .profile-header #exhloj-profile-entry{background:#263a5266;color:white;border-color:#ffffff9c}
    #exhloj-profile-entry:focus-visible{outline:2px solid currentColor;outline-offset:2px}
    #exhloj-profile-view details{margin:10px 0}#exhloj-profile-view summary{font-weight:600}
    #exhloj-menu-options{margin:12px 0;padding:8px 12px 12px;border:1px solid #ccd7df;border-radius:6px;min-width:0}
    #exhloj-menu-options .exhloj-menu-options-row{display:flex;flex-wrap:wrap;gap:0 16px}
    #exhloj-menu-options label{margin:3px 0}
    #exhloj-menu-options p{margin:2px 0 8px;font-size:13px}
    #exhloj-local-dialog textarea{box-sizing:border-box;width:100%;height:150px;font:12px/1.6 monospace;color:#263445;background:#f7f9fb}
    #exhloj-local-dialog input[type=number]{width:90px;color:#263445;background:white;border:1px solid #aaa;padding:3px}
    #exhloj-local-dialog summary{cursor:pointer}#exhloj-local-dialog pre{white-space:pre-wrap;overflow-wrap:anywhere}
    #exhloj-local-dialog table{border-collapse:collapse;width:100%}#exhloj-local-dialog td,#exhloj-local-dialog th{padding:6px;text-align:left;border-bottom:1px solid #ddd}
    .exhloj-local-button{cursor:pointer;margin:4px 8px 4px 0;padding:6px 12px}
    #exhloj-local-dialog .exhloj-local-button{border:1px solid #cbd6e1;border-radius:6px;background:#f5f8fb;color:#263445;font:inherit}
    #exhloj-local-dialog .exhloj-local-button:hover{border-color:#6c9ec9;background:#edf4fb}
    #exhloj-local-dialog .exhloj-local-button:disabled{opacity:.5;cursor:default}
    .exhloj-title-host{display:flex;align-items:center;gap:.45rem;flex-wrap:wrap}
    .exhloj-title-host>.section__title,.exhloj-title-host>h1,.exhloj-title-host>h2{flex:1 1 8rem;min-width:0;overflow-wrap:anywhere}
    .exhloj-title-host>.section__tools{position:static;inset:auto;transform:none;margin:0;max-width:100%;min-width:0}
    @media(max-width:640px){.exhloj-title-host>:is(.section__title,h1,h2){flex-basis:0}.exhloj-title-host>.section__tools{order:1;flex:1 1 100%}}
    #exhloj-title-toggle{flex:none;align-self:center;margin-inline-start:auto;padding:3px 9px;min-height:28px;white-space:nowrap;font:inherit;font-size:13px;line-height:1.4;color:#245b82;background:#eef4f8;border:1px solid #d8e2e8;border-radius:4px;cursor:pointer}
    #exhloj-title-toggle:after{content:'▾';margin-inline-start:5px}
    #exhloj-title-toggle[aria-expanded=true]:after{content:'▴'}
    #exhloj-title-toggle.exhloj-title-fallback{float:right;margin:0 0 0 6px}
    #exhloj-title-popup{position:fixed;z-index:99999;box-sizing:border-box;width:max-content;min-width:min(170px,calc(100vw - 16px));max-width:min(285px,calc(100vw - 16px));overflow:auto;overscroll-behavior:contain;margin:0;padding:4px;background:#fff;color:#263445;border:1px solid #d8e2e8;border-radius:6px;box-shadow:0 5px 16px #162a4129;font-size:14px;line-height:1.5}
    #exhloj-title-popup button{display:block;box-sizing:border-box;width:100%;margin:0;padding:6px 10px;text-align:start;background:transparent;color:inherit;line-height:inherit;font:inherit;border:0;border-radius:3px;cursor:pointer}
    #exhloj-title-popup button:is(:hover,:focus-visible){background:#edf4f9;color:#185b94}
    #exhloj-title-popup [role=separator]{margin:4px 5px;border-top:1px solid #dce4ea}
    #exhloj-title-popup .exhloj-remote-status{padding:4px 10px}
    /* Hydro's .problem__tags has font-size:0; restore the native tag size for the entire source group. */
    #exhloj-local-remote{display:inline-flex;align-self:flex-start;gap:4px;align-items:center;flex-wrap:wrap;vertical-align:middle;max-width:100%;list-style:none;font-size:14px;line-height:1.4}
    .problem__tags>#exhloj-local-remote{margin-inline-start:3px}
    #exhloj-local-remote:empty{display:none}
    #exhloj-local-remote :is(a,button,.exhloj-remote-chip){display:inline-flex;align-items:center;box-sizing:border-box;min-height:30px;max-width:100%;margin:0;padding:0 10px;border:0;border-radius:4px;background:#eff4f8;color:#245173;font:inherit;overflow-wrap:anywhere;text-decoration:none}
    #exhloj-local-remote :is(a,button):hover{text-decoration:underline;cursor:pointer}
    #exhloj-local-settings [hidden]{display:none!important}
    @media(pointer:coarse){#exhloj-title-toggle,#exhloj-title-popup button{min-height:40px}}
    @media(prefers-color-scheme:dark){#exhloj-title-popup{background:#252e37;color:#e3ebf1;border-color:#4a5866}#exhloj-title-popup button:is(:hover,:focus-visible){background:#354454;color:#e3ebf1}}
    .exhloj-local-medal{font-size:1.25em;vertical-align:middle}
    .exhloj-local-earliest{background-color:rgb(217,240,199)!important}
    [data-exh-files-in-helper]{display:none!important}
    #exhloj-contest-files{margin:10px 0 14px}
    #exhloj-contest-files h3{margin:0 0 4px}
    #exhloj-contest-files ul{list-style:none;margin:0;padding:0;max-height:15rem;overflow:auto}
    #exhloj-contest-files li{display:flex;align-items:baseline;gap:12px;max-width:100%;padding:4px 0;border-bottom:1px solid #dce5ee}
    #exhloj-contest-files a{min-width:0;overflow-wrap:anywhere}
    #exhloj-contest-files small{margin-inline-start:auto;white-space:nowrap;font-variant-numeric:tabular-nums}
    html.exhloj-local-rounded .section{border-radius:8px!important}
    html.exhloj-local-rounded .section__table-header{border-radius:8px 8px 0 0}
    html.exhloj-local-rounded .contest-sidebar__bg,html.exhloj-local-rounded .profile-header.user-profile-bg{border-radius:8px}
    html.exhloj-local-rounded :is(.search>button,.search>input,.widget--category-filter__tag,button.button,input.textbox,ol.menu.dropdown-target,select.select){border-radius:5px}
    html.exhloj-local-rounded div.dialog__content{border-radius:10px}
    html.exhloj-local-ui :is(.page--contest_scoreboard,.page--homework_scoreboard) .col--user{min-width:15rem}
    html.exhloj-local-ui .contest-type--codeforces .contest-type-tag{background:#ffa646}
    .exhloj-captcha-tools{font-size:13px;line-height:1.7;margin:6px 0}
    [data-exhloj-captcha-folded]{display:none!important}
    .exhloj-remote-tools{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:10px 0}
    .exhloj-remote-tools a,.exhloj-remote-chip{display:inline-block;padding:4px 9px;border-radius:5px;background:#f0f4f8;color:#245173}
    .exhloj-remote-status{font-size:12px;opacity:.8;flex-basis:100%;overflow-wrap:anywhere}
    .exhloj-search-options{display:flex;flex-wrap:wrap;gap:0 20px}
    .exhloj-search-note{color:#66788a;font-size:13px;overflow-wrap:anywhere}
    .exhloj-search-candidate{border:1px solid #dce5ee;border-radius:8px;padding:12px 14px;margin:10px 0;overflow-wrap:anywhere}
    .exhloj-search-candidate p{margin:4px 0}.exhloj-search-candidate a{color:#185b94}
    .exhloj-search-candidate details{margin-top:8px}.exhloj-search-candidate pre{max-height:180px;overflow:auto;font:inherit}
    .exhloj-search-status{white-space:pre-wrap;overflow-wrap:anywhere}
    #exhloj-local-dialog #exhloj-search-query{height:140px;font:inherit;padding:10px;border:1px solid #b5bfca;border-radius:7px}
    .exhloj-remote-article{margin:12px 0;padding:16px;border:1px solid #d8e0e8;border-radius:8px;overflow-wrap:anywhere}
    .exhloj-remote-article pre{overflow:auto;white-space:pre}.exhloj-remote-article img{max-width:100%}
    .exhloj-work-progress{padding:8px 12px;background:#eef5fb;border-radius:6px;white-space:pre-wrap;overflow-wrap:anywhere}
    .exhloj-work-results{overflow:auto;max-height:45vh}.exhloj-work-results table{min-width:500px}
    #exhloj-homework-plan-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,11rem),1fr));gap:8px 12px;align-items:end;margin:12px 0}
    #exhloj-local-dialog #exhloj-homework-plan-form label{margin:0}
    #exhloj-homework-plan-form input{display:block;width:100%;min-width:0;box-sizing:border-box;padding:5px 8px;font:inherit;color:inherit;background:white;border:1px solid #b5bfca;border-radius:5px}
    #exhloj-homework-plan-scan{grid-column:1}
    #exhloj-homework-plan-results th,#exhloj-homework-plan-results td{text-align:left;vertical-align:top;padding:5px 8px}
    #exhloj-homework-plan-results td:nth-child(2){font-variant-numeric:tabular-nums}
    .exhloj-oier-option{padding:8px 0;border-bottom:1px solid #ddd}.exhloj-oier-option p{margin:3px 0}
    .exhloj-work-errors{color:#9a3939;white-space:pre-wrap;max-height:150px;overflow:auto}
    #exhloj-local-dialog .exhloj-remote-article textarea{height:180px}
    #exhloj-local-dialog input[type=text],#exhloj-local-dialog select{box-sizing:border-box;max-width:100%;padding:5px 8px;border:1px solid #b5bfca;background:#fff;color:#263445}
    #exhloj-local-dialog .exhloj-source-input{width:100%}
    .exhloj-user-name,.exhloj-user-rating{font-weight:700}
    .exhloj-user-level-1{color:grey!important}.exhloj-user-level-2{color:green!important}.exhloj-user-level-3{color:#03a89e!important}
    .exhloj-user-level-4{color:#00f!important}.exhloj-user-level-5{color:#a0a!important}.exhloj-user-level-6{color:#ff8c00!important}
    :is(.exhloj-user-level-7,.exhloj-user-level-8,.exhloj-user-level-9,.exhloj-user-level-10){color:red!important}.exhloj-user-level-teacher{color:#000!important}
    .exhloj-user-ccf{display:inline-flex;width:1em;height:1em;margin-inline-start:.25em;vertical-align:-.125em;line-height:1;white-space:nowrap}
    .exhloj-user-ccf>svg{display:block;width:100%;height:100%;fill:currentColor}
    .exhloj-user-ccf-green{color:#5eb95e}.exhloj-user-ccf-blue{color:#3498db}.exhloj-user-ccf-gold{color:#f1c40f}
    .exhloj-user-gain{color:green}.exhloj-user-loss{color:#c33}.exhloj-user-data{display:grid;grid-template-columns:auto 1fr;gap:4px 12px}
    .exhloj-user-data dt,.exhloj-user-data dd{margin:0;overflow-wrap:anywhere}
    [data-exh-user-column]{text-align:center;white-space:nowrap}#exhloj-user-commands,#exhloj-user-json{height:230px!important}
  `;
  document.head.append(baseStyle);

  const PANEL_SECTIONS = [['home', '首页'], ['contest', '比赛'], ['juan', '卷王'], ['user', '用户'], ['ranking', '排名页'], ['remote', '题源'], ['settings', '设置'], ['data', '数据']];
  let panelSection = 'home';
  function modal(title, section = panelSection) {
    $('#exhloj-local-dialog')?.close();
    $('#exhloj-local-dialog')?.remove();
    panelSection = section;
    const dialog = el('dialog', { id: 'exhloj-local-dialog', 'aria-label': `Extend HLOJ · ${title}`, 'data-panel-section': section });
    const header = el('header');
    const close = button('关闭', 'close');
    const heading = el('div'); heading.append(el('div', { class: 'exhloj-panel-brand' }, `Extend HLOJ ${VERSION}`), el('h2', {}, title)); header.append(heading, close);
    const nav = el('nav', { class: 'exhloj-panel-nav', 'aria-label': '功能导航' });
    for (const [id, label] of PANEL_SECTIONS) nav.append(el('button', { type: 'button', class: 'exhloj-panel-tab', 'data-exh-action': 'panel-tab', 'data-panel-tab': id, ...(id === section ? { 'aria-current': 'page' } : {}) }, label));
    const body = el('div', { class: 'exhloj-dialog-body' });
    dialog.append(header, nav, body); document.body.append(dialog);
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    dialog.showModal();
    return body;
  }
  function openPanelSection(section) {
    if (!PANEL_SECTIONS.some(row => row[0] === section)) return;
    const module = { contest: 'contestHelper', juan: 'juanMonitor', user: 'userModule', ranking: 'ui', remote: 'remote' }[section];
    if (module && !settings[module]) {
      const body = modal(PANEL_SECTIONS.find(row => row[0] === section)[1], section);
      body.append(el('p', {}, '此功能已关闭，可在设置中开启。'), button('打开设置', 'panel-settings')); return;
    }
    const open = { home: openHome, contest: openContestHelper, juan: openJuanMonitor, user: openUserTools, ranking: openRankingOptions, remote: openRemoteTools, settings: openSettings, data: openDataTools }[section];
    if (open) open();
  }
  function syncRankingLayout() {
    const here = /^(?:\/d\/[^/]+)?\/ranking\/?$/.test(location.pathname) && (!pageName() || pageName() === 'ranking');
    const classes = document.documentElement.classList;
    classes.toggle('exhloj-ranking-left', here && enabled('rankingAlignLeft'));
    classes.toggle('exhloj-ranking-no-bio', here && enabled('rankingHideBio'));
  }
  function openRankingOptions() {
    const body = modal('排名页', 'ranking'), group = el('fieldset', { id: 'exhloj-ranking-options' });
    group.append(el('legend', {}, '域排名表'));
    for (const [key, [title]] of Object.entries(RANKING_OPTIONS)) {
      const label = el('label'), input = el('input', { type: 'checkbox', name: key });
      input.checked = settings.options[key]; label.append(input, title); group.append(label);
      input.addEventListener('change', () => task(() => {
        const next = { ...settings, options: { ...settings.options, [key]: input.checked } };
        try { save(SETTINGS_KEY, next); } catch (error) { input.checked = settings.options[key]; throw error; }
        settings = next; syncRankingLayout();
      }));
    }
    body.append(group, el('p', {}, '左对齐会把 RP、题目、比赛和通过数排在用户名旁边。修改立即生效。'));
  }
  function openHome() {
    const body = modal('控制面板', 'home'), store = userStore();
    body.append(el('p', { class: 'exhloj-panel-summary' }, `当前域：${domainId()} · ${+user()._id > 0 ? '已登录' : '游客'}　　${Object.keys(store.users.oiers).length} 份本地资料 · ${store.ratings.contests.length} 场 Rated 比赛`));
    const cards = el('div', { class: 'exhloj-panel-grid' });
    for (const [title, description, action, module] of [
      [pageName().startsWith('homework') ? '作业助手' : '比赛助手', '查看附件、导出题面与提交记录，管理报名。', 'contest-helper', 'contestHelper'],
      ['卷王监视器', '汇总练习成绩，查看近期进度。', 'juan-open', 'juanMonitor'],
      ['用户与 Rating', '管理个人资料、OIerDb 绑定和比赛 Rating。', 'user-open', 'userModule'],
      ['题源与难度', '查看原题、洛谷难度、翻译和题解。', 'panel-remote', 'remote'],
      ['设置', '调整界面、验证码和自动报名。', 'panel-settings', ''],
      ['数据与备份', '导出备份，恢复设置和本地资料。', 'panel-data', ''],
    ]) {
      const disabled = module && !settings[module], card = el('button', { type: 'button', class: 'exhloj-panel-card', 'data-exh-action': action, ...(disabled ? { disabled: '' } : {}) });
      card.append(el('strong', {}, title), el('span', {}, disabled ? '已关闭，可在设置中开启。' : description)); cards.append(card);
    }
    body.append(cards);
    if (userLoadError) body.append(el('p', { class: 'exhloj-work-errors' }, `本地用户数据需要检查：${userLoadError}`));
    const footer = el('div', { class: 'exhloj-panel-footer' });
    for (const [label, url] of [['使用说明', 'https://github.com/sxmqwq/new-exhloj#readme'], ['更新记录', 'https://github.com/sxmqwq/new-exhloj/releases/latest']]) footer.append(el('a', { href: url, target: '_blank', rel: 'noopener noreferrer' }, label));
    body.append(footer);
  }
  function openRemoteTools() {
    const body = modal('题源与难度', 'remote');
    body.append(button('按题意搜索原题', 'remote-search'), el('p', { class: 'exhloj-search-note' }, '输入题面或简述，在原题机和 CPRet 中查找候选，核对后再关联。'));
    const label = el('label', {}, '洛谷题号或链接'); label.append(el('input', { id: 'exhloj-luogu-id', class: 'exhloj-source-input', type: 'text', placeholder: '例如 P10873', 'aria-label': '洛谷题号' }));
    body.append(label, button('打开洛谷工具', 'luogu-tool'));
    if (current('pdoc')) body.append(el('h3', {}, '当前题目'), button('配置当前题源', 'remote-config'));
    body.append(el('p', {}, '在题目页也可直接读取难度、查看原题和题解。'));
  }
  function download(name, content, type = 'application/json') {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const link = el('a', { href: url, download: name });
    document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function validateCache(value) {
    if (!isObject(value)) throw new Error('缓存必须是 JSON 对象');
    const safe = {};
    for (const key of LEGACY_KEYS) if (Object.hasOwn(value, key)) safe[key] = value[key];
    return safe;
  }
  function exportData() {
    return { format: 'exhloj', schemaVersion: 1, version: VERSION,
      exportedAt: new Date().toISOString(), settings, cache: validateCache(stored(CACHE_KEY, {})) };
  }
  function importData(text) {
    if (new Blob([text]).size > LIMIT) throw new Error('导入文件超过 2 MiB');
    const data = JSON.parse(text);
    if (!isObject(data)) throw new Error('无效的 JSON 对象');
    let nextSettings = settings, cache;
    if (['exhloj', 'exhloj-core-ui'].includes(data.format)) {
      if (data.schemaVersion !== 1) throw new Error('不支持的备份版本');
      nextSettings = normalizeSettings(data.settings);
      cache = validateCache(data.cache);
    } else {
      cache = validateCache(data);
      if (Object.keys(cache).length === 0) throw new Error('没有找到可导入的旧版缓存字段');
    }
    if (data.settings?.userDisplay === undefined && typeof cache['model.user.display-name'] === 'string') nextSettings = normalizeSettings({ ...nextSettings, userDisplay: cache['model.user.display-name'] });
    if (data.settings?.userCCF === undefined && typeof cache['model.user.display-ccflevel'] === 'boolean') nextSettings = normalizeSettings({ ...nextSettings, userCCF: cache['model.user.display-ccflevel'] });
    // 先完整校验，再写入；模块仅使用已恢复的本地字段。
    const merged = { ...validateCache(stored(CACHE_KEY, {})), ...cache };
    const oldSettings = settings, oldCache = stored(CACHE_KEY, {});
    try { save(CACHE_KEY, merged); save(SETTINGS_KEY, nextSettings); }
    catch (error) { try { save(CACHE_KEY, oldCache); save(SETTINGS_KEY, oldSettings); } catch {} throw error; }
    settings = nextSettings;
    refresh();
  }
  function openSettings(focus = '') {
    const body = modal('设置', 'settings');
    body.append(el('h3', {}, '界面与功能'));
    const form = el('form', { id: 'exhloj-local-settings' });
    const moduleLabel = el('label');
    const moduleInput = el('input', { type: 'checkbox', name: 'ui' }); moduleInput.checked = settings.ui;
    moduleLabel.append(moduleInput, '界面增强'); form.append(moduleLabel);
    for (const [key, [text]] of Object.entries(OPTIONS)) {
      if (key === 'cph' || key === 'editor' || Object.hasOwn(MENU_OPTIONS, key) || Object.hasOwn(RANKING_OPTIONS, key)) continue;
      const label = el('label'), input = el('input', { type: 'checkbox', name: key });
      input.checked = settings.options[key]; label.append(input, text); form.append(label);
    }
    const menus = el('fieldset', { id: 'exhloj-menu-options' }); menus.append(el('legend', {}, '菜单精简'));
    for (const [name, keys] of [['题目侧栏', ['hideEmptyDiscussion', 'hideEmptySolution']], ['作业与比赛侧栏', ['showUnknownHomeworkSimilarity', 'showUnknownSimilarity']],
      ['顶部导航', ['hideNavProblems', 'hideNavTraining', 'hideNavDiscussion', 'hideNavRecords']], ['用户主页', ['profileInfoEntry']]]) {
      const row = el('div', { class: 'exhloj-menu-options-row' });
      for (const key of keys) {
        const label = el('label'), input = el('input', { type: 'checkbox', name: key });
        input.checked = settings.options[key]; label.append(input, MENU_OPTIONS[key][0]); row.append(label);
      }
      menus.append(el('strong', {}, name), row);
      if (name === '作业与比赛侧栏') menus.append(el('p', {}, '明确有权限时显示，明确无权限时隐藏。两个开关只影响权限未知的入口。'));
    }
    form.append(menus);
    const editors = el('fieldset', { id: 'exhloj-editor-options' }); editors.append(el('legend', {}, '发送到编辑器'));
    for (const key of ['cph', 'editor']) {
      const portKey = key + 'Port', toggle = el('input', { type: 'checkbox', name: key }), label = el('label');
      const port = el('input', { type: 'number', min: 1, max: 65535, name: portKey, value: settings[portKey], required: true });
      const portLabel = el('label', {}, (key === 'cph' ? 'CPH' : 'CP Editor') + ' 端口 '); portLabel.append(port);
      toggle.checked = settings.options[key]; label.append(toggle, OPTIONS[key][0]); editors.append(label, portLabel);
      const reveal = () => { portLabel.hidden = port.disabled = !toggle.checked; }; reveal(); toggle.addEventListener('change', reveal);
    }
    form.append(editors);
    for (const [key, text] of [['captcha', '验证码识别'], ['captchaHide', '识别成功后折叠验证码'],
      ['captchaRemember', '识别成功后勾选“记住我”'], ['remote', '题源与题解'],
      ['remoteAuto', '自动读取已识别题目的难度（缓存 24 小时）'],
      ['contestHelper', '比赛助手'], ['homeworkPlanner', '作业补题计划'], ['juanMonitor', '卷王监视器'], ['userModule', '用户资料与 Rating']]) {
      const label = el('label'), input = el('input', { type: 'checkbox', name: key });
      input.checked = settings[key]; label.append(input, text); form.append(label);
    }
    for (const [key, text, choices] of [
      ['remoteContest', '比赛页面题源', [['hide', '隐藏'], ['shortcut', '按 Ctrl+Q 显示'], ['show', '显示']]],
      ['remoteColor', '难度颜色', [['text', '文字颜色'], ['background', '背景颜色'], ['none', '不着色']]]]) {
      const label = el('label', {}, text + ' '), select = el('select', { name: key });
      for (const [value, title] of choices) select.append(el('option', { value }, title));
      select.value = settings[key]; label.append(select); form.append(label);
    }
    const advanced = el('details', { id: 'exhloj-attend-options' }); advanced.open = focus === 'attendance';
    advanced.append(el('summary', {}, '自动报名与请求参数'));
    for (const [key, title, min, max] of [['helperDelay', '请求间隔（毫秒）', 100, 5000], ['helperPageLimit', '每类列表最多页数', 1, 1000], ['helperRequestLimit', '单次任务最多请求数', 10, 10000], ['autoAttendInterval', '自动报名检查间隔（秒）', 10, 86400]]) {
      const label = el('label', {}, title + ' '); label.append(el('input', { type: 'number', name: key, value: settings[key], min, max, required: true })); advanced.append(label);
    }
    for (const [key, title] of [['autoAttend', '启用自动报名（只处理下方明确配置的目标）']]) {
      const label = el('label'), input = el('input', { type: 'checkbox', name: key }); input.checked = settings[key]; label.append(input, title); advanced.append(label);
    }
    for (const [key, title, placeholder] of [['autoAttendTargets', '报名目标，每行 域ID/contest 或 域ID/homework', 'system/contest'], ['autoAttendTitle', '标题必须包含（留空不限）', ''], ['autoAttendRules', '允许的赛制，逗号分隔（留空不限）', 'oi,acm']]) {
      const label = el('label', {}, title); const input = el('input', { type: 'text', class: 'exhloj-source-input', name: key, value: settings[key], placeholder });
      if (key === 'autoAttendTargets') { const field = el('textarea', { name: key, placeholder }); field.value = settings[key]; label.append(field); } else label.append(input);
      advanced.append(label);
    }
    advanced.append(el('p', {}, '保存后保持 OJ 登录，并开着一个 OJ 页面，自动报名才会运行。'));
    form.append(advanced, button('保存设置', 'save-settings'), button('刷新页面', 'reload'));
    body.append(form, button('验证码识别记录', 'captcha-history'));
    if (focus === 'attendance') advanced.scrollIntoView({ block: 'start' });
    if (focus === 'editors') form.elements.cph.focus();
  }
  function openDataTools() {
    const body = modal('数据与备份', 'data');
    body.append(el('h3', {}, '备份'), el('p', {}, '备份包括设置、题源配置、用户资料和 Rating。数据保存在当前浏览器中。'), button('导出完整备份', 'export'));
    if (settings.userModule) body.append(button('仅导出用户与 Rating', 'user-export'));
    body.append(el('h3', {}, '恢复'), el('p', {}, '选择备份文件或粘贴 JSON 后导入。支持本版及兼容的旧版 JSON 备份。'));
    body.append(el('input', { type: 'file', accept: '.json,application/json', id: 'exhloj-local-import-file', 'aria-label': '选择 JSON 备份' }));
    body.append(el('textarea', { id: 'exhloj-local-import', placeholder: '在此粘贴 JSON 备份', 'aria-label': '导入 JSON' }));
    body.append(button('导入备份', 'import'), button('查看备份内容', 'view-cache'));
    const details = el('details'); details.append(el('summary', {}, '兼容与故障信息'), button('读取同一脚本的旧缓存', 'legacy'));
    details.append(el('pre', {}, JSON.stringify({ version: VERSION, page: pageName(), domain: domainId(),
      hasUiContext: !!page.UiContext, hasHydro: !!page.Hydro, lastPageError }, null, 2)));
    body.append(details);
  }

  async function copyText(text) {
    if (typeof text !== 'string' || !text.length) throw new Error('未找到可复制的原始 Markdown');
    try { await navigator.clipboard.writeText(text); }
    catch {
      const area = el('textarea', { readonly: '', style: 'position:fixed;left:-10000px;top:0' }); area.value = text;
      document.body.append(area); area.select();
      const ok = document.execCommand('copy'); area.remove();
      if (!ok) {
        const body = modal('复制 Markdown');
        const field = el('textarea', { 'aria-label': 'Markdown 原文' }); field.value = text; body.append(field);
        field.focus(); field.select();
        notify('浏览器拒绝自动复制，请按 Ctrl+C'); return;
      }
    }
    notify('已复制 Markdown');
  }
  function markdownContent(content) {
    if (typeof content !== 'string') {
      if (isObject(content)) return content.zh || content['zh-CN'] || Object.values(content).find(v => typeof v === 'string') || '';
      return '';
    }
    try { const parsed = JSON.parse(content); if (isObject(parsed)) return markdownContent(parsed); } catch {}
    return content;
  }

  let route = location.href, routeOwner = String(user()._id || 0), routeName = pageName(), routeDomain = domainId();
  let routeEpoch = 0, contextBody = {}, pageRequest, lastPageError = '';
  function current(name) { syncPageContext(); return contextBody[name] ?? ui()[name]; }
  async function requestJSON(path = location.href, options = {}) {
    const url = new URL(path, location.href);
    if (url.origin !== location.origin) throw new Error('只允许请求当前 OJ');
    const abort = new AbortController(), timer = setTimeout(() => abort.abort(), 12000);
    const cancel = () => abort.abort();
    if (options.signal?.aborted) cancel();
    options.signal?.addEventListener('abort', cancel, { once: true });
    try {
      const response = await fetch(url.href, { ...options, credentials: 'same-origin', redirect: 'error', cache: 'no-store',
        signal: abort.signal, headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...options.headers } });
      if (response.status === 401) throw new Error('OJ 接口返回 HTTP 401；请在原站确认登录状态后重试');
      if (response.status === 403) throw new Error('OJ 接口返回 HTTP 403；请确认当前账号的页面访问权限');
      if (!response.ok) throw new Error(`OJ 接口返回 HTTP ${response.status}`);
      const body = await response.json();
      if (!isObject(body) || body.error) throw new Error(body.error?.message || 'OJ 返回了无效页面数据');
      return body;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error(options.signal?.aborted ? '任务已取消' : 'OJ 接口请求超时');
      if (error instanceof SyntaxError) throw new Error('OJ 没有返回 JSON；请检查登录状态或站点版本');
      throw error;
    } finally { clearTimeout(timer); options.signal?.removeEventListener('abort', cancel); }
  }
  async function loadPage() {
    // 点击可能早于 120 ms 的 DOM 刷新；先同步上下文，避免复用上一页面或账号的请求。
    syncPageContext();
    if (!pageRequest) {
      const epoch = routeEpoch, address = route, owner = routeOwner, name = routeName;
      const stillCurrent = () => epoch === routeEpoch && address === location.href &&
        owner === String(user()._id || 0) && name === pageName();
      const request = requestJSON(address).then(body => {
        if (!stillCurrent()) throw new Error('页面或账号已切换，请在新页面重试');
        contextBody = body; lastPageError = ''; return body;
      }).catch(error => {
        if (stillCurrent()) lastPageError = error.message;
        // 只释放自己的失败请求；用户可再次点击，不增加后台重试或清理站点会话。
        if (pageRequest === request) pageRequest = undefined;
        throw error;
      });
      pageRequest = request;
    }
    return pageRequest;
  }

  function installMenu() {
    const menu = $('#menu-nav-user');
    if (menu && !$('.exhloj-local-menu', menu)) {
      const li = el('li', { class: 'menu__item exhloj-local-menu' });
      const link = el('a', { class: 'menu__link', href: '#exhloj-settings', 'data-exh-action': 'settings' }, '⚙ Extend HLOJ');
      li.append(link);
      const anchor = $$('li', menu).find(item => $('a', item)?.getAttribute('href')?.replace(/\/$/, '').endsWith('/file'));
      if (anchor) anchor.after(li); else menu.append(li);
      broadcast('menu.open');
    }
    if (enabled('cleanMenu') && menu) {
      for (const link of $$('a[href]', menu)) {
        if ((link.getAttribute('href') || '').includes('Error: No route found for name:')) link.closest('li')?.remove();
      }
    }
    // 清除旧版分散插入的工具项，用户菜单只保留一个插件入口。
    for (const item of $$('[data-exh-work-menu]', menu || document)) item.remove();
  }
  const mainNav = 'nav.nav .nav__list--main, #menu .nav__list--main';
  const sideMenus = '.section--problem-sidebar, .section--contest-sidebar, .section--homework-sidebar, .medium-3.columns, .section.side';
  const navSections = [
    ['hideNavProblems', /^\/(?:p|problem|problems)$/, /^(?:题库|題庫|problems?|problem set)$/i],
    ['hideNavTraining', /^\/(?:training|trainings)$/, /^(?:训练|訓練|training|trainings)$/i],
    ['hideNavDiscussion', /^\/(?:discuss|discussion|discussions)$/, /^(?:讨论|討論|discussions?)$/i],
    ['hideNavRecords', /^\/(?:record|records|submissions)$/, /^(?:评测记录|评测纪录|評測記錄|評測紀錄|records?|submissions?|judge records?)$/i],
  ];
  const menuText = node => (node?.textContent || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  function menuPath(link) {
    const href = link.getAttribute('href'); if (!href || href.startsWith('#')) return null;
    try {
      const url = new URL(href, location.href);
      return url.origin === location.origin ? url.pathname.replace(/^\/d\/[^/]+(?=\/|$)/, '').replace(/\/+$/, '') : null;
    } catch { return null; }
  }
  function zeroMenuKey(link, row) {
    const match = /^(讨论|討論|discussions?|题解|題解|solutions?)(?:\s*\(\s*(\d+)\s*\)|\s*(\d+))?$/i.exec(menuText(link));
    if (!match || !/^0+$/.test(match[2] ?? match[3] ?? link.dataset.count ?? row.dataset.count ?? '')) return '';
    return /^(讨论|討論|discussions?)$/i.test(match[1]) ? 'hideEmptyDiscussion' : 'hideEmptySolution';
  }
  function currentSimilarityActivity() {
    const name = pageName(), path = location.pathname.replace(/^\/d\/[^/]+(?=\/|$)/, '');
    const route = path.match(/^\/(?:discuss\/)?(homework|contest)\/([^/]+)/);
    if (route) return { kind: route[1], id: route[2] };
    if (/^\/(?:homework|contest)\/?$/.test(path) || /^(?:homework|contest)_main$/.test(name)) return null;
    const pageKind = name.match(/^(homework|contest)_/)?.[1];
    const doc = ui().tdoc, docId = String(doc?.docId || doc?._id || '');
    const tid = new URLSearchParams(location.search).get('tid'), id = tid || docId;
    if (!pageKind && !(isProblemPage(name) && tid && tid === docId && doc?.rule === 'homework')) return null;
    const kind = docId === id && doc?.rule === 'homework' ? 'homework' : pageKind;
    return id ? { kind, id } : null;
  }
  function isSimilarityEntry(link, activity) {
    if (/^(?:(?:代码|代碼|程式碼)\s*(?:相似度|查重)(?:查询|查詢|检查|檢查|检测|檢測)?|(?:code\s+)?(?:similarity|plagiarism)(?:\s+(?:query|check(?:er)?|report))?)(?:$|\s*[(（])/i.test(menuText(link))) return true;
    const path = menuPath(link) || '', route = path.match(/^\/(homework|contest)\/([^/]+)\/(?:hydroac-sim|sim|moss|plagiarism|(?:code[-_])?similarity)$/i);
    // Homework can use the shared contest similarity route on Hydro.
    return !!route && route[2] === activity.id && (route[1] === activity.kind || activity.kind === 'homework' && route[1] === 'contest');
  }
  function similarityAccess(link, row, activity) {
    let granted = false;
    for (const node of new Set([link, row])) {
      if (node.matches(':disabled,.disabled,[aria-disabled="true"]') ||
          /无权限|没有权限|没有查看权限|权限不足|無權限|權限不足|permission denied|access denied|no permission/i.test([node.title, node.getAttribute('aria-label'), menuText(link)].join(' '))) return false;
      for (const value of [node.dataset.canViewSimilarity, node.dataset.canAccess, node.dataset.permissionStatus]) {
        if (value === 'false' || value === 'denied') return false;
        if (value === 'true' || value === 'allowed') granted = true;
      }
    }
    // Only use explicit permissions for the viewer and the current activity; an active link alone does not grant access.
    const context = ui(), doc = context.tdoc, viewer = context.viewerId ?? context.tsdoc?.uid;
    if (viewer != null && String(viewer) === String(user()._id) && String(doc?.docId || doc?._id || '') === activity.id &&
        (!doc?.domainId || doc.domainId === domainId()) && (!doc?.rule || (doc.rule === 'homework') === (activity.kind === 'homework'))) {
      for (const value of [context.canViewSimilarity, context.canViewCodeSimilarity, context.permissions?.canViewSimilarity]) {
        if (value === false) return false;
        if (value === true) granted = true;
      }
    }
    return granted ? true : null;
  }
  function syncMenuVisibility() {
    const hidden = new Set(), touchedMenus = new Set(), marker = 'data-exh-menu-hidden';
    if (settings.ui) {
      for (const nav of $$(mainNav)) for (const link of $$(':scope > li > a, :scope > a.nav__item', nav)) {
        const path = menuPath(link); if (path == null) continue;
        const label = menuText(link);
        const match = navSections.find(([, , names]) => names.test(label)) ||
          (!link.search && !link.hash && navSections.find(([, route]) => route.test(path)));
        if (match && enabled(match[0])) hidden.add(link.parentElement === nav ? link : link.parentElement);
      }
      const activity = currentSimilarityActivity(), problem = isProblemPage() || /^problem_(?:submit|solution|statistics|files)$/.test(pageName());
      for (const link of $$(':is(' + sideMenus + ') :is(a.menu__link,button.menu__link,.menu__item > a,.menu__item > button)')) {
        if (link.closest('.typo,.markdown-body,#exhloj-local-dialog')) continue;
        const row = link.parentElement.matches('li,.menu__item') ? link.parentElement : link;
        let hide = false;
        if ((problem || link.closest('.section--problem-sidebar')) && !/^\/discuss\/(?:contest|homework)\//.test(menuPath(link) || '')) {
          const key = zeroMenuKey(link, row); hide = !!key && enabled(key);
        }
        if (activity && isSimilarityEntry(link, activity)) {
          const access = similarityAccess(link, row, activity);
          hide = access === false || (access === null && !enabled(activity.kind === 'homework' ? 'showUnknownHomeworkSimilarity' : 'showUnknownSimilarity'));
        }
        if (hide) {
          const target = row !== link && $$('a,button', row).length !== 1 ? link : row;
          hidden.add(target);
          if (target.parentElement.matches('ol.menu,ul.menu')) touchedMenus.add(target.parentElement);
        }
      }
      for (const menu of touchedMenus) {
        let hasItem = false, pending = null;
        for (const item of menu.children) {
          if (item.matches('.menu__seperator,.menu__separator')) {
            if (!hasItem || pending) hidden.add(item); else pending = item;
          } else if (!hidden.has(item) && !item.hidden) { hasItem = true; pending = null; }
        }
        if (pending) hidden.add(pending);
      }
    }
    for (const node of $$('[data-exh-menu-hidden]')) if (!hidden.has(node)) node.removeAttribute(marker);
    for (const node of hidden) if (!node.hasAttribute(marker)) node.setAttribute(marker, '');
  }
  function niceSize(value) {
    const size = Number(value);
    if (value == null || value === '' || !Number.isFinite(size) || size < 0) return '—';
    if (size < 1024) return `${size} B`;
    const n = Math.min(3, Math.floor(Math.log(size) / Math.log(1024)));
    return `${(size / 1024 ** n).toFixed(1)} ${['B', 'KiB', 'MiB', 'GiB'][n]}`;
  }
  let homeworkStarted = false, recordStarted = false, solutionStarted = false;
  function mainColumn() { return $('.main .medium-9.columns, .medium-9.columns, main, .main'); }
  function profileEntryTarget() {
    const primary = $('.main > .row > .medium-9.columns') || $('main, .main');
    if (!primary) return null;
    const header = $('.profile-header', primary);
    return (header && ($('.profile-header__contact-bar', header) || $('.profile-header__main', header) || header)) || primary;
  }
  async function homework() {
    if (homeworkStarted || !mainColumn()) return;
    homeworkStarted = true;
    const epoch = routeEpoch;
    try {
      let tdoc = current('tdoc');
      if (!tdoc?.title) { await loadPage(); tdoc = current('tdoc'); }
      if (epoch !== routeEpoch || !enabled('homework') || !tdoc) return;
      const heading = $('.medium-9.columns > .section:first-child .section__header h1, .medium-9.columns h1, main h1');
      const title = `${translate('Homework Introduction')} - ${tdoc.title || ''}`;
      if (heading && heading.textContent !== title) heading.textContent = title;
      broadcast('homework_detail.prepare', tdoc);
    } catch (error) { if (epoch === routeEpoch) notify(`作业增强：${error.message}`, true); }
  }
  function scoreboard() {
    for (const rank of $$('td.col--rank')) {
      const text = rank.textContent.trim();
      if (/^[123]$/.test(text)) {
        const medal = el('span', { class: 'exhloj-local-medal', title: `第 ${text} 名`, 'aria-label': `第 ${text} 名` }, ['', '🥇', '🥈', '🥉'][+text]);
        rank.replaceChildren(medal);
      }
    }
    const title = $('h2.text-center');
    if (title && !$('a', title) && /\/scoreboard\/?$/.test(location.pathname)) {
      const link = el('a', { href: location.pathname.replace(/\/scoreboard\/?$/, '') }, title.textContent);
      title.replaceChildren(link);
    }
    if (pageName() !== 'homework_scoreboard') return;
    for (const table of $$('.section__table-container > .data-table, table[data-exh-scoreboard]')) {
      const first = new Map(), winners = new Set();
      for (const row of $$('tbody > tr', table)) {
        [...row.children].forEach((cell, index) => {
          if (!cell.matches('td.col--problem')) return;
          const text = cell.textContent.trim();
          if (!text || text.split('\n')[0].includes('-')) return;
          const id = $('a[href*="/record/"]', cell)?.getAttribute('href')?.match(/\/record\/([\da-f]{24})(?:[/?#]|$)/i)?.[1];
          if (!id) return;
          const time = parseInt(id.slice(0, 8), 16);
          if (!first.has(index) || time < first.get(index).time) first.set(index, { time, cells: [cell] });
          else if (time === first.get(index).time) first.get(index).cells.push(cell);
        });
      }
      for (const { cells } of first.values()) for (const cell of cells) winners.add(cell);
      for (const cell of $$('td.col--problem', table)) {
        const wanted = winners.has(cell);
        if (cell.classList.contains('exhloj-local-earliest') !== wanted) cell.classList.toggle('exhloj-local-earliest', wanted);
        if (wanted && !$('.exhloj-local-earliest-label', cell)) {
          cell.dataset.exhEarliest = '1';
          cell.append(el('span', { class: 'exhloj-local-earliest-label', title: '本页可见记录中的最早提交（秒级，同秒并列）；不保证为 AC', 'aria-label': '本页最早提交' }, ' ◷'));
        } else if (!wanted && cell.dataset.exhEarliest) {
          delete cell.dataset.exhEarliest; $('.exhloj-local-earliest-label', cell)?.remove();
        }
      }
    }
  }

  const isProblemPage = (name = pageName()) => name === 'problem_detail' || name.endsWith('detail_problem');
  const hiddenContestSource = () => pageName() === 'contest_detail_problem' &&
    (settings.remoteContest === 'hide' || (settings.remoteContest === 'shortcut' && !contestRevealed));
  function titleLocation() {
    const column = $('.main .medium-9.columns') || $('.main .medium-12.columns') || $('.medium-9.columns') || $('main') || $('.main');
    if (!column) return {};
    const tags = isProblemPage() && $('.problem__tags', column);
    const section = tags && tags.closest('.section');
    const header = (section && $('.section__header', section)) || $$('.section__header', column).find(node =>
      !node.closest('[data-exh-files-in-helper],#exhloj-local-remote-content') && $('h1,h2,.section__title', node));
    const heading = !header && $$('h1,h2,.section__title', column).find(node => !node.closest('.typo,#exhloj-local-remote-content'));
    return { column, tags, header, heading };
  }
  function remoteActions(state) {
    const items = [], origin = state?.origin;
    if (origin?.luoguId || origin?.type === 'codeforces') items.push(['读取 / 刷新难度', 'remote-meta']);
    if (origin?.luoguId) items.push([state.showStatement ? '收起题面 / 翻译' : '题面 / 翻译', 'remote-statement'],
      [state.showSolutions ? '收起洛谷题解' : '查看洛谷题解', 'remote-solutions'], ['导出已加载内容', 'remote-export']);
    return items;
  }
  function titleModel() {
    const groups = [], name = pageName(); let label, note = '', view = '';
    if (isProblemPage(name)) {
      label = '题目工具';
      const local = [['markdown', '复制题面 Markdown', 'problem-copy'], ['cph', '发送到 CPH', 'cph'], ['editor', '发送到 CP Editor', 'editor']];
      groups.push(local.filter(([key]) => enabled(key)).map(([, ...item]) => item));
      if (settings.remote && !hiddenContestSource() && remoteState) {
        view = remoteState.id;
        groups.push([...remoteActions(remoteState), ['按题意搜索原题', 'remote-search'], ['配置题源', 'remote-config']]);
        note = remoteState.origin?.type === 'none' ? '已停用此题的自动题源识别' : remoteState.messages.join('；');
      } else if (settings.remote && hiddenContestSource() && settings.remoteContest === 'shortcut') note = '按 Ctrl+Q 显示比赛题源';
      if (settings.ui && groups.some(group => group.length)) groups.push([['编辑器设置', 'editor-settings']]);
    } else if (['contest_main', 'contest_detail', 'contest_scoreboard', 'homework_main', 'homework_detail', 'homework_scoreboard'].includes(name)) {
      label = name.startsWith('homework') ? '作业工具' : '比赛工具';
      if (name === 'homework_main' && settings.homeworkPlanner) groups.push([['补题计划', 'homework-plan-open']]);
      if (settings.userModule && name.startsWith('contest')) {
        const rating = [], target = contestContext();
        if (name !== 'contest_main' && ratedContestPath(target.domain + '/' + target.id, false)) rating.push(['加入 Rating 并结算', 'user-rate-current']);
        groups.push([...rating, ['时间轴结算', 'user-timeline'], ['Rating 记录与命令', 'user-rated']]);
      }
      if (settings.contestHelper && !name.endsWith('_main')) groups.push([[name.startsWith('homework') ? '作业助手' : '比赛助手', 'contest-helper']]);
    }
    return { label, groups: groups.filter(group => group.length), note, view };
  }
  let titleTrigger, titlePopup, titleHost, titleSignature;
  function closeTitleMenu(restore = false) {
    if (!titlePopup) return;
    titlePopup.remove(); titlePopup = undefined; titleSignature = '';
    titleTrigger?.setAttribute('aria-expanded', 'false'); titleTrigger?.removeAttribute('aria-controls');
    if (restore) titleTrigger?.focus({ preventScroll: true });
  }
  function removeTitleTools() {
    closeTitleMenu(); titleTrigger?.remove(); titleTrigger = undefined;
    titleHost?.classList.remove('exhloj-title-host'); titleHost = undefined;
  }
  function positionTitleMenu() {
    if (!titlePopup) return;
    const a = titleTrigger.getBoundingClientRect(), w = document.documentElement.clientWidth, h = window.innerHeight, pad = 6;
    if (!titleTrigger.isConnected || a.bottom < 0 || a.top > h) { closeTitleMenu(); return; }
    const below = h - a.bottom - pad * 2, above = a.top - pad * 2;
    const flip = below < titlePopup.scrollHeight + 2 && above > below;
    titlePopup.style.maxHeight = Math.max(40, flip ? above : below) + 'px';
    titlePopup.style.left = Math.max(pad, Math.min(w - titlePopup.offsetWidth - pad, a.right - titlePopup.offsetWidth)) + 'px';
    titlePopup.style.top = Math.max(pad, flip ? a.top - pad - titlePopup.offsetHeight : a.bottom + pad) + 'px';
  }
  function paintTitleMenu(model) {
    if (!titlePopup) return;
    const signature = JSON.stringify(model);
    if (signature !== titleSignature) {
      const focus = titlePopup.contains(document.activeElement) && document.activeElement.dataset.exhAction;
      const fragment = document.createDocumentFragment();
      model.groups.forEach((group, index) => {
        if (index) fragment.append(el('div', { role: 'separator' }));
        for (const [text, action] of group) fragment.append(el('button', { type: 'button', role: 'menuitem', tabindex: '-1',
          'data-exh-action': action, ...(model.view && action.startsWith('remote-') ? { 'data-remote-view': model.view } : {}) }, text));
      });
      if (model.note) fragment.append(el('div', { class: 'exhloj-remote-status', role: 'status' }, model.note));
      titlePopup.replaceChildren(fragment); titleSignature = signature;
      if (focus) ($$('button', titlePopup).find(node => node.dataset.exhAction === focus) || $('button', titlePopup))?.focus({ preventScroll: true });
    }
    positionTitleMenu();
  }
  function showTitleMenu(last = false) {
    syncPageContext(); syncTitleTools();
    if (!titleTrigger?.isConnected) return;
    if (!titlePopup) {
      titlePopup = el('div', { id: 'exhloj-title-popup', role: 'menu', 'aria-labelledby': 'exhloj-title-toggle' });
      document.body.append(titlePopup); titleTrigger.setAttribute('aria-controls', titlePopup.id); titleTrigger.setAttribute('aria-expanded', 'true');
    }
    paintTitleMenu(titleModel());
    if (titlePopup) $$('button', titlePopup).at(last ? -1 : 0)?.focus({ preventScroll: true });
  }
  function syncTitleTools() {
    const model = titleModel();
    if (!model.groups.length) { removeTitleTools(); return; }
    const { column, header, heading } = titleLocation();
    if (!column) { removeTitleTools(); return; }
    if (!titleTrigger) {
      titleTrigger = el('button', { type: 'button', id: 'exhloj-title-toggle', 'aria-haspopup': 'menu', 'aria-expanded': 'false' });
      titleTrigger.addEventListener('click', () => titlePopup ? closeTitleMenu(true) : showTitleMenu());
    }
    if (titleTrigger.textContent !== model.label) titleTrigger.textContent = model.label;
    if (titleHost !== header) { titleHost?.classList.remove('exhloj-title-host'); titleHost = header; }
    titleTrigger.classList.toggle('exhloj-title-fallback', !header);
    if (header) {
      header.classList.add('exhloj-title-host');
      if (titleTrigger.parentNode !== header) header.append(titleTrigger);
    } else if (!titleTrigger.isConnected || titleTrigger.parentNode !== (heading?.parentNode || column)) {
      if (heading) heading.before(titleTrigger); else column.prepend(titleTrigger);
    }
    paintTitleMenu(model);
  }
  document.addEventListener('pointerdown', event => {
    if (titlePopup && !titlePopup.contains(event.target) && !titleTrigger.contains(event.target)) closeTitleMenu();
  }, true);
  document.addEventListener('focusin', event => {
    if (titlePopup && !titlePopup.contains(event.target) && event.target !== titleTrigger) closeTitleMenu();
  });
  document.addEventListener('keydown', event => {
    if (event.target === titleTrigger && ['ArrowDown', 'ArrowUp'].includes(event.key)) {
      event.preventDefault(); showTitleMenu(event.key === 'ArrowUp'); return;
    }
    if (!titlePopup) return;
    if (event.key === 'Escape') { event.preventDefault(); closeTitleMenu(true); return; }
    if (!titlePopup.contains(event.target)) return;
    if (event.key === 'Tab') { closeTitleMenu(true); return; }
    const nodes = $$('button', titlePopup), index = nodes.indexOf(document.activeElement);
    const next = { ArrowDown: (index + 1) % nodes.length, ArrowUp: (index + nodes.length - 1) % nodes.length, Home: 0, End: nodes.length - 1 }[event.key];
    if (next !== undefined) { event.preventDefault(); nodes[next]?.focus({ preventScroll: true }); }
  });
  window.addEventListener('resize', positionTitleMenu);
  document.addEventListener('scroll', event => { if (titlePopup && event.target !== titlePopup) positionTitleMenu(); }, true);
  async function problemDocument(needConfig = false) {
    if (!current('pdoc')?.content || (needConfig && !current('pdoc')?.config)) await loadPage();
    const pdoc = current('pdoc');
    if (!pdoc) throw new Error('页面未提供题目资料');
    return pdoc;
  }
  function samples() {
    const result = [];
    for (const input of $$('code[class*="language-input"]')) {
      const suffix = [...input.classList].find(c => /^language-input\d*$/.test(c))?.replace('language-input', '');
      if (suffix === undefined) continue;
      const output = $(`code.language-output${suffix}`);
      if (output) result.push({ input: input.textContent, output: output.textContent });
    }
    if (!result.length) {
      const inputs = $$('.sample .input pre, .sample-input pre');
      const outputs = $$('.sample .output pre, .sample-output pre');
      inputs.forEach((input, i) => { if (outputs[i]) result.push({ input: input.textContent, output: outputs[i].textContent }); });
    }
    return result;
  }
  async function cphPayload() {
    const pdoc = await problemDocument(true), config = isObject(pdoc.config) ? pdoc.config : {};
    const tdoc = current('tdoc');
    const oj = location.hostname === 'oj.hailiangedu.com' ? 'HLOJ' : location.hostname.includes('nfls') ? 'NFLSOJ' : 'OIFHA';
    const subType = typeof config.subType === 'string' ? config.subType : '';
    const fileBase = /^[\w.-]+$/.test(subType) ? subType : '';
    const problemId = pdoc._id || pdoc.docId || pdoc.pid || location.pathname;
    return { name: pdoc.title || document.title, group: oj + (tdoc?.title ? ` - ${tdoc.title}` : ''),
      url: location.href, interactive: config.type === 'interactive',
      memoryLimit: Number(config.memoryMax ?? config.memoryLimit) || 256,
      timeLimit: Number(config.timeMax ?? config.timeLimit) || 1000,
      tests: samples(), testType: 'single', input: fileBase ? { type: 'file', fileName: `${fileBase}.in` } : { type: 'stdin' },
      output: fileBase ? { type: 'file', fileName: `${fileBase}.out` } : { type: 'stdout' }, languages: {},
      // 每次点击只发送一道题，所以接收端的批次大小也必须是 1。
      batch: { id: `${oj}/${domainId()}/${problemId}/${Date.now()}`, size: 1 } };
  }
  function sendLocal(port, payload) {
    return new Promise((resolve, reject) => {
      let finished = false;
      const fail = message => { if (!finished) { finished = true; reject(new Error(message)); } };
      const timer = setTimeout(() => fail(`本机 ${port} 端口连接超时`), 6000);
      const done = fn => value => { if (finished) return; clearTimeout(timer); fn(value); };
      try {
        GM_xmlhttpRequest({ method: 'POST', url: `http://localhost:${port}/`, timeout: 5000,
          headers: { 'Content-Type': 'application/json' }, data: JSON.stringify(payload),
          onload: done(response => { if ([200, 201, 202, 204].includes(response.status)) { finished = true; resolve(); }
            else fail(`本机接收端返回 HTTP ${response.status}`); }),
          onerror: done(() => fail(`无法连接 localhost:${port}，请先启动对应扩展并允许本机连接`)),
          ontimeout: done(() => fail(`本机 ${port} 端口连接超时`)), onabort: done(() => fail('本机请求已取消')) });
      } catch (error) { clearTimeout(timer); fail(error.message); }
    });
  }

  async function solutionTools() {
    if (solutionStarted) return;
    const entries = $$('ul.dczcomments__list.view--solution > li.dczcomments__item > div.media, .solution-section .media');
    if (!entries.length) return;
    solutionStarted = true;
    // 原文在点击时才读取，初次打开题解页不额外抓取内容。
    for (const entry of entries) {
      if (!$('.typo.richmedia', entry) || $('[data-exh-action="solution-copy"]', entry)) continue;
      const raw = $('[data-raw-url]', entry)?.getAttribute('data-raw-url') || '';
      const id = entry.closest('[data-doc-id]')?.getAttribute('data-doc-id') || raw.replace(/\/raw\/?$/, '').split('/').pop() || '';
      const tool = button('复制 Markdown', 'solution-copy', { 'data-solution-id': id });
      ($('.media__left.top', entry) || entry).append(tool);
    }
    solutionStarted = false;
  }
  async function copySolution(control) {
    const id = control.dataset.solutionId;
    let docs = current('psdocs');
    if (!Array.isArray(docs)) { await loadPage(); docs = current('psdocs'); }
    const doc = docs?.find(item => String(item._id ?? item.docId) === id);
    if (!doc || typeof doc.content !== 'string') throw new Error('没有找到这篇题解的 Markdown（可能没有查看权限）');
    await copyText(doc.content);
  }

  function avatarTools() {
    if ($('#exhloj-local-avatar')) return;
    const target = $('.main .medium-10.columns > .section:first-child, .main .section, main');
    if (!target) return;
    const section = el('div', { id: 'exhloj-local-avatar', class: 'section__body typo' });
    section.append(el('h3', {}, '链接头像'), el('p', {}, '填入图片的 HTTP(S) 链接，或“我的文件”中的 /file/... 路径。点击保存后更新 OJ 头像。'));
    const label = el('label', {}, '图片链接');
    label.append(el('input', { class: 'textbox', type: 'text', name: 'exhloj-local-avatar-url', placeholder: `/file/${user()._id || ''}/avatar.png` }));
    section.append(label, button('保存头像', 'avatar-save')); target.append(section);
  }
  async function saveAvatar() {
    const input = $('[name="exhloj-local-avatar-url"]');
    const value = input?.value.trim();
    if (!value) throw new Error('请填写头像链接');
    const url = new URL(value, location.origin);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('头像必须是普通 HTTP(S) 链接');
    const payload = { avatar: `url:${url.href}` };
    const csrf = $('input[name="_csrf"]')?.value || $('meta[name="csrf-token"]')?.content;
    if (csrf) payload._csrf = csrf;
    const body = await requestJSON('/home/avatar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!body.url) throw new Error('服务器未确认头像更新，请检查链接或站点兼容性');
    notify('头像已更新，刷新页面查看');
  }

  // captcha: 原 1.16.1 的 137 个字形特征；只识别本机页面已有的 SVG。
  const CAPTCHA_GLYPHS = {"986":["I","l"],"998":["1"],"1068":["I","l"],"1081":["1"],"1082":["v"],"1130":["Y"],"1134":["Y"],"1172":["v"],"1224":["Y"],"1274":["L","y"],"1298":["V"],"1311":["V"],"1360":["i"],"1380":["L","y"],"1406":["V"],"1473":["i"],"1478":["T"],"1491":["r"],"1598":["N","X"],"1601":["T"],"1604":["X"],"1610":["J","x"],"1613":["x"],"1614":["N"],"1615":["r","N"],"1616":["N"],"1617":["N"],"1618":["N"],"1634":["k"],"1637":["k"],"1694":["z","t"],"1706":["K"],"1709":["K"],"1731":["X","N"],"1744":["x","J"],"1754":["F"],"1770":["k"],"1835":["z","t"],"1838":["u"],"1840":["A"],"1844":["A"],"1848":["K"],"1850":["Z"],"1853":["Z"],"1886":["h"],"1900":["F"],"1922":["H"],"1928":["H"],"1960":["P"],"1991":["u"],"1993":["A"],"1996":["D"],"2004":["Z"],"2018":["w"],"2035":["w"],"2042":["7"],"2043":["h"],"2080":["j"],"2082":["H"],"2104":["R"],"2107":["R"],"2123":["P"],"2140":["4"],"2162":["D"],"2164":["O"],"2183":["w"],"2198":["n","C"],"2199":["C"],"2200":["C"],"2201":["C"],"2202":["C"],"2210":["f"],"2212":["7"],"2246":["E"],"2253":["j"],"2260":["o"],"2272":["d"],"2279":["R","M"],"2282":["M"],"2294":["U"],"2301":["U"],"2310":["W"],"2318":["4","W"],"2321":["M"],"2332":["a"],"2344":["O"],"2345":["W"],"2346":["W"],"2366":["s"],"2380":["b"],"2381":["n","C"],"2382":["0"],"2394":["f"],"2433":["E"],"2448":["o"],"2461":["d"],"2464":["p"],"2466":["M"],"2485":["U"],"2498":["c"],"2501":["e"],"2503":["W"],"2512":["q"],"2526":["a"],"2546":["2"],"2563":["s"],"2578":["b"],"2580":["0"],"2606":["5"],"2632":["6"],"2669":["p"],"2706":["c"],"2709":["e"],"2721":["q"],"2758":["2"],"2800":["9"],"2823":["5"],"2851":["6"],"3033":["9"],"3038":["S"],"3054":["B"],"3160":["g"],"3244":["Q"],"3254":["Q"],"3266":["G"],"3291":["S"],"3308":["B"],"3414":["8"],"3423":["g"],"3514":["Q"],"3538":["G"],"3663":["m"],"3667":["m"],"3698":["8"],"3878":["3"],"3968":["m"],"4201":["3"]};
  const CAPTCHA_RULES = {
    986: ['minY', 13, 'I', 'l'], 1068: ['minY', 13, 'I', 'l'],
    1274: ['moveY', 30, 'y', 'L'], 1380: ['moveY', 30, 'y', 'L'],
    1610: ['minY', 19, 'x', 'J'], 1744: ['minY', 19, 'x', 'J'],
    1615: ['minY', 18, 'r', 'N'], 2198: ['minY', 19, 'n', 'C'],
    2381: ['minY', 19, 'n', 'C'], 2318: ['width', 30, 'W', '4'],
    1598: ['minY', 13, 'X', 'N'], 1731: ['minY', 13, 'X', 'N'],
    1694: ['minY', 22, 'z', 't'], 1835: ['minY', 22, 'z', 't'],
    2279: ['minY', 13, 'R', 'M'],
  };
  function recognizeCaptcha(svg) {
    if (typeof svg !== 'string' || svg.length > 150000) return { answer: '', lengths: [] };
    const doc = new DOMParser().parseFromString(svg, 'image/svg+xml');
    if (doc.querySelector('parsererror')) return { answer: '', lengths: [] };
    const paths = [...doc.querySelectorAll('path[d]')].map(p => p.getAttribute('d')).filter(d => d.length > 450);
    paths.sort((a, b) => Number(a.match(/[\d.]+/)?.[0]) - Number(b.match(/[\d.]+/)?.[0]));
    const letters = paths.map(d => {
      const rule = CAPTCHA_RULES[d.length];
      if (!rule) return CAPTCHA_GLYPHS[d.length]?.length === 1 ? CAPTCHA_GLYPHS[d.length][0] : '';
      const nums = (d.match(/\d+(?:\.\d*)?/g) || []).map(Number);
      const xs = nums.filter((_, i) => i % 2 === 0), ys = nums.filter((_, i) => i % 2 === 1);
      const value = rule[0] === 'minY' ? Math.min(...ys) : rule[0] === 'width' ? Math.max(...xs) - Math.min(...xs) :
        Number(d.match(/M(\d+(?:\.\d*)?)\s+(\d+(?:\.\d*)?)/)?.[2]);
      return Number.isFinite(value) ? value > rule[1] ? rule[2] : rule[3] : '';
    });
    return { answer: paths.length >= 3 && paths.length <= 8 && letters.every(Boolean) ? letters.join('') : '', lengths: paths.map(d => d.length) };
  }
  const captchaStates = new WeakMap();
  function captchaGroup(input) {
    const form = input.closest('form');
    const controls = 'input:not([type="hidden"]),textarea,select,button[type="submit"],button:not([type])';
    const safe = node => node !== form && node !== document.body &&
      !(node !== input && node.matches(controls)) && !$$(controls, node).some(control => control !== input);
    let anchor = input;
    for (let node = input.parentElement; node && node !== form && node !== document.body; node = node.parentElement) {
      if (!safe(node)) break;
      if (node === input.parentElement || node.matches('.row,.form__item,.form-group,.field,.captcha,[data-captcha]')) anchor = node;
    }
    const dedicated = $$('.captcha,.captcha-container,.captcha-image,.captcha__image,[data-captcha]', form || anchor).filter(safe);
    // 选择完整且只含验证码控件的行；其他布局仅折叠输入组与明确标识的验证码图像。
    const nodes = [...new Set([anchor, ...dedicated])];
    return { anchor, targets: nodes.filter(node => !nodes.some(parent => parent !== node && parent.contains(node))) };
  }
  function captchaSVG(input) {
    const group = captchaGroup(input), scope = input.closest('form') || group.anchor;
    const localImages = $$('img[src^="data:image/svg+xml"]', group.anchor);
    const image = localImages[0] || $('img[src^="data:image/svg+xml"]', scope);
    if (image) {
      try {
        const src = image.getAttribute('src');
        return /;base64,/.test(src) ? atob(src.split(',')[1]) : decodeURIComponent(src.slice(src.indexOf(',') + 1));
      } catch {}
    }
    const inline = $('svg.captcha, .captcha svg, svg[data-captcha]', scope) ||
      $$('svg', group.anchor).find(svg => $$('path[d]', svg).filter(path => path.getAttribute('d').length > 450).length >= 3);
    return inline ? new XMLSerializer().serializeToString(inline) : typeof ui().captcha === 'string' ? ui().captcha : '';
  }
  function restoreCaptchaNode(node, original) {
    if (original.value) node.style.setProperty('display', original.value, original.priority);
    else node.style.removeProperty('display');
    node.removeAttribute('data-exhloj-captcha-folded');
    node.removeAttribute('data-exhloj-captcha-display');
  }
  function syncCaptchaTargets(state, group = captchaGroup(state.input)) {
    state.anchor = group.anchor;
    state.styles ||= new Map();
    for (const [node, original] of state.styles) {
      if (!group.targets.includes(node)) { restoreCaptchaNode(node, original); state.styles.delete(node); }
    }
    state.targets = group.targets;
    if (state.collapsed) {
      for (const node of state.targets) {
        if (!node.isConnected) continue;
        if (!state.styles.has(node)) {
          let original = { value: node.style.getPropertyValue('display'), priority: node.style.getPropertyPriority('display') };
          // 原站克隆验证码 DOM 时也可能复制我们的隐藏样式，保留快照才能正确展开。
          try {
            const snapshot = JSON.parse(node.getAttribute('data-exhloj-captcha-display') || 'null');
            if (node.hasAttribute('data-exhloj-captcha-folded') && typeof snapshot?.value === 'string' && ['', 'important'].includes(snapshot.priority)) original = snapshot;
          } catch {}
          state.styles.set(node, original);
          node.setAttribute('data-exhloj-captcha-display', JSON.stringify(original));
        }
        node.setAttribute('data-exhloj-captcha-folded', '');
        node.style.setProperty('display', 'none', 'important');
      }
    }
  }
  function captchaVisible(state, visible) {
    state.collapsed = !visible;
    if (visible) {
      for (const [node, original] of state.styles || []) restoreCaptchaNode(node, original);
      state.styles?.clear();
    } else syncCaptchaTargets(state);
    const toggle = $('[data-exh-action="captcha-toggle"]', state.tools);
    if (toggle) {
      toggle.textContent = visible ? '折叠验证码' : '展开验证码';
      toggle.setAttribute('aria-expanded', String(visible));
    }
  }
  function runCaptcha(force = false) {
    if (!settings.captcha) return;
    for (const input of $$('input[name="captcha"]')) {
      if (input.disabled) continue;
      const svg = captchaSVG(input);
      if (!svg) continue;
      const prior = captchaStates.get(input);
      if (!force && prior?.svg === svg) {
        syncCaptchaTargets(prior);
        if (prior.anchor.nextElementSibling !== prior.tools) prior.anchor.after(prior.tools);
        continue;
      }
      if (prior) { captchaVisible(prior, true); prior.tools.remove(); }
      const result = recognizeCaptcha(svg), tools = el('div', { class: 'exhloj-captcha-tools' });
      const group = captchaGroup(input);
      const state = { svg, tools, result, input, anchor: group.anchor, targets: group.targets, styles: new Map(), collapsed: false }; captchaStates.set(input, state);
      const previousAuto = prior?.filled && prior.result.answer === input.value;
      if (!result.answer && previousAuto) { input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true })); }
      const canFill = result.answer && (force || !input.value || previousAuto);
      state.filled = !!canFill;
      if (canFill) {
        input.value = result.answer;
        input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true }));
        if (settings.captchaRemember) {
          const remember = $('input[name="rememberme"]', input.closest('form') || document);
          if (remember && !remember.checked) { remember.checked = true; remember.dispatchEvent(new Event('change', { bubbles: true })); }
        }
        if (settings.captchaHide) captchaVisible(state, false);
      }
      tools.append(el('span', {}, canFill ? `验证码已填入 ${result.answer}。` : result.answer ? '保留你已输入的验证码。' : '此验证码未识别，请手动输入。'));
      if (result.answer) tools.append(button('折叠验证码', 'captcha-toggle'));
      tools.append(button('重新识别', 'captcha-retry'));
      state.anchor.after(tools);
      captchaVisible(state, !state.collapsed);
      const history = stored(CAPTCHA_KEY, []);
      save(CAPTCHA_KEY, [...(Array.isArray(history) ? history : []).slice(-49), { time: Date.now(), answer: result.answer, lengths: result.lengths }]);
    }
  }
  function showCaptchaHistory() {
    const body = modal('验证码识别记录', 'settings');
    body.append(el('p', {}, '最多保留 50 条本地识别记录，仅含识别结果与字形长度，不保存账号或密码。'));
    const records = stored(CAPTCHA_KEY, []);
    for (const item of (Array.isArray(records) ? records : []).slice().reverse()) {
      body.append(el('p', {}, `${new Date(item.time).toLocaleString()} · ${item.answer || '未识别'} · ${(item.lengths || []).join(', ')}`));
    }
    body.append(button('清空记录', 'captcha-clear'));
  }

  // remote-problem: 站内配置 / 本地映射 + 原站读取，不依赖共享插件服务器。
  var ExhlojMarkdown=(()=>{var ma=Object.defineProperty;var _l=Object.getOwnPropertyDescriptor;var Hl=Object.getOwnPropertyNames;var $l=Object.prototype.hasOwnProperty;var Ul=(r,e)=>{for(var t in e)ma(r,t,{get:e[t],enumerable:!0})},Gl=(r,e,t,a)=>{if(e&&typeof e=="object"||typeof e=="function")for(let n of Hl(e))!$l.call(r,n)&&n!==t&&ma(r,n,{get:()=>e[n],enumerable:!(a=_l(e,n))||a.enumerable});return r};var jl=r=>Gl(ma({},"__esModule",{value:!0}),r);var _4={};Ul(_4,{render:()=>F4});function ga(){return{async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null}}var K0=ga();function mi(r){K0=r}var X0={exec:()=>null};function dt(r){let e=[];return t=>{let a=Math.max(0,Math.min(3,t-1)),n=e[a];return n||(n=r(a),e[a]=n),n}}function Y(r,e=""){let t=typeof r=="string"?r:r.source,a={replace:(n,i)=>{let l=typeof i=="string"?i:i.source;return l=l.replace(Te.caret,"$1"),t=t.replace(n,l),a},getRegex:()=>new RegExp(t,e)};return a}var Wl=((r="")=>{try{return!!new RegExp("(?<=1)(?<!1)"+r)}catch{return!1}})(),Te={codeRemoveIndent:/^(?: {0,3}\t| {1,4})/gm,outputLinkReplace:/\\([\[\]])/g,indentCodeCompensation:/^(\s+)(?:```)/,beginningSpace:/^\s+/,endingHash:/#$/,startingSpaceChar:/^ /,endingSpaceChar:/ $/,endingSpaceTabChar:/[ \t]$/,nonSpaceChar:/[^ ]/,newLineCharGlobal:/\n/g,tabCharGlobal:/\t/g,leadingSpaceTab:/^[ \t]+/,multipleSpaceGlobal:/\s+/g,blankLine:/^[ \t]*$/,doubleBlankLine:/\n[ \t]*\n[ \t]*$/,blockquoteStart:/^ {0,3}>/,blockquoteSetextReplace:/\n {0,3}((?:=+|-+) *)(?=\n|$)/g,blockquoteSetextReplace2:/^ {0,3}>[ \t]?/gm,listReplaceNesting:/^ {1,4}(?=( {4})*[^ ])/g,listIsTask:/^\[[ xX]\] +\S/,listReplaceTask:/^\[[ xX]\] +/,listTaskCheckbox:/\[[ xX]\]/,anyLine:/\n.*\n/,hrefBrackets:/^<(.*)>$/,tableDelimiter:/[:|]/,tableAlignChars:/^\||\| *$/g,tableRowBlankLine:/\n[ \t]*$/,tableAlignRight:/^ *-+: *$/,tableAlignCenter:/^ *:-+: *$/,tableAlignLeft:/^ *:-+ *$/,startATag:/^<a /i,endATag:/^<\/a>/i,startPreScriptTag:/^<(pre|code|kbd|script)(\s|>)/i,endPreScriptTag:/^<\/(pre|code|kbd|script)(\s|>)/i,startAngleBracket:/^</,endAngleBracket:/>$/,pedanticHrefTitle:/^([^'"]*[^\s])\s+(['"])(.*)\2/,unicodeAlphaNumeric:/[\p{L}\p{N}]/u,numericCharacterReference:/&#(?:(\d{1,7})|[Xx]([A-Fa-f0-9]{1,6}));/,numericCharacterReferenceOrAmpersand:/&#(?:(\d{1,7})|[Xx]([A-Fa-f0-9]{1,6}));|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,escapeTest:/[&<>"']/,escapeReplace:/[&<>"']/g,escapeTestNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,escapeReplaceNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,caret:/(^|[^\[])\^/g,percentDecode:/%25/g,findPipe:/\|/g,splitPipe:/ \|/,slashPipe:/\\\|/g,carriageReturn:/\r\n|\r/g,spaceLine:/^ +$/gm,notSpaceStart:/^\S*/,endingNewline:/\n$/,listItemRegex:r=>new RegExp(`^( {0,3}${r})((?:[	 ][^\\n]*)?(?:\\n|$))`),nextBulletRegex:dt(r=>new RegExp(`^ {0,${r}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`)),hrRegex:dt(r=>new RegExp(`^ {0,${r}}((?:-[ 	]*){3,}|(?:_[ 	]*){3,}|(?:\\*[ 	]*){3,})(?:\\n+|$)`)),fencesBeginRegex:dt(r=>new RegExp(`^ {0,${r}}(?:\`\`\`|~~~)`)),headingBeginRegex:dt(r=>new RegExp(`^ {0,${r}}#`)),htmlBeginRegex:dt(r=>new RegExp(`^ {0,${r}}(?:</?(?:${Bt})(?: +|$|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)`,"i")),blockquoteBeginRegex:dt(r=>new RegExp(`^ {0,${r}}>`))},Vl=/^(?:[ \t]*(?:\n|$))+/,Yl=/^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/,Xl=/^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,Ot=/^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,Zl=/^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,ba=/ {0,3}(?:[*+-]|\d{1,9}[.)])/,di=/^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |fences|blockquote|heading|hr|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,pi=Y(di).replace(/bull/g,ba).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}(?:\s|$)/).replace(/hr/g,/ {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).replace(/\|table/g,"").getRegex(),Kl=Y(di).replace(/bull/g,ba).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}(?:\s|$)/).replace(/hr/g,/ {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).replace(/table/g,/ {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(),ya=/^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table|[ \t]+\n)[^\n]+)*)/,Ql=/^[^\n]+/,xa=/(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/,Jl=Y(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label",xa).replace("title",/(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(),e1=Y(/^(bull)([ \t][^\n]*?)?(?:\n|$)/).replace(/bull/g,ba).getRegex(),Bt="address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul",wa=/<!--(?:-?>|[\s\S]*?(?:-->|$))/,t1=Y("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n*|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>[^\\n]*\\n*|$)|<![A-Z][\\s\\S]*?(?:>[^\\n]*\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>[^\\n]*\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!(?:script|pre|style|textarea)(?![a-z0-9-]))([a-z][a-z0-9-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</[a-z][a-z0-9-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))","i").replace("comment",wa).replace("tag",Bt).replace("attribute",/ +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(),fi=r=>Y(ya).replace("hr",Ot).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("|table","").replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list",r).replace("html"," {0,3}(?:</?(?:tag)(?: +|\\n|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)").replace("tag",Bt).getRegex(),r1=fi(/ {0,3}(?:[*+-]|1[.)])[ \t]+[^ \t\n]/),a1=fi(/ {0,3}(?:[*+-]|\d{1,9}[.)])(?:[ \t]|\n|$)/),n1=Y(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph",a1).getRegex(),ka={blockquote:n1,code:Yl,def:Jl,fences:Xl,heading:Zl,hr:Ot,html:t1,lheading:pi,list:e1,newline:Vl,paragraph:r1,table:X0,text:Ql},ri=Y("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr",Ot).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("blockquote"," {0,3}>").replace("code","(?: {4}| {0,3}	)[^\\n]").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list"," {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html"," {0,3}(?:</?(?:tag)(?: +|\\n|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)").replace("tag",Bt).getRegex(),i1={...ka,lheading:Kl,table:ri,paragraph:Y(ya).replace("hr",Ot).replace("heading"," {0,3}#{1,6}(?:\\s|$)").replace("|lheading","").replace("table",ri).replace("blockquote"," {0,3}>").replace("fences"," {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace("list"," {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]").replace("html"," {0,3}(?:</?(?:tag)(?: +|\\n|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)").replace("tag",Bt).getRegex()},s1={...ka,html:Y(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment",wa).replace(/tag/g,"(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),def:/^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,heading:/^(#{1,6})(.*)(?:\n+|$)/,fences:X0,lheading:/^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,paragraph:Y(ya).replace("hr",Ot).replace("heading",` *#{1,6} *[^
]`).replace("lheading",pi).replace("|table","").replace("blockquote"," {0,3}>").replace("|fences","").replace("|list","").replace("|html","").replace("|tag","").getRegex()},l1=/^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,o1=/^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,vi=/^( {2,}|\\)\n(?!\s*$)[ \t]*/,u1=/^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,h0=/[\p{P}\p{S}]/u,pt=/[\s\p{P}\p{S}]/u,Nt=/[^\s\p{P}\p{S}]/u,c1=Y(/^((?![*_])punctSpace)/,"u").replace(/punctSpace/g,pt).getRegex(),h1=/[\p{Pi}\p{Ps}"']/u,gi=/(?!~)[\p{P}\p{S}]/u,m1=/(?!~)[\s\p{P}\p{S}]/u,d1=/(?:[^\s\p{P}\p{S}]|~)/u,p1=Y(/link|precode-code|html/,"g").replace("link",/\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-",Wl?"(?<!`)()":"(^^|[^`])").replace("code",/(?<b>`+)[^`]+\k<b>(?!`)/).replace("html",/<(?! )[^<>]*?>/).getRegex(),bi=/^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/,f1=Y(bi,"u").replace(/punct/g,h0).getRegex(),v1=Y(bi,"u").replace(/punct/g,gi).getRegex(),g1=/^(?:\*+(?:((?!\*)(?!openQuote)punct)|([^\s*]))?)|^_+(?:((?!_)(?!openQuote)punct)|([^\s_]))?/,b1=Y(g1,"u").replace(/openQuote/g,h1).replace(/punct/g,h0).getRegex(),yi="^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)",y1=Y(yi,"gu").replace(/notPunctSpace/g,Nt).replace(/punctSpace/g,pt).replace(/punct/g,h0).getRegex(),x1=Y(yi,"gu").replace(/notPunctSpace/g,d1).replace(/punctSpace/g,m1).replace(/punct/g,gi).getRegex(),w1="^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)[\\s](\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|(?:(?!\\*)punct|notPunctSpace)(\\*+)(?!\\*)(?=notPunctSpace)",k1=Y(w1,"gu").replace(/notPunctSpace/g,Nt).replace(/punctSpace/g,pt).replace(/punct/g,h0).getRegex(),S1=Y("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)","gu").replace(/notPunctSpace/g,Nt).replace(/punctSpace/g,pt).replace(/punct/g,h0).getRegex(),T1="^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)[\\s](_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)|(?:(?!_)punct|notPunctSpace)(_+)(?!_)(?=notPunctSpace)",A1=Y(T1,"gu").replace(/notPunctSpace/g,Nt).replace(/punctSpace/g,pt).replace(/punct/g,h0).getRegex(),z1=Y(/^~~?(?:((?!~)punct)|[^\s~])/,"u").replace(/punct/g,h0).getRegex(),M1="^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)",E1=Y(M1,"gu").replace(/notPunctSpace/g,Nt).replace(/punctSpace/g,pt).replace(/punct/g,h0).getRegex(),R1=Y(/\\(punct)/,"gu").replace(/punct/g,h0).getRegex(),D1=Y(/(`+)(?:[^`]|[^`][\s\S]*?[^`])\1(?!`)|`+|\\(punct)/,"gu").replace(/punct/g,h0).getRegex(),C1=Y(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme",/[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email",/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(),I1=Y(wa).replace("(?:-->|$)","-->").getRegex(),O1=Y("^comment|^</[a-zA-Z][a-zA-Z0-9-]*\\s*>|^<[a-zA-Z][a-zA-Z0-9-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment",I1).replace("attribute",/\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(),xi=/\[(?:\\[\s\S]|[^\[\]\\])*\]/,vr=Y(/(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/).replace("brackets",xi).getRegex(),B1=Y(/^!?\[(label)\]\([ \t\n]*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?[ \t\n]*\)/).replace("label",vr).replace("href",/<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]+|(?=\))/).replace("title",/"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(),N1=Y(/^!?\[(label)\]\[(ref)\]/).replace("label",vr).replace("ref",xa).getRegex(),L1=Y(/^!?\[(ref)\](?:\[\])?/).replace("ref",xa).getRegex(),ai=/(?!\s*\])(?:\\[\s\S]|[^\[\]\\]){1,999}/,q1=Y(/(?:[^\[\]\\`]*(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\]))){0,999}?[^\[\]\\`]*?/).replace("brackets",xi).getRegex(),P1=Y("reflink|nolink(?!\\()","g").replace("reflink",Y(/^!?\[(label)\]\[(ref)\]/).replace("label",q1).replace("ref",ai).getRegex()).replace("nolink",Y(/^!?\[(ref)\](?:\[\])?/).replace("ref",ai).getRegex()).getRegex(),ni=/[hH][tT][tT][pP][sS]?|[fF][tT][pP]/,F1=/[A-Za-z0-9._+-]+@[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/,_1=Y(/(?:mailto:email|xmpp:email(?:\/[A-Za-z0-9@.]+)?)/).replace(/email/g,F1).getRegex(),Sa={_backpedal:X0,anyPunctuation:R1,anyPunctuationOutsideCode:D1,autolink:C1,blockSkip:p1,br:vi,code:o1,del:X0,delLDelim:X0,delRDelim:X0,emStrongLDelim:f1,emStrongRDelimAst:y1,emStrongRDelimUnd:S1,escape:l1,link:B1,nolink:L1,punctuation:c1,reflink:N1,reflinkSearch:P1,tag:O1,text:u1,url:X0},H1={...Sa,emStrongLDelim:b1,emStrongRDelimAst:k1,emStrongRDelimUnd:A1,link:Y(/^!?\[(label)\]\((.*?)\)/).replace("label",vr).getRegex(),reflink:Y(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label",vr).getRegex()},pa={...Sa,emStrongRDelimAst:x1,emStrongLDelim:v1,delLDelim:z1,delRDelim:E1,url:Y(/^emailProtocol|^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("emailProtocol",_1).replace("protocol",ni).replace("email",/[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/).getRegex(),_backpedal:/(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,del:/^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/,text:Y(/^(?:[^a-zA-Z0-9](?=emailProtocol)|(`+|~+|[^`~])(?:(?=[`~])|(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9](?=emailProtocol)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))))/).replace("protocol",ni).replace(/emailProtocol/g,/(?:mailto|xmpp):/).getRegex()},$1={...pa,br:Y(vi).replace("{2,}","*").getRegex(),text:Y(pa.text).replace("\\b_","\\b_| {2,}\\n").replace(/\{2,\}/g,"*").getRegex()},fr={normal:ka,gfm:i1,pedantic:s1},Ct={normal:Sa,gfm:pa,breaks:$1,pedantic:H1},U1={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},ii=r=>U1[r];function Ve(r,e){if(e){if(Te.escapeTest.test(r))return r.replace(Te.escapeReplace,ii)}else if(Te.escapeTestNoEncode.test(r))return r.replace(Te.escapeReplaceNoEncode,ii);return r}function G1(r){return Te.numericCharacterReference.test(r)?r.replace(Te.numericCharacterReferenceOrAmpersand,(e,t,a)=>{if(t===void 0&&a===void 0)return"&amp;";let n=t===void 0?Number.parseInt(a,16):Number.parseInt(t,10);return n===0||n>1114111||n>=55296&&n<=57343?"\uFFFD":n===38?"&amp;":String.fromCodePoint(n)}):r}function si(r){try{r=encodeURI(r).replace(Te.percentDecode,"%")}catch{return null}return r}function li(r,e){let t=r.replace(Te.findPipe,(i,l,u)=>{let h=!1,d=l;for(;--d>=0&&u[d]==="\\";)h=!h;return h?"|":" |"}),a=t.split(Te.splitPipe),n=0;if(a[0].trim()||a.shift(),a.length>0&&!a.at(-1)?.trim()&&a.pop(),e)if(a.length>e)a.splice(e);else for(;a.length<e;)a.push("");for(;n<a.length;n++)a[n]=a[n].trim().replace(Te.slashPipe,"|");return a}function O0(r,e,t){let a=r.length;if(a===0)return"";let n=0;for(;n<a;){let i=r.charAt(a-n-1);if(i===e&&!t)n++;else if(i!==e&&t)n++;else break}return r.slice(0,a-n)}function oi(r){let e=r.split(`
`),t=e.length-1;for(;t>=0&&Te.blankLine.test(e[t]);)t--;return e.length-t<=2?r:e.slice(0,t+1).join(`
`)}function gr(r){return r.trim().toLowerCase().toUpperCase().toLowerCase()}function ui(r,e){if(r.indexOf(e[0])===-1&&r.indexOf(e[1])===-1)return-1;let t=0;for(let a=0;a<r.length;a++)if(r[a]==="\\")a++;else if(r[a]===e[0])t++;else if(r[a]===e[1]&&(t--,t<0))return a;return t>0?-2:-1}function da(r,e=0){let t=e,a="";for(let n of r)if(n==="	"){let i=4-t%4;a+=" ".repeat(i),t+=i}else a+=n,t++;return a}function ci(r,e,t,a,n){let i=e.href,l=e.title||null,u=r[1].replace(n.other.outputLinkReplace,"$1"),h=r[0].charAt(0)==="!",d=a.state.inLink,f=a.state.linkEmitted,b=a.state.inRawBlock;a.state.inLink=!0,a.state.linkEmitted=!1;let k=a.inlineTokens(u),w=a.state.linkEmitted;if(a.state.linkEmitted=f,a.state.inLink=d,!h){if(w){a.state.inRawBlock=b;return}a.state.linkEmitted=!0}return{type:h?"image":"link",raw:t,href:i,title:l,text:u,tokens:k}}function j1(r,e,t){let a=r.match(t.other.indentCodeCompensation);if(a===null)return e;let n=a[1];return e.split(`
`).map(i=>{let l=i.match(t.other.beginningSpace);if(l===null)return i;let[u]=l;return i.slice(Math.min(u.length,n.length))}).join(`
`)}function hi(r,e,t,a){if(!e.includes("<"))return!1;for(let n=0;n<e.length;n++){if(e[n]==="\\"){n++;continue}if(e[n]==="`"){let u=a.inline.code.exec(e.slice(n));if(u){n+=u[0].length-1;continue}}if(e[n]!=="<")continue;let i=r.slice(t+n),l=a.inline.tag.exec(i)||a.inline.autolink.exec(i);if(l){if(l[0].length>e.length-n)return!0;n+=l[0].length-1}}return!1}var br=class{options;rules;lexer;constructor(r){this.options=r||K0}space(r){let e=this.rules.block.newline.exec(r);if(e&&e[0].length>0)return{type:"space",raw:e[0]}}code(r){let e=this.rules.block.code.exec(r);if(e){let t=this.options.pedantic?e[0]:oi(e[0]),a=t.replace(this.rules.other.codeRemoveIndent,"");return{type:"code",raw:t,codeBlockStyle:"indented",text:a}}}fences(r){let e=this.rules.block.fences.exec(r);if(e){let t=e[0],a=j1(t,e[3]||"",this.rules);return{type:"code",raw:t,lang:e[2]?e[2].trim().replace(this.rules.inline.anyPunctuation,"$1"):e[2],text:a}}}heading(r){let e=this.rules.block.heading.exec(r);if(e){let t=e[2].trim();if(this.rules.other.endingHash.test(t)){let a=O0(t,"#");(this.options.pedantic||!a||this.rules.other.endingSpaceTabChar.test(a))&&(t=a.trim())}return{type:"heading",raw:O0(e[0],`
`),depth:e[1].length,text:t,tokens:this.lexer.inline(t)}}}hr(r){let e=this.rules.block.hr.exec(r);if(e)return{type:"hr",raw:O0(e[0],`
`)}}blockquote(r){let e=this.rules.block.blockquote.exec(r);if(e){let t=O0(e[0],`
`).split(`
`),a="",n="",i=[];for(;t.length>0;){let l=!1,u=[],h;for(h=0;h<t.length;h++)if(this.rules.other.blockquoteStart.test(t[h]))u.push(t[h]),l=!0;else if(!l)u.push(t[h]);else break;t=t.slice(h);let d=u.join(`
`),f=d.replace(this.rules.other.blockquoteSetextReplace,`
    $1`).replace(this.rules.other.blockquoteSetextReplace2,"");a=a?`${a}
${d}`:d,n=n?`${n}
${f}`:f;let b=this.lexer.state.top;if(this.lexer.state.top=!0,this.lexer.blockTokens(f,i,!0),this.lexer.state.top=b,t.length===0)break;let k=i.at(-1);if(k?.type==="code"||k?.type==="heading"||k?.type==="hr"||k?.type==="html")break;if(k?.type==="blockquote"){let w=k,M=t.join(`
`),D=w.raw+`
`+M.replace(this.rules.other.blockquoteSetextReplace2,""),E=this.blockquote(D);i[i.length-1]=E;let N=D.substring(E.raw.length).replace(/^\n/,""),B=N?N.split(`
`).length:0,F=B?t.slice(0,-B):t;F.length>0&&(a=`${a}
${F.join(`
`)}`),n=n.substring(0,n.length-w.text.length)+E.text;break}else if(k?.type==="list"){let w=k,M=w.raw+`
`+t.join(`
`),D=this.list(M);i[i.length-1]=D,a=a.substring(0,a.length-k.raw.length)+D.raw,n=n.substring(0,n.length-w.raw.length)+D.raw,t=M.substring(i.at(-1).raw.length).split(`
`);continue}}return{type:"blockquote",raw:a,tokens:i,text:n}}}list(r){let e=this.rules.block.list.exec(r);if(e){let t=r,a=()=>t.length-r.length,n=e[1].trim(),i=n.length>1,l={type:"list",raw:"",ordered:i,start:i?+n.slice(0,-1):"",loose:!1,items:[]};n=i?`\\d{1,9}\\${n.slice(-1)}`:`\\${n}`,this.options.pedantic&&(n=i?n:"[*+-]");let u=this.rules.other.listItemRegex(n),h=!1;for(;r;){let f=!1,b="";if(!(e=u.exec(r))||this.rules.block.hr.test(r))break;let k=a();r=r.substring(e[0].length);let w=e[2].split(`
`,1)[0],M=e[1].length,D=this.options.pedantic?da(w,M):w.replace(this.rules.other.leadingSpaceTab,H=>da(H,M)),E=r.split(`
`,1)[0],N=!D.trim(),B=0;if(this.options.pedantic?(B=2,b=D.trimStart()):N?B=M+1:(B=D.search(this.rules.other.nonSpaceChar),B=B>4?1:B,b=D.slice(B),B+=M),N&&this.rules.other.blankLine.test(E)&&(r=r.substring(E.length+1),f=!0),!f){let H=this.rules.other.nextBulletRegex(B),V=this.rules.other.hrRegex(B),j=this.rules.other.fencesBeginRegex(B),$=this.rules.other.headingBeginRegex(B),X=this.rules.other.htmlBeginRegex(B),ee=this.rules.other.blockquoteBeginRegex(B);for(;r;){let ae=r.split(`
`,1)[0],Q;if(E=ae,this.options.pedantic?(E=E.replace(this.rules.other.listReplaceNesting,"  "),Q=E):Q=E.replace(this.rules.other.leadingSpaceTab,ie=>da(ie)),j.test(E)||$.test(E)||X.test(E)||ee.test(E)||H.test(E)||V.test(E))break;if(Q.search(this.rules.other.nonSpaceChar)>=B||!E.trim())b+=`
`+Q.slice(B);else{if(N||D.replace(this.rules.other.tabCharGlobal,"    ").search(this.rules.other.nonSpaceChar)>=4||j.test(D)||$.test(D)||V.test(D))break;b+=`
`+E}N=!E.trim(),r=r.substring(ae.length+1),D=Q.slice(B)}}let F=t.slice(k,a());l.loose||(h?l.loose=!0:this.rules.other.doubleBlankLine.test(F)&&(h=!0)),l.items.push({type:"list_item",raw:F,task:!!this.options.gfm&&this.rules.other.listIsTask.test(b),loose:!1,text:b,tokens:[]})}let d=l.items.at(-1);if(d)d.raw=d.raw.trimEnd(),d.text=d.text.trimEnd();else return;l.raw=t.slice(0,a()).trimEnd();for(let f of l.items)if(this.lexer.state.top=!1,f.tokens=this.lexer.blockTokens(f.text,[]),!l.loose){let b=f.tokens.filter(w=>w.type==="space"),k=b.length>0&&b.some(w=>this.rules.other.anyLine.test(w.raw));l.loose=k}for(let f of l.items){let b=f.tokens[0];if(f.task&&(b?.type==="text"||b?.type==="paragraph")){f.text=f.text.replace(this.rules.other.listReplaceTask,""),b.raw=b.raw.replace(this.rules.other.listReplaceTask,""),b.text=b.text.replace(this.rules.other.listReplaceTask,"");for(let w=this.lexer.inlineQueue.length-1;w>=0;w--)if(this.rules.other.listIsTask.test(this.lexer.inlineQueue[w].src)){this.lexer.inlineQueue[w].src=this.lexer.inlineQueue[w].src.replace(this.rules.other.listReplaceTask,"");break}let k=this.rules.other.listTaskCheckbox.exec(f.raw);if(k){let w={type:"checkbox",raw:k[0]+" ",checked:k[0]!=="[ ]"};f.checked=w.checked,l.loose?f.tokens[0]&&["paragraph","text"].includes(f.tokens[0].type)&&"tokens"in f.tokens[0]&&f.tokens[0].tokens?(f.tokens[0].raw=w.raw+f.tokens[0].raw,f.tokens[0].text=w.raw+f.tokens[0].text,f.tokens[0].tokens.unshift(w)):f.tokens.unshift({type:"paragraph",raw:w.raw,text:w.raw,tokens:[w]}):f.tokens.unshift(w)}}else f.task&&(f.task=!1)}if(l.loose)for(let f of l.items){f.loose=!0;for(let b of f.tokens)b.type==="text"&&(b.type="paragraph")}return l}}html(r){let e=this.rules.block.html.exec(r);if(e){let t=oi(e[0]);return{type:"html",block:!0,raw:t,pre:e[1]==="pre"||e[1]==="script"||e[1]==="style",text:t}}}def(r){let e=this.rules.block.def.exec(r);if(e){if(!this.rules.other.startAngleBracket.test(e[2])&&ui(e[2],"()")!==-1)return;let t=gr(e[1]).replace(this.rules.other.multipleSpaceGlobal," "),a=e[2]?e[2].replace(this.rules.other.hrefBrackets,"$1").replace(this.rules.inline.anyPunctuation,"$1"):"",n=e[3]?e[3].substring(1,e[3].length-1).replace(this.rules.inline.anyPunctuation,"$1"):e[3];return{type:"def",tag:t,raw:O0(e[0],`
`),href:a,title:n}}}table(r){let e=this.rules.block.table.exec(r);if(!e||!this.rules.other.tableDelimiter.test(e[2]))return;let t=li(e[1]),a=e[2].replace(this.rules.other.tableAlignChars,"").split("|"),n=e[3]?.trim()?e[3].replace(this.rules.other.tableRowBlankLine,"").split(`
`):[],i={type:"table",raw:O0(e[0],`
`),header:[],align:[],rows:[]};if(t.length===a.length){for(let l of a)this.rules.other.tableAlignRight.test(l)?i.align.push("right"):this.rules.other.tableAlignCenter.test(l)?i.align.push("center"):this.rules.other.tableAlignLeft.test(l)?i.align.push("left"):i.align.push(null);for(let l=0;l<t.length;l++)i.header.push({text:t[l],tokens:this.lexer.inline(t[l]),header:!0,align:i.align[l]});for(let l of n)i.rows.push(li(l,i.header.length).map((u,h)=>({text:u,tokens:this.lexer.inline(u),header:!1,align:i.align[h]})));return i}}lheading(r){let e=this.rules.block.lheading.exec(r);if(e){let t=e[1].trim();return{type:"heading",raw:O0(e[0],`
`),depth:e[2].charAt(0)==="="?1:2,text:t,tokens:this.lexer.inline(t)}}}paragraph(r){let e=this.rules.block.paragraph.exec(r);if(e){let t=e[1].charAt(e[1].length-1)===`
`?e[1].slice(0,-1):e[1];return{type:"paragraph",raw:e[0],text:t,tokens:this.lexer.inline(t)}}}text(r){let e=this.rules.block.text.exec(r);if(e)return{type:"text",raw:e[0],text:e[0],tokens:this.lexer.inline(e[0])}}escape(r){let e=this.rules.inline.escape.exec(r);if(e)return{type:"escape",raw:e[0],text:e[1]}}tag(r){let e=this.rules.inline.tag.exec(r);if(e)return!this.lexer.state.inLink&&this.rules.other.startATag.test(e[0])?this.lexer.state.inLink=!0:this.lexer.state.inLink&&this.rules.other.endATag.test(e[0])&&(this.lexer.state.inLink=!1),!this.lexer.state.inRawBlock&&this.rules.other.startPreScriptTag.test(e[0])?this.lexer.state.inRawBlock=!0:this.lexer.state.inRawBlock&&this.rules.other.endPreScriptTag.test(e[0])&&(this.lexer.state.inRawBlock=!1),{type:"html",raw:e[0],inLink:this.lexer.state.inLink,inRawBlock:this.lexer.state.inRawBlock,block:!1,text:e[0]}}link(r){if(this.lexer.state.linkParenPossible===!1)return;let e=this.rules.inline.link.exec(r);if(e){let t=e[0].charAt(0)==="!"?2:1;if(!this.options.pedantic&&hi(r,e[1],t,this.rules))return;let a=e[2].trim();if(!this.options.pedantic&&this.rules.other.startAngleBracket.test(a)){if(!this.rules.other.endAngleBracket.test(a))return;let l=O0(a.slice(0,-1),"\\");if((a.length-l.length)%2===0)return}else{let l=ui(e[2],"()");if(l===-2)return;if(l>-1){let u=(e[0].indexOf("!")===0?5:4)+e[1].length+l;e[2]=e[2].substring(0,l),e[0]=e[0].substring(0,u).trim(),e[3]=""}}let n=e[2],i="";if(this.options.pedantic){let l=this.rules.other.pedanticHrefTitle.exec(n);l&&(n=l[1],i=l[3])}else i=e[3]?e[3].slice(1,-1):"";return n=n.trim(),this.rules.other.startAngleBracket.test(n)&&(this.options.pedantic&&!this.rules.other.endAngleBracket.test(a)?n=n.slice(1):n=n.slice(1,-1)),ci(e,{href:n&&n.replace(this.rules.inline.anyPunctuation,"$1"),title:i&&i.replace(this.rules.inline.anyPunctuation,"$1")},e[0],this.lexer,this.rules)}}reflink(r,e){let t;if((t=this.rules.inline.reflink.exec(r))||(t=this.rules.inline.nolink.exec(r))){let a=t[0].charAt(0)==="!"?2:1;if(!this.options.pedantic&&hi(r,t[1],a,this.rules))return;let n=(t[2]||t[1]).replace(this.rules.other.multipleSpaceGlobal," "),i=e[gr(n)];if(!i){let l=t[0].charAt(0);return{type:"text",raw:l,text:l}}return ci(t,i,t[0],this.lexer,this.rules)}}emStrong(r,e,t=""){let a=this.rules.inline.emStrongLDelim.exec(r);if(!(!a||!a[1]&&!a[2]&&!a[3]&&!a[4]||a[4]&&t.match(this.rules.other.unicodeAlphaNumeric))&&(!(a[1]||a[3])||!t||this.rules.inline.punctuation.exec(t))){let n=[...a[0]].length-1,i,l,u=n,h=0,d=a[0][0],f=t===d,b=d==="*"?this.rules.inline.emStrongRDelimAst:this.rules.inline.emStrongRDelimUnd;for(b.lastIndex=0,e=e.slice(-1*r.length+n);(a=b.exec(e))!==null;){if(i=a[1]||a[2]||a[3]||a[4]||a[5]||a[6],!i)continue;if(l=[...i].length,a[3]||a[4]){u+=l;continue}else if(a[5]||a[6]){if(n%3&&!((n+l)%3)){h+=l;continue}if(f)break}if(u-=l,u>0)continue;l=Math.min(l,l+u+h);let k=[...a[0]][0].length,w=r.slice(0,n+a.index+k+l);if(Math.min(n,l)%2){let D=w.slice(1,-1);return{type:"em",raw:w,text:D,tokens:this.lexer.inlineTokens(D)}}let M=w.slice(2,-2);return{type:"strong",raw:w,text:M,tokens:this.lexer.inlineTokens(M)}}}}codespan(r){let e=this.rules.inline.code.exec(r);if(e){let t=e[2].replace(this.rules.other.newLineCharGlobal," "),a=this.rules.other.nonSpaceChar.test(t),n=this.rules.other.startingSpaceChar.test(t)&&this.rules.other.endingSpaceChar.test(t);return a&&n&&(t=t.substring(1,t.length-1)),{type:"codespan",raw:e[0],text:t}}}br(r){let e=this.rules.inline.br.exec(r);if(e)return{type:"br",raw:e[0]}}del(r,e,t=""){let a=this.rules.inline.delLDelim.exec(r);if(a&&(!a[1]||!t||this.rules.inline.punctuation.exec(t))){let n=[...a[0]].length-1,i,l,u=n,h=this.rules.inline.delRDelim;for(h.lastIndex=0,e=e.slice(-1*r.length+n);(a=h.exec(e))!==null;){if(i=a[1]||a[2]||a[3]||a[4]||a[5]||a[6],!i||(l=[...i].length,l!==n))continue;if(a[3]||a[4]){u+=l;continue}if(u-=l,u>0)continue;l=Math.min(l,l+u);let d=[...a[0]][0].length,f=r.slice(0,n+a.index+d+l),b=f.slice(n,-n);return{type:"del",raw:f,text:b,tokens:this.lexer.inlineTokens(b)}}}}autolink(r){let e=this.rules.inline.autolink.exec(r);if(e){let t,a;return e[2]==="@"?(t=e[1],a="mailto:"+t):(t=e[1],a=t),{type:"link",raw:e[0],text:t,href:a,autolink:!0,tokens:[{type:"text",raw:t,text:t}]}}}url(r){let e;if(e=this.rules.inline.url.exec(r)){let t,a;if(e[2]==="@")t=e[0],a="mailto:"+t;else{let n;do n=e[0],e[0]=this.rules.inline._backpedal.exec(e[0])?.[0]??"";while(n!==e[0]);t=e[0],e[1]==="www."?a="http://"+e[0]:a=e[0]}return{type:"link",raw:e[0],text:t,href:a,autolink:!0,tokens:[{type:"text",raw:t,text:t}]}}}inlineText(r){let e=this.rules.inline.text.exec(r);if(e){let t=this.lexer.state.inRawBlock;return{type:"text",raw:e[0],text:t?e[0]:G1(e[0]),escaped:t}}}},s0=class fa{tokens;options;state;inlineQueue;tokenizer;constructor(e){this.tokens=[],this.tokens.links=Object.create(null),this.options=e||K0,this.options.tokenizer=this.options.tokenizer||new br,this.tokenizer=this.options.tokenizer,this.tokenizer.options=this.options,this.tokenizer.lexer=this,this.inlineQueue=[],this.state={inLink:!1,inRawBlock:!1,linkEmitted:!1,linkParenPossible:!0,top:!0};let t={other:Te,block:fr.normal,inline:Ct.normal};this.options.pedantic?(t.block=fr.pedantic,t.inline=Ct.pedantic):this.options.gfm&&(t.block=fr.gfm,this.options.breaks?t.inline=Ct.breaks:t.inline=Ct.gfm),this.tokenizer.rules=t}static get rules(){return{block:fr,inline:Ct}}static lex(e,t){return new fa(t).lex(e)}static lexInline(e,t){return new fa(t).inlineTokens(e)}lex(e){e=e.replace(Te.carriageReturn,`
`),this.blockTokens(e,this.tokens);for(let t=0;t<this.inlineQueue.length;t++){let a=this.inlineQueue[t];this.inlineTokens(a.src,a.tokens)}return this.inlineQueue=[],this.tokens}blockTokens(e,t=[],a=!1){this.tokenizer.lexer=this,this.options.pedantic&&(e=e.replace(Te.tabCharGlobal,"    ").replace(Te.spaceLine,""));let n=1/0;for(;e;){if(e.length<n)n=e.length;else{this.infiniteLoopError(e.charCodeAt(0));break}let i;if(this.options.extensions?.block?.some(u=>(i=u.call({lexer:this},e,t))?(e=e.substring(i.raw.length),t.push(i),!0):!1))continue;if(i=this.tokenizer.space(e)){e=e.substring(i.raw.length);let u=t.at(-1);i.raw.length===1&&u!==void 0?u.raw+=`
`:t.push(i);continue}if(i=this.tokenizer.code(e)){e=e.substring(i.raw.length);let u=t.at(-1);u?.type==="paragraph"||u?.type==="text"?(u.raw+=(u.raw.endsWith(`
`)?"":`
`)+i.raw,u.text+=`
`+i.text,this.inlineQueue.at(-1).src=u.text):t.push(i);continue}if(i=this.tokenizer.fences(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.heading(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.hr(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.blockquote(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.list(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.html(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.def(e)){e=e.substring(i.raw.length);let u=t.at(-1);u?.type==="paragraph"||u?.type==="text"?(u.raw+=(u.raw.endsWith(`
`)?"":`
`)+i.raw,u.text+=`
`+i.raw,this.inlineQueue.at(-1).src=u.text):this.tokens.links[i.tag]||(this.tokens.links[i.tag]={href:i.href,title:i.title},t.push(i));continue}if(i=this.tokenizer.table(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.lheading(e)){e=e.substring(i.raw.length),t.push(i);continue}let l=e;if(this.options.extensions?.startBlock){let u=1/0,h=e.slice(1),d;this.options.extensions.startBlock.forEach(f=>{d=f.call({lexer:this},h),typeof d=="number"&&d>=0&&(u=Math.min(u,d))}),u<1/0&&u>=0&&(l=e.substring(0,u+1))}if(this.state.top&&(i=this.tokenizer.paragraph(l))){let u=t.at(-1);a&&u?.type==="paragraph"?(u.raw+=(u.raw.endsWith(`
`)?"":`
`)+i.raw,u.text+=`
`+i.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=u.text):t.push(i),a=l.length!==e.length,e=e.substring(i.raw.length);continue}if(i=this.tokenizer.text(e)){e=e.substring(i.raw.length);let u=t.at(-1);u?.type==="text"?(u.raw+=(u.raw.endsWith(`
`)?"":`
`)+i.raw,u.text+=`
`+i.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=u.text):t.push(i);continue}if(e){this.infiniteLoopError(e.charCodeAt(0));break}}return this.state.top=!0,t}inline(e,t=[]){return this.inlineQueue.push({src:e,tokens:t}),t}linkInText(e){if(!e.includes("["))return!1;let t=this.tokenizer.rules.inline.link;for(let a of e.matchAll(this.tokenizer.rules.inline.blockSkip))if(t.test(a[0])&&e.charAt(a.index-1)!=="!")return!0;for(let a of e.matchAll(this.tokenizer.rules.inline.reflinkSearch)){let n=a[0],i=n.lastIndexOf("[");if(!(n.charAt(0)==="!"||!Object.hasOwn(this.tokens.links,gr(n.slice(i+1,-1))))&&!(i>1&&this.linkInText(n.slice(1,i-1))))return!0}return!1}inlineTokens(e,t=[]){this.tokenizer.lexer=this;let a=this.state.linkParenPossible;this.state.linkParenPossible=a&&e.includes(")");try{return this.#e(e,t)}finally{this.state.linkParenPossible=a}}#e(e,t){let a=e;if(this.tokens.links&&e.includes("[")){let u=this.tokenizer.rules.inline.reflinkSearch,h=d=>{let f=d.lastIndexOf("[");if(!Object.hasOwn(this.tokens.links,gr(d.slice(f+1,-1))))return d;if(f>1&&d.charAt(0)!=="!"){let b=d.slice(1,f-1);if(this.linkInText(b))return"["+b.replace(u,h)+"]["+"a".repeat(d.length-f-2)+"]"}return"["+"a".repeat(d.length-2)+"]"};a=a.replace(u,h)}a=a.replace(this.tokenizer.rules.inline.anyPunctuationOutsideCode,(u,h,d)=>d?"+".repeat(u.length):h?h+u.slice(h.length,-h.length).replace(/`/g,"+")+h:u),a=a.replace(this.tokenizer.rules.inline.blockSkip,(u,h,d)=>{let f=d?d.length:0;return u.slice(0,f)+"["+"a".repeat(u.length-f-2)+"]"}),a=this.options.hooks?.emStrongMask?.call({lexer:this},a)??a;let n=!1,i="",l=1/0;for(;e;){if(e.length<l)l=e.length;else{this.infiniteLoopError(e.charCodeAt(0));break}n||(i=""),n=!1;let u;if(this.options.extensions?.inline?.some(d=>(u=d.call({lexer:this},e,t))?(e=e.substring(u.raw.length),t.push(u),!0):!1))continue;if(u=this.tokenizer.escape(e)){e=e.substring(u.raw.length),t.push(u);continue}if(u=this.tokenizer.tag(e)){e=e.substring(u.raw.length),t.push(u);continue}if(u=this.tokenizer.link(e)){e=e.substring(u.raw.length),t.push(u);continue}if(u=this.tokenizer.reflink(e,this.tokens.links)){e=e.substring(u.raw.length);let d=t.at(-1);u.type==="text"&&d?.type==="text"?(d.raw+=u.raw,d.text+=u.text):t.push(u);continue}if(u=this.tokenizer.emStrong(e,a,i)){e=e.substring(u.raw.length),t.push(u);continue}if(u=this.tokenizer.codespan(e)){e=e.substring(u.raw.length),t.push(u);continue}if(u=this.tokenizer.br(e)){e=e.substring(u.raw.length),t.push(u);continue}if(u=this.tokenizer.del(e,a,i)){e=e.substring(u.raw.length),t.push(u);continue}if(u=this.tokenizer.autolink(e)){e=e.substring(u.raw.length),t.push(u);continue}if(!this.state.inLink&&(u=this.tokenizer.url(e))){e=e.substring(u.raw.length),t.push(u);continue}let h=e;if(this.options.extensions?.startInline){let d=1/0,f=e.slice(1),b;this.options.extensions.startInline.forEach(k=>{b=k.call({lexer:this},f),typeof b=="number"&&b>=0&&(d=Math.min(d,b))}),d<1/0&&d>=0&&(h=e.substring(0,d+1))}if(u=this.tokenizer.inlineText(h)){e=e.substring(u.raw.length),u.raw.slice(-1)!=="_"&&(i=u.raw.slice(-1)),n=!0;let d=t.at(-1);d?.type==="text"?(d.raw+=u.raw,d.text+=u.text):t.push(u);continue}if(e){this.infiniteLoopError(e.charCodeAt(0));break}}return t}infiniteLoopError(e){let t="Infinite loop on byte: "+e;if(this.options.silent)console.error(t);else throw new Error(t)}},yr=class{options;parser;constructor(r){this.options=r||K0}space(r){return""}code({text:r,lang:e,escaped:t}){let a=(e||"").match(Te.notSpaceStart)?.[0],n=r?r.replace(Te.endingNewline,"")+`
`:"";return a?'<pre><code class="language-'+Ve(a)+'">'+(t?n:Ve(n,!0))+`</code></pre>
`:"<pre><code>"+(t?n:Ve(n,!0))+`</code></pre>
`}blockquote({tokens:r}){return`<blockquote>
${this.parser.parse(r)}</blockquote>
`}html({text:r}){return r}def(r){return""}heading({tokens:r,depth:e}){return`<h${e}>${this.parser.parseInline(r)}</h${e}>
`}hr(r){return`<hr>
`}list(r){let e=r.ordered,t=r.start,a="";for(let l=0;l<r.items.length;l++){let u=r.items[l];a+=this.listitem(u)}let n=e?"ol":"ul",i=e&&t!==1?' start="'+t+'"':"";return"<"+n+i+`>
`+a+"</"+n+`>
`}listitem(r){return`<li>${this.parser.parse(r.tokens)}</li>
`}checkbox({checked:r}){return"<input "+(r?'checked="" ':"")+'disabled="" type="checkbox"> '}paragraph({tokens:r}){return`<p>${this.parser.parseInline(r)}</p>
`}table(r){let e="",t="";for(let n=0;n<r.header.length;n++)t+=this.tablecell(r.header[n]);e+=this.tablerow({text:t});let a="";for(let n=0;n<r.rows.length;n++){let i=r.rows[n];t="";for(let l=0;l<i.length;l++)t+=this.tablecell(i[l]);a+=this.tablerow({text:t})}return a&&(a=`<tbody>${a}</tbody>`),`<table>
<thead>
`+e+`</thead>
`+a+`</table>
`}tablerow({text:r}){return`<tr>
${r}</tr>
`}tablecell(r){let e=this.parser.parseInline(r.tokens),t=r.header?"th":"td";return(r.align?`<${t} align="${r.align}">`:`<${t}>`)+e+`</${t}>
`}strong({tokens:r}){return`<strong>${this.parser.parseInline(r)}</strong>`}em({tokens:r}){return`<em>${this.parser.parseInline(r)}</em>`}codespan({text:r}){return`<code>${Ve(r,!0)}</code>`}br(r){return"<br>"}del({tokens:r}){return`<del>${this.parser.parseInline(r)}</del>`}link({href:r,title:e,text:t,tokens:a,autolink:n}){let i=n?Ve(t,!0):this.parser.parseInline(a),l=si(r);if(l===null)return i;r=Ve(l,n);let u='<a href="'+r+'"';return e&&(u+=' title="'+Ve(e)+'"'),u+=">"+i+"</a>",u}image({href:r,title:e,text:t,tokens:a}){a&&(t=this.parser.parseInline(a,this.parser.textRenderer));let n=si(r);if(n===null)return Ve(t);r=n;let i=`<img src="${Ve(r)}" alt="${Ve(t)}"`;return e&&(i+=` title="${Ve(e)}"`),i+=">",i}text(r){return"tokens"in r&&r.tokens?this.parser.parseInline(r.tokens):"escaped"in r&&r.escaped?r.text:Ve(r.text)}},Ta=class{strong({text:r}){return r}em({text:r}){return r}codespan({text:r}){return r}del({text:r}){return r}html({text:r}){return r}text({text:r}){return r}link({text:r}){return""+r}image({text:r}){return""+r}br(){return""}checkbox({raw:r}){return r}},l0=class va{options;renderer;textRenderer;constructor(e){this.options=e||K0,this.options.renderer=this.options.renderer||new yr,this.renderer=this.options.renderer,this.renderer.options=this.options,this.renderer.parser=this,this.textRenderer=new Ta}static parse(e,t){return new va(t).parse(e)}static parseInline(e,t){return new va(t).parseInline(e)}parse(e){this.renderer.parser=this;let t="";for(let a=0;a<e.length;a++){let n=e[a];if(this.options.extensions?.renderers?.[n.type]){let l=n,u=this.options.extensions.renderers[l.type].call({parser:this},l);if(u!==!1||!["space","hr","heading","code","table","blockquote","list","checkbox","html","def","paragraph","text"].includes(l.type)){t+=u||"";continue}}let i=n;switch(i.type){case"space":{t+=this.renderer.space(i);break}case"hr":{t+=this.renderer.hr(i);break}case"heading":{t+=this.renderer.heading(i);break}case"code":{t+=this.renderer.code(i);break}case"table":{t+=this.renderer.table(i);break}case"blockquote":{t+=this.renderer.blockquote(i);break}case"list":{t+=this.renderer.list(i);break}case"checkbox":{t+=this.renderer.checkbox(i);break}case"html":{t+=this.renderer.html(i);break}case"def":{t+=this.renderer.def(i);break}case"paragraph":{t+=this.renderer.paragraph(i);break}case"text":{t+=this.renderer.text(i);break}default:{let l='Token with "'+i.type+'" type was not found.';if(this.options.silent)return console.error(l),"";throw new Error(l)}}}return t}parseInline(e,t=this.renderer){this.renderer.parser=this;let a="";for(let n=0;n<e.length;n++){let i=e[n];if(this.options.extensions?.renderers?.[i.type]){let u=this.options.extensions.renderers[i.type].call({parser:this},i);if(u!==!1||!["escape","html","link","image","checkbox","strong","em","codespan","br","del","text"].includes(i.type)){a+=u||"";continue}}let l=i;switch(l.type){case"escape":{a+=t.text(l);break}case"html":{a+=t.html(l);break}case"link":{a+=t.link(l);break}case"image":{a+=t.image(l);break}case"checkbox":{a+=t.checkbox(l);break}case"strong":{a+=t.strong(l);break}case"em":{a+=t.em(l);break}case"codespan":{a+=t.codespan(l);break}case"br":{a+=t.br(l);break}case"del":{a+=t.del(l);break}case"text":{a+=t.text(l);break}default:{let u='Token with "'+l.type+'" type was not found.';if(this.options.silent)return console.error(u),"";throw new Error(u)}}}return a}},It=class{options;block;constructor(r){this.options=r||K0}static passThroughHooks=new Set(["preprocess","postprocess","processAllTokens","emStrongMask"]);static passThroughHooksRespectAsync=new Set(["preprocess","postprocess","processAllTokens"]);preprocess(r){return r}postprocess(r){return r}processAllTokens(r){return r}emStrongMask(r){return r}provideLexer(r=this.block){return r?s0.lex:s0.lexInline}provideParser(r=this.block){return r?l0.parse:l0.parseInline}};function Y0(r,e){if(Array.isArray(e))for(let t=0;t<e.length;t++)r.push(e[t]);else r.push(e)}var W1=class{defaults=ga();options=this.setOptions;parse=this.parseMarkdown(!0);parseInline=this.parseMarkdown(!1);Parser=l0;Renderer=yr;TextRenderer=Ta;Lexer=s0;Tokenizer=br;Hooks=It;constructor(...r){this.use(...r)}walkTokens(r,e){let t=[];for(let a of r)switch(Y0(t,e.call(this,a)),a.type){case"table":{let n=a;for(let i of n.header)Y0(t,this.walkTokens(i.tokens,e));for(let i of n.rows)for(let l of i)Y0(t,this.walkTokens(l.tokens,e));break}case"list":{let n=a;Y0(t,this.walkTokens(n.items,e));break}default:{let n=a;this.defaults.extensions?.childTokens?.[n.type]?this.defaults.extensions.childTokens[n.type].forEach(i=>{let l=n[i].flat(1/0);Y0(t,this.walkTokens(l,e))}):n.tokens&&Y0(t,this.walkTokens(n.tokens,e))}}return t}use(...r){let e=this.defaults.extensions||{renderers:{},childTokens:{}};return r.forEach(t=>{let a={...t};if(a.async=this.defaults.async||a.async||!1,t.extensions&&(t.extensions.forEach(n=>{if(!n.name)throw new Error("extension name required");if("renderer"in n){let i=e.renderers[n.name];i?e.renderers[n.name]=function(...l){let u=n.renderer.apply(this,l);return u===!1&&(u=i.apply(this,l)),u}:e.renderers[n.name]=n.renderer}if("tokenizer"in n){if(!n.level||n.level!=="block"&&n.level!=="inline")throw new Error("extension level must be 'block' or 'inline'");let i=e[n.level];i?i.unshift(n.tokenizer):e[n.level]=[n.tokenizer],n.start&&(n.level==="block"?e.startBlock?e.startBlock.push(n.start):e.startBlock=[n.start]:n.level==="inline"&&(e.startInline?e.startInline.push(n.start):e.startInline=[n.start]))}"childTokens"in n&&n.childTokens&&(e.childTokens[n.name]=n.childTokens)}),a.extensions=e),t.renderer){let n=this.defaults.renderer||new yr(this.defaults);for(let i in t.renderer){if(!(i in n))throw new Error(`renderer '${i}' does not exist`);if(["options","parser"].includes(i))continue;let l=i,u=t.renderer[l],h=n[l];n[l]=(...d)=>{let f=u.apply(n,d);return f===!1&&(f=h.apply(n,d)),f||""}}a.renderer=n}if(t.tokenizer){let n=this.defaults.tokenizer||new br(this.defaults);for(let i in t.tokenizer){if(!(i in n))throw new Error(`tokenizer '${i}' does not exist`);if(["options","rules","lexer"].includes(i))continue;let l=i,u=t.tokenizer[l],h=n[l];n[l]=(...d)=>{let f=u.apply(n,d);return f===!1&&(f=h.apply(n,d)),f}}a.tokenizer=n}if(t.hooks){let n=this.defaults.hooks||new It;for(let i in t.hooks){if(!(i in n))throw new Error(`hook '${i}' does not exist`);if(["options","block"].includes(i))continue;let l=i,u=t.hooks[l],h=n[l];It.passThroughHooks.has(i)?n[l]=d=>{if(this.defaults.async&&It.passThroughHooksRespectAsync.has(i))return(async()=>{let b=await u.call(n,d);return h.call(n,b)})();let f=u.call(n,d);return h.call(n,f)}:n[l]=(...d)=>{if(this.defaults.async)return(async()=>{let b=await u.apply(n,d);return b===!1&&(b=await h.apply(n,d)),b})();let f=u.apply(n,d);return f===!1&&(f=h.apply(n,d)),f}}a.hooks=n}if(t.walkTokens){let n=this.defaults.walkTokens,i=t.walkTokens;a.walkTokens=function(l){let u=[];return u.push(i.call(this,l)),n&&Y0(u,n.call(this,l)),u}}this.defaults={...this.defaults,...a}}),this}setOptions(r){return this.defaults={...this.defaults,...r},this}lexer(r,e){return s0.lex(r,e??this.defaults)}parser(r,e){return l0.parse(r,e??this.defaults)}parseMarkdown(r){return(e,t)=>{let a={...t},n={...this.defaults,...a},i=this.onError(!!n.silent,!!n.async);if(this.defaults.async===!0&&a.async===!1)return i(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));if(typeof e>"u"||e===null)return i(new Error("marked(): input parameter is undefined or null"));if(typeof e!="string")return i(new Error("marked(): input parameter is of type "+Object.prototype.toString.call(e)+", string expected"));if(n.hooks&&(n.hooks.options=n,n.hooks.block=r),n.async)return(async()=>{let l=n.hooks?await n.hooks.preprocess(e):e,u=await(n.hooks?await n.hooks.provideLexer(r):r?s0.lex:s0.lexInline)(l,n),h=n.hooks?await n.hooks.processAllTokens(u):u;n.walkTokens&&await Promise.all(this.walkTokens(h,n.walkTokens));let d=await(n.hooks?await n.hooks.provideParser(r):r?l0.parse:l0.parseInline)(h,n);return n.hooks?await n.hooks.postprocess(d):d})().catch(i);try{n.hooks&&(e=n.hooks.preprocess(e));let l=(n.hooks?n.hooks.provideLexer(r):r?s0.lex:s0.lexInline)(e,n);n.hooks&&(l=n.hooks.processAllTokens(l)),n.walkTokens&&this.walkTokens(l,n.walkTokens);let u=(n.hooks?n.hooks.provideParser(r):r?l0.parse:l0.parseInline)(l,n);return n.hooks&&(u=n.hooks.postprocess(u)),u}catch(l){return i(l)}}}onError(r,e){return t=>{if(t.message+=`
Please report this to https://github.com/markedjs/marked.`,r){let a="<p>An error occurred:</p><pre>"+Ve(t.message+"",!0)+"</pre>";return e?Promise.resolve(a):a}if(e)return Promise.reject(t);throw t}}},Z0=new W1;function ne(r,e){return Z0.parse(r,e)}ne.options=ne.setOptions=function(r){return Z0.setOptions(r),ne.defaults=Z0.defaults,mi(ne.defaults),ne};ne.getDefaults=ga;ne.defaults=K0;function V1(...r){return Z0.use(...r),ne.defaults=Z0.defaults,mi(ne.defaults),ne}ne.use=V1;ne.walkTokens=function(r,e){return Z0.walkTokens(r,e)};ne.parseInline=Z0.parseInline;ne.Parser=l0;ne.parser=l0.parse;ne.Renderer=yr;ne.TextRenderer=Ta;ne.Lexer=s0;ne.lexer=s0.lex;ne.Tokenizer=br;ne.Hooks=It;ne.parse=ne;var $4=ne.options,U4=ne.setOptions,G4=ne.walkTokens,j4=ne.parseInline;var W4=l0.parse,V4=s0.lex;/*! @license DOMPurify 3.4.17 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.17/LICENSE */function Y1(r,e){this.v=r,this.k=e}function wi(r,e){(e==null||e>r.length)&&(e=r.length);for(var t=0,a=Array(e);t<e;t++)a[t]=r[t];return a}function X1(r){if(Array.isArray(r))return r}function Z1(r,e){var t=r==null?null:typeof Symbol<"u"&&r[Symbol.iterator]||r["@@iterator"];if(t!=null){var a,n,i,l,u=[],h=!0,d=!1;try{if(i=(t=t.call(r)).next,e===0){if(Object(t)!==t)return;h=!1}else for(;!(h=(a=i.call(t)).done)&&(u.push(a.value),u.length!==e);h=!0);}catch(f){d=!0,n=f}finally{try{if(!h&&t.return!=null&&(l=t.return(),Object(l)!==l))return}finally{if(d)throw n}}return u}}function K1(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}/*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */function Q1(r,e){return X1(r)||Z1(r,e)||J1(r,e)||K1()}function J1(r,e){if(r){if(typeof r=="string")return wi(r,e);var t={}.toString.call(r).slice(8,-1);return t==="Object"&&r.constructor&&(t=r.constructor.name),t==="Map"||t==="Set"?Array.from(r):t==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?wi(r,e):void 0}}function xr(r){var e,t;function a(i,l){try{var u=r[i](l),h=u.value,d=h instanceof Y1;Promise.resolve(d?h.v:h).then(function(f){if(d){var b=i==="return"&&h.k?i:"next";if(!h.k||f.done)return a(b,f);f=r[b](f).value}n(!!u.done,f)},function(f){a("throw",f)})}catch(f){n(2,f)}}function n(i,l){i===2?e.reject(l):e.resolve({value:l,done:i}),(e=e.next)?a(e.key,e.arg):t=null}this._invoke=function(i,l){return new Promise(function(u,h){var d={key:i,arg:l,resolve:u,reject:h,next:null};t?t=t.next=d:(e=t=d,a(i,l))})},typeof r.return!="function"&&(this.return=void 0)}xr.prototype[typeof Symbol=="function"&&Symbol.asyncIterator||"@@asyncIterator"]=function(){return this},xr.prototype.next=function(r){return this._invoke("next",r)},xr.prototype.throw=function(r){return this._invoke("throw",r)},xr.prototype.return=function(r){return this._invoke("return",r)};var Li=Object.entries,ki=Object.setPrototypeOf,eo=Object.isFrozen,qi=Object.getPrototypeOf,Pi=Object.getOwnPropertyDescriptor,Ae=Object.freeze,Ee=Object.seal,ft=Object.create,Fi=typeof Reflect<"u"&&Reflect,Ba=Fi.apply,Na=Fi.construct;Ae||(Ae=function(e){return e});Ee||(Ee=function(e){return e});Ba||(Ba=function(e,t){for(var a=arguments.length,n=new Array(a>2?a-2:0),i=2;i<a;i++)n[i-2]=arguments[i];return e.apply(t,n)});Na||(Na=function(e){for(var t=arguments.length,a=new Array(t>1?t-1:0),n=1;n<t;n++)a[n-1]=arguments[n];return new e(...a)});var y0=ce(Array.prototype.forEach);Array.prototype.indexOf;var to=ce(Array.prototype.lastIndexOf),Si=ce(Array.prototype.pop),Lt=ce(Array.prototype.push),ro=ce(Array.prototype.slice),ao=ce(Array.prototype.splice),vt=Array.isArray,Aa=_i(Set),za=ce(Set.prototype.add),qt=ce(Set.prototype.has),Q0=ce(String.prototype.toLowerCase),Ma=ce(String.prototype.toString),Ti=ce(String.prototype.match),Pt=ce(String.prototype.replace),Ai=ce(String.prototype.indexOf),no=ce(String.prototype.trim),io=ce(Number.prototype.toString),so=ce(Boolean.prototype.toString),zi=typeof BigInt>"u"?null:ce(BigInt.prototype.toString),Mi=typeof Symbol>"u"?null:ce(Symbol.prototype.toString),_e=ce(Object.prototype.hasOwnProperty),Ft=ce(Object.prototype.toString),Me=ce(RegExp.prototype.test),x0=_i(TypeError);function ce(r){return function(e){e instanceof RegExp&&(e.lastIndex=0);for(var t=arguments.length,a=new Array(t>1?t-1:0),n=1;n<t;n++)a[n-1]=arguments[n];return Ba(r,e,a)}}function _i(r){return function(){for(var e=arguments.length,t=new Array(e),a=0;a<e;a++)t[a]=arguments[a];return Na(r,t)}}function J(r,e){let t=arguments.length>2&&arguments[2]!==void 0?arguments[2]:Q0;if(ki&&ki(r,null),!vt(e))return r;let a=e.length;for(;a--;){let n=e[a];if(typeof n=="string"){let i=t(n);i!==n&&(eo(e)||(e[a]=i),n=i)}r[n]=!0}return r}function lo(r){for(let e=0;e<r.length;e++)_e(r,e)||(r[e]=null);return r}function Ye(r){let e=ft(null);for(let a of Li(r)){var t=Q1(a,2);let n=t[0],i=t[1];_e(r,n)&&(vt(i)?e[n]=lo(i):i&&typeof i=="object"&&i.constructor===Object?e[n]=Ye(i):e[n]=i)}return e}function oo(r){switch(typeof r){case"string":return r;case"number":return io(r);case"boolean":return so(r);case"bigint":return zi?zi(r):"0";case"symbol":return Mi?Mi(r):"Symbol()";case"undefined":return Ft(r);case"function":case"object":{if(r===null)return Ft(r);let e=r,t=t0(e,"toString");if(typeof t=="function"){let a=t(e);return typeof a=="string"?a:Ft(a)}return Ft(r)}default:return Ft(r)}}function t0(r,e){for(;r!==null;){let a=Pi(r,e);if(a){if(a.get)return ce(a.get);if(typeof a.value=="function")return ce(a.value)}r=qi(r)}function t(){return null}return t}function uo(r,e){for(;r!==null;){let t=Pi(r,e);if(t)return t.get?ce(t.get):null;r=qi(r)}return null}function co(r){try{return Me(r,""),!0}catch{return!1}}var Ei=Ae(["a","abbr","acronym","address","area","article","aside","audio","b","bdi","bdo","big","blink","blockquote","body","br","button","canvas","caption","center","cite","code","col","colgroup","content","data","datalist","dd","decorator","del","details","dfn","dialog","dir","div","dl","dt","element","em","fieldset","figcaption","figure","font","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","img","input","ins","kbd","label","legend","li","main","map","mark","marquee","menu","menuitem","meter","nav","nobr","ol","optgroup","option","output","p","picture","pre","progress","q","rp","rt","ruby","s","samp","search","section","select","shadow","slot","small","source","spacer","span","strike","strong","style","sub","summary","sup","table","tbody","td","template","textarea","tfoot","th","thead","time","tr","track","tt","u","ul","var","video","wbr"]),Ea=Ae(["svg","a","altglyph","altglyphdef","altglyphitem","animatecolor","animatemotion","animatetransform","circle","clippath","defs","desc","ellipse","enterkeyhint","exportparts","filter","font","g","glyph","glyphref","hkern","image","inputmode","line","lineargradient","marker","mask","metadata","mpath","part","path","pattern","polygon","polyline","radialgradient","rect","stop","style","switch","symbol","text","textpath","title","tref","tspan","view","vkern"]),Ra=Ae(["feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence"]),ho=Ae(["animate","color-profile","cursor","discard","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignobject","hatch","hatchpath","mesh","meshgradient","meshpatch","meshrow","missing-glyph","script","set","solidcolor","unknown","use"]),Da=Ae(["math","menclose","merror","mfenced","mfrac","mglyph","mi","mlabeledtr","mmultiscripts","mn","mo","mover","mpadded","mphantom","mroot","mrow","ms","mspace","msqrt","mstyle","msub","msup","msubsup","mtable","mtd","mtext","mtr","munder","munderover","mprescripts"]),mo=Ae(["maction","maligngroup","malignmark","mlongdiv","mscarries","mscarry","msgroup","mstack","msline","msrow","semantics","annotation","annotation-xml","mprescripts","none"]),Ri=Ae(["#text"]),Di=Ae(["accept","action","align","alt","autocapitalize","autocomplete","autopictureinpicture","autoplay","background","bgcolor","border","capture","cellpadding","cellspacing","checked","cite","class","clear","color","cols","colspan","command","commandfor","controls","controlslist","coords","crossorigin","datetime","decoding","default","dir","disabled","disablepictureinpicture","disableremoteplayback","download","draggable","enctype","enterkeyhint","exportparts","face","for","headers","height","hidden","high","href","hreflang","id","inert","inputmode","integrity","ismap","kind","label","lang","list","loading","loop","low","max","maxlength","media","method","min","minlength","multiple","muted","name","nonce","noshade","novalidate","nowrap","open","optimum","part","pattern","placeholder","playsinline","popover","popovertarget","popovertargetaction","poster","preload","pubdate","radiogroup","readonly","rel","required","rev","reversed","role","rows","rowspan","spellcheck","scope","selected","shape","size","sizes","slot","span","srclang","start","src","srcset","step","style","summary","tabindex","title","translate","type","usemap","valign","value","width","wrap","xmlns"]),Ca=Ae(["accent-height","accumulate","additive","alignment-baseline","amplitude","ascent","attributename","attributetype","azimuth","basefrequency","baseline-shift","begin","bias","by","class","clip","clippathunits","clip-path","clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","cx","cy","d","dx","dy","diffuseconstant","direction","display","divisor","dominant-baseline","dur","edgemode","elevation","end","exponent","fill","fill-opacity","fill-rule","filter","filterunits","flood-color","flood-opacity","font-family","font-size","font-size-adjust","font-stretch","font-style","font-variant","font-weight","fx","fy","g1","g2","glyph-name","glyphref","gradientunits","gradienttransform","height","href","id","image-rendering","in","in2","intercept","k","k1","k2","k3","k4","kerning","keypoints","keysplines","keytimes","lang","lengthadjust","letter-spacing","kernelmatrix","kernelunitlength","lighting-color","local","marker-end","marker-mid","marker-start","markerheight","markerunits","markerwidth","maskcontentunits","maskunits","max","mask","mask-type","media","method","mode","min","name","numoctaves","offset","operator","opacity","order","orient","orientation","origin","overflow","paint-order","path","pathlength","patterncontentunits","patterntransform","patternunits","pointer-events","points","preservealpha","preserveaspectratio","primitiveunits","r","rx","ry","radius","refx","refy","repeatcount","repeatdur","restart","result","rotate","scale","seed","shape-rendering","slope","specularconstant","specularexponent","spreadmethod","startoffset","stddeviation","stitchtiles","stop-color","stop-opacity","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke","stroke-width","style","surfacescale","systemlanguage","tabindex","tablevalues","targetx","targety","transform","transform-origin","text-anchor","text-decoration","text-orientation","text-rendering","textlength","type","u1","u2","unicode","values","vector-effect","viewbox","visibility","version","vert-adv-y","vert-origin-x","vert-origin-y","width","word-spacing","wrap","writing-mode","xchannelselector","ychannelselector","x","x1","x2","xmlns","y","y1","y2","z","zoomandpan"]),Ci=Ae(["accent","accentunder","align","bevelled","close","columnalign","columnlines","columnspacing","columnspan","denomalign","depth","dir","display","displaystyle","encoding","fence","frame","height","href","id","largeop","length","linethickness","lquote","lspace","mathbackground","mathcolor","mathsize","mathvariant","maxsize","minsize","movablelimits","notation","numalign","open","rowalign","rowlines","rowspacing","rowspan","rspace","rquote","scriptlevel","scriptminsize","scriptsizemultiplier","selection","separator","separators","stretchy","subscriptshift","supscriptshift","symmetric","voffset","width","xmlns"]),wr=Ae(["xlink:href","xml:id","xlink:title","xml:space","xmlns:xlink"]),po=Ee(/{{[\w\W]*|^[\w\W]*}}/g),fo=Ee(/<%[\w\W]*|^[\w\W]*%>/g),vo=Ee(/\${[\w\W]*/g),go=Ee(/^data-[\-\w.\u00B7-\uFFFF]+$/),bo=Ee(/^aria-[\-\w]+$/),Ii=Ee(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),yo=Ee(/^(?:\w+script|data):/i),xo=Ee(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),wo=Ee(/^html$/i),ko=Ee(/^[a-z][.\w]*(-[.\w]+)+$/i),Ia=Ee(/<[/\w!]/g),Oi=Ee(/<[/\w]/g),So=Ee(/<\/no(script|embed|frames)/i),Bi=Ee(/\/>/i),be={element:1,attribute:2,text:3,cdataSection:4,entityReference:5,entityNode:6,processingInstruction:7,comment:8,document:9,documentType:10,documentFragment:11,notation:12},To=Ae(J({},["style","script","xmp","iframe","noembed","noframes","plaintext","noscript"])),Ao=function(){return typeof window>"u"?null:window},zo=function(e,t){if(typeof e!="object"||typeof e.createPolicy!="function")return null;let a=null,n="data-tt-policy-suffix";t&&t.hasAttribute(n)&&(a=t.getAttribute(n));let i="dompurify"+(a?"#"+a:"");try{return e.createPolicy(i,{createHTML(l){return l},createScriptURL(l){return l}})}catch{return console.warn("TrustedTypes policy "+i+" could not be created."),null}},Ni=function(){return{afterSanitizeAttributes:[],afterSanitizeElements:[],afterSanitizeShadowDOM:[],beforeSanitizeAttributes:[],beforeSanitizeElements:[],beforeSanitizeShadowDOM:[],uponSanitizeAttribute:[],uponSanitizeElement:[],uponSanitizeShadowNode:[]}},B0=function(e,t,a,n){return _e(e,t)&&vt(e[t])?J(n.base?Ye(n.base):{},e[t],n.transform):a},Oa=function(e,t,a){let n=_e(e,t)?e[t]:void 0;return n&&typeof n=="object"?Ye(n):a()};function Hi(){let r=arguments.length>0&&arguments[0]!==void 0?arguments[0]:Ao(),e=A=>Hi(A);if(e.version="3.4.17",e.removed=[],!r||!r.document||r.document.nodeType!==be.document||!r.Element)return e.isSupported=!1,e;let t=r.document,a=t,n=a.currentScript;r.DocumentFragment;let i=r.HTMLTemplateElement,l=r.Node,u=r.Element,h=r.NodeFilter;r.NamedNodeMap===void 0&&(r.NamedNodeMap||r.MozNamedAttrMap),r.HTMLFormElement;let d=r.DOMParser,f=r.trustedTypes,b=u.prototype,k=t0(b,"cloneNode"),w=t0(b,"remove"),M=t0(b,"removeAttributeNode"),D=t0(b,"nextSibling"),E=t0(b,"childNodes"),N=t0(b,"parentNode"),B=t0(b,"shadowRoot"),F=t0(b,"attributes"),H=l&&l.prototype?t0(l.prototype,"nodeType"):null,V=l&&l.prototype?t0(l.prototype,"nodeName"):null,j=l&&l.prototype?t0(l.prototype,"ownerDocument"):null,$=function(p){return H?H(p):p.nodeType},X=function(p){return V?V(p):p.nodeName},ee=uo(b,"namespaceURI"),ae=function(p){return ee?ee(p):p.namespaceURI};if(typeof i=="function"){let A=t.createElement("template");A.content&&A.content.ownerDocument&&(t=A.content.ownerDocument)}let Q,ie="",$e,Ue=!1,ze=0,n0=function(){if(ze>0)throw x0('A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.')},Ge=function(p){n0(),ze++;try{return Q.createHTML(p)}finally{ze--}},M0=function(p){n0(),ze++;try{return Q.createScriptURL(p)}finally{ze--}},Tt=function(){return Ue||($e=zo(f,n),Ue=!0),$e},je=t,Qe=je.implementation,E0=je.createNodeIterator,We=je.createDocumentFragment,rt=je.getElementsByTagName,Qt=a.importNode,le=Ni();e.isSupported=typeof Li=="function"&&typeof N=="function"&&Qe&&Qe.createHTMLDocument!==void 0;let R0=po,Jt=fo,D0=vo,er=go,tr=bo,rr=yo,U0=xo,at=ko,ar=Ii,ue=null,At=J({},[...Ei,...Ea,...Ra,...Da,...Ri]),oe=null,nt=J({},[...Di,...Ca,...Ci,...wr]),Ce=Object.seal(ft(null,{tagNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeNameCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},allowCustomizedBuiltInElements:{writable:!0,configurable:!1,enumerable:!0,value:!1}})),G0=null,nr=null,Je=Object.seal(ft(null,{tagCheck:{writable:!0,configurable:!1,enumerable:!0,value:null},attributeCheck:{writable:!0,configurable:!1,enumerable:!0,value:null}})),zt=!0,it=!0,ir=!1,Mt=!0,qe=!1,e0=!0,j0=!1,Yr=!1,sr=null,lr=null,Xr=!1,st=!1,or=!1,ur=!1,In=!0,On=!1,Bn="user-content-",Zr=!0,Kr=!1,W0=null,lt={},V0=null,Nn=J({},["annotation-xml","audio","colgroup","desc","foreignobject","head","iframe","math","mi","mn","mo","ms","mtext","noembed","noframes","noscript","plaintext","script","selectedcontent","style","svg","template","thead","title","video","xmp"]),Ln=null,qn=J({},["audio","video","img","source","image","track"]),Pn=null,Fn=J({},["alt","class","for","id","label","name","pattern","placeholder","role","summary","title","value","style","xmlns"]),cr="http://www.w3.org/1998/Math/MathML",hr="http://www.w3.org/2000/svg",u0="http://www.w3.org/1999/xhtml",ot=u0,Qr=!1,Jr=null,xl=J({},[cr,hr,u0],Ma),_n=Ae(["mi","mo","mn","ms","mtext"]),ea=J({},_n),Hn=Ae(["annotation-xml"]),ta=J({},Hn),wl=J({},["title","style","font","a","script"]),Et=null,kl=["application/xhtml+xml","text/html"],Sl="text/html",ge=null,ut=null,Tl=t.createElement("form"),$n=function(p){return p instanceof RegExp||p instanceof Function},ra=function(){let p=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};if(ut&&ut===p)return;(!p||typeof p!="object")&&(p={}),p=Ye(p),Et=kl.indexOf(p.PARSER_MEDIA_TYPE)===-1?Sl:p.PARSER_MEDIA_TYPE,ge=Et==="application/xhtml+xml"?Ma:Q0,ue=B0(p,"ALLOWED_TAGS",At,{transform:ge}),oe=B0(p,"ALLOWED_ATTR",nt,{transform:ge}),Jr=B0(p,"ALLOWED_NAMESPACES",xl,{transform:Ma}),Pn=B0(p,"ADD_URI_SAFE_ATTR",Fn,{transform:ge,base:Fn}),Ln=B0(p,"ADD_DATA_URI_TAGS",qn,{transform:ge,base:qn}),V0=B0(p,"FORBID_CONTENTS",Nn,{transform:ge}),G0=B0(p,"FORBID_TAGS",Ye({}),{transform:ge}),nr=B0(p,"FORBID_ATTR",Ye({}),{transform:ge}),lt=_e(p,"USE_PROFILES")?p.USE_PROFILES&&typeof p.USE_PROFILES=="object"?Ye(p.USE_PROFILES):p.USE_PROFILES:!1,zt=p.ALLOW_ARIA_ATTR!==!1,it=p.ALLOW_DATA_ATTR!==!1,ir=p.ALLOW_UNKNOWN_PROTOCOLS||!1,Mt=p.ALLOW_SELF_CLOSE_IN_ATTR!==!1,qe=p.SAFE_FOR_TEMPLATES||!1,e0=p.SAFE_FOR_XML!==!1,j0=p.WHOLE_DOCUMENT||!1,st=p.RETURN_DOM||!1,or=p.RETURN_DOM_FRAGMENT||!1,ur=p.RETURN_TRUSTED_TYPE||!1,Xr=p.FORCE_BODY||!1,In=p.SANITIZE_DOM!==!1,On=p.SANITIZE_NAMED_PROPS||!1,Zr=p.KEEP_CONTENT!==!1,Kr=p.IN_PLACE||!1,ar=co(p.ALLOWED_URI_REGEXP)?p.ALLOWED_URI_REGEXP:Ii,ot=typeof p.NAMESPACE=="string"?p.NAMESPACE:u0,ea=Oa(p,"MATHML_TEXT_INTEGRATION_POINTS",()=>J({},_n)),ta=Oa(p,"HTML_INTEGRATION_POINTS",()=>J({},Hn));let x=Oa(p,"CUSTOM_ELEMENT_HANDLING",()=>ft(null));if(Ce=ft(null),_e(x,"tagNameCheck")&&$n(x.tagNameCheck)&&(Ce.tagNameCheck=x.tagNameCheck),_e(x,"attributeNameCheck")&&$n(x.attributeNameCheck)&&(Ce.attributeNameCheck=x.attributeNameCheck),_e(x,"allowCustomizedBuiltInElements")&&typeof x.allowCustomizedBuiltInElements=="boolean"&&(Ce.allowCustomizedBuiltInElements=x.allowCustomizedBuiltInElements),Ee(Ce),qe&&(it=!1),or&&(st=!0),lt&&(ue=J({},Ri),oe=ft(null),lt.html===!0&&(J(ue,Ei),J(oe,Di)),lt.svg===!0&&(J(ue,Ea),J(oe,Ca),J(oe,wr)),lt.svgFilters===!0&&(J(ue,Ra),J(oe,Ca),J(oe,wr)),lt.mathMl===!0&&(J(ue,Da),J(oe,Ci),J(oe,wr))),Je.tagCheck=null,Je.attributeCheck=null,_e(p,"ADD_TAGS")&&(typeof p.ADD_TAGS=="function"?Je.tagCheck=p.ADD_TAGS:vt(p.ADD_TAGS)&&(ue===At&&(ue=Ye(ue)),J(ue,p.ADD_TAGS,ge))),_e(p,"ADD_ATTR")&&(typeof p.ADD_ATTR=="function"?Je.attributeCheck=p.ADD_ATTR:vt(p.ADD_ATTR)&&(oe===nt&&(oe=Ye(oe)),J(oe,p.ADD_ATTR,ge))),_e(p,"ADD_FORBID_CONTENTS")&&vt(p.ADD_FORBID_CONTENTS)&&(V0===Nn&&(V0=Ye(V0)),J(V0,p.ADD_FORBID_CONTENTS,ge)),Zr&&(ue["#text"]=!0),j0&&J(ue,["html","head","body"]),ue.table&&(J(ue,["tbody"]),delete G0.tbody),p.TRUSTED_TYPES_POLICY){if(typeof p.TRUSTED_TYPES_POLICY.createHTML!="function")throw x0('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');if(typeof p.TRUSTED_TYPES_POLICY.createScriptURL!="function")throw x0('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');let S=Q;Q=p.TRUSTED_TYPES_POLICY;try{ie=Ge("")}catch(T){throw Q=S,T}}else p.TRUSTED_TYPES_POLICY===null?(Q=void 0,ie=""):(Q===void 0&&(Q=Tt()),Q&&typeof ie=="string"&&(ie=Ge("")));Ae&&Ae(p),ut=p},Un=J({},[...Ea,...Ra,...ho]),Gn=J({},[...Da,...mo]),Al=function(p,x,S){return x.namespaceURI===u0?p==="svg":x.namespaceURI===cr?p==="svg"&&(S==="annotation-xml"||ea[S]):!!Un[p]},zl=function(p,x,S){return x.namespaceURI===u0?p==="math":x.namespaceURI===hr?p==="math"&&ta[S]:!!Gn[p]},Ml=function(p,x,S){return x.namespaceURI===hr&&!ta[S]||x.namespaceURI===cr&&!ea[S]?!1:!Gn[p]&&(wl[p]||!Un[p])},El=function(p){let x=ae(p),S=Q0(X(p)),T=N(p),P,U;return T&&$(T)===be.element?(P={namespaceURI:ae(T)},U=Q0(X(T))):(P={namespaceURI:ot},U="template"),Jr[x]?x===hr?Al(S,P,U):x===cr?zl(S,P,U):x===u0?Ml(S,P,U):!!(Et==="application/xhtml+xml"&&Jr[x]):!1},C0=function(p){Lt(e.removed,{element:p});try{N(p).removeChild(p)}catch{if(w(p),!N(p))throw x0("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place")}},jn=function(p,x,S){try{M(p,x)}catch{try{p.removeAttribute(S)}catch{}}},aa=function(p){ia(p);let x=E(p);x&&y0(ro(x),T=>{try{w(T)}catch{}});let S=$(p)===be.element?F(p):null;if(S)for(let T=S.length-1;T>=0;--T){let P=S[T],U=P&&P.name;typeof U=="string"&&jn(p,P,U)}},ct=function(p,x,S){if(!S)try{S=x.getAttributeNode(p)}catch{S=null}Lt(e.removed,{attribute:S||null,from:x});try{S?M(x,S):x.removeAttribute(p)}catch{try{x.removeAttribute(p)}catch{}}if(p==="is")if(st||or)try{C0(x)}catch{}else try{x.setAttribute(p,"")}catch{}},Wn=function(p){let x=F(p);if(x)for(let S=x.length-1;S>=0;--S){let T=x[S],P=T&&T.name;typeof P!="string"||oe[ge(P)]||jn(p,T,P)}},na=function(p,x){let S=arguments.length>2&&arguments[2]!==void 0?arguments[2]:!1,T=[p];for(;T.length>0;){let P=T.pop();if(x(P)===!1)continue;if(S&&$(P)===be.element){let Z=B(P);I0(Z)&&T.push(Z)}let U=E(P);if(U)for(let Z=U.length-1;Z>=0;--Z)T.push(U[Z])}},ia=function(p){na(p,x=>{$(x)===be.element&&Wn(x)})},sa=function(p){let x=[];return na(p,S=>{x.push(S)},!0),x},Rl=function(p,x){let S=Aa();y0(sa(p),T=>{$(T)===be.element&&za(S,T)}),y0(x,T=>{$(T)===be.element&&!qt(S,T)&&Wn(T)})},Vn=function(p,x){let S=!1;return y0(e.removed,T=>{T.element&&(S=S||T.element===p,ia(T.element))}),Rl(p,x),S},Dl=8,Cl=function(p,x){let S=W0,T=null,P=()=>(T||(T=Aa(),y0(x,U=>{za(T,U)})),T);for(let U=0;;U++){let Z=sa(p),we=[p],c0=!1;if(y0(Z,Ie=>{$(Ie)===be.documentFragment?Lt(we,Ie):!c0&&!qt(S,Ie)&&(c0=qt(P(),Ie))}),!c0)return;if(U>=Dl)throw x0("the tree kept changing during in-place sanitization; refusing to return it");y0(we,(Ie,Pe)=>{Il(Ie,Pe>0,p,P())})}},Il=function(p,x,S,T){let P=la(p),U;for(;U=P.nextNode();)!qt(T,U)||qt(W0,U)||(x&&i0(le.uponSanitizeShadowNode,U,null),ua(U,S),ca(U,S),I0(U.content)&&Dt(U.content))},Ol=function(p){W0&&za(W0,p)},Yn=function(p,x){return e0?p==="patchsrc"?!0:p==="for"&&x!=="label"&&x!=="output":!1},Bl=function(p){e0&&na(p,x=>{let S=$(x);if(S===be.processingInstruction||S===be.comment&&Me(Oi,x.data)){try{w(x)}catch{}return!1}if(S===be.element){let T=x,P=ge(X(x));try{T.hasAttribute&&T.hasAttribute("patchsrc")&&T.removeAttribute("patchsrc"),T.hasAttribute&&T.hasAttribute("for")&&Yn("for",P)&&T.removeAttribute("for")}catch{}}return!0})},Xn=function(p){let x=null,S=null;if(Xr)p="<remove></remove>"+p;else{let U=Ti(p,/^[\r\n\t ]+/);S=U&&U[0]}Et==="application/xhtml+xml"&&ot===u0&&(p='<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>'+p+"</body></html>");let T=Q?Ge(p):p;if(ot===u0)try{x=new d().parseFromString(T,Et)}catch{}if(!x||!x.documentElement){x=Qe.createDocument(ot,"template",null);try{x.documentElement.innerHTML=Qr?ie:T}catch{}}let P=x.body||x.documentElement;return p&&S&&P.insertBefore(t.createTextNode(S),P.childNodes[0]||null),ot===u0?rt.call(x,j0?"html":"body")[0]:j0?x.documentElement:P},la=function(p){let x=j?j(p):p.ownerDocument;return E0.call(x||p,p,h.SHOW_ELEMENT|h.SHOW_COMMENT|h.SHOW_TEXT|h.SHOW_PROCESSING_INSTRUCTION|h.SHOW_CDATA_SECTION,null)},mr=function(p){return p=Pt(p,R0," "),p=Pt(p,Jt," "),p=Pt(p,D0," "),p},oa=function(p){var x;Zn(p);let S=(x=p.querySelectorAll)===null||x===void 0?void 0:x.call(p,"template");S&&y0(S,T=>{I0(T.content)&&oa(T.content)})},Zn=function(p){p.normalize();let x=j?j(p):p.ownerDocument,S=E0.call(x||p,p,h.SHOW_TEXT|h.SHOW_COMMENT|h.SHOW_CDATA_SECTION|h.SHOW_PROCESSING_INSTRUCTION,null),T=S.nextNode();for(;T;)T.data=mr(T.data),T=S.nextNode()},dr=function(p){let x=V?V(p):null;return typeof x!="string"||ge(x)!=="form"?!1:typeof p.nodeName!="string"||typeof p.textContent!="string"||typeof p.removeChild!="function"||p.attributes!==F(p)||typeof p.removeAttribute!="function"||typeof p.removeAttributeNode!="function"||typeof p.getAttributeNode!="function"||typeof p.setAttribute!="function"||typeof p.namespaceURI!="string"||typeof p.insertBefore!="function"||typeof p.hasChildNodes!="function"||p.nodeType!==H(p)||p.childNodes!==E(p)},I0=function(p){if(!H||typeof p!="object"||p===null)return!1;try{return H(p)===be.documentFragment}catch{return!1}},Rt=function(p){if(!H||typeof p!="object"||p===null)return!1;try{return typeof H(p)=="number"}catch{return!1}};function i0(A,p,x){A.length!==0&&y0(A,S=>{S.call(e,p,x,ut)})}let Nl=function(p,x){return!!(e0&&p.hasChildNodes()&&!Rt(p.firstElementChild)&&Me(Ia,p.textContent)&&Me(Ia,p.innerHTML)||e0&&To[x]&&$(p)===be.element&&ae(p)===u0&&(Rt(p.firstElementChild)||typeof p.textContent=="string"&&Me(Ia,p.textContent))||p.nodeType===be.processingInstruction||e0&&p.nodeType===be.comment&&Me(Oi,p.data))},pr=function(p,x){if(p instanceof RegExp)return Me(p,x);if(p instanceof Function){for(var S=arguments.length,T=new Array(S>2?S-2:0),P=2;P<S;P++)T[P-2]=arguments[P];return!!p(x,...T)}return!1},Ll=function(p,x,S){if(!G0[x]&&Jn(x)&&pr(Ce.tagNameCheck,x))return!1;if(Zr&&!V0[x]&&!V0[Q0(x)]){let T=N(p),P=E(p);if(P&&T){let U=P.length;for(let Z=U-1;Z>=0;--Z){let we=p===S?k(P[Z],!0):P[Z];T.insertBefore(we,D(p))}}}return C0(p),!0},Kn=function(p,x,S,T){return p.length===0?x:x===S||x===T?Ye(x):x},ht=function(p,x){return p===x||N(p)!==null?!1:(Kr&&ia(p),!0)},ua=function(p,x){if(Ol(p),i0(le.beforeSanitizeElements,p,null),ht(p,x))return!0;if(dr(p))return C0(p),!0;let S=ge(X(p));if(ue=Kn(le.uponSanitizeElement,ue,At,sr),i0(le.uponSanitizeElement,p,{tagName:S,allowedTags:ue}),ht(p,x))return!0;if(Nl(p,S))return C0(p),!0;if(G0[S]||!(Je.tagCheck instanceof Function&&Je.tagCheck(S))&&!ue[S]){let T=Ll(p,S,x);return T===!1&&(i0(le.afterSanitizeElements,p,null),ht(p,x))?!0:T}if($(p)===be.element&&!El(p)||(S==="noscript"||S==="noembed"||S==="noframes")&&Me(So,p.innerHTML))return C0(p),!0;if(qe&&p.nodeType===be.text){let T=mr(p.textContent);p.textContent!==T&&(Lt(e.removed,{element:p.cloneNode()}),p.textContent=T)}return i0(le.afterSanitizeElements,p,null),ht(p,x)},Qn=function(p,x,S){if(nr[x]||Yn(x,p)||In&&(x==="id"||x==="name")&&(S in t||S in Tl))return!1;let T=oe[x]||Je.attributeCheck instanceof Function&&Je.attributeCheck(x,p);return it&&Me(er,x)||zt&&Me(tr,x)?!0:T?Pn[x]||Me(ar,Pt(S,U0,""))||(x==="src"||x==="xlink:href"||x==="href")&&p!=="script"&&Ai(S,"data:")===0&&Ln[p]||ir&&!Me(rr,Pt(S,U0,""))?!0:!S:Jn(p)&&pr(Ce.tagNameCheck,p)&&pr(Ce.attributeNameCheck,x,p)||x==="is"&&Ce.allowCustomizedBuiltInElements&&pr(Ce.tagNameCheck,S)},ql=J({},["annotation-xml","color-profile","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","missing-glyph"]),Jn=function(p){return!ql[Q0(p)]&&Me(at,p)},Pl=function(p,x,S,T){if(Q&&typeof f=="object"&&typeof f.getAttributeType=="function"&&!S)switch(f.getAttributeType(p,x)){case"TrustedHTML":return Ge(T);case"TrustedScriptURL":return M0(T)}return T},Fl=function(p,x,S,T){try{return S?p.setAttributeNS(S,x,T):p.setAttribute(x,T),dr(p)?(C0(p),!1):!0}catch{return ct(x,p),!1}},ei=function(p,x){return e0&&Me(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i,x)?!0:Q0(p)==="attributename"&&Ti(x,"href")!==null},ca=function(p,x){if(i0(le.beforeSanitizeAttributes,p,null),ht(p,x))return;let S=p.attributes;if(!S||dr(p))return;oe=Kn(le.uponSanitizeAttribute,oe,nt,lr);let T={attrName:"",attrValue:"",keepAttr:!0,allowedAttributes:oe,forceKeepAttr:void 0},P=S.length,U=ge(p.nodeName);for(;P--;){let Z=S[P],we=Z.name,c0=Z.namespaceURI,Ie=Z.value,Pe=ge(we),mt=Ie,Fe=we==="value"?mt:no(mt),ti=!1;if(T.attrName=Pe,T.attrValue=Fe,T.keepAttr=!0,T.forceKeepAttr=void 0,i0(le.uponSanitizeAttribute,p,T),Fe=T.attrValue,On&&(Pe==="id"||Pe==="name")&&Ai(Fe,Bn)!==0&&(ct(we,p,Z),Fe=Bn+Fe,ti=!0),ei(we,Fe)){ct(we,p,Z);continue}if(!T.forceKeepAttr){if(!T.keepAttr){ct(we,p,Z);continue}if(!Mt&&Me(Bi,Fe)){ct(we,p,Z);continue}if(qe&&(Fe=mr(Fe)),!Qn(U,Pe,Fe)){ct(we,p,Z);continue}Fe=Pl(U,Pe,c0,Fe),Fe!==mt&&Fl(p,we,c0,Fe)&&ti&&Si(e.removed)}}i0(le.afterSanitizeAttributes,p,null),ht(p,x)},Dt=function(p){let x=null,S=la(p);for(i0(le.beforeSanitizeShadowDOM,p,null);x=S.nextNode();)if(i0(le.uponSanitizeShadowNode,x,null),ua(x,p),ca(x,p),I0(x.content)&&Dt(x.content),$(x)===be.element){let T=B(x);I0(T)&&(ha(T),Dt(T))}qe&&Zn(p),i0(le.afterSanitizeShadowDOM,p,null)},ha=function(p){let x=[{node:p,shadow:null}];for(;x.length>0;){let S=x.pop();if(S.shadow){Dt(S.shadow);continue}let T=S.node,P=$(T)===be.element,U=E(T);if(U)for(let Z=U.length-1;Z>=0;--Z)x.push({node:U[Z],shadow:null});if(P){let Z=V?V(T):null;if(typeof Z=="string"&&ge(Z)==="template"){let we=T.content;I0(we)&&x.push({node:we,shadow:null})}}if(P){let Z=B(T);I0(Z)&&x.push({node:null,shadow:Z},{node:Z,shadow:null})}}};return e.sanitize=function(A){let p=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},x=null,S=null,T=null,P=null;if(Qr=!A,Qr&&(A="<!-->"),typeof A!="string"&&!Rt(A)&&(A=oo(A),typeof A!="string"))throw x0("dirty is not a string, aborting");if(!e.isSupported)return A;Yr?(ue=sr,oe=lr):ra(p),(le.uponSanitizeElement.length>0||le.uponSanitizeAttribute.length>0)&&(ue=Ye(ue)),le.uponSanitizeAttribute.length>0&&(oe=Ye(oe)),e.removed=[];let U=Kr&&typeof A!="string"&&Rt(A),Z=[],we=W0;if(U){Bl(A);let Pe=X(A);if(typeof Pe=="string"){let mt=ge(Pe);if(!ue[mt]||G0[mt])throw aa(A),x0("root node is forbidden and cannot be sanitized in-place")}if(dr(A))throw aa(A),x0("root node is clobbered and cannot be sanitized in-place");Z=sa(A),W0=Aa()}else if(Rt(A))x=Xn("<!---->"),S=x.ownerDocument.importNode(A,!0),S.nodeType===be.element&&S.nodeName==="BODY"||S.nodeName==="HTML"?x=S:x.appendChild(S),ha(x);else{if(!st&&!qe&&!j0&&A.indexOf("<")===-1)return Q&&ur?Ge(A):A;if(x=Xn(A),!x)return st?null:ur?ie:""}x&&Xr&&C0(x.firstChild);let c0=U?A:x;try{U&&ha(A);let Pe=la(c0);for(;T=Pe.nextNode();)ua(T,c0),ca(T,c0),I0(T.content)&&Dt(T.content);U&&Cl(A,Z)}catch(Pe){throw U&&(aa(A),Vn(A,Z)),Pe}finally{W0=we}if(U){if(Vn(A,Z))throw x0("a node selected for removal could not be safely returned; refusing to sanitize in place");return qe&&oa(A),A}if(st){if(qe&&oa(x),or)for(P=We.call(x.ownerDocument);x.firstChild;)P.appendChild(x.firstChild);else P=x;return(oe.shadowroot||oe.shadowrootmode)&&(P=Qt.call(a,P,!0)),P}let Ie=j0?x.outerHTML:x.innerHTML;return j0&&ue["!doctype"]&&x.ownerDocument&&x.ownerDocument.doctype&&x.ownerDocument.doctype.name&&Me(wo,x.ownerDocument.doctype.name)&&(Ie="<!DOCTYPE "+x.ownerDocument.doctype.name+`>
`+Ie),qe&&(Ie=mr(Ie)),Q&&ur?Ge(Ie):Ie},e.setConfig=function(){let A=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};ra(A),Yr=!0,sr=ue,lr=oe},e.clearConfig=function(){ut=null,Yr=!1,sr=null,lr=null,Q=$e,ie=""},e.isValidAttribute=function(A,p,x){ut||ra({});let S=ge(A),T=ge(p);return typeof x=="string"&&(ei(p,x)||!Mt&&Me(Bi,x))?!1:Qn(S,T,x)},e.addHook=function(A,p){typeof p=="function"&&_e(le,A)&&Lt(le[A],p)},e.removeHook=function(A,p){if(_e(le,A)){if(p!==void 0){let x=to(le[A],p);return x===-1?void 0:ao(le[A],x,1)[0]}return Si(le[A])}},e.removeHooks=function(A){_e(le,A)&&(le[A]=[])},e.removeAllHooks=function(){le=Ni()},e}var $i=Hi();var C=class r extends Error{constructor(e,t){var a="KaTeX parse error: "+e,n,i,l=t&&t.loc;if(l&&l.start<=l.end){var u=l.lexer.input;n=l.start,i=l.end,n===u.length?a+=" at end of input: ":a+=" at position "+(n+1)+": ";var h=u.slice(n,i).replace(/[^]/g,"$&\u0332"),d;n>15?d="\u2026"+u.slice(n-15,n):d=u.slice(0,n);var f;i+15<u.length?f=u.slice(i,i+15)+"\u2026":f=u.slice(i),a+=d+h+f}super(a),this.name="ParseError",this.position=void 0,this.length=void 0,this.rawMessage=void 0,Object.setPrototypeOf(this,r.prototype),this.position=n,n!=null&&i!=null&&(this.length=i-n),this.rawMessage=e}},Mo=/([A-Z])/g,Eo=r=>r.replace(Mo,"-$1").toLowerCase(),Ro={"&":"&amp;",">":"&gt;","<":"&lt;",'"':"&quot;","'":"&#x27;"},Do=/[&><"']/g,De=r=>String(r).replace(Do,e=>Ro[e]),Cr=r=>r.type==="ordgroup"||r.type==="color"?r.body.length===1?Cr(r.body[0]):r:r.type==="font"?Cr(r.body):r,Co=new Set(["mathord","textord","atom"]),T0=r=>Co.has(Cr(r).type),Io=r=>{var e=/^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(r);return e?e[2]!==":"||!/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(e[1])?null:e[1].toLowerCase():"_relative"},Xa={displayMode:{type:"boolean",description:"Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",cli:"-d, --display-mode"},output:{type:{enum:["htmlAndMathml","html","mathml"]},description:"Determines the markup language of the output.",cli:"-F, --format <type>"},leqno:{type:"boolean",description:"Render display math in leqno style (left-justified tags)."},fleqn:{type:"boolean",description:"Render display math flush left."},throwOnError:{type:"boolean",default:!0,cli:"-t, --no-throw-on-error",cliDescription:"Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."},errorColor:{type:"string",default:"#cc0000",cli:"-c, --error-color <color>",cliDescription:"A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",cliProcessor:r=>"#"+r},macros:{type:"object",cli:"-m, --macro <def>",cliDescription:"Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",cliDefault:[],cliProcessor:(r,e)=>(e.push(r),e)},minRuleThickness:{type:"number",description:"Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",processor:r=>Math.max(0,r),cli:"--min-rule-thickness <size>",cliProcessor:parseFloat},colorIsTextColor:{type:"boolean",description:"Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",cli:"-b, --color-is-text-color"},strict:{type:[{enum:["warn","ignore","error"]},"boolean","function"],description:"Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",cli:"-S, --strict",cliDefault:!1},trust:{type:["boolean","function"],description:"Trust the input, enabling all HTML features such as \\url.",cli:"-T, --trust"},maxSize:{type:"number",default:1/0,description:"If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",processor:r=>Math.max(0,r),cli:"-s, --max-size <n>",cliProcessor:parseInt},maxExpand:{type:"number",default:1e3,description:"Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",processor:r=>Math.max(0,r),cli:"-e, --max-expand <n>",cliProcessor:r=>r==="Infinity"?1/0:parseInt(r)},globalGroup:{type:"boolean",cli:!1}};function Oo(r){if(typeof r!="string")return r.enum[0];switch(r){case"boolean":return!1;case"string":return"";case"number":return 0;case"object":return{};default:throw new Error("Unexpected schema type; settings must declare an explicit default.")}}function Bo(r){if(Object.prototype.hasOwnProperty.call(r,"default")&&r.default!==void 0)return r.default;var e=Array.isArray(r.type)?r.type[0]:r.type;return Oo(e)}function No(r,e,t,a){var n=Object.prototype.hasOwnProperty.call(t,e)?t[e]:void 0,i=Object.prototype.hasOwnProperty.call(a,"processor")?a.processor:void 0;r[e]=n!==void 0?i?i(n):n:Bo(a)}var Gt=class{constructor(e){e===void 0&&(e={}),this.displayMode=void 0,this.output=void 0,this.leqno=void 0,this.fleqn=void 0,this.throwOnError=void 0,this.errorColor=void 0,this.macros=void 0,this.minRuleThickness=void 0,this.colorIsTextColor=void 0,this.strict=void 0,this.trust=void 0,this.maxSize=void 0,this.maxExpand=void 0,this.globalGroup=void 0,e=e||{};for(var t of Object.keys(Xa)){var a=Xa[t];a&&No(this,t,e,a)}}reportNonstrict(e,t,a){var n=this.strict;if(typeof n=="function"&&(n=n(e,t,a)),!(!n||n==="ignore")){if(n===!0||n==="error")throw new C("LaTeX-incompatible input and strict mode is set to 'error': "+(t+" ["+e+"]"),a);n==="warn"?typeof console<"u"&&console.warn("LaTeX-incompatible input and strict mode is set to 'warn': "+(t+" ["+e+"]")):typeof console<"u"&&console.warn("LaTeX-incompatible input and strict mode is set to "+("unrecognized '"+n+"': "+t+" ["+e+"]"))}}useStrictBehavior(e,t,a){var n=this.strict;if(typeof n=="function")try{n=n(e,t,a)}catch{n="error"}return!n||n==="ignore"?!1:n===!0||n==="error"?!0:n==="warn"?(typeof console<"u"&&console.warn("LaTeX-incompatible input and strict mode is set to 'warn': "+(t+" ["+e+"]")),!1):(typeof console<"u"&&console.warn("LaTeX-incompatible input and strict mode is set to "+("unrecognized '"+n+"': "+t+" ["+e+"]")),!1)}isTrusted(e){if("url"in e&&e.url&&!e.protocol){var t=Io(e.url);if(t==null)return!1;e.protocol=t}var a=typeof this.trust=="function"?this.trust(e):this.trust;return!!a}},m0=class{constructor(e,t,a){this.id=void 0,this.size=void 0,this.cramped=void 0,this.id=e,this.size=t,this.cramped=a}sup(){return d0[Lo[this.id]]}sub(){return d0[qo[this.id]]}fracNum(){return d0[Po[this.id]]}fracDen(){return d0[Fo[this.id]]}cramp(){return d0[_o[this.id]]}text(){return d0[Ho[this.id]]}isTight(){return this.size>=2}},gn=0,Or=1,bt=2,S0=3,jt=4,r0=5,yt=6,Be=7,d0=[new m0(gn,0,!1),new m0(Or,0,!0),new m0(bt,1,!1),new m0(S0,1,!0),new m0(jt,2,!1),new m0(r0,2,!0),new m0(yt,3,!1),new m0(Be,3,!0)],Lo=[jt,r0,jt,r0,yt,Be,yt,Be],qo=[r0,r0,r0,r0,Be,Be,Be,Be],Po=[bt,S0,jt,r0,yt,Be,yt,Be],Fo=[S0,S0,r0,r0,Be,Be,Be,Be],_o=[Or,Or,S0,S0,r0,r0,Be,Be],Ho=[gn,Or,bt,S0,bt,S0,bt,S0],W={DISPLAY:d0[gn],TEXT:d0[bt],SCRIPT:d0[jt],SCRIPTSCRIPT:d0[yt]},Za=[{name:"latin",blocks:[[256,591],[768,879]]},{name:"cyrillic",blocks:[[1024,1279]]},{name:"armenian",blocks:[[1328,1423]]},{name:"brahmic",blocks:[[2304,4255]]},{name:"georgian",blocks:[[4256,4351]]},{name:"cjk",blocks:[[12288,12543],[19968,40879],[65280,65376]]},{name:"hangul",blocks:[[44032,55215]]}];function $o(r){for(var e=0;e<Za.length;e++)for(var t=Za[e],a=0;a<t.blocks.length;a++){var n=t.blocks[a];if(r>=n[0]&&r<=n[1])return t.name}return null}var Ir=[];Za.forEach(r=>r.blocks.forEach(e=>Ir.push(...e)));function zs(r){for(var e=0;e<Ir.length;e+=2)if(r>=Ir[e]&&r<=Ir[e+1])return!0;return!1}var ke=r=>r+" "+r,gt=80,Uo=function(e,t){return"M95,"+(622+e+t)+`
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l`+e/2.075+" -"+e+`
c5.3,-9.3,12,-14,20,-14
H400000v`+(40+e)+`H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M`+(834+e)+" "+t+"h400000v"+(40+e)+"h-400000z"},Go=function(e,t){return"M263,"+(601+e+t)+`c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l`+e/2.084+" -"+e+`
c4.7,-7.3,11,-11,19,-11
H40000v`+(40+e)+`H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M`+(1001+e)+" "+t+"h400000v"+(40+e)+"h-400000z"},jo=function(e,t){return"M983 "+(10+e+t)+`
l`+e/3.13+" -"+e+`
c4,-6.7,10,-10,18,-10 H400000v`+(40+e)+`
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M`+(1001+e)+" "+t+"h400000v"+(40+e)+"h-400000z"},Wo=function(e,t){return"M424,"+(2398+e+t)+`
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l`+e/4.223+" -"+e+`c4,-6.7,10,-10,18,-10 H400000
v`+(40+e)+`H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M`+(1001+e)+" "+t+`
h400000v`+(40+e)+"h-400000z"},Vo=function(e,t){return"M473,"+(2713+e+t)+`
c339.3,-1799.3,509.3,-2700,510,-2702 l`+e/5.298+" -"+e+`
c3.3,-7.3,9.3,-11,18,-11 H400000v`+(40+e)+`H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM`+(1001+e)+" "+t+"h400000v"+(40+e)+"H1017.7z"},Yo=function(e){var t=e/2;return"M400000 "+e+" H0 L"+t+" 0 l65 45 L145 "+(e-80)+" H400000z"},Xo=function(e,t,a){var n=a-54-t-e;return"M702 "+(e+t)+"H400000"+(40+e)+`
H742v`+n+`l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 `+t+"H400000v"+(40+e)+"H742z"},Zo=function(e,t,a){t=1e3*t;var n="";switch(e){case"sqrtMain":n=Uo(t,gt);break;case"sqrtSize1":n=Go(t,gt);break;case"sqrtSize2":n=jo(t,gt);break;case"sqrtSize3":n=Wo(t,gt);break;case"sqrtSize4":n=Vo(t,gt);break;case"sqrtTall":n=Xo(t,gt,a)}return n},Ko=function(e,t){switch(e){case"\u239C":return ke("M291 0 H417 V"+t+" H291z");case"\u2223":return ke("M145 0 H188 V"+t+" H145z");case"\u2225":return ke("M145 0 H188 V"+t+" H145z")+ke("M367 0 H410 V"+t+" H367z");case"\u239F":return ke("M457 0 H583 V"+t+" H457z");case"\u23A2":return ke("M319 0 H403 V"+t+" H319z");case"\u23A5":return ke("M263 0 H347 V"+t+" H263z");case"\u23AA":return ke("M384 0 H504 V"+t+" H384z");case"\u23D0":return ke("M312 0 H355 V"+t+" H312z");case"\u2016":return ke("M257 0 H300 V"+t+" H257z")+ke("M478 0 H521 V"+t+" H478z");default:return""}},Ui={doubleleftarrow:`M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,doublerightarrow:`M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,leftarrow:`M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,leftbrace:`M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,leftbraceunder:`M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,leftgroup:`M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,leftgroupunder:`M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,leftharpoon:`M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,leftharpoonplus:`M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,leftharpoondown:`M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,leftharpoondownplus:`M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,lefthook:`M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,leftlinesegment:ke("M40 281 V428 H0 V94 H40 V241 H400000 v40z"),leftbracketunder:ke("M0 0 h120 V290 H399995 v120 H0z"),leftbracketover:ke("M0 440 h120 V150 H399995 v-120 H0z"),leftmapsto:ke("M40 281 V448H0V74H40V241H400000v40z"),leftToFrom:`M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,longequal:ke("M0 50 h400000 v40H0z m0 194h40000v40H0z"),midbrace:`M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,midbraceunder:`M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,oiintSize1:`M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,oiintSize2:`M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,oiiintSize1:`M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,oiiintSize2:`M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,rightarrow:`M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,rightbrace:`M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,rightbraceunder:`M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,rightgroup:`M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,rightgroupunder:`M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,rightharpoon:`M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,rightharpoonplus:`M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,rightharpoondown:`M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,rightharpoondownplus:`M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,righthook:`M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,rightlinesegment:ke("M399960 241 V94 h40 V428 h-40 V281 H0 v-40z"),rightbracketunder:ke("M399995 0 h-120 V290 H0 v120 H400000z"),rightbracketover:ke("M399995 440 h-120 V150 H0 v-120 H399995z"),rightToFrom:`M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,twoheadleftarrow:`M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,twoheadrightarrow:`M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,tilde1:`M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,tilde2:`M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,tilde3:`M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,tilde4:`M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,vec:`M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,widehat1:`M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,widehat2:`M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,widehat3:`M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,widehat4:`M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,widecheck1:`M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,widecheck2:`M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,widecheck3:`M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,widecheck4:`M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,baraboveleftarrow:`M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,rightarrowabovebar:`M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,baraboveshortleftharpoon:`M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,rightharpoonaboveshortbar:`M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,shortbaraboveleftharpoon:`M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,shortrightharpoonabovebar:`M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`},Qo=function(e,t){switch(e){case"lbrack":return"M403 1759 V84 H666 V0 H319 V1759 v"+t+` v1759 v84 h347 v-84
H403z M403 1759 V0 H319 V1759 v`+t+" v1759 v84 h84z";case"rbrack":return"M347 1759 V0 H0 V84 H263 V1759 v"+t+` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v`+t+" v1759 h84z";case"vert":return"M145 15 v585 v"+t+` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v`+-t+` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v`+t+" v585 h43z";case"doublevert":return"M145 15 v585 v"+t+` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v`+-t+` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v`+t+` v585 h43z
M367 15 v585 v`+t+` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v`+-t+` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v`+t+" v585 h43z";case"lfloor":return"M319 602 V0 H403 V602 v"+t+` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v`+t+" v1715 H319z";case"rfloor":return"M319 602 V0 H403 V602 v"+t+` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v`+t+" v1715 H319z";case"lceil":return"M403 1759 V84 H666 V0 H319 V1759 v"+t+` v602 h84z
M403 1759 V0 H319 V1759 v`+t+" v602 h84z";case"rceil":return"M347 1759 V0 H0 V84 H263 V1759 v"+t+` v602 h84z
M347 1759 V0 h-84 V1759 v`+t+" v602 h84z";case"lparen":return`M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,`+(t+84)+`c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-`+(t+92)+`c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;case"rparen":return`M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,`+(t+9)+`
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-`+(t+144)+`c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;default:throw new Error("Unknown stretchy delimiter.")}};function Jo(r){return"toText"in r}var q0=class{constructor(e){this.children=void 0,this.classes=void 0,this.height=void 0,this.depth=void 0,this.maxFontSize=void 0,this.style=void 0,this.children=e,this.classes=[],this.height=0,this.depth=0,this.maxFontSize=0,this.style={}}hasClass(e){return this.classes.includes(e)}toNode(){for(var e=document.createDocumentFragment(),t=0;t<this.children.length;t++)e.appendChild(this.children[t].toNode());return e}toMarkup(){for(var e="",t=0;t<this.children.length;t++)e+=this.children[t].toMarkup();return e}toText(){return this.children.map(e=>{if(Jo(e))return e.toText();throw new Error("Expected MathDomNode with toText, got "+e.constructor.name)}).join("")}},Ka={pt:1,mm:7227/2540,cm:7227/254,in:72.27,bp:803/800,pc:12,dd:1238/1157,cc:14856/1157,nd:685/642,nc:1370/107,sp:1/65536,px:803/800},eu={ex:!0,em:!0,mu:!0},Ms=function(e){return typeof e!="string"&&(e=e.unit),e in Ka||e in eu||e==="ex"},fe=function(e,t){var a;if(e.unit in Ka)a=Ka[e.unit]/t.fontMetrics().ptPerEm/t.sizeMultiplier;else if(e.unit==="mu")a=t.fontMetrics().cssEmPerMu;else{var n;if(t.style.isTight()?n=t.havingStyle(t.style.text()):n=t,e.unit==="ex")a=n.fontMetrics().xHeight;else if(e.unit==="em")a=n.fontMetrics().quad;else throw new C("Invalid unit: '"+e.unit+"'");n!==t&&(a*=n.sizeMultiplier/t.sizeMultiplier)}return Math.min(e.number*a,t.maxSize)},O=function(e){return+e.toFixed(4)+"em"},P0=function(e){return e.filter(t=>t).join(" ")},bn=function(e){var t="";for(var a of Object.keys(e)){var n=e[a];n!==void 0&&(t+=Eo(a)+":"+n+";")}return t},Es=function(e,t,a){if(this.classes=e||[],this.attributes={},this.height=0,this.depth=0,this.maxFontSize=0,this.style=a||{},t){t.style.isTight()&&this.classes.push("mtight");var n=t.getColor();n&&(this.style.color=n)}},Rs=function(e){var t=document.createElement(e);t.className=P0(this.classes),Object.assign(t.style,this.style);for(var a of Object.keys(this.attributes))t.setAttribute(a,this.attributes[a]);for(var n=0;n<this.children.length;n++)t.appendChild(this.children[n].toNode());return t},tu=/[\s"'>/=\x00-\x1f]/,Ds=function(e){var t="<"+e;this.classes.length&&(t+=' class="'+De(P0(this.classes))+'"');var a=bn(this.style);a&&(t+=' style="'+De(a)+'"');for(var n of Object.keys(this.attributes)){if(tu.test(n))throw new C("Invalid attribute name '"+n+"'");t+=" "+n+'="'+De(this.attributes[n])+'"'}t+=">";for(var i=0;i<this.children.length;i++)t+=this.children[i].toMarkup();return t+="</"+e+">",t},F0=class{constructor(e,t,a,n){this.children=void 0,this.attributes=void 0,this.classes=void 0,this.height=void 0,this.depth=void 0,this.width=void 0,this.maxFontSize=void 0,this.style=void 0,this.italic=void 0,Es.call(this,e,a,n),this.children=t||[]}setAttribute(e,t){this.attributes[e]=t}hasClass(e){return this.classes.includes(e)}toNode(){return Rs.call(this,"span")}toMarkup(){return Ds.call(this,"span")}},xt=class{constructor(e,t,a,n){this.children=void 0,this.attributes=void 0,this.classes=void 0,this.height=void 0,this.depth=void 0,this.maxFontSize=void 0,this.style=void 0,Es.call(this,t,n),this.children=a||[],this.setAttribute("href",e)}setAttribute(e,t){this.attributes[e]=t}hasClass(e){return this.classes.includes(e)}toNode(){return Rs.call(this,"a")}toMarkup(){return Ds.call(this,"a")}},Qa=class{constructor(e,t,a){this.src=void 0,this.alt=void 0,this.classes=void 0,this.height=void 0,this.depth=void 0,this.maxFontSize=void 0,this.style=void 0,this.alt=t,this.src=e,this.classes=["mord"],this.height=0,this.depth=0,this.maxFontSize=0,this.style=a}hasClass(e){return this.classes.includes(e)}toNode(){var e=document.createElement("img");return e.src=this.src,e.alt=this.alt,e.className="mord",Object.assign(e.style,this.style),e}toMarkup(){var e='<img src="'+De(this.src)+'"'+(' alt="'+De(this.alt)+'"'),t=bn(this.style);return t&&(e+=' style="'+De(t)+'"'),e+="'/>",e}},ru={\u00EE:"\u0131\u0302",\u00EF:"\u0131\u0308",\u00ED:"\u0131\u0301",\u00EC:"\u0131\u0300"},Ne=class{constructor(e,t,a,n,i,l,u,h){this.text=void 0,this.height=void 0,this.depth=void 0,this.italic=void 0,this.skew=void 0,this.width=void 0,this.maxFontSize=void 0,this.classes=void 0,this.style=void 0,this.text=e,this.height=t||0,this.depth=a||0,this.italic=n||0,this.skew=i||0,this.width=l||0,this.classes=u||[],this.style=h||{},this.maxFontSize=0;var d=$o(this.text.charCodeAt(0));d&&this.classes.push(d+"_fallback"),/[îïíì]/.test(this.text)&&(this.text=ru[this.text])}hasClass(e){return this.classes.includes(e)}toNode(){var e=document.createTextNode(this.text),t=null;return this.italic>0&&(t=document.createElement("span"),t.style.marginRight=O(this.italic)),this.classes.length>0&&(t=t||document.createElement("span"),t.className=P0(this.classes)),Object.keys(this.style).length>0&&(t=t||document.createElement("span"),Object.assign(t.style,this.style)),t?(t.appendChild(e),t):e}toMarkup(){var e=!1,t="<span";this.classes.length&&(e=!0,t+=' class="',t+=De(P0(this.classes)),t+='"');var a="";this.italic>0&&(a+="margin-right:"+O(this.italic)+";"),a+=bn(this.style),a&&(e=!0,t+=' style="'+De(a)+'"');var n=De(this.text);return e?(t+=">",t+=n,t+="</span>",t):n}},o0=class{constructor(e,t){this.children=void 0,this.attributes=void 0,this.children=e||[],this.attributes=t||{}}toNode(){var e="http://www.w3.org/2000/svg",t=document.createElementNS(e,"svg");for(var a of Object.keys(this.attributes))t.setAttribute(a,this.attributes[a]);for(var n=0;n<this.children.length;n++)t.appendChild(this.children[n].toNode());return t}toMarkup(){var e='<svg xmlns="http://www.w3.org/2000/svg"';for(var t of Object.keys(this.attributes))e+=" "+t+'="'+De(this.attributes[t])+'"';e+=">";for(var a=0;a<this.children.length;a++)e+=this.children[a].toMarkup();return e+="</svg>",e}},f0=class{constructor(e,t){this.pathName=void 0,this.alternate=void 0,this.pathName=e,this.alternate=t}toNode(){var e="http://www.w3.org/2000/svg",t=document.createElementNS(e,"path");return this.alternate?t.setAttribute("d",this.alternate):t.setAttribute("d",Ui[this.pathName]),t}toMarkup(){return this.alternate?'<path d="'+De(this.alternate)+'"/>':'<path d="'+De(Ui[this.pathName])+'"/>'}},Wt=class{constructor(e){this.attributes=void 0,this.attributes=e||{}}toNode(){var e="http://www.w3.org/2000/svg",t=document.createElementNS(e,"line");for(var a of Object.keys(this.attributes))t.setAttribute(a,this.attributes[a]);return t}toMarkup(){var e="<line";for(var t of Object.keys(this.attributes))e+=" "+t+'="'+De(this.attributes[t])+'"';return e+="/>",e}};function au(r){if(r instanceof Ne)return r;throw new Error("Expected symbolNode but got "+String(r)+".")}function nu(r){if(r instanceof F0)return r;throw new Error("Expected span<HtmlDomNode> but got "+String(r)+".")}var iu=r=>r instanceof F0||r instanceof xt||r instanceof q0,p0={"AMS-Regular":{32:[0,0,0,0,.25],65:[0,.68889,0,0,.72222],66:[0,.68889,0,0,.66667],67:[0,.68889,0,0,.72222],68:[0,.68889,0,0,.72222],69:[0,.68889,0,0,.66667],70:[0,.68889,0,0,.61111],71:[0,.68889,0,0,.77778],72:[0,.68889,0,0,.77778],73:[0,.68889,0,0,.38889],74:[.16667,.68889,0,0,.5],75:[0,.68889,0,0,.77778],76:[0,.68889,0,0,.66667],77:[0,.68889,0,0,.94445],78:[0,.68889,0,0,.72222],79:[.16667,.68889,0,0,.77778],80:[0,.68889,0,0,.61111],81:[.16667,.68889,0,0,.77778],82:[0,.68889,0,0,.72222],83:[0,.68889,0,0,.55556],84:[0,.68889,0,0,.66667],85:[0,.68889,0,0,.72222],86:[0,.68889,0,0,.72222],87:[0,.68889,0,0,1],88:[0,.68889,0,0,.72222],89:[0,.68889,0,0,.72222],90:[0,.68889,0,0,.66667],107:[0,.68889,0,0,.55556],160:[0,0,0,0,.25],165:[0,.675,.025,0,.75],174:[.15559,.69224,0,0,.94666],240:[0,.68889,0,0,.55556],295:[0,.68889,0,0,.54028],710:[0,.825,0,0,2.33334],732:[0,.9,0,0,2.33334],770:[0,.825,0,0,2.33334],771:[0,.9,0,0,2.33334],989:[.08167,.58167,0,0,.77778],1008:[0,.43056,.04028,0,.66667],8245:[0,.54986,0,0,.275],8463:[0,.68889,0,0,.54028],8487:[0,.68889,0,0,.72222],8498:[0,.68889,0,0,.55556],8502:[0,.68889,0,0,.66667],8503:[0,.68889,0,0,.44445],8504:[0,.68889,0,0,.66667],8513:[0,.68889,0,0,.63889],8592:[-.03598,.46402,0,0,.5],8594:[-.03598,.46402,0,0,.5],8602:[-.13313,.36687,0,0,1],8603:[-.13313,.36687,0,0,1],8606:[.01354,.52239,0,0,1],8608:[.01354,.52239,0,0,1],8610:[.01354,.52239,0,0,1.11111],8611:[.01354,.52239,0,0,1.11111],8619:[0,.54986,0,0,1],8620:[0,.54986,0,0,1],8621:[-.13313,.37788,0,0,1.38889],8622:[-.13313,.36687,0,0,1],8624:[0,.69224,0,0,.5],8625:[0,.69224,0,0,.5],8630:[0,.43056,0,0,1],8631:[0,.43056,0,0,1],8634:[.08198,.58198,0,0,.77778],8635:[.08198,.58198,0,0,.77778],8638:[.19444,.69224,0,0,.41667],8639:[.19444,.69224,0,0,.41667],8642:[.19444,.69224,0,0,.41667],8643:[.19444,.69224,0,0,.41667],8644:[.1808,.675,0,0,1],8646:[.1808,.675,0,0,1],8647:[.1808,.675,0,0,1],8648:[.19444,.69224,0,0,.83334],8649:[.1808,.675,0,0,1],8650:[.19444,.69224,0,0,.83334],8651:[.01354,.52239,0,0,1],8652:[.01354,.52239,0,0,1],8653:[-.13313,.36687,0,0,1],8654:[-.13313,.36687,0,0,1],8655:[-.13313,.36687,0,0,1],8666:[.13667,.63667,0,0,1],8667:[.13667,.63667,0,0,1],8669:[-.13313,.37788,0,0,1],8672:[-.064,.437,0,0,1.334],8674:[-.064,.437,0,0,1.334],8705:[0,.825,0,0,.5],8708:[0,.68889,0,0,.55556],8709:[.08167,.58167,0,0,.77778],8717:[0,.43056,0,0,.42917],8722:[-.03598,.46402,0,0,.5],8724:[.08198,.69224,0,0,.77778],8726:[.08167,.58167,0,0,.77778],8733:[0,.69224,0,0,.77778],8736:[0,.69224,0,0,.72222],8737:[0,.69224,0,0,.72222],8738:[.03517,.52239,0,0,.72222],8739:[.08167,.58167,0,0,.22222],8740:[.25142,.74111,0,0,.27778],8741:[.08167,.58167,0,0,.38889],8742:[.25142,.74111,0,0,.5],8756:[0,.69224,0,0,.66667],8757:[0,.69224,0,0,.66667],8764:[-.13313,.36687,0,0,.77778],8765:[-.13313,.37788,0,0,.77778],8769:[-.13313,.36687,0,0,.77778],8770:[-.03625,.46375,0,0,.77778],8774:[.30274,.79383,0,0,.77778],8776:[-.01688,.48312,0,0,.77778],8778:[.08167,.58167,0,0,.77778],8782:[.06062,.54986,0,0,.77778],8783:[.06062,.54986,0,0,.77778],8785:[.08198,.58198,0,0,.77778],8786:[.08198,.58198,0,0,.77778],8787:[.08198,.58198,0,0,.77778],8790:[0,.69224,0,0,.77778],8791:[.22958,.72958,0,0,.77778],8796:[.08198,.91667,0,0,.77778],8806:[.25583,.75583,0,0,.77778],8807:[.25583,.75583,0,0,.77778],8808:[.25142,.75726,0,0,.77778],8809:[.25142,.75726,0,0,.77778],8812:[.25583,.75583,0,0,.5],8814:[.20576,.70576,0,0,.77778],8815:[.20576,.70576,0,0,.77778],8816:[.30274,.79383,0,0,.77778],8817:[.30274,.79383,0,0,.77778],8818:[.22958,.72958,0,0,.77778],8819:[.22958,.72958,0,0,.77778],8822:[.1808,.675,0,0,.77778],8823:[.1808,.675,0,0,.77778],8828:[.13667,.63667,0,0,.77778],8829:[.13667,.63667,0,0,.77778],8830:[.22958,.72958,0,0,.77778],8831:[.22958,.72958,0,0,.77778],8832:[.20576,.70576,0,0,.77778],8833:[.20576,.70576,0,0,.77778],8840:[.30274,.79383,0,0,.77778],8841:[.30274,.79383,0,0,.77778],8842:[.13597,.63597,0,0,.77778],8843:[.13597,.63597,0,0,.77778],8847:[.03517,.54986,0,0,.77778],8848:[.03517,.54986,0,0,.77778],8858:[.08198,.58198,0,0,.77778],8859:[.08198,.58198,0,0,.77778],8861:[.08198,.58198,0,0,.77778],8862:[0,.675,0,0,.77778],8863:[0,.675,0,0,.77778],8864:[0,.675,0,0,.77778],8865:[0,.675,0,0,.77778],8872:[0,.69224,0,0,.61111],8873:[0,.69224,0,0,.72222],8874:[0,.69224,0,0,.88889],8876:[0,.68889,0,0,.61111],8877:[0,.68889,0,0,.61111],8878:[0,.68889,0,0,.72222],8879:[0,.68889,0,0,.72222],8882:[.03517,.54986,0,0,.77778],8883:[.03517,.54986,0,0,.77778],8884:[.13667,.63667,0,0,.77778],8885:[.13667,.63667,0,0,.77778],8888:[0,.54986,0,0,1.11111],8890:[.19444,.43056,0,0,.55556],8891:[.19444,.69224,0,0,.61111],8892:[.19444,.69224,0,0,.61111],8901:[0,.54986,0,0,.27778],8903:[.08167,.58167,0,0,.77778],8905:[.08167,.58167,0,0,.77778],8906:[.08167,.58167,0,0,.77778],8907:[0,.69224,0,0,.77778],8908:[0,.69224,0,0,.77778],8909:[-.03598,.46402,0,0,.77778],8910:[0,.54986,0,0,.76042],8911:[0,.54986,0,0,.76042],8912:[.03517,.54986,0,0,.77778],8913:[.03517,.54986,0,0,.77778],8914:[0,.54986,0,0,.66667],8915:[0,.54986,0,0,.66667],8916:[0,.69224,0,0,.66667],8918:[.0391,.5391,0,0,.77778],8919:[.0391,.5391,0,0,.77778],8920:[.03517,.54986,0,0,1.33334],8921:[.03517,.54986,0,0,1.33334],8922:[.38569,.88569,0,0,.77778],8923:[.38569,.88569,0,0,.77778],8926:[.13667,.63667,0,0,.77778],8927:[.13667,.63667,0,0,.77778],8928:[.30274,.79383,0,0,.77778],8929:[.30274,.79383,0,0,.77778],8934:[.23222,.74111,0,0,.77778],8935:[.23222,.74111,0,0,.77778],8936:[.23222,.74111,0,0,.77778],8937:[.23222,.74111,0,0,.77778],8938:[.20576,.70576,0,0,.77778],8939:[.20576,.70576,0,0,.77778],8940:[.30274,.79383,0,0,.77778],8941:[.30274,.79383,0,0,.77778],8994:[.19444,.69224,0,0,.77778],8995:[.19444,.69224,0,0,.77778],9416:[.15559,.69224,0,0,.90222],9484:[0,.69224,0,0,.5],9488:[0,.69224,0,0,.5],9492:[0,.37788,0,0,.5],9496:[0,.37788,0,0,.5],9585:[.19444,.68889,0,0,.88889],9586:[.19444,.74111,0,0,.88889],9632:[0,.675,0,0,.77778],9633:[0,.675,0,0,.77778],9650:[0,.54986,0,0,.72222],9651:[0,.54986,0,0,.72222],9654:[.03517,.54986,0,0,.77778],9660:[0,.54986,0,0,.72222],9661:[0,.54986,0,0,.72222],9664:[.03517,.54986,0,0,.77778],9674:[.11111,.69224,0,0,.66667],9733:[.19444,.69224,0,0,.94445],10003:[0,.69224,0,0,.83334],10016:[0,.69224,0,0,.83334],10731:[.11111,.69224,0,0,.66667],10846:[.19444,.75583,0,0,.61111],10877:[.13667,.63667,0,0,.77778],10878:[.13667,.63667,0,0,.77778],10885:[.25583,.75583,0,0,.77778],10886:[.25583,.75583,0,0,.77778],10887:[.13597,.63597,0,0,.77778],10888:[.13597,.63597,0,0,.77778],10889:[.26167,.75726,0,0,.77778],10890:[.26167,.75726,0,0,.77778],10891:[.48256,.98256,0,0,.77778],10892:[.48256,.98256,0,0,.77778],10901:[.13667,.63667,0,0,.77778],10902:[.13667,.63667,0,0,.77778],10933:[.25142,.75726,0,0,.77778],10934:[.25142,.75726,0,0,.77778],10935:[.26167,.75726,0,0,.77778],10936:[.26167,.75726,0,0,.77778],10937:[.26167,.75726,0,0,.77778],10938:[.26167,.75726,0,0,.77778],10949:[.25583,.75583,0,0,.77778],10950:[.25583,.75583,0,0,.77778],10955:[.28481,.79383,0,0,.77778],10956:[.28481,.79383,0,0,.77778],57350:[.08167,.58167,0,0,.22222],57351:[.08167,.58167,0,0,.38889],57352:[.08167,.58167,0,0,.77778],57353:[0,.43056,.04028,0,.66667],57356:[.25142,.75726,0,0,.77778],57357:[.25142,.75726,0,0,.77778],57358:[.41951,.91951,0,0,.77778],57359:[.30274,.79383,0,0,.77778],57360:[.30274,.79383,0,0,.77778],57361:[.41951,.91951,0,0,.77778],57366:[.25142,.75726,0,0,.77778],57367:[.25142,.75726,0,0,.77778],57368:[.25142,.75726,0,0,.77778],57369:[.25142,.75726,0,0,.77778],57370:[.13597,.63597,0,0,.77778],57371:[.13597,.63597,0,0,.77778]},"Caligraphic-Regular":{32:[0,0,0,0,.25],65:[0,.68333,0,.19445,.79847],66:[0,.68333,.03041,.13889,.65681],67:[0,.68333,.05834,.13889,.52653],68:[0,.68333,.02778,.08334,.77139],69:[0,.68333,.08944,.11111,.52778],70:[0,.68333,.09931,.11111,.71875],71:[.09722,.68333,.0593,.11111,.59487],72:[0,.68333,.00965,.11111,.84452],73:[0,.68333,.07382,0,.54452],74:[.09722,.68333,.18472,.16667,.67778],75:[0,.68333,.01445,.05556,.76195],76:[0,.68333,0,.13889,.68972],77:[0,.68333,0,.13889,1.2009],78:[0,.68333,.14736,.08334,.82049],79:[0,.68333,.02778,.11111,.79611],80:[0,.68333,.08222,.08334,.69556],81:[.09722,.68333,0,.11111,.81667],82:[0,.68333,0,.08334,.8475],83:[0,.68333,.075,.13889,.60556],84:[0,.68333,.25417,0,.54464],85:[0,.68333,.09931,.08334,.62583],86:[0,.68333,.08222,0,.61278],87:[0,.68333,.08222,.08334,.98778],88:[0,.68333,.14643,.13889,.7133],89:[.09722,.68333,.08222,.08334,.66834],90:[0,.68333,.07944,.13889,.72473],160:[0,0,0,0,.25]},"Fraktur-Regular":{32:[0,0,0,0,.25],33:[0,.69141,0,0,.29574],34:[0,.69141,0,0,.21471],38:[0,.69141,0,0,.73786],39:[0,.69141,0,0,.21201],40:[.24982,.74947,0,0,.38865],41:[.24982,.74947,0,0,.38865],42:[0,.62119,0,0,.27764],43:[.08319,.58283,0,0,.75623],44:[0,.10803,0,0,.27764],45:[.08319,.58283,0,0,.75623],46:[0,.10803,0,0,.27764],47:[.24982,.74947,0,0,.50181],48:[0,.47534,0,0,.50181],49:[0,.47534,0,0,.50181],50:[0,.47534,0,0,.50181],51:[.18906,.47534,0,0,.50181],52:[.18906,.47534,0,0,.50181],53:[.18906,.47534,0,0,.50181],54:[0,.69141,0,0,.50181],55:[.18906,.47534,0,0,.50181],56:[0,.69141,0,0,.50181],57:[.18906,.47534,0,0,.50181],58:[0,.47534,0,0,.21606],59:[.12604,.47534,0,0,.21606],61:[-.13099,.36866,0,0,.75623],63:[0,.69141,0,0,.36245],65:[0,.69141,0,0,.7176],66:[0,.69141,0,0,.88397],67:[0,.69141,0,0,.61254],68:[0,.69141,0,0,.83158],69:[0,.69141,0,0,.66278],70:[.12604,.69141,0,0,.61119],71:[0,.69141,0,0,.78539],72:[.06302,.69141,0,0,.7203],73:[0,.69141,0,0,.55448],74:[.12604,.69141,0,0,.55231],75:[0,.69141,0,0,.66845],76:[0,.69141,0,0,.66602],77:[0,.69141,0,0,1.04953],78:[0,.69141,0,0,.83212],79:[0,.69141,0,0,.82699],80:[.18906,.69141,0,0,.82753],81:[.03781,.69141,0,0,.82699],82:[0,.69141,0,0,.82807],83:[0,.69141,0,0,.82861],84:[0,.69141,0,0,.66899],85:[0,.69141,0,0,.64576],86:[0,.69141,0,0,.83131],87:[0,.69141,0,0,1.04602],88:[0,.69141,0,0,.71922],89:[.18906,.69141,0,0,.83293],90:[.12604,.69141,0,0,.60201],91:[.24982,.74947,0,0,.27764],93:[.24982,.74947,0,0,.27764],94:[0,.69141,0,0,.49965],97:[0,.47534,0,0,.50046],98:[0,.69141,0,0,.51315],99:[0,.47534,0,0,.38946],100:[0,.62119,0,0,.49857],101:[0,.47534,0,0,.40053],102:[.18906,.69141,0,0,.32626],103:[.18906,.47534,0,0,.5037],104:[.18906,.69141,0,0,.52126],105:[0,.69141,0,0,.27899],106:[0,.69141,0,0,.28088],107:[0,.69141,0,0,.38946],108:[0,.69141,0,0,.27953],109:[0,.47534,0,0,.76676],110:[0,.47534,0,0,.52666],111:[0,.47534,0,0,.48885],112:[.18906,.52396,0,0,.50046],113:[.18906,.47534,0,0,.48912],114:[0,.47534,0,0,.38919],115:[0,.47534,0,0,.44266],116:[0,.62119,0,0,.33301],117:[0,.47534,0,0,.5172],118:[0,.52396,0,0,.5118],119:[0,.52396,0,0,.77351],120:[.18906,.47534,0,0,.38865],121:[.18906,.47534,0,0,.49884],122:[.18906,.47534,0,0,.39054],160:[0,0,0,0,.25],8216:[0,.69141,0,0,.21471],8217:[0,.69141,0,0,.21471],58112:[0,.62119,0,0,.49749],58113:[0,.62119,0,0,.4983],58114:[.18906,.69141,0,0,.33328],58115:[.18906,.69141,0,0,.32923],58116:[.18906,.47534,0,0,.50343],58117:[0,.69141,0,0,.33301],58118:[0,.62119,0,0,.33409],58119:[0,.47534,0,0,.50073]},"Main-Bold":{32:[0,0,0,0,.25],33:[0,.69444,0,0,.35],34:[0,.69444,0,0,.60278],35:[.19444,.69444,0,0,.95833],36:[.05556,.75,0,0,.575],37:[.05556,.75,0,0,.95833],38:[0,.69444,0,0,.89444],39:[0,.69444,0,0,.31944],40:[.25,.75,0,0,.44722],41:[.25,.75,0,0,.44722],42:[0,.75,0,0,.575],43:[.13333,.63333,0,0,.89444],44:[.19444,.15556,0,0,.31944],45:[0,.44444,0,0,.38333],46:[0,.15556,0,0,.31944],47:[.25,.75,0,0,.575],48:[0,.64444,0,0,.575],49:[0,.64444,0,0,.575],50:[0,.64444,0,0,.575],51:[0,.64444,0,0,.575],52:[0,.64444,0,0,.575],53:[0,.64444,0,0,.575],54:[0,.64444,0,0,.575],55:[0,.64444,0,0,.575],56:[0,.64444,0,0,.575],57:[0,.64444,0,0,.575],58:[0,.44444,0,0,.31944],59:[.19444,.44444,0,0,.31944],60:[.08556,.58556,0,0,.89444],61:[-.10889,.39111,0,0,.89444],62:[.08556,.58556,0,0,.89444],63:[0,.69444,0,0,.54305],64:[0,.69444,0,0,.89444],65:[0,.68611,0,0,.86944],66:[0,.68611,0,0,.81805],67:[0,.68611,0,0,.83055],68:[0,.68611,0,0,.88194],69:[0,.68611,0,0,.75555],70:[0,.68611,0,0,.72361],71:[0,.68611,0,0,.90416],72:[0,.68611,0,0,.9],73:[0,.68611,0,0,.43611],74:[0,.68611,0,0,.59444],75:[0,.68611,0,0,.90138],76:[0,.68611,0,0,.69166],77:[0,.68611,0,0,1.09166],78:[0,.68611,0,0,.9],79:[0,.68611,0,0,.86388],80:[0,.68611,0,0,.78611],81:[.19444,.68611,0,0,.86388],82:[0,.68611,0,0,.8625],83:[0,.68611,0,0,.63889],84:[0,.68611,0,0,.8],85:[0,.68611,0,0,.88472],86:[0,.68611,.01597,0,.86944],87:[0,.68611,.01597,0,1.18888],88:[0,.68611,0,0,.86944],89:[0,.68611,.02875,0,.86944],90:[0,.68611,0,0,.70277],91:[.25,.75,0,0,.31944],92:[.25,.75,0,0,.575],93:[.25,.75,0,0,.31944],94:[0,.69444,0,0,.575],95:[.31,.13444,.03194,0,.575],97:[0,.44444,0,0,.55902],98:[0,.69444,0,0,.63889],99:[0,.44444,0,0,.51111],100:[0,.69444,0,0,.63889],101:[0,.44444,0,0,.52708],102:[0,.69444,.10903,0,.35139],103:[.19444,.44444,.01597,0,.575],104:[0,.69444,0,0,.63889],105:[0,.69444,0,0,.31944],106:[.19444,.69444,0,0,.35139],107:[0,.69444,0,0,.60694],108:[0,.69444,0,0,.31944],109:[0,.44444,0,0,.95833],110:[0,.44444,0,0,.63889],111:[0,.44444,0,0,.575],112:[.19444,.44444,0,0,.63889],113:[.19444,.44444,0,0,.60694],114:[0,.44444,0,0,.47361],115:[0,.44444,0,0,.45361],116:[0,.63492,0,0,.44722],117:[0,.44444,0,0,.63889],118:[0,.44444,.01597,0,.60694],119:[0,.44444,.01597,0,.83055],120:[0,.44444,0,0,.60694],121:[.19444,.44444,.01597,0,.60694],122:[0,.44444,0,0,.51111],123:[.25,.75,0,0,.575],124:[.25,.75,0,0,.31944],125:[.25,.75,0,0,.575],126:[.35,.34444,0,0,.575],160:[0,0,0,0,.25],163:[0,.69444,0,0,.86853],168:[0,.69444,0,0,.575],172:[0,.44444,0,0,.76666],176:[0,.69444,0,0,.86944],177:[.13333,.63333,0,0,.89444],184:[.17014,0,0,0,.51111],198:[0,.68611,0,0,1.04166],215:[.13333,.63333,0,0,.89444],216:[.04861,.73472,0,0,.89444],223:[0,.69444,0,0,.59722],230:[0,.44444,0,0,.83055],247:[.13333,.63333,0,0,.89444],248:[.09722,.54167,0,0,.575],305:[0,.44444,0,0,.31944],338:[0,.68611,0,0,1.16944],339:[0,.44444,0,0,.89444],567:[.19444,.44444,0,0,.35139],710:[0,.69444,0,0,.575],711:[0,.63194,0,0,.575],713:[0,.59611,0,0,.575],714:[0,.69444,0,0,.575],715:[0,.69444,0,0,.575],728:[0,.69444,0,0,.575],729:[0,.69444,0,0,.31944],730:[0,.69444,0,0,.86944],732:[0,.69444,0,0,.575],733:[0,.69444,0,0,.575],915:[0,.68611,0,0,.69166],916:[0,.68611,0,0,.95833],920:[0,.68611,0,0,.89444],923:[0,.68611,0,0,.80555],926:[0,.68611,0,0,.76666],928:[0,.68611,0,0,.9],931:[0,.68611,0,0,.83055],933:[0,.68611,0,0,.89444],934:[0,.68611,0,0,.83055],936:[0,.68611,0,0,.89444],937:[0,.68611,0,0,.83055],8211:[0,.44444,.03194,0,.575],8212:[0,.44444,.03194,0,1.14999],8216:[0,.69444,0,0,.31944],8217:[0,.69444,0,0,.31944],8220:[0,.69444,0,0,.60278],8221:[0,.69444,0,0,.60278],8224:[.19444,.69444,0,0,.51111],8225:[.19444,.69444,0,0,.51111],8242:[0,.55556,0,0,.34444],8407:[0,.72444,.15486,0,.575],8463:[0,.69444,0,0,.66759],8465:[0,.69444,0,0,.83055],8467:[0,.69444,0,0,.47361],8472:[.19444,.44444,0,0,.74027],8476:[0,.69444,0,0,.83055],8501:[0,.69444,0,0,.70277],8592:[-.10889,.39111,0,0,1.14999],8593:[.19444,.69444,0,0,.575],8594:[-.10889,.39111,0,0,1.14999],8595:[.19444,.69444,0,0,.575],8596:[-.10889,.39111,0,0,1.14999],8597:[.25,.75,0,0,.575],8598:[.19444,.69444,0,0,1.14999],8599:[.19444,.69444,0,0,1.14999],8600:[.19444,.69444,0,0,1.14999],8601:[.19444,.69444,0,0,1.14999],8636:[-.10889,.39111,0,0,1.14999],8637:[-.10889,.39111,0,0,1.14999],8640:[-.10889,.39111,0,0,1.14999],8641:[-.10889,.39111,0,0,1.14999],8656:[-.10889,.39111,0,0,1.14999],8657:[.19444,.69444,0,0,.70277],8658:[-.10889,.39111,0,0,1.14999],8659:[.19444,.69444,0,0,.70277],8660:[-.10889,.39111,0,0,1.14999],8661:[.25,.75,0,0,.70277],8704:[0,.69444,0,0,.63889],8706:[0,.69444,.06389,0,.62847],8707:[0,.69444,0,0,.63889],8709:[.05556,.75,0,0,.575],8711:[0,.68611,0,0,.95833],8712:[.08556,.58556,0,0,.76666],8715:[.08556,.58556,0,0,.76666],8722:[.13333,.63333,0,0,.89444],8723:[.13333,.63333,0,0,.89444],8725:[.25,.75,0,0,.575],8726:[.25,.75,0,0,.575],8727:[-.02778,.47222,0,0,.575],8728:[-.02639,.47361,0,0,.575],8729:[-.02639,.47361,0,0,.575],8730:[.18,.82,0,0,.95833],8733:[0,.44444,0,0,.89444],8734:[0,.44444,0,0,1.14999],8736:[0,.69224,0,0,.72222],8739:[.25,.75,0,0,.31944],8741:[.25,.75,0,0,.575],8743:[0,.55556,0,0,.76666],8744:[0,.55556,0,0,.76666],8745:[0,.55556,0,0,.76666],8746:[0,.55556,0,0,.76666],8747:[.19444,.69444,.12778,0,.56875],8764:[-.10889,.39111,0,0,.89444],8768:[.19444,.69444,0,0,.31944],8771:[.00222,.50222,0,0,.89444],8773:[.027,.638,0,0,.894],8776:[.02444,.52444,0,0,.89444],8781:[.00222,.50222,0,0,.89444],8801:[.00222,.50222,0,0,.89444],8804:[.19667,.69667,0,0,.89444],8805:[.19667,.69667,0,0,.89444],8810:[.08556,.58556,0,0,1.14999],8811:[.08556,.58556,0,0,1.14999],8826:[.08556,.58556,0,0,.89444],8827:[.08556,.58556,0,0,.89444],8834:[.08556,.58556,0,0,.89444],8835:[.08556,.58556,0,0,.89444],8838:[.19667,.69667,0,0,.89444],8839:[.19667,.69667,0,0,.89444],8846:[0,.55556,0,0,.76666],8849:[.19667,.69667,0,0,.89444],8850:[.19667,.69667,0,0,.89444],8851:[0,.55556,0,0,.76666],8852:[0,.55556,0,0,.76666],8853:[.13333,.63333,0,0,.89444],8854:[.13333,.63333,0,0,.89444],8855:[.13333,.63333,0,0,.89444],8856:[.13333,.63333,0,0,.89444],8857:[.13333,.63333,0,0,.89444],8866:[0,.69444,0,0,.70277],8867:[0,.69444,0,0,.70277],8868:[0,.69444,0,0,.89444],8869:[0,.69444,0,0,.89444],8900:[-.02639,.47361,0,0,.575],8901:[-.02639,.47361,0,0,.31944],8902:[-.02778,.47222,0,0,.575],8968:[.25,.75,0,0,.51111],8969:[.25,.75,0,0,.51111],8970:[.25,.75,0,0,.51111],8971:[.25,.75,0,0,.51111],8994:[-.13889,.36111,0,0,1.14999],8995:[-.13889,.36111,0,0,1.14999],9651:[.19444,.69444,0,0,1.02222],9657:[-.02778,.47222,0,0,.575],9661:[.19444,.69444,0,0,1.02222],9667:[-.02778,.47222,0,0,.575],9711:[.19444,.69444,0,0,1.14999],9824:[.12963,.69444,0,0,.89444],9825:[.12963,.69444,0,0,.89444],9826:[.12963,.69444,0,0,.89444],9827:[.12963,.69444,0,0,.89444],9837:[0,.75,0,0,.44722],9838:[.19444,.69444,0,0,.44722],9839:[.19444,.69444,0,0,.44722],10216:[.25,.75,0,0,.44722],10217:[.25,.75,0,0,.44722],10815:[0,.68611,0,0,.9],10927:[.19667,.69667,0,0,.89444],10928:[.19667,.69667,0,0,.89444],57376:[.19444,.69444,0,0,0]},"Main-BoldItalic":{32:[0,0,0,0,.25],33:[0,.69444,.11417,0,.38611],34:[0,.69444,.07939,0,.62055],35:[.19444,.69444,.06833,0,.94444],37:[.05556,.75,.12861,0,.94444],38:[0,.69444,.08528,0,.88555],39:[0,.69444,.12945,0,.35555],40:[.25,.75,.15806,0,.47333],41:[.25,.75,.03306,0,.47333],42:[0,.75,.14333,0,.59111],43:[.10333,.60333,.03306,0,.88555],44:[.19444,.14722,0,0,.35555],45:[0,.44444,.02611,0,.41444],46:[0,.14722,0,0,.35555],47:[.25,.75,.15806,0,.59111],48:[0,.64444,.13167,0,.59111],49:[0,.64444,.13167,0,.59111],50:[0,.64444,.13167,0,.59111],51:[0,.64444,.13167,0,.59111],52:[.19444,.64444,.13167,0,.59111],53:[0,.64444,.13167,0,.59111],54:[0,.64444,.13167,0,.59111],55:[.19444,.64444,.13167,0,.59111],56:[0,.64444,.13167,0,.59111],57:[0,.64444,.13167,0,.59111],58:[0,.44444,.06695,0,.35555],59:[.19444,.44444,.06695,0,.35555],61:[-.10889,.39111,.06833,0,.88555],63:[0,.69444,.11472,0,.59111],64:[0,.69444,.09208,0,.88555],65:[0,.68611,0,0,.86555],66:[0,.68611,.0992,0,.81666],67:[0,.68611,.14208,0,.82666],68:[0,.68611,.09062,0,.87555],69:[0,.68611,.11431,0,.75666],70:[0,.68611,.12903,0,.72722],71:[0,.68611,.07347,0,.89527],72:[0,.68611,.17208,0,.8961],73:[0,.68611,.15681,0,.47166],74:[0,.68611,.145,0,.61055],75:[0,.68611,.14208,0,.89499],76:[0,.68611,0,0,.69777],77:[0,.68611,.17208,0,1.07277],78:[0,.68611,.17208,0,.8961],79:[0,.68611,.09062,0,.85499],80:[0,.68611,.0992,0,.78721],81:[.19444,.68611,.09062,0,.85499],82:[0,.68611,.02559,0,.85944],83:[0,.68611,.11264,0,.64999],84:[0,.68611,.12903,0,.7961],85:[0,.68611,.17208,0,.88083],86:[0,.68611,.18625,0,.86555],87:[0,.68611,.18625,0,1.15999],88:[0,.68611,.15681,0,.86555],89:[0,.68611,.19803,0,.86555],90:[0,.68611,.14208,0,.70888],91:[.25,.75,.1875,0,.35611],93:[.25,.75,.09972,0,.35611],94:[0,.69444,.06709,0,.59111],95:[.31,.13444,.09811,0,.59111],97:[0,.44444,.09426,0,.59111],98:[0,.69444,.07861,0,.53222],99:[0,.44444,.05222,0,.53222],100:[0,.69444,.10861,0,.59111],101:[0,.44444,.085,0,.53222],102:[.19444,.69444,.21778,0,.4],103:[.19444,.44444,.105,0,.53222],104:[0,.69444,.09426,0,.59111],105:[0,.69326,.11387,0,.35555],106:[.19444,.69326,.1672,0,.35555],107:[0,.69444,.11111,0,.53222],108:[0,.69444,.10861,0,.29666],109:[0,.44444,.09426,0,.94444],110:[0,.44444,.09426,0,.64999],111:[0,.44444,.07861,0,.59111],112:[.19444,.44444,.07861,0,.59111],113:[.19444,.44444,.105,0,.53222],114:[0,.44444,.11111,0,.50167],115:[0,.44444,.08167,0,.48694],116:[0,.63492,.09639,0,.385],117:[0,.44444,.09426,0,.62055],118:[0,.44444,.11111,0,.53222],119:[0,.44444,.11111,0,.76777],120:[0,.44444,.12583,0,.56055],121:[.19444,.44444,.105,0,.56166],122:[0,.44444,.13889,0,.49055],126:[.35,.34444,.11472,0,.59111],160:[0,0,0,0,.25],168:[0,.69444,.11473,0,.59111],176:[0,.69444,0,0,.94888],184:[.17014,0,0,0,.53222],198:[0,.68611,.11431,0,1.02277],216:[.04861,.73472,.09062,0,.88555],223:[.19444,.69444,.09736,0,.665],230:[0,.44444,.085,0,.82666],248:[.09722,.54167,.09458,0,.59111],305:[0,.44444,.09426,0,.35555],338:[0,.68611,.11431,0,1.14054],339:[0,.44444,.085,0,.82666],567:[.19444,.44444,.04611,0,.385],710:[0,.69444,.06709,0,.59111],711:[0,.63194,.08271,0,.59111],713:[0,.59444,.10444,0,.59111],714:[0,.69444,.08528,0,.59111],715:[0,.69444,0,0,.59111],728:[0,.69444,.10333,0,.59111],729:[0,.69444,.12945,0,.35555],730:[0,.69444,0,0,.94888],732:[0,.69444,.11472,0,.59111],733:[0,.69444,.11472,0,.59111],915:[0,.68611,.12903,0,.69777],916:[0,.68611,0,0,.94444],920:[0,.68611,.09062,0,.88555],923:[0,.68611,0,0,.80666],926:[0,.68611,.15092,0,.76777],928:[0,.68611,.17208,0,.8961],931:[0,.68611,.11431,0,.82666],933:[0,.68611,.10778,0,.88555],934:[0,.68611,.05632,0,.82666],936:[0,.68611,.10778,0,.88555],937:[0,.68611,.0992,0,.82666],8211:[0,.44444,.09811,0,.59111],8212:[0,.44444,.09811,0,1.18221],8216:[0,.69444,.12945,0,.35555],8217:[0,.69444,.12945,0,.35555],8220:[0,.69444,.16772,0,.62055],8221:[0,.69444,.07939,0,.62055]},"Main-Italic":{32:[0,0,0,0,.25],33:[0,.69444,.12417,0,.30667],34:[0,.69444,.06961,0,.51444],35:[.19444,.69444,.06616,0,.81777],37:[.05556,.75,.13639,0,.81777],38:[0,.69444,.09694,0,.76666],39:[0,.69444,.12417,0,.30667],40:[.25,.75,.16194,0,.40889],41:[.25,.75,.03694,0,.40889],42:[0,.75,.14917,0,.51111],43:[.05667,.56167,.03694,0,.76666],44:[.19444,.10556,0,0,.30667],45:[0,.43056,.02826,0,.35778],46:[0,.10556,0,0,.30667],47:[.25,.75,.16194,0,.51111],48:[0,.64444,.13556,0,.51111],49:[0,.64444,.13556,0,.51111],50:[0,.64444,.13556,0,.51111],51:[0,.64444,.13556,0,.51111],52:[.19444,.64444,.13556,0,.51111],53:[0,.64444,.13556,0,.51111],54:[0,.64444,.13556,0,.51111],55:[.19444,.64444,.13556,0,.51111],56:[0,.64444,.13556,0,.51111],57:[0,.64444,.13556,0,.51111],58:[0,.43056,.0582,0,.30667],59:[.19444,.43056,.0582,0,.30667],61:[-.13313,.36687,.06616,0,.76666],63:[0,.69444,.1225,0,.51111],64:[0,.69444,.09597,0,.76666],65:[0,.68333,0,0,.74333],66:[0,.68333,.10257,0,.70389],67:[0,.68333,.14528,0,.71555],68:[0,.68333,.09403,0,.755],69:[0,.68333,.12028,0,.67833],70:[0,.68333,.13305,0,.65277],71:[0,.68333,.08722,0,.77361],72:[0,.68333,.16389,0,.74333],73:[0,.68333,.15806,0,.38555],74:[0,.68333,.14028,0,.525],75:[0,.68333,.14528,0,.76888],76:[0,.68333,0,0,.62722],77:[0,.68333,.16389,0,.89666],78:[0,.68333,.16389,0,.74333],79:[0,.68333,.09403,0,.76666],80:[0,.68333,.10257,0,.67833],81:[.19444,.68333,.09403,0,.76666],82:[0,.68333,.03868,0,.72944],83:[0,.68333,.11972,0,.56222],84:[0,.68333,.13305,0,.71555],85:[0,.68333,.16389,0,.74333],86:[0,.68333,.18361,0,.74333],87:[0,.68333,.18361,0,.99888],88:[0,.68333,.15806,0,.74333],89:[0,.68333,.19383,0,.74333],90:[0,.68333,.14528,0,.61333],91:[.25,.75,.1875,0,.30667],93:[.25,.75,.10528,0,.30667],94:[0,.69444,.06646,0,.51111],95:[.31,.12056,.09208,0,.51111],97:[0,.43056,.07671,0,.51111],98:[0,.69444,.06312,0,.46],99:[0,.43056,.05653,0,.46],100:[0,.69444,.10333,0,.51111],101:[0,.43056,.07514,0,.46],102:[.19444,.69444,.21194,0,.30667],103:[.19444,.43056,.08847,0,.46],104:[0,.69444,.07671,0,.51111],105:[0,.65536,.1019,0,.30667],106:[.19444,.65536,.14467,0,.30667],107:[0,.69444,.10764,0,.46],108:[0,.69444,.10333,0,.25555],109:[0,.43056,.07671,0,.81777],110:[0,.43056,.07671,0,.56222],111:[0,.43056,.06312,0,.51111],112:[.19444,.43056,.06312,0,.51111],113:[.19444,.43056,.08847,0,.46],114:[0,.43056,.10764,0,.42166],115:[0,.43056,.08208,0,.40889],116:[0,.61508,.09486,0,.33222],117:[0,.43056,.07671,0,.53666],118:[0,.43056,.10764,0,.46],119:[0,.43056,.10764,0,.66444],120:[0,.43056,.12042,0,.46389],121:[.19444,.43056,.08847,0,.48555],122:[0,.43056,.12292,0,.40889],126:[.35,.31786,.11585,0,.51111],160:[0,0,0,0,.25],168:[0,.66786,.10474,0,.51111],176:[0,.69444,0,0,.83129],184:[.17014,0,0,0,.46],198:[0,.68333,.12028,0,.88277],216:[.04861,.73194,.09403,0,.76666],223:[.19444,.69444,.10514,0,.53666],230:[0,.43056,.07514,0,.71555],248:[.09722,.52778,.09194,0,.51111],338:[0,.68333,.12028,0,.98499],339:[0,.43056,.07514,0,.71555],710:[0,.69444,.06646,0,.51111],711:[0,.62847,.08295,0,.51111],713:[0,.56167,.10333,0,.51111],714:[0,.69444,.09694,0,.51111],715:[0,.69444,0,0,.51111],728:[0,.69444,.10806,0,.51111],729:[0,.66786,.11752,0,.30667],730:[0,.69444,0,0,.83129],732:[0,.66786,.11585,0,.51111],733:[0,.69444,.1225,0,.51111],915:[0,.68333,.13305,0,.62722],916:[0,.68333,0,0,.81777],920:[0,.68333,.09403,0,.76666],923:[0,.68333,0,0,.69222],926:[0,.68333,.15294,0,.66444],928:[0,.68333,.16389,0,.74333],931:[0,.68333,.12028,0,.71555],933:[0,.68333,.11111,0,.76666],934:[0,.68333,.05986,0,.71555],936:[0,.68333,.11111,0,.76666],937:[0,.68333,.10257,0,.71555],8211:[0,.43056,.09208,0,.51111],8212:[0,.43056,.09208,0,1.02222],8216:[0,.69444,.12417,0,.30667],8217:[0,.69444,.12417,0,.30667],8220:[0,.69444,.1685,0,.51444],8221:[0,.69444,.06961,0,.51444],8463:[0,.68889,0,0,.54028]},"Main-Regular":{32:[0,0,0,0,.25],33:[0,.69444,0,0,.27778],34:[0,.69444,0,0,.5],35:[.19444,.69444,0,0,.83334],36:[.05556,.75,0,0,.5],37:[.05556,.75,0,0,.83334],38:[0,.69444,0,0,.77778],39:[0,.69444,0,0,.27778],40:[.25,.75,0,0,.38889],41:[.25,.75,0,0,.38889],42:[0,.75,0,0,.5],43:[.08333,.58333,0,0,.77778],44:[.19444,.10556,0,0,.27778],45:[0,.43056,0,0,.33333],46:[0,.10556,0,0,.27778],47:[.25,.75,0,0,.5],48:[0,.64444,0,0,.5],49:[0,.64444,0,0,.5],50:[0,.64444,0,0,.5],51:[0,.64444,0,0,.5],52:[0,.64444,0,0,.5],53:[0,.64444,0,0,.5],54:[0,.64444,0,0,.5],55:[0,.64444,0,0,.5],56:[0,.64444,0,0,.5],57:[0,.64444,0,0,.5],58:[0,.43056,0,0,.27778],59:[.19444,.43056,0,0,.27778],60:[.0391,.5391,0,0,.77778],61:[-.13313,.36687,0,0,.77778],62:[.0391,.5391,0,0,.77778],63:[0,.69444,0,0,.47222],64:[0,.69444,0,0,.77778],65:[0,.68333,0,0,.75],66:[0,.68333,0,0,.70834],67:[0,.68333,0,0,.72222],68:[0,.68333,0,0,.76389],69:[0,.68333,0,0,.68056],70:[0,.68333,0,0,.65278],71:[0,.68333,0,0,.78472],72:[0,.68333,0,0,.75],73:[0,.68333,0,0,.36111],74:[0,.68333,0,0,.51389],75:[0,.68333,0,0,.77778],76:[0,.68333,0,0,.625],77:[0,.68333,0,0,.91667],78:[0,.68333,0,0,.75],79:[0,.68333,0,0,.77778],80:[0,.68333,0,0,.68056],81:[.19444,.68333,0,0,.77778],82:[0,.68333,0,0,.73611],83:[0,.68333,0,0,.55556],84:[0,.68333,0,0,.72222],85:[0,.68333,0,0,.75],86:[0,.68333,.01389,0,.75],87:[0,.68333,.01389,0,1.02778],88:[0,.68333,0,0,.75],89:[0,.68333,.025,0,.75],90:[0,.68333,0,0,.61111],91:[.25,.75,0,0,.27778],92:[.25,.75,0,0,.5],93:[.25,.75,0,0,.27778],94:[0,.69444,0,0,.5],95:[.31,.12056,.02778,0,.5],97:[0,.43056,0,0,.5],98:[0,.69444,0,0,.55556],99:[0,.43056,0,0,.44445],100:[0,.69444,0,0,.55556],101:[0,.43056,0,0,.44445],102:[0,.69444,.07778,0,.30556],103:[.19444,.43056,.01389,0,.5],104:[0,.69444,0,0,.55556],105:[0,.66786,0,0,.27778],106:[.19444,.66786,0,0,.30556],107:[0,.69444,0,0,.52778],108:[0,.69444,0,0,.27778],109:[0,.43056,0,0,.83334],110:[0,.43056,0,0,.55556],111:[0,.43056,0,0,.5],112:[.19444,.43056,0,0,.55556],113:[.19444,.43056,0,0,.52778],114:[0,.43056,0,0,.39167],115:[0,.43056,0,0,.39445],116:[0,.61508,0,0,.38889],117:[0,.43056,0,0,.55556],118:[0,.43056,.01389,0,.52778],119:[0,.43056,.01389,0,.72222],120:[0,.43056,0,0,.52778],121:[.19444,.43056,.01389,0,.52778],122:[0,.43056,0,0,.44445],123:[.25,.75,0,0,.5],124:[.25,.75,0,0,.27778],125:[.25,.75,0,0,.5],126:[.35,.31786,0,0,.5],160:[0,0,0,0,.25],163:[0,.69444,0,0,.76909],167:[.19444,.69444,0,0,.44445],168:[0,.66786,0,0,.5],172:[0,.43056,0,0,.66667],176:[0,.69444,0,0,.75],177:[.08333,.58333,0,0,.77778],182:[.19444,.69444,0,0,.61111],184:[.17014,0,0,0,.44445],198:[0,.68333,0,0,.90278],215:[.08333,.58333,0,0,.77778],216:[.04861,.73194,0,0,.77778],223:[0,.69444,0,0,.5],230:[0,.43056,0,0,.72222],247:[.08333,.58333,0,0,.77778],248:[.09722,.52778,0,0,.5],305:[0,.43056,0,0,.27778],338:[0,.68333,0,0,1.01389],339:[0,.43056,0,0,.77778],567:[.19444,.43056,0,0,.30556],710:[0,.69444,0,0,.5],711:[0,.62847,0,0,.5],713:[0,.56778,0,0,.5],714:[0,.69444,0,0,.5],715:[0,.69444,0,0,.5],728:[0,.69444,0,0,.5],729:[0,.66786,0,0,.27778],730:[0,.69444,0,0,.75],732:[0,.66786,0,0,.5],733:[0,.69444,0,0,.5],915:[0,.68333,0,0,.625],916:[0,.68333,0,0,.83334],920:[0,.68333,0,0,.77778],923:[0,.68333,0,0,.69445],926:[0,.68333,0,0,.66667],928:[0,.68333,0,0,.75],931:[0,.68333,0,0,.72222],933:[0,.68333,0,0,.77778],934:[0,.68333,0,0,.72222],936:[0,.68333,0,0,.77778],937:[0,.68333,0,0,.72222],8211:[0,.43056,.02778,0,.5],8212:[0,.43056,.02778,0,1],8216:[0,.69444,0,0,.27778],8217:[0,.69444,0,0,.27778],8220:[0,.69444,0,0,.5],8221:[0,.69444,0,0,.5],8224:[.19444,.69444,0,0,.44445],8225:[.19444,.69444,0,0,.44445],8230:[0,.123,0,0,1.172],8242:[0,.55556,0,0,.275],8407:[0,.71444,.15382,0,.5],8463:[0,.68889,0,0,.54028],8465:[0,.69444,0,0,.72222],8467:[0,.69444,0,.11111,.41667],8472:[.19444,.43056,0,.11111,.63646],8476:[0,.69444,0,0,.72222],8501:[0,.69444,0,0,.61111],8592:[-.13313,.36687,0,0,1],8593:[.19444,.69444,0,0,.5],8594:[-.13313,.36687,0,0,1],8595:[.19444,.69444,0,0,.5],8596:[-.13313,.36687,0,0,1],8597:[.25,.75,0,0,.5],8598:[.19444,.69444,0,0,1],8599:[.19444,.69444,0,0,1],8600:[.19444,.69444,0,0,1],8601:[.19444,.69444,0,0,1],8614:[.011,.511,0,0,1],8617:[.011,.511,0,0,1.126],8618:[.011,.511,0,0,1.126],8636:[-.13313,.36687,0,0,1],8637:[-.13313,.36687,0,0,1],8640:[-.13313,.36687,0,0,1],8641:[-.13313,.36687,0,0,1],8652:[.011,.671,0,0,1],8656:[-.13313,.36687,0,0,1],8657:[.19444,.69444,0,0,.61111],8658:[-.13313,.36687,0,0,1],8659:[.19444,.69444,0,0,.61111],8660:[-.13313,.36687,0,0,1],8661:[.25,.75,0,0,.61111],8704:[0,.69444,0,0,.55556],8706:[0,.69444,.05556,.08334,.5309],8707:[0,.69444,0,0,.55556],8709:[.05556,.75,0,0,.5],8711:[0,.68333,0,0,.83334],8712:[.0391,.5391,0,0,.66667],8715:[.0391,.5391,0,0,.66667],8722:[.08333,.58333,0,0,.77778],8723:[.08333,.58333,0,0,.77778],8725:[.25,.75,0,0,.5],8726:[.25,.75,0,0,.5],8727:[-.03472,.46528,0,0,.5],8728:[-.05555,.44445,0,0,.5],8729:[-.05555,.44445,0,0,.5],8730:[.2,.8,0,0,.83334],8733:[0,.43056,0,0,.77778],8734:[0,.43056,0,0,1],8736:[0,.69224,0,0,.72222],8739:[.25,.75,0,0,.27778],8741:[.25,.75,0,0,.5],8743:[0,.55556,0,0,.66667],8744:[0,.55556,0,0,.66667],8745:[0,.55556,0,0,.66667],8746:[0,.55556,0,0,.66667],8747:[.19444,.69444,.11111,0,.41667],8764:[-.13313,.36687,0,0,.77778],8768:[.19444,.69444,0,0,.27778],8771:[-.03625,.46375,0,0,.77778],8773:[-.022,.589,0,0,.778],8776:[-.01688,.48312,0,0,.77778],8781:[-.03625,.46375,0,0,.77778],8784:[-.133,.673,0,0,.778],8801:[-.03625,.46375,0,0,.77778],8804:[.13597,.63597,0,0,.77778],8805:[.13597,.63597,0,0,.77778],8810:[.0391,.5391,0,0,1],8811:[.0391,.5391,0,0,1],8826:[.0391,.5391,0,0,.77778],8827:[.0391,.5391,0,0,.77778],8834:[.0391,.5391,0,0,.77778],8835:[.0391,.5391,0,0,.77778],8838:[.13597,.63597,0,0,.77778],8839:[.13597,.63597,0,0,.77778],8846:[0,.55556,0,0,.66667],8849:[.13597,.63597,0,0,.77778],8850:[.13597,.63597,0,0,.77778],8851:[0,.55556,0,0,.66667],8852:[0,.55556,0,0,.66667],8853:[.08333,.58333,0,0,.77778],8854:[.08333,.58333,0,0,.77778],8855:[.08333,.58333,0,0,.77778],8856:[.08333,.58333,0,0,.77778],8857:[.08333,.58333,0,0,.77778],8866:[0,.69444,0,0,.61111],8867:[0,.69444,0,0,.61111],8868:[0,.69444,0,0,.77778],8869:[0,.69444,0,0,.77778],8872:[.249,.75,0,0,.867],8900:[-.05555,.44445,0,0,.5],8901:[-.05555,.44445,0,0,.27778],8902:[-.03472,.46528,0,0,.5],8904:[.005,.505,0,0,.9],8942:[.03,.903,0,0,.278],8943:[-.19,.313,0,0,1.172],8945:[-.1,.823,0,0,1.282],8968:[.25,.75,0,0,.44445],8969:[.25,.75,0,0,.44445],8970:[.25,.75,0,0,.44445],8971:[.25,.75,0,0,.44445],8994:[-.14236,.35764,0,0,1],8995:[-.14236,.35764,0,0,1],9136:[.244,.744,0,0,.412],9137:[.244,.745,0,0,.412],9651:[.19444,.69444,0,0,.88889],9657:[-.03472,.46528,0,0,.5],9661:[.19444,.69444,0,0,.88889],9667:[-.03472,.46528,0,0,.5],9711:[.19444,.69444,0,0,1],9824:[.12963,.69444,0,0,.77778],9825:[.12963,.69444,0,0,.77778],9826:[.12963,.69444,0,0,.77778],9827:[.12963,.69444,0,0,.77778],9837:[0,.75,0,0,.38889],9838:[.19444,.69444,0,0,.38889],9839:[.19444,.69444,0,0,.38889],10216:[.25,.75,0,0,.38889],10217:[.25,.75,0,0,.38889],10222:[.244,.744,0,0,.412],10223:[.244,.745,0,0,.412],10229:[.011,.511,0,0,1.609],10230:[.011,.511,0,0,1.638],10231:[.011,.511,0,0,1.859],10232:[.024,.525,0,0,1.609],10233:[.024,.525,0,0,1.638],10234:[.024,.525,0,0,1.858],10236:[.011,.511,0,0,1.638],10815:[0,.68333,0,0,.75],10927:[.13597,.63597,0,0,.77778],10928:[.13597,.63597,0,0,.77778],57376:[.19444,.69444,0,0,0]},"Math-BoldItalic":{32:[0,0,0,0,.25],48:[0,.44444,0,0,.575],49:[0,.44444,0,0,.575],50:[0,.44444,0,0,.575],51:[.19444,.44444,0,0,.575],52:[.19444,.44444,0,0,.575],53:[.19444,.44444,0,0,.575],54:[0,.64444,0,0,.575],55:[.19444,.44444,0,0,.575],56:[0,.64444,0,0,.575],57:[.19444,.44444,0,0,.575],65:[0,.68611,0,0,.86944],66:[0,.68611,.04835,0,.8664],67:[0,.68611,.06979,0,.81694],68:[0,.68611,.03194,0,.93812],69:[0,.68611,.05451,0,.81007],70:[0,.68611,.15972,0,.68889],71:[0,.68611,0,0,.88673],72:[0,.68611,.08229,0,.98229],73:[0,.68611,.07778,0,.51111],74:[0,.68611,.10069,0,.63125],75:[0,.68611,.06979,0,.97118],76:[0,.68611,0,0,.75555],77:[0,.68611,.11424,0,1.14201],78:[0,.68611,.11424,0,.95034],79:[0,.68611,.03194,0,.83666],80:[0,.68611,.15972,0,.72309],81:[.19444,.68611,0,0,.86861],82:[0,.68611,.00421,0,.87235],83:[0,.68611,.05382,0,.69271],84:[0,.68611,.15972,0,.63663],85:[0,.68611,.11424,0,.80027],86:[0,.68611,.25555,0,.67778],87:[0,.68611,.15972,0,1.09305],88:[0,.68611,.07778,0,.94722],89:[0,.68611,.25555,0,.67458],90:[0,.68611,.06979,0,.77257],97:[0,.44444,0,0,.63287],98:[0,.69444,0,0,.52083],99:[0,.44444,0,0,.51342],100:[0,.69444,0,0,.60972],101:[0,.44444,0,0,.55361],102:[.19444,.69444,.11042,0,.56806],103:[.19444,.44444,.03704,0,.5449],104:[0,.69444,0,0,.66759],105:[0,.69326,0,0,.4048],106:[.19444,.69326,.0622,0,.47083],107:[0,.69444,.01852,0,.6037],108:[0,.69444,.0088,0,.34815],109:[0,.44444,0,0,1.0324],110:[0,.44444,0,0,.71296],111:[0,.44444,0,0,.58472],112:[.19444,.44444,0,0,.60092],113:[.19444,.44444,.03704,0,.54213],114:[0,.44444,.03194,0,.5287],115:[0,.44444,0,0,.53125],116:[0,.63492,0,0,.41528],117:[0,.44444,0,0,.68102],118:[0,.44444,.03704,0,.56666],119:[0,.44444,.02778,0,.83148],120:[0,.44444,0,0,.65903],121:[.19444,.44444,.03704,0,.59028],122:[0,.44444,.04213,0,.55509],160:[0,0,0,0,.25],915:[0,.68611,.15972,0,.65694],916:[0,.68611,0,0,.95833],920:[0,.68611,.03194,0,.86722],923:[0,.68611,0,0,.80555],926:[0,.68611,.07458,0,.84125],928:[0,.68611,.08229,0,.98229],931:[0,.68611,.05451,0,.88507],933:[0,.68611,.15972,0,.67083],934:[0,.68611,0,0,.76666],936:[0,.68611,.11653,0,.71402],937:[0,.68611,.04835,0,.8789],945:[0,.44444,0,0,.76064],946:[.19444,.69444,.03403,0,.65972],947:[.19444,.44444,.06389,0,.59003],948:[0,.69444,.03819,0,.52222],949:[0,.44444,0,0,.52882],950:[.19444,.69444,.06215,0,.50833],951:[.19444,.44444,.03704,0,.6],952:[0,.69444,.03194,0,.5618],953:[0,.44444,0,0,.41204],954:[0,.44444,0,0,.66759],955:[0,.69444,0,0,.67083],956:[.19444,.44444,0,0,.70787],957:[0,.44444,.06898,0,.57685],958:[.19444,.69444,.03021,0,.50833],959:[0,.44444,0,0,.58472],960:[0,.44444,.03704,0,.68241],961:[.19444,.44444,0,0,.6118],962:[.09722,.44444,.07917,0,.42361],963:[0,.44444,.03704,0,.68588],964:[0,.44444,.13472,0,.52083],965:[0,.44444,.03704,0,.63055],966:[.19444,.44444,0,0,.74722],967:[.19444,.44444,0,0,.71805],968:[.19444,.69444,.03704,0,.75833],969:[0,.44444,.03704,0,.71782],977:[0,.69444,0,0,.69155],981:[.19444,.69444,0,0,.7125],982:[0,.44444,.03194,0,.975],1009:[.19444,.44444,0,0,.6118],1013:[0,.44444,0,0,.48333],57649:[0,.44444,0,0,.39352],57911:[.19444,.44444,0,0,.43889]},"Math-Italic":{32:[0,0,0,0,.25],48:[0,.43056,0,0,.5],49:[0,.43056,0,0,.5],50:[0,.43056,0,0,.5],51:[.19444,.43056,0,0,.5],52:[.19444,.43056,0,0,.5],53:[.19444,.43056,0,0,.5],54:[0,.64444,0,0,.5],55:[.19444,.43056,0,0,.5],56:[0,.64444,0,0,.5],57:[.19444,.43056,0,0,.5],65:[0,.68333,0,.13889,.75],66:[0,.68333,.05017,.08334,.75851],67:[0,.68333,.07153,.08334,.71472],68:[0,.68333,.02778,.05556,.82792],69:[0,.68333,.05764,.08334,.7382],70:[0,.68333,.13889,.08334,.64306],71:[0,.68333,0,.08334,.78625],72:[0,.68333,.08125,.05556,.83125],73:[0,.68333,.07847,.11111,.43958],74:[0,.68333,.09618,.16667,.55451],75:[0,.68333,.07153,.05556,.84931],76:[0,.68333,0,.02778,.68056],77:[0,.68333,.10903,.08334,.97014],78:[0,.68333,.10903,.08334,.80347],79:[0,.68333,.02778,.08334,.76278],80:[0,.68333,.13889,.08334,.64201],81:[.19444,.68333,0,.08334,.79056],82:[0,.68333,.00773,.08334,.75929],83:[0,.68333,.05764,.08334,.6132],84:[0,.68333,.13889,.08334,.58438],85:[0,.68333,.10903,.02778,.68278],86:[0,.68333,.22222,0,.58333],87:[0,.68333,.13889,0,.94445],88:[0,.68333,.07847,.08334,.82847],89:[0,.68333,.22222,0,.58056],90:[0,.68333,.07153,.08334,.68264],97:[0,.43056,0,0,.52859],98:[0,.69444,0,0,.42917],99:[0,.43056,0,.05556,.43276],100:[0,.69444,0,.16667,.52049],101:[0,.43056,0,.05556,.46563],102:[.19444,.69444,.10764,.16667,.48959],103:[.19444,.43056,.03588,.02778,.47697],104:[0,.69444,0,0,.57616],105:[0,.65952,0,0,.34451],106:[.19444,.65952,.05724,0,.41181],107:[0,.69444,.03148,0,.5206],108:[0,.69444,.01968,.08334,.29838],109:[0,.43056,0,0,.87801],110:[0,.43056,0,0,.60023],111:[0,.43056,0,.05556,.48472],112:[.19444,.43056,0,.08334,.50313],113:[.19444,.43056,.03588,.08334,.44641],114:[0,.43056,.02778,.05556,.45116],115:[0,.43056,0,.05556,.46875],116:[0,.61508,0,.08334,.36111],117:[0,.43056,0,.02778,.57246],118:[0,.43056,.03588,.02778,.48472],119:[0,.43056,.02691,.08334,.71592],120:[0,.43056,0,.02778,.57153],121:[.19444,.43056,.03588,.05556,.49028],122:[0,.43056,.04398,.05556,.46505],160:[0,0,0,0,.25],915:[0,.68333,.13889,.08334,.61528],916:[0,.68333,0,.16667,.83334],920:[0,.68333,.02778,.08334,.76278],923:[0,.68333,0,.16667,.69445],926:[0,.68333,.07569,.08334,.74236],928:[0,.68333,.08125,.05556,.83125],931:[0,.68333,.05764,.08334,.77986],933:[0,.68333,.13889,.05556,.58333],934:[0,.68333,0,.08334,.66667],936:[0,.68333,.11,.05556,.61222],937:[0,.68333,.05017,.08334,.7724],945:[0,.43056,.0037,.02778,.6397],946:[.19444,.69444,.05278,.08334,.56563],947:[.19444,.43056,.05556,0,.51773],948:[0,.69444,.03785,.05556,.44444],949:[0,.43056,0,.08334,.46632],950:[.19444,.69444,.07378,.08334,.4375],951:[.19444,.43056,.03588,.05556,.49653],952:[0,.69444,.02778,.08334,.46944],953:[0,.43056,0,.05556,.35394],954:[0,.43056,0,0,.57616],955:[0,.69444,0,0,.58334],956:[.19444,.43056,0,.02778,.60255],957:[0,.43056,.06366,.02778,.49398],958:[.19444,.69444,.04601,.11111,.4375],959:[0,.43056,0,.05556,.48472],960:[0,.43056,.03588,0,.57003],961:[.19444,.43056,0,.08334,.51702],962:[.09722,.43056,.07986,.08334,.36285],963:[0,.43056,.03588,0,.57141],964:[0,.43056,.1132,.02778,.43715],965:[0,.43056,.03588,.02778,.54028],966:[.19444,.43056,0,.08334,.65417],967:[.19444,.43056,0,.05556,.62569],968:[.19444,.69444,.03588,.11111,.65139],969:[0,.43056,.03588,0,.62245],977:[0,.69444,0,.08334,.59144],981:[.19444,.69444,0,.08334,.59583],982:[0,.43056,.02778,0,.82813],1009:[.19444,.43056,0,.08334,.51702],1013:[0,.43056,0,.05556,.4059],57649:[0,.43056,0,.02778,.32246],57911:[.19444,.43056,0,.08334,.38403]},"SansSerif-Bold":{32:[0,0,0,0,.25],33:[0,.69444,0,0,.36667],34:[0,.69444,0,0,.55834],35:[.19444,.69444,0,0,.91667],36:[.05556,.75,0,0,.55],37:[.05556,.75,0,0,1.02912],38:[0,.69444,0,0,.83056],39:[0,.69444,0,0,.30556],40:[.25,.75,0,0,.42778],41:[.25,.75,0,0,.42778],42:[0,.75,0,0,.55],43:[.11667,.61667,0,0,.85556],44:[.10556,.13056,0,0,.30556],45:[0,.45833,0,0,.36667],46:[0,.13056,0,0,.30556],47:[.25,.75,0,0,.55],48:[0,.69444,0,0,.55],49:[0,.69444,0,0,.55],50:[0,.69444,0,0,.55],51:[0,.69444,0,0,.55],52:[0,.69444,0,0,.55],53:[0,.69444,0,0,.55],54:[0,.69444,0,0,.55],55:[0,.69444,0,0,.55],56:[0,.69444,0,0,.55],57:[0,.69444,0,0,.55],58:[0,.45833,0,0,.30556],59:[.10556,.45833,0,0,.30556],61:[-.09375,.40625,0,0,.85556],63:[0,.69444,0,0,.51945],64:[0,.69444,0,0,.73334],65:[0,.69444,0,0,.73334],66:[0,.69444,0,0,.73334],67:[0,.69444,0,0,.70278],68:[0,.69444,0,0,.79445],69:[0,.69444,0,0,.64167],70:[0,.69444,0,0,.61111],71:[0,.69444,0,0,.73334],72:[0,.69444,0,0,.79445],73:[0,.69444,0,0,.33056],74:[0,.69444,0,0,.51945],75:[0,.69444,0,0,.76389],76:[0,.69444,0,0,.58056],77:[0,.69444,0,0,.97778],78:[0,.69444,0,0,.79445],79:[0,.69444,0,0,.79445],80:[0,.69444,0,0,.70278],81:[.10556,.69444,0,0,.79445],82:[0,.69444,0,0,.70278],83:[0,.69444,0,0,.61111],84:[0,.69444,0,0,.73334],85:[0,.69444,0,0,.76389],86:[0,.69444,.01528,0,.73334],87:[0,.69444,.01528,0,1.03889],88:[0,.69444,0,0,.73334],89:[0,.69444,.0275,0,.73334],90:[0,.69444,0,0,.67223],91:[.25,.75,0,0,.34306],93:[.25,.75,0,0,.34306],94:[0,.69444,0,0,.55],95:[.35,.10833,.03056,0,.55],97:[0,.45833,0,0,.525],98:[0,.69444,0,0,.56111],99:[0,.45833,0,0,.48889],100:[0,.69444,0,0,.56111],101:[0,.45833,0,0,.51111],102:[0,.69444,.07639,0,.33611],103:[.19444,.45833,.01528,0,.55],104:[0,.69444,0,0,.56111],105:[0,.69444,0,0,.25556],106:[.19444,.69444,0,0,.28611],107:[0,.69444,0,0,.53056],108:[0,.69444,0,0,.25556],109:[0,.45833,0,0,.86667],110:[0,.45833,0,0,.56111],111:[0,.45833,0,0,.55],112:[.19444,.45833,0,0,.56111],113:[.19444,.45833,0,0,.56111],114:[0,.45833,.01528,0,.37222],115:[0,.45833,0,0,.42167],116:[0,.58929,0,0,.40417],117:[0,.45833,0,0,.56111],118:[0,.45833,.01528,0,.5],119:[0,.45833,.01528,0,.74445],120:[0,.45833,0,0,.5],121:[.19444,.45833,.01528,0,.5],122:[0,.45833,0,0,.47639],126:[.35,.34444,0,0,.55],160:[0,0,0,0,.25],168:[0,.69444,0,0,.55],176:[0,.69444,0,0,.73334],180:[0,.69444,0,0,.55],184:[.17014,0,0,0,.48889],305:[0,.45833,0,0,.25556],567:[.19444,.45833,0,0,.28611],710:[0,.69444,0,0,.55],711:[0,.63542,0,0,.55],713:[0,.63778,0,0,.55],728:[0,.69444,0,0,.55],729:[0,.69444,0,0,.30556],730:[0,.69444,0,0,.73334],732:[0,.69444,0,0,.55],733:[0,.69444,0,0,.55],915:[0,.69444,0,0,.58056],916:[0,.69444,0,0,.91667],920:[0,.69444,0,0,.85556],923:[0,.69444,0,0,.67223],926:[0,.69444,0,0,.73334],928:[0,.69444,0,0,.79445],931:[0,.69444,0,0,.79445],933:[0,.69444,0,0,.85556],934:[0,.69444,0,0,.79445],936:[0,.69444,0,0,.85556],937:[0,.69444,0,0,.79445],8211:[0,.45833,.03056,0,.55],8212:[0,.45833,.03056,0,1.10001],8216:[0,.69444,0,0,.30556],8217:[0,.69444,0,0,.30556],8220:[0,.69444,0,0,.55834],8221:[0,.69444,0,0,.55834]},"SansSerif-Italic":{32:[0,0,0,0,.25],33:[0,.69444,.05733,0,.31945],34:[0,.69444,.00316,0,.5],35:[.19444,.69444,.05087,0,.83334],36:[.05556,.75,.11156,0,.5],37:[.05556,.75,.03126,0,.83334],38:[0,.69444,.03058,0,.75834],39:[0,.69444,.07816,0,.27778],40:[.25,.75,.13164,0,.38889],41:[.25,.75,.02536,0,.38889],42:[0,.75,.11775,0,.5],43:[.08333,.58333,.02536,0,.77778],44:[.125,.08333,0,0,.27778],45:[0,.44444,.01946,0,.33333],46:[0,.08333,0,0,.27778],47:[.25,.75,.13164,0,.5],48:[0,.65556,.11156,0,.5],49:[0,.65556,.11156,0,.5],50:[0,.65556,.11156,0,.5],51:[0,.65556,.11156,0,.5],52:[0,.65556,.11156,0,.5],53:[0,.65556,.11156,0,.5],54:[0,.65556,.11156,0,.5],55:[0,.65556,.11156,0,.5],56:[0,.65556,.11156,0,.5],57:[0,.65556,.11156,0,.5],58:[0,.44444,.02502,0,.27778],59:[.125,.44444,.02502,0,.27778],61:[-.13,.37,.05087,0,.77778],63:[0,.69444,.11809,0,.47222],64:[0,.69444,.07555,0,.66667],65:[0,.69444,0,0,.66667],66:[0,.69444,.08293,0,.66667],67:[0,.69444,.11983,0,.63889],68:[0,.69444,.07555,0,.72223],69:[0,.69444,.11983,0,.59722],70:[0,.69444,.13372,0,.56945],71:[0,.69444,.11983,0,.66667],72:[0,.69444,.08094,0,.70834],73:[0,.69444,.13372,0,.27778],74:[0,.69444,.08094,0,.47222],75:[0,.69444,.11983,0,.69445],76:[0,.69444,0,0,.54167],77:[0,.69444,.08094,0,.875],78:[0,.69444,.08094,0,.70834],79:[0,.69444,.07555,0,.73611],80:[0,.69444,.08293,0,.63889],81:[.125,.69444,.07555,0,.73611],82:[0,.69444,.08293,0,.64584],83:[0,.69444,.09205,0,.55556],84:[0,.69444,.13372,0,.68056],85:[0,.69444,.08094,0,.6875],86:[0,.69444,.1615,0,.66667],87:[0,.69444,.1615,0,.94445],88:[0,.69444,.13372,0,.66667],89:[0,.69444,.17261,0,.66667],90:[0,.69444,.11983,0,.61111],91:[.25,.75,.15942,0,.28889],93:[.25,.75,.08719,0,.28889],94:[0,.69444,.0799,0,.5],95:[.35,.09444,.08616,0,.5],97:[0,.44444,.00981,0,.48056],98:[0,.69444,.03057,0,.51667],99:[0,.44444,.08336,0,.44445],100:[0,.69444,.09483,0,.51667],101:[0,.44444,.06778,0,.44445],102:[0,.69444,.21705,0,.30556],103:[.19444,.44444,.10836,0,.5],104:[0,.69444,.01778,0,.51667],105:[0,.67937,.09718,0,.23889],106:[.19444,.67937,.09162,0,.26667],107:[0,.69444,.08336,0,.48889],108:[0,.69444,.09483,0,.23889],109:[0,.44444,.01778,0,.79445],110:[0,.44444,.01778,0,.51667],111:[0,.44444,.06613,0,.5],112:[.19444,.44444,.0389,0,.51667],113:[.19444,.44444,.04169,0,.51667],114:[0,.44444,.10836,0,.34167],115:[0,.44444,.0778,0,.38333],116:[0,.57143,.07225,0,.36111],117:[0,.44444,.04169,0,.51667],118:[0,.44444,.10836,0,.46111],119:[0,.44444,.10836,0,.68334],120:[0,.44444,.09169,0,.46111],121:[.19444,.44444,.10836,0,.46111],122:[0,.44444,.08752,0,.43472],126:[.35,.32659,.08826,0,.5],160:[0,0,0,0,.25],168:[0,.67937,.06385,0,.5],176:[0,.69444,0,0,.73752],184:[.17014,0,0,0,.44445],305:[0,.44444,.04169,0,.23889],567:[.19444,.44444,.04169,0,.26667],710:[0,.69444,.0799,0,.5],711:[0,.63194,.08432,0,.5],713:[0,.60889,.08776,0,.5],714:[0,.69444,.09205,0,.5],715:[0,.69444,0,0,.5],728:[0,.69444,.09483,0,.5],729:[0,.67937,.07774,0,.27778],730:[0,.69444,0,0,.73752],732:[0,.67659,.08826,0,.5],733:[0,.69444,.09205,0,.5],915:[0,.69444,.13372,0,.54167],916:[0,.69444,0,0,.83334],920:[0,.69444,.07555,0,.77778],923:[0,.69444,0,0,.61111],926:[0,.69444,.12816,0,.66667],928:[0,.69444,.08094,0,.70834],931:[0,.69444,.11983,0,.72222],933:[0,.69444,.09031,0,.77778],934:[0,.69444,.04603,0,.72222],936:[0,.69444,.09031,0,.77778],937:[0,.69444,.08293,0,.72222],8211:[0,.44444,.08616,0,.5],8212:[0,.44444,.08616,0,1],8216:[0,.69444,.07816,0,.27778],8217:[0,.69444,.07816,0,.27778],8220:[0,.69444,.14205,0,.5],8221:[0,.69444,.00316,0,.5]},"SansSerif-Regular":{32:[0,0,0,0,.25],33:[0,.69444,0,0,.31945],34:[0,.69444,0,0,.5],35:[.19444,.69444,0,0,.83334],36:[.05556,.75,0,0,.5],37:[.05556,.75,0,0,.83334],38:[0,.69444,0,0,.75834],39:[0,.69444,0,0,.27778],40:[.25,.75,0,0,.38889],41:[.25,.75,0,0,.38889],42:[0,.75,0,0,.5],43:[.08333,.58333,0,0,.77778],44:[.125,.08333,0,0,.27778],45:[0,.44444,0,0,.33333],46:[0,.08333,0,0,.27778],47:[.25,.75,0,0,.5],48:[0,.65556,0,0,.5],49:[0,.65556,0,0,.5],50:[0,.65556,0,0,.5],51:[0,.65556,0,0,.5],52:[0,.65556,0,0,.5],53:[0,.65556,0,0,.5],54:[0,.65556,0,0,.5],55:[0,.65556,0,0,.5],56:[0,.65556,0,0,.5],57:[0,.65556,0,0,.5],58:[0,.44444,0,0,.27778],59:[.125,.44444,0,0,.27778],61:[-.13,.37,0,0,.77778],63:[0,.69444,0,0,.47222],64:[0,.69444,0,0,.66667],65:[0,.69444,0,0,.66667],66:[0,.69444,0,0,.66667],67:[0,.69444,0,0,.63889],68:[0,.69444,0,0,.72223],69:[0,.69444,0,0,.59722],70:[0,.69444,0,0,.56945],71:[0,.69444,0,0,.66667],72:[0,.69444,0,0,.70834],73:[0,.69444,0,0,.27778],74:[0,.69444,0,0,.47222],75:[0,.69444,0,0,.69445],76:[0,.69444,0,0,.54167],77:[0,.69444,0,0,.875],78:[0,.69444,0,0,.70834],79:[0,.69444,0,0,.73611],80:[0,.69444,0,0,.63889],81:[.125,.69444,0,0,.73611],82:[0,.69444,0,0,.64584],83:[0,.69444,0,0,.55556],84:[0,.69444,0,0,.68056],85:[0,.69444,0,0,.6875],86:[0,.69444,.01389,0,.66667],87:[0,.69444,.01389,0,.94445],88:[0,.69444,0,0,.66667],89:[0,.69444,.025,0,.66667],90:[0,.69444,0,0,.61111],91:[.25,.75,0,0,.28889],93:[.25,.75,0,0,.28889],94:[0,.69444,0,0,.5],95:[.35,.09444,.02778,0,.5],97:[0,.44444,0,0,.48056],98:[0,.69444,0,0,.51667],99:[0,.44444,0,0,.44445],100:[0,.69444,0,0,.51667],101:[0,.44444,0,0,.44445],102:[0,.69444,.06944,0,.30556],103:[.19444,.44444,.01389,0,.5],104:[0,.69444,0,0,.51667],105:[0,.67937,0,0,.23889],106:[.19444,.67937,0,0,.26667],107:[0,.69444,0,0,.48889],108:[0,.69444,0,0,.23889],109:[0,.44444,0,0,.79445],110:[0,.44444,0,0,.51667],111:[0,.44444,0,0,.5],112:[.19444,.44444,0,0,.51667],113:[.19444,.44444,0,0,.51667],114:[0,.44444,.01389,0,.34167],115:[0,.44444,0,0,.38333],116:[0,.57143,0,0,.36111],117:[0,.44444,0,0,.51667],118:[0,.44444,.01389,0,.46111],119:[0,.44444,.01389,0,.68334],120:[0,.44444,0,0,.46111],121:[.19444,.44444,.01389,0,.46111],122:[0,.44444,0,0,.43472],126:[.35,.32659,0,0,.5],160:[0,0,0,0,.25],168:[0,.67937,0,0,.5],176:[0,.69444,0,0,.66667],184:[.17014,0,0,0,.44445],305:[0,.44444,0,0,.23889],567:[.19444,.44444,0,0,.26667],710:[0,.69444,0,0,.5],711:[0,.63194,0,0,.5],713:[0,.60889,0,0,.5],714:[0,.69444,0,0,.5],715:[0,.69444,0,0,.5],728:[0,.69444,0,0,.5],729:[0,.67937,0,0,.27778],730:[0,.69444,0,0,.66667],732:[0,.67659,0,0,.5],733:[0,.69444,0,0,.5],915:[0,.69444,0,0,.54167],916:[0,.69444,0,0,.83334],920:[0,.69444,0,0,.77778],923:[0,.69444,0,0,.61111],926:[0,.69444,0,0,.66667],928:[0,.69444,0,0,.70834],931:[0,.69444,0,0,.72222],933:[0,.69444,0,0,.77778],934:[0,.69444,0,0,.72222],936:[0,.69444,0,0,.77778],937:[0,.69444,0,0,.72222],8211:[0,.44444,.02778,0,.5],8212:[0,.44444,.02778,0,1],8216:[0,.69444,0,0,.27778],8217:[0,.69444,0,0,.27778],8220:[0,.69444,0,0,.5],8221:[0,.69444,0,0,.5]},"Script-Regular":{32:[0,0,0,0,.25],65:[0,.7,.22925,0,.80253],66:[0,.7,.04087,0,.90757],67:[0,.7,.1689,0,.66619],68:[0,.7,.09371,0,.77443],69:[0,.7,.18583,0,.56162],70:[0,.7,.13634,0,.89544],71:[0,.7,.17322,0,.60961],72:[0,.7,.29694,0,.96919],73:[0,.7,.19189,0,.80907],74:[.27778,.7,.19189,0,1.05159],75:[0,.7,.31259,0,.91364],76:[0,.7,.19189,0,.87373],77:[0,.7,.15981,0,1.08031],78:[0,.7,.3525,0,.9015],79:[0,.7,.08078,0,.73787],80:[0,.7,.08078,0,1.01262],81:[0,.7,.03305,0,.88282],82:[0,.7,.06259,0,.85],83:[0,.7,.19189,0,.86767],84:[0,.7,.29087,0,.74697],85:[0,.7,.25815,0,.79996],86:[0,.7,.27523,0,.62204],87:[0,.7,.27523,0,.80532],88:[0,.7,.26006,0,.94445],89:[0,.7,.2939,0,.70961],90:[0,.7,.24037,0,.8212],160:[0,0,0,0,.25]},"Size1-Regular":{32:[0,0,0,0,.25],40:[.35001,.85,0,0,.45834],41:[.35001,.85,0,0,.45834],47:[.35001,.85,0,0,.57778],91:[.35001,.85,0,0,.41667],92:[.35001,.85,0,0,.57778],93:[.35001,.85,0,0,.41667],123:[.35001,.85,0,0,.58334],125:[.35001,.85,0,0,.58334],160:[0,0,0,0,.25],710:[0,.72222,0,0,.55556],732:[0,.72222,0,0,.55556],770:[0,.72222,0,0,.55556],771:[0,.72222,0,0,.55556],8214:[-99e-5,.601,0,0,.77778],8593:[1e-5,.6,0,0,.66667],8595:[1e-5,.6,0,0,.66667],8657:[1e-5,.6,0,0,.77778],8659:[1e-5,.6,0,0,.77778],8719:[.25001,.75,0,0,.94445],8720:[.25001,.75,0,0,.94445],8721:[.25001,.75,0,0,1.05556],8730:[.35001,.85,0,0,1],8739:[-.00599,.606,0,0,.33333],8741:[-.00599,.606,0,0,.55556],8747:[.30612,.805,.19445,0,.47222],8748:[.306,.805,.19445,0,.47222],8749:[.306,.805,.19445,0,.47222],8750:[.30612,.805,.19445,0,.47222],8896:[.25001,.75,0,0,.83334],8897:[.25001,.75,0,0,.83334],8898:[.25001,.75,0,0,.83334],8899:[.25001,.75,0,0,.83334],8968:[.35001,.85,0,0,.47222],8969:[.35001,.85,0,0,.47222],8970:[.35001,.85,0,0,.47222],8971:[.35001,.85,0,0,.47222],9168:[-99e-5,.601,0,0,.66667],10216:[.35001,.85,0,0,.47222],10217:[.35001,.85,0,0,.47222],10752:[.25001,.75,0,0,1.11111],10753:[.25001,.75,0,0,1.11111],10754:[.25001,.75,0,0,1.11111],10756:[.25001,.75,0,0,.83334],10758:[.25001,.75,0,0,.83334]},"Size2-Regular":{32:[0,0,0,0,.25],40:[.65002,1.15,0,0,.59722],41:[.65002,1.15,0,0,.59722],47:[.65002,1.15,0,0,.81111],91:[.65002,1.15,0,0,.47222],92:[.65002,1.15,0,0,.81111],93:[.65002,1.15,0,0,.47222],123:[.65002,1.15,0,0,.66667],125:[.65002,1.15,0,0,.66667],160:[0,0,0,0,.25],710:[0,.75,0,0,1],732:[0,.75,0,0,1],770:[0,.75,0,0,1],771:[0,.75,0,0,1],8719:[.55001,1.05,0,0,1.27778],8720:[.55001,1.05,0,0,1.27778],8721:[.55001,1.05,0,0,1.44445],8730:[.65002,1.15,0,0,1],8747:[.86225,1.36,.44445,0,.55556],8748:[.862,1.36,.44445,0,.55556],8749:[.862,1.36,.44445,0,.55556],8750:[.86225,1.36,.44445,0,.55556],8896:[.55001,1.05,0,0,1.11111],8897:[.55001,1.05,0,0,1.11111],8898:[.55001,1.05,0,0,1.11111],8899:[.55001,1.05,0,0,1.11111],8968:[.65002,1.15,0,0,.52778],8969:[.65002,1.15,0,0,.52778],8970:[.65002,1.15,0,0,.52778],8971:[.65002,1.15,0,0,.52778],10216:[.65002,1.15,0,0,.61111],10217:[.65002,1.15,0,0,.61111],10752:[.55001,1.05,0,0,1.51112],10753:[.55001,1.05,0,0,1.51112],10754:[.55001,1.05,0,0,1.51112],10756:[.55001,1.05,0,0,1.11111],10758:[.55001,1.05,0,0,1.11111]},"Size3-Regular":{32:[0,0,0,0,.25],40:[.95003,1.45,0,0,.73611],41:[.95003,1.45,0,0,.73611],47:[.95003,1.45,0,0,1.04445],91:[.95003,1.45,0,0,.52778],92:[.95003,1.45,0,0,1.04445],93:[.95003,1.45,0,0,.52778],123:[.95003,1.45,0,0,.75],125:[.95003,1.45,0,0,.75],160:[0,0,0,0,.25],710:[0,.75,0,0,1.44445],732:[0,.75,0,0,1.44445],770:[0,.75,0,0,1.44445],771:[0,.75,0,0,1.44445],8730:[.95003,1.45,0,0,1],8968:[.95003,1.45,0,0,.58334],8969:[.95003,1.45,0,0,.58334],8970:[.95003,1.45,0,0,.58334],8971:[.95003,1.45,0,0,.58334],10216:[.95003,1.45,0,0,.75],10217:[.95003,1.45,0,0,.75]},"Size4-Regular":{32:[0,0,0,0,.25],40:[1.25003,1.75,0,0,.79167],41:[1.25003,1.75,0,0,.79167],47:[1.25003,1.75,0,0,1.27778],91:[1.25003,1.75,0,0,.58334],92:[1.25003,1.75,0,0,1.27778],93:[1.25003,1.75,0,0,.58334],123:[1.25003,1.75,0,0,.80556],125:[1.25003,1.75,0,0,.80556],160:[0,0,0,0,.25],710:[0,.825,0,0,1.8889],732:[0,.825,0,0,1.8889],770:[0,.825,0,0,1.8889],771:[0,.825,0,0,1.8889],8730:[1.25003,1.75,0,0,1],8968:[1.25003,1.75,0,0,.63889],8969:[1.25003,1.75,0,0,.63889],8970:[1.25003,1.75,0,0,.63889],8971:[1.25003,1.75,0,0,.63889],9115:[.64502,1.155,0,0,.875],9116:[1e-5,.6,0,0,.875],9117:[.64502,1.155,0,0,.875],9118:[.64502,1.155,0,0,.875],9119:[1e-5,.6,0,0,.875],9120:[.64502,1.155,0,0,.875],9121:[.64502,1.155,0,0,.66667],9122:[-99e-5,.601,0,0,.66667],9123:[.64502,1.155,0,0,.66667],9124:[.64502,1.155,0,0,.66667],9125:[-99e-5,.601,0,0,.66667],9126:[.64502,1.155,0,0,.66667],9127:[1e-5,.9,0,0,.88889],9128:[.65002,1.15,0,0,.88889],9129:[.90001,0,0,0,.88889],9130:[0,.3,0,0,.88889],9131:[1e-5,.9,0,0,.88889],9132:[.65002,1.15,0,0,.88889],9133:[.90001,0,0,0,.88889],9143:[.88502,.915,0,0,1.05556],10216:[1.25003,1.75,0,0,.80556],10217:[1.25003,1.75,0,0,.80556],57344:[-.00499,.605,0,0,1.05556],57345:[-.00499,.605,0,0,1.05556],57680:[0,.12,0,0,.45],57681:[0,.12,0,0,.45],57682:[0,.12,0,0,.45],57683:[0,.12,0,0,.45]},"Typewriter-Regular":{32:[0,0,0,0,.525],33:[0,.61111,0,0,.525],34:[0,.61111,0,0,.525],35:[0,.61111,0,0,.525],36:[.08333,.69444,0,0,.525],37:[.08333,.69444,0,0,.525],38:[0,.61111,0,0,.525],39:[0,.61111,0,0,.525],40:[.08333,.69444,0,0,.525],41:[.08333,.69444,0,0,.525],42:[0,.52083,0,0,.525],43:[-.08056,.53055,0,0,.525],44:[.13889,.125,0,0,.525],45:[-.08056,.53055,0,0,.525],46:[0,.125,0,0,.525],47:[.08333,.69444,0,0,.525],48:[0,.61111,0,0,.525],49:[0,.61111,0,0,.525],50:[0,.61111,0,0,.525],51:[0,.61111,0,0,.525],52:[0,.61111,0,0,.525],53:[0,.61111,0,0,.525],54:[0,.61111,0,0,.525],55:[0,.61111,0,0,.525],56:[0,.61111,0,0,.525],57:[0,.61111,0,0,.525],58:[0,.43056,0,0,.525],59:[.13889,.43056,0,0,.525],60:[-.05556,.55556,0,0,.525],61:[-.19549,.41562,0,0,.525],62:[-.05556,.55556,0,0,.525],63:[0,.61111,0,0,.525],64:[0,.61111,0,0,.525],65:[0,.61111,0,0,.525],66:[0,.61111,0,0,.525],67:[0,.61111,0,0,.525],68:[0,.61111,0,0,.525],69:[0,.61111,0,0,.525],70:[0,.61111,0,0,.525],71:[0,.61111,0,0,.525],72:[0,.61111,0,0,.525],73:[0,.61111,0,0,.525],74:[0,.61111,0,0,.525],75:[0,.61111,0,0,.525],76:[0,.61111,0,0,.525],77:[0,.61111,0,0,.525],78:[0,.61111,0,0,.525],79:[0,.61111,0,0,.525],80:[0,.61111,0,0,.525],81:[.13889,.61111,0,0,.525],82:[0,.61111,0,0,.525],83:[0,.61111,0,0,.525],84:[0,.61111,0,0,.525],85:[0,.61111,0,0,.525],86:[0,.61111,0,0,.525],87:[0,.61111,0,0,.525],88:[0,.61111,0,0,.525],89:[0,.61111,0,0,.525],90:[0,.61111,0,0,.525],91:[.08333,.69444,0,0,.525],92:[.08333,.69444,0,0,.525],93:[.08333,.69444,0,0,.525],94:[0,.61111,0,0,.525],95:[.09514,0,0,0,.525],96:[0,.61111,0,0,.525],97:[0,.43056,0,0,.525],98:[0,.61111,0,0,.525],99:[0,.43056,0,0,.525],100:[0,.61111,0,0,.525],101:[0,.43056,0,0,.525],102:[0,.61111,0,0,.525],103:[.22222,.43056,0,0,.525],104:[0,.61111,0,0,.525],105:[0,.61111,0,0,.525],106:[.22222,.61111,0,0,.525],107:[0,.61111,0,0,.525],108:[0,.61111,0,0,.525],109:[0,.43056,0,0,.525],110:[0,.43056,0,0,.525],111:[0,.43056,0,0,.525],112:[.22222,.43056,0,0,.525],113:[.22222,.43056,0,0,.525],114:[0,.43056,0,0,.525],115:[0,.43056,0,0,.525],116:[0,.55358,0,0,.525],117:[0,.43056,0,0,.525],118:[0,.43056,0,0,.525],119:[0,.43056,0,0,.525],120:[0,.43056,0,0,.525],121:[.22222,.43056,0,0,.525],122:[0,.43056,0,0,.525],123:[.08333,.69444,0,0,.525],124:[.08333,.69444,0,0,.525],125:[.08333,.69444,0,0,.525],126:[0,.61111,0,0,.525],127:[0,.61111,0,0,.525],160:[0,0,0,0,.525],176:[0,.61111,0,0,.525],184:[.19445,0,0,0,.525],305:[0,.43056,0,0,.525],567:[.22222,.43056,0,0,.525],711:[0,.56597,0,0,.525],713:[0,.56555,0,0,.525],714:[0,.61111,0,0,.525],715:[0,.61111,0,0,.525],728:[0,.61111,0,0,.525],730:[0,.61111,0,0,.525],770:[0,.61111,0,0,.525],771:[0,.61111,0,0,.525],776:[0,.61111,0,0,.525],915:[0,.61111,0,0,.525],916:[0,.61111,0,0,.525],920:[0,.61111,0,0,.525],923:[0,.61111,0,0,.525],926:[0,.61111,0,0,.525],928:[0,.61111,0,0,.525],931:[0,.61111,0,0,.525],933:[0,.61111,0,0,.525],934:[0,.61111,0,0,.525],936:[0,.61111,0,0,.525],937:[0,.61111,0,0,.525],8216:[0,.61111,0,0,.525],8217:[0,.61111,0,0,.525],8242:[0,.61111,0,0,.525],9251:[.11111,.21944,0,0,.525]}},La={slant:[.25,.25,.25],space:[0,0,0],stretch:[0,0,0],shrink:[0,0,0],xHeight:[.431,.431,.431],quad:[1,1.171,1.472],extraSpace:[0,0,0],num1:[.677,.732,.925],num2:[.394,.384,.387],num3:[.444,.471,.504],denom1:[.686,.752,1.025],denom2:[.345,.344,.532],sup1:[.413,.503,.504],sup2:[.363,.431,.404],sup3:[.289,.286,.294],sub1:[.15,.143,.2],sub2:[.247,.286,.4],supDrop:[.386,.353,.494],subDrop:[.05,.071,.1],delim1:[2.39,1.7,1.98],delim2:[1.01,1.157,1.42],axisHeight:[.25,.25,.25],defaultRuleThickness:[.04,.049,.049],bigOpSpacing1:[.111,.111,.111],bigOpSpacing2:[.166,.166,.166],bigOpSpacing3:[.2,.2,.2],bigOpSpacing4:[.6,.611,.611],bigOpSpacing5:[.1,.143,.143],sqrtRuleThickness:[.04,.04,.04],ptPerEm:[10,10,10],doubleRuleSep:[.2,.2,.2],arrayRuleWidth:[.04,.04,.04],fboxsep:[.3,.3,.3],fboxrule:[.04,.04,.04]},Gi={\u00C5:"A",\u00D0:"D",\u00DE:"o",\u00E5:"a",\u00F0:"d",\u00FE:"o",\u0410:"A",\u0411:"B",\u0412:"B",\u0413:"F",\u0414:"A",\u0415:"E",\u0416:"K",\u0417:"3",\u0418:"N",\u0419:"N",\u041A:"K",\u041B:"N",\u041C:"M",\u041D:"H",\u041E:"O",\u041F:"N",\u0420:"P",\u0421:"C",\u0422:"T",\u0423:"y",\u0424:"O",\u0425:"X",\u0426:"U",\u0427:"h",\u0428:"W",\u0429:"W",\u042A:"B",\u042B:"X",\u042C:"B",\u042D:"3",\u042E:"X",\u042F:"R",\u0430:"a",\u0431:"b",\u0432:"a",\u0433:"r",\u0434:"y",\u0435:"e",\u0436:"m",\u0437:"e",\u0438:"n",\u0439:"n",\u043A:"n",\u043B:"n",\u043C:"m",\u043D:"n",\u043E:"o",\u043F:"n",\u0440:"p",\u0441:"c",\u0442:"o",\u0443:"y",\u0444:"b",\u0445:"x",\u0446:"n",\u0447:"n",\u0448:"w",\u0449:"w",\u044A:"a",\u044B:"m",\u044C:"a",\u044D:"e",\u044E:"m",\u044F:"r"};function su(r,e){p0[r]=e}function yn(r,e,t){if(!p0[e])throw new Error("Font metrics not found for font: "+e+".");var a=r.charCodeAt(0),n=p0[e][a];if(!n&&r[0]in Gi&&(a=Gi[r[0]].charCodeAt(0),n=p0[e][a]),!n&&t==="text"&&zs(a)&&(n=p0[e][77]),n)return{depth:n[0],height:n[1],italic:n[2],skew:n[3],width:n[4]}}var qa={};function lu(r){var e;if(r>=5?e=0:r>=3?e=1:e=2,!qa[e]){var t=qa[e]={cssEmPerMu:La.quad[e]/18};for(var a of Object.keys(La))t[a]=La[a][e]}return qa[e]}var he={math:{},text:{}};function s(r,e,t,a,n,i){he[r][n]={font:e,group:t,replace:a},i&&a&&(he[r][a]=he[r][n])}var o="math",z="text",c="main",v="ams",me="accent-token",q="bin",Le="close",St="inner",_="mathord",xe="op-token",Ze="open",Kt="punct",g="rel",A0="spacing",y="textord";s(o,c,g,"\u2261","\\equiv",!0);s(o,c,g,"\u227A","\\prec",!0);s(o,c,g,"\u227B","\\succ",!0);s(o,c,g,"\u223C","\\sim",!0);s(o,c,g,"\u22A5","\\perp");s(o,c,g,"\u2AAF","\\preceq",!0);s(o,c,g,"\u2AB0","\\succeq",!0);s(o,c,g,"\u2243","\\simeq",!0);s(o,c,g,"\u2223","\\mid",!0);s(o,c,g,"\u226A","\\ll",!0);s(o,c,g,"\u226B","\\gg",!0);s(o,c,g,"\u224D","\\asymp",!0);s(o,c,g,"\u2225","\\parallel");s(o,c,g,"\u22C8","\\bowtie",!0);s(o,c,g,"\u2323","\\smile",!0);s(o,c,g,"\u2291","\\sqsubseteq",!0);s(o,c,g,"\u2292","\\sqsupseteq",!0);s(o,c,g,"\u2250","\\doteq",!0);s(o,c,g,"\u2322","\\frown",!0);s(o,c,g,"\u220B","\\ni",!0);s(o,c,g,"\u221D","\\propto",!0);s(o,c,g,"\u22A2","\\vdash",!0);s(o,c,g,"\u22A3","\\dashv",!0);s(o,c,g,"\u220B","\\owns");s(o,c,Kt,".","\\ldotp");s(o,c,Kt,"\u22C5","\\cdotp");s(o,c,Kt,"\u22C5","\xB7");s(z,c,y,"\u22C5","\xB7");s(o,c,y,"#","\\#");s(z,c,y,"#","\\#");s(o,c,y,"&","\\&");s(z,c,y,"&","\\&");s(o,c,y,"\u2135","\\aleph",!0);s(o,c,y,"\u2200","\\forall",!0);s(o,c,y,"\u210F","\\hbar",!0);s(o,c,y,"\u2203","\\exists",!0);s(o,c,y,"\u2207","\\nabla",!0);s(o,c,y,"\u266D","\\flat",!0);s(o,c,y,"\u2113","\\ell",!0);s(o,c,y,"\u266E","\\natural",!0);s(o,c,y,"\u2663","\\clubsuit",!0);s(o,c,y,"\u2118","\\wp",!0);s(o,c,y,"\u266F","\\sharp",!0);s(o,c,y,"\u2662","\\diamondsuit",!0);s(o,c,y,"\u211C","\\Re",!0);s(o,c,y,"\u2661","\\heartsuit",!0);s(o,c,y,"\u2111","\\Im",!0);s(o,c,y,"\u2660","\\spadesuit",!0);s(o,c,y,"\xA7","\\S",!0);s(z,c,y,"\xA7","\\S");s(o,c,y,"\xB6","\\P",!0);s(z,c,y,"\xB6","\\P");s(o,c,y,"\u2020","\\dag");s(z,c,y,"\u2020","\\dag");s(z,c,y,"\u2020","\\textdagger");s(o,c,y,"\u2021","\\ddag");s(z,c,y,"\u2021","\\ddag");s(z,c,y,"\u2021","\\textdaggerdbl");s(o,c,Le,"\u23B1","\\rmoustache",!0);s(o,c,Ze,"\u23B0","\\lmoustache",!0);s(o,c,Le,"\u27EF","\\rgroup",!0);s(o,c,Ze,"\u27EE","\\lgroup",!0);s(o,c,q,"\u2213","\\mp",!0);s(o,c,q,"\u2296","\\ominus",!0);s(o,c,q,"\u228E","\\uplus",!0);s(o,c,q,"\u2293","\\sqcap",!0);s(o,c,q,"\u2217","\\ast");s(o,c,q,"\u2294","\\sqcup",!0);s(o,c,q,"\u25EF","\\bigcirc",!0);s(o,c,q,"\u2219","\\bullet",!0);s(o,c,q,"\u2021","\\ddagger");s(o,c,q,"\u2240","\\wr",!0);s(o,c,q,"\u2A3F","\\amalg");s(o,c,q,"&","\\And");s(o,c,g,"\u27F5","\\longleftarrow",!0);s(o,c,g,"\u21D0","\\Leftarrow",!0);s(o,c,g,"\u27F8","\\Longleftarrow",!0);s(o,c,g,"\u27F6","\\longrightarrow",!0);s(o,c,g,"\u21D2","\\Rightarrow",!0);s(o,c,g,"\u27F9","\\Longrightarrow",!0);s(o,c,g,"\u2194","\\leftrightarrow",!0);s(o,c,g,"\u27F7","\\longleftrightarrow",!0);s(o,c,g,"\u21D4","\\Leftrightarrow",!0);s(o,c,g,"\u27FA","\\Longleftrightarrow",!0);s(o,c,g,"\u21A6","\\mapsto",!0);s(o,c,g,"\u27FC","\\longmapsto",!0);s(o,c,g,"\u2197","\\nearrow",!0);s(o,c,g,"\u21A9","\\hookleftarrow",!0);s(o,c,g,"\u21AA","\\hookrightarrow",!0);s(o,c,g,"\u2198","\\searrow",!0);s(o,c,g,"\u21BC","\\leftharpoonup",!0);s(o,c,g,"\u21C0","\\rightharpoonup",!0);s(o,c,g,"\u2199","\\swarrow",!0);s(o,c,g,"\u21BD","\\leftharpoondown",!0);s(o,c,g,"\u21C1","\\rightharpoondown",!0);s(o,c,g,"\u2196","\\nwarrow",!0);s(o,c,g,"\u21CC","\\rightleftharpoons",!0);s(o,v,g,"\u226E","\\nless",!0);s(o,v,g,"\uE010","\\@nleqslant");s(o,v,g,"\uE011","\\@nleqq");s(o,v,g,"\u2A87","\\lneq",!0);s(o,v,g,"\u2268","\\lneqq",!0);s(o,v,g,"\uE00C","\\@lvertneqq");s(o,v,g,"\u22E6","\\lnsim",!0);s(o,v,g,"\u2A89","\\lnapprox",!0);s(o,v,g,"\u2280","\\nprec",!0);s(o,v,g,"\u22E0","\\npreceq",!0);s(o,v,g,"\u22E8","\\precnsim",!0);s(o,v,g,"\u2AB9","\\precnapprox",!0);s(o,v,g,"\u2241","\\nsim",!0);s(o,v,g,"\uE006","\\@nshortmid");s(o,v,g,"\u2224","\\nmid",!0);s(o,v,g,"\u22AC","\\nvdash",!0);s(o,v,g,"\u22AD","\\nvDash",!0);s(o,v,g,"\u22EA","\\ntriangleleft");s(o,v,g,"\u22EC","\\ntrianglelefteq",!0);s(o,v,g,"\u228A","\\subsetneq",!0);s(o,v,g,"\uE01A","\\@varsubsetneq");s(o,v,g,"\u2ACB","\\subsetneqq",!0);s(o,v,g,"\uE017","\\@varsubsetneqq");s(o,v,g,"\u226F","\\ngtr",!0);s(o,v,g,"\uE00F","\\@ngeqslant");s(o,v,g,"\uE00E","\\@ngeqq");s(o,v,g,"\u2A88","\\gneq",!0);s(o,v,g,"\u2269","\\gneqq",!0);s(o,v,g,"\uE00D","\\@gvertneqq");s(o,v,g,"\u22E7","\\gnsim",!0);s(o,v,g,"\u2A8A","\\gnapprox",!0);s(o,v,g,"\u2281","\\nsucc",!0);s(o,v,g,"\u22E1","\\nsucceq",!0);s(o,v,g,"\u22E9","\\succnsim",!0);s(o,v,g,"\u2ABA","\\succnapprox",!0);s(o,v,g,"\u2246","\\ncong",!0);s(o,v,g,"\uE007","\\@nshortparallel");s(o,v,g,"\u2226","\\nparallel",!0);s(o,v,g,"\u22AF","\\nVDash",!0);s(o,v,g,"\u22EB","\\ntriangleright");s(o,v,g,"\u22ED","\\ntrianglerighteq",!0);s(o,v,g,"\uE018","\\@nsupseteqq");s(o,v,g,"\u228B","\\supsetneq",!0);s(o,v,g,"\uE01B","\\@varsupsetneq");s(o,v,g,"\u2ACC","\\supsetneqq",!0);s(o,v,g,"\uE019","\\@varsupsetneqq");s(o,v,g,"\u22AE","\\nVdash",!0);s(o,v,g,"\u2AB5","\\precneqq",!0);s(o,v,g,"\u2AB6","\\succneqq",!0);s(o,v,g,"\uE016","\\@nsubseteqq");s(o,v,q,"\u22B4","\\unlhd");s(o,v,q,"\u22B5","\\unrhd");s(o,v,g,"\u219A","\\nleftarrow",!0);s(o,v,g,"\u219B","\\nrightarrow",!0);s(o,v,g,"\u21CD","\\nLeftarrow",!0);s(o,v,g,"\u21CF","\\nRightarrow",!0);s(o,v,g,"\u21AE","\\nleftrightarrow",!0);s(o,v,g,"\u21CE","\\nLeftrightarrow",!0);s(o,v,g,"\u25B3","\\vartriangle");s(o,v,y,"\u210F","\\hslash");s(o,v,y,"\u25BD","\\triangledown");s(o,v,y,"\u25CA","\\lozenge");s(o,v,y,"\u24C8","\\circledS");s(o,v,y,"\xAE","\\circledR");s(z,v,y,"\xAE","\\circledR");s(o,v,y,"\u2221","\\measuredangle",!0);s(o,v,y,"\u2204","\\nexists");s(o,v,y,"\u2127","\\mho");s(o,v,y,"\u2132","\\Finv",!0);s(o,v,y,"\u2141","\\Game",!0);s(o,v,y,"\u2035","\\backprime");s(o,v,y,"\u25B2","\\blacktriangle");s(o,v,y,"\u25BC","\\blacktriangledown");s(o,v,y,"\u25A0","\\blacksquare");s(o,v,y,"\u29EB","\\blacklozenge");s(o,v,y,"\u2605","\\bigstar");s(o,v,y,"\u2222","\\sphericalangle",!0);s(o,v,y,"\u2201","\\complement",!0);s(o,v,y,"\xF0","\\eth",!0);s(z,c,y,"\xF0","\xF0");s(o,v,y,"\u2571","\\diagup");s(o,v,y,"\u2572","\\diagdown");s(o,v,y,"\u25A1","\\square");s(o,v,y,"\u25A1","\\Box");s(o,v,y,"\u25CA","\\Diamond");s(o,v,y,"\xA5","\\yen",!0);s(z,v,y,"\xA5","\\yen",!0);s(o,v,y,"\u2713","\\checkmark",!0);s(z,v,y,"\u2713","\\checkmark");s(o,v,y,"\u2136","\\beth",!0);s(o,v,y,"\u2138","\\daleth",!0);s(o,v,y,"\u2137","\\gimel",!0);s(o,v,y,"\u03DD","\\digamma",!0);s(o,v,y,"\u03F0","\\varkappa");s(o,v,Ze,"\u250C","\\@ulcorner",!0);s(o,v,Le,"\u2510","\\@urcorner",!0);s(o,v,Ze,"\u2514","\\@llcorner",!0);s(o,v,Le,"\u2518","\\@lrcorner",!0);s(o,v,g,"\u2266","\\leqq",!0);s(o,v,g,"\u2A7D","\\leqslant",!0);s(o,v,g,"\u2A95","\\eqslantless",!0);s(o,v,g,"\u2272","\\lesssim",!0);s(o,v,g,"\u2A85","\\lessapprox",!0);s(o,v,g,"\u224A","\\approxeq",!0);s(o,v,q,"\u22D6","\\lessdot");s(o,v,g,"\u22D8","\\lll",!0);s(o,v,g,"\u2276","\\lessgtr",!0);s(o,v,g,"\u22DA","\\lesseqgtr",!0);s(o,v,g,"\u2A8B","\\lesseqqgtr",!0);s(o,v,g,"\u2251","\\doteqdot");s(o,v,g,"\u2253","\\risingdotseq",!0);s(o,v,g,"\u2252","\\fallingdotseq",!0);s(o,v,g,"\u223D","\\backsim",!0);s(o,v,g,"\u22CD","\\backsimeq",!0);s(o,v,g,"\u2AC5","\\subseteqq",!0);s(o,v,g,"\u22D0","\\Subset",!0);s(o,v,g,"\u228F","\\sqsubset",!0);s(o,v,g,"\u227C","\\preccurlyeq",!0);s(o,v,g,"\u22DE","\\curlyeqprec",!0);s(o,v,g,"\u227E","\\precsim",!0);s(o,v,g,"\u2AB7","\\precapprox",!0);s(o,v,g,"\u22B2","\\vartriangleleft");s(o,v,g,"\u22B4","\\trianglelefteq");s(o,v,g,"\u22A8","\\vDash",!0);s(o,v,g,"\u22AA","\\Vvdash",!0);s(o,v,g,"\u2323","\\smallsmile");s(o,v,g,"\u2322","\\smallfrown");s(o,v,g,"\u224F","\\bumpeq",!0);s(o,v,g,"\u224E","\\Bumpeq",!0);s(o,v,g,"\u2267","\\geqq",!0);s(o,v,g,"\u2A7E","\\geqslant",!0);s(o,v,g,"\u2A96","\\eqslantgtr",!0);s(o,v,g,"\u2273","\\gtrsim",!0);s(o,v,g,"\u2A86","\\gtrapprox",!0);s(o,v,q,"\u22D7","\\gtrdot");s(o,v,g,"\u22D9","\\ggg",!0);s(o,v,g,"\u2277","\\gtrless",!0);s(o,v,g,"\u22DB","\\gtreqless",!0);s(o,v,g,"\u2A8C","\\gtreqqless",!0);s(o,v,g,"\u2256","\\eqcirc",!0);s(o,v,g,"\u2257","\\circeq",!0);s(o,v,g,"\u225C","\\triangleq",!0);s(o,v,g,"\u223C","\\thicksim");s(o,v,g,"\u2248","\\thickapprox");s(o,v,g,"\u2AC6","\\supseteqq",!0);s(o,v,g,"\u22D1","\\Supset",!0);s(o,v,g,"\u2290","\\sqsupset",!0);s(o,v,g,"\u227D","\\succcurlyeq",!0);s(o,v,g,"\u22DF","\\curlyeqsucc",!0);s(o,v,g,"\u227F","\\succsim",!0);s(o,v,g,"\u2AB8","\\succapprox",!0);s(o,v,g,"\u22B3","\\vartriangleright");s(o,v,g,"\u22B5","\\trianglerighteq");s(o,v,g,"\u22A9","\\Vdash",!0);s(o,v,g,"\u2223","\\shortmid");s(o,v,g,"\u2225","\\shortparallel");s(o,v,g,"\u226C","\\between",!0);s(o,v,g,"\u22D4","\\pitchfork",!0);s(o,v,g,"\u221D","\\varpropto");s(o,v,g,"\u25C0","\\blacktriangleleft");s(o,v,g,"\u2234","\\therefore",!0);s(o,v,g,"\u220D","\\backepsilon");s(o,v,g,"\u25B6","\\blacktriangleright");s(o,v,g,"\u2235","\\because",!0);s(o,v,g,"\u22D8","\\llless");s(o,v,g,"\u22D9","\\gggtr");s(o,v,q,"\u22B2","\\lhd");s(o,v,q,"\u22B3","\\rhd");s(o,v,g,"\u2242","\\eqsim",!0);s(o,c,g,"\u22C8","\\Join");s(o,v,g,"\u2251","\\Doteq",!0);s(o,v,q,"\u2214","\\dotplus",!0);s(o,v,q,"\u2216","\\smallsetminus");s(o,v,q,"\u22D2","\\Cap",!0);s(o,v,q,"\u22D3","\\Cup",!0);s(o,v,q,"\u2A5E","\\doublebarwedge",!0);s(o,v,q,"\u229F","\\boxminus",!0);s(o,v,q,"\u229E","\\boxplus",!0);s(o,v,q,"\u22C7","\\divideontimes",!0);s(o,v,q,"\u22C9","\\ltimes",!0);s(o,v,q,"\u22CA","\\rtimes",!0);s(o,v,q,"\u22CB","\\leftthreetimes",!0);s(o,v,q,"\u22CC","\\rightthreetimes",!0);s(o,v,q,"\u22CF","\\curlywedge",!0);s(o,v,q,"\u22CE","\\curlyvee",!0);s(o,v,q,"\u229D","\\circleddash",!0);s(o,v,q,"\u229B","\\circledast",!0);s(o,v,q,"\u22C5","\\centerdot");s(o,v,q,"\u22BA","\\intercal",!0);s(o,v,q,"\u22D2","\\doublecap");s(o,v,q,"\u22D3","\\doublecup");s(o,v,q,"\u22A0","\\boxtimes",!0);s(o,v,g,"\u21E2","\\dashrightarrow",!0);s(o,v,g,"\u21E0","\\dashleftarrow",!0);s(o,v,g,"\u21C7","\\leftleftarrows",!0);s(o,v,g,"\u21C6","\\leftrightarrows",!0);s(o,v,g,"\u21DA","\\Lleftarrow",!0);s(o,v,g,"\u219E","\\twoheadleftarrow",!0);s(o,v,g,"\u21A2","\\leftarrowtail",!0);s(o,v,g,"\u21AB","\\looparrowleft",!0);s(o,v,g,"\u21CB","\\leftrightharpoons",!0);s(o,v,g,"\u21B6","\\curvearrowleft",!0);s(o,v,g,"\u21BA","\\circlearrowleft",!0);s(o,v,g,"\u21B0","\\Lsh",!0);s(o,v,g,"\u21C8","\\upuparrows",!0);s(o,v,g,"\u21BF","\\upharpoonleft",!0);s(o,v,g,"\u21C3","\\downharpoonleft",!0);s(o,c,g,"\u22B6","\\origof",!0);s(o,c,g,"\u22B7","\\imageof",!0);s(o,v,g,"\u22B8","\\multimap",!0);s(o,v,g,"\u21AD","\\leftrightsquigarrow",!0);s(o,v,g,"\u21C9","\\rightrightarrows",!0);s(o,v,g,"\u21C4","\\rightleftarrows",!0);s(o,v,g,"\u21A0","\\twoheadrightarrow",!0);s(o,v,g,"\u21A3","\\rightarrowtail",!0);s(o,v,g,"\u21AC","\\looparrowright",!0);s(o,v,g,"\u21B7","\\curvearrowright",!0);s(o,v,g,"\u21BB","\\circlearrowright",!0);s(o,v,g,"\u21B1","\\Rsh",!0);s(o,v,g,"\u21CA","\\downdownarrows",!0);s(o,v,g,"\u21BE","\\upharpoonright",!0);s(o,v,g,"\u21C2","\\downharpoonright",!0);s(o,v,g,"\u21DD","\\rightsquigarrow",!0);s(o,v,g,"\u21DD","\\leadsto");s(o,v,g,"\u21DB","\\Rrightarrow",!0);s(o,v,g,"\u21BE","\\restriction");s(o,c,y,"\u2018","`");s(o,c,y,"$","\\$");s(z,c,y,"$","\\$");s(z,c,y,"$","\\textdollar");s(o,c,y,"%","\\%");s(z,c,y,"%","\\%");s(o,c,y,"_","\\_");s(z,c,y,"_","\\_");s(z,c,y,"_","\\textunderscore");s(o,c,y,"\u2220","\\angle",!0);s(o,c,y,"\u221E","\\infty",!0);s(o,c,y,"\u2032","\\prime");s(o,c,y,"\u25B3","\\triangle");s(o,c,y,"\u0393","\\Gamma",!0);s(o,c,y,"\u0394","\\Delta",!0);s(o,c,y,"\u0398","\\Theta",!0);s(o,c,y,"\u039B","\\Lambda",!0);s(o,c,y,"\u039E","\\Xi",!0);s(o,c,y,"\u03A0","\\Pi",!0);s(o,c,y,"\u03A3","\\Sigma",!0);s(o,c,y,"\u03A5","\\Upsilon",!0);s(o,c,y,"\u03A6","\\Phi",!0);s(o,c,y,"\u03A8","\\Psi",!0);s(o,c,y,"\u03A9","\\Omega",!0);s(o,c,y,"A","\u0391");s(o,c,y,"B","\u0392");s(o,c,y,"E","\u0395");s(o,c,y,"Z","\u0396");s(o,c,y,"H","\u0397");s(o,c,y,"I","\u0399");s(o,c,y,"K","\u039A");s(o,c,y,"M","\u039C");s(o,c,y,"N","\u039D");s(o,c,y,"O","\u039F");s(o,c,y,"P","\u03A1");s(o,c,y,"T","\u03A4");s(o,c,y,"X","\u03A7");s(o,c,y,"\xAC","\\neg",!0);s(o,c,y,"\xAC","\\lnot");s(o,c,y,"\u22A4","\\top");s(o,c,y,"\u22A5","\\bot");s(o,c,y,"\u2205","\\emptyset");s(o,v,y,"\u2205","\\varnothing");s(o,c,_,"\u03B1","\\alpha",!0);s(o,c,_,"\u03B2","\\beta",!0);s(o,c,_,"\u03B3","\\gamma",!0);s(o,c,_,"\u03B4","\\delta",!0);s(o,c,_,"\u03F5","\\epsilon",!0);s(o,c,_,"\u03B6","\\zeta",!0);s(o,c,_,"\u03B7","\\eta",!0);s(o,c,_,"\u03B8","\\theta",!0);s(o,c,_,"\u03B9","\\iota",!0);s(o,c,_,"\u03BA","\\kappa",!0);s(o,c,_,"\u03BB","\\lambda",!0);s(o,c,_,"\u03BC","\\mu",!0);s(o,c,_,"\u03BD","\\nu",!0);s(o,c,_,"\u03BE","\\xi",!0);s(o,c,_,"\u03BF","\\omicron",!0);s(o,c,_,"\u03C0","\\pi",!0);s(o,c,_,"\u03C1","\\rho",!0);s(o,c,_,"\u03C3","\\sigma",!0);s(o,c,_,"\u03C4","\\tau",!0);s(o,c,_,"\u03C5","\\upsilon",!0);s(o,c,_,"\u03D5","\\phi",!0);s(o,c,_,"\u03C7","\\chi",!0);s(o,c,_,"\u03C8","\\psi",!0);s(o,c,_,"\u03C9","\\omega",!0);s(o,c,_,"\u03B5","\\varepsilon",!0);s(o,c,_,"\u03D1","\\vartheta",!0);s(o,c,_,"\u03D6","\\varpi",!0);s(o,c,_,"\u03F1","\\varrho",!0);s(o,c,_,"\u03C2","\\varsigma",!0);s(o,c,_,"\u03C6","\\varphi",!0);s(o,c,q,"\u2217","*",!0);s(o,c,q,"+","+");s(o,c,q,"\u2212","-",!0);s(o,c,q,"\u22C5","\\cdot",!0);s(o,c,q,"\u2218","\\circ",!0);s(o,c,q,"\xF7","\\div",!0);s(o,c,q,"\xB1","\\pm",!0);s(o,c,q,"\xD7","\\times",!0);s(o,c,q,"\u2229","\\cap",!0);s(o,c,q,"\u222A","\\cup",!0);s(o,c,q,"\u2216","\\setminus",!0);s(o,c,q,"\u2227","\\land");s(o,c,q,"\u2228","\\lor");s(o,c,q,"\u2227","\\wedge",!0);s(o,c,q,"\u2228","\\vee",!0);s(o,c,y,"\u221A","\\surd");s(o,c,Ze,"\u27E8","\\langle",!0);s(o,c,Ze,"\u2223","\\lvert");s(o,c,Ze,"\u2225","\\lVert");s(o,c,Le,"?","?");s(o,c,Le,"!","!");s(o,c,Le,"\u27E9","\\rangle",!0);s(o,c,Le,"\u2223","\\rvert");s(o,c,Le,"\u2225","\\rVert");s(o,c,g,"=","=");s(o,c,g,":",":");s(o,c,g,"\u2248","\\approx",!0);s(o,c,g,"\u2245","\\cong",!0);s(o,c,g,"\u2265","\\ge");s(o,c,g,"\u2265","\\geq",!0);s(o,c,g,"\u2190","\\gets");s(o,c,g,">","\\gt",!0);s(o,c,g,"\u2208","\\in",!0);s(o,c,g,"\uE020","\\@not");s(o,c,g,"\u2282","\\subset",!0);s(o,c,g,"\u2283","\\supset",!0);s(o,c,g,"\u2286","\\subseteq",!0);s(o,c,g,"\u2287","\\supseteq",!0);s(o,v,g,"\u2288","\\nsubseteq",!0);s(o,v,g,"\u2289","\\nsupseteq",!0);s(o,c,g,"\u22A8","\\models");s(o,c,g,"\u2190","\\leftarrow",!0);s(o,c,g,"\u2264","\\le");s(o,c,g,"\u2264","\\leq",!0);s(o,c,g,"<","\\lt",!0);s(o,c,g,"\u2192","\\rightarrow",!0);s(o,c,g,"\u2192","\\to");s(o,v,g,"\u2271","\\ngeq",!0);s(o,v,g,"\u2270","\\nleq",!0);s(o,c,A0,"\xA0","\\ ");s(o,c,A0,"\xA0","\\space");s(o,c,A0,"\xA0","\\nobreakspace");s(z,c,A0,"\xA0","\\ ");s(z,c,A0,"\xA0"," ");s(z,c,A0,"\xA0","\\space");s(z,c,A0,"\xA0","\\nobreakspace");s(o,c,A0,"","\\nobreak");s(o,c,A0,"","\\allowbreak");s(o,c,Kt,",",",");s(o,c,Kt,";",";");s(o,v,q,"\u22BC","\\barwedge",!0);s(o,v,q,"\u22BB","\\veebar",!0);s(o,c,q,"\u2299","\\odot",!0);s(o,c,q,"\u2295","\\oplus",!0);s(o,c,q,"\u2297","\\otimes",!0);s(o,c,y,"\u2202","\\partial",!0);s(o,c,q,"\u2298","\\oslash",!0);s(o,v,q,"\u229A","\\circledcirc",!0);s(o,v,q,"\u22A1","\\boxdot",!0);s(o,c,q,"\u25B3","\\bigtriangleup");s(o,c,q,"\u25BD","\\bigtriangledown");s(o,c,q,"\u2020","\\dagger");s(o,c,q,"\u22C4","\\diamond");s(o,c,q,"\u22C6","\\star");s(o,c,q,"\u25C3","\\triangleleft");s(o,c,q,"\u25B9","\\triangleright");s(o,c,Ze,"{","\\{");s(z,c,y,"{","\\{");s(z,c,y,"{","\\textbraceleft");s(o,c,Le,"}","\\}");s(z,c,y,"}","\\}");s(z,c,y,"}","\\textbraceright");s(o,c,Ze,"{","\\lbrace");s(o,c,Le,"}","\\rbrace");s(o,c,Ze,"[","\\lbrack",!0);s(z,c,y,"[","\\lbrack",!0);s(o,c,Le,"]","\\rbrack",!0);s(z,c,y,"]","\\rbrack",!0);s(o,c,Ze,"(","\\lparen",!0);s(o,c,Le,")","\\rparen",!0);s(z,c,y,"<","\\textless",!0);s(z,c,y,">","\\textgreater",!0);s(o,c,Ze,"\u230A","\\lfloor",!0);s(o,c,Le,"\u230B","\\rfloor",!0);s(o,c,Ze,"\u2308","\\lceil",!0);s(o,c,Le,"\u2309","\\rceil",!0);s(o,c,y,"\\","\\backslash");s(o,c,y,"\u2223","|");s(o,c,y,"\u2223","\\vert");s(z,c,y,"|","\\textbar",!0);s(o,c,y,"\u2225","\\|");s(o,c,y,"\u2225","\\Vert");s(z,c,y,"\u2225","\\textbardbl");s(z,c,y,"~","\\textasciitilde");s(z,c,y,"\\","\\textbackslash");s(z,c,y,"^","\\textasciicircum");s(o,c,g,"\u2191","\\uparrow",!0);s(o,c,g,"\u21D1","\\Uparrow",!0);s(o,c,g,"\u2193","\\downarrow",!0);s(o,c,g,"\u21D3","\\Downarrow",!0);s(o,c,g,"\u2195","\\updownarrow",!0);s(o,c,g,"\u21D5","\\Updownarrow",!0);s(o,c,xe,"\u2210","\\coprod");s(o,c,xe,"\u22C1","\\bigvee");s(o,c,xe,"\u22C0","\\bigwedge");s(o,c,xe,"\u2A04","\\biguplus");s(o,c,xe,"\u22C2","\\bigcap");s(o,c,xe,"\u22C3","\\bigcup");s(o,c,xe,"\u222B","\\int");s(o,c,xe,"\u222B","\\intop");s(o,c,xe,"\u222C","\\iint");s(o,c,xe,"\u222D","\\iiint");s(o,c,xe,"\u220F","\\prod");s(o,c,xe,"\u2211","\\sum");s(o,c,xe,"\u2A02","\\bigotimes");s(o,c,xe,"\u2A01","\\bigoplus");s(o,c,xe,"\u2A00","\\bigodot");s(o,c,xe,"\u222E","\\oint");s(o,c,xe,"\u222F","\\oiint");s(o,c,xe,"\u2230","\\oiiint");s(o,c,xe,"\u2A06","\\bigsqcup");s(o,c,xe,"\u222B","\\smallint");s(z,c,St,"\u2026","\\textellipsis");s(o,c,St,"\u2026","\\mathellipsis");s(z,c,St,"\u2026","\\ldots",!0);s(o,c,St,"\u2026","\\ldots",!0);s(o,c,St,"\u22EF","\\@cdots",!0);s(o,c,St,"\u22F1","\\ddots",!0);s(o,c,y,"\u22EE","\\varvdots");s(z,c,y,"\u22EE","\\varvdots");s(o,c,me,"\u02CA","\\acute");s(o,c,me,"\u02CB","\\grave");s(o,c,me,"\xA8","\\ddot");s(o,c,me,"~","\\tilde");s(o,c,me,"\u02C9","\\bar");s(o,c,me,"\u02D8","\\breve");s(o,c,me,"\u02C7","\\check");s(o,c,me,"^","\\hat");s(o,c,me,"\u20D7","\\vec");s(o,c,me,"\u02D9","\\dot");s(o,c,me,"\u02DA","\\mathring");s(o,c,_,"\uE131","\\@imath");s(o,c,_,"\uE237","\\@jmath");s(o,c,y,"\u0131","\u0131");s(o,c,y,"\u0237","\u0237");s(z,c,y,"\u0131","\\i",!0);s(z,c,y,"\u0237","\\j",!0);s(z,c,y,"\xDF","\\ss",!0);s(z,c,y,"\xE6","\\ae",!0);s(z,c,y,"\u0153","\\oe",!0);s(z,c,y,"\xF8","\\o",!0);s(z,c,y,"\xC6","\\AE",!0);s(z,c,y,"\u0152","\\OE",!0);s(z,c,y,"\xD8","\\O",!0);s(z,c,me,"\u02CA","\\'");s(z,c,me,"\u02CB","\\`");s(z,c,me,"\u02C6","\\^");s(z,c,me,"\u02DC","\\~");s(z,c,me,"\u02C9","\\=");s(z,c,me,"\u02D8","\\u");s(z,c,me,"\u02D9","\\.");s(z,c,me,"\xB8","\\c");s(z,c,me,"\u02DA","\\r");s(z,c,me,"\u02C7","\\v");s(z,c,me,"\xA8",'\\"');s(z,c,me,"\u02DD","\\H");s(z,c,me,"\u25EF","\\textcircled");var Cs={"--":!0,"---":!0,"``":!0,"''":!0};s(z,c,y,"\u2013","--",!0);s(z,c,y,"\u2013","\\textendash");s(z,c,y,"\u2014","---",!0);s(z,c,y,"\u2014","\\textemdash");s(z,c,y,"\u2018","`",!0);s(z,c,y,"\u2018","\\textquoteleft");s(z,c,y,"\u2019","'",!0);s(z,c,y,"\u2019","\\textquoteright");s(z,c,y,"\u201C","``",!0);s(z,c,y,"\u201C","\\textquotedblleft");s(z,c,y,"\u201D","''",!0);s(z,c,y,"\u201D","\\textquotedblright");s(o,c,y,"\xB0","\\degree",!0);s(z,c,y,"\xB0","\\degree");s(z,c,y,"\xB0","\\textdegree",!0);s(o,c,y,"\xA3","\\pounds");s(o,c,y,"\xA3","\\mathsterling",!0);s(z,c,y,"\xA3","\\pounds");s(z,c,y,"\xA3","\\textsterling",!0);s(o,v,y,"\u2720","\\maltese");s(z,v,y,"\u2720","\\maltese");var ji='0123456789/@."';for(kr=0;kr<ji.length;kr++)Pa=ji.charAt(kr),s(o,c,y,Pa,Pa);var Pa,kr,Wi='0123456789!@*()-=+";:?/.,';for(Sr=0;Sr<Wi.length;Sr++)Fa=Wi.charAt(Sr),s(z,c,y,Fa,Fa);var Fa,Sr,Br="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";for(Tr=0;Tr<Br.length;Tr++)_t=Br.charAt(Tr),s(o,c,_,_t,_t),s(z,c,y,_t,_t);var _t,Tr;s(o,v,y,"C","\u2102");s(z,v,y,"C","\u2102");s(o,v,y,"H","\u210D");s(z,v,y,"H","\u210D");s(o,v,y,"N","\u2115");s(z,v,y,"N","\u2115");s(o,v,y,"P","\u2119");s(z,v,y,"P","\u2119");s(o,v,y,"Q","\u211A");s(z,v,y,"Q","\u211A");s(o,v,y,"R","\u211D");s(z,v,y,"R","\u211D");s(o,v,y,"Z","\u2124");s(z,v,y,"Z","\u2124");s(o,c,_,"h","\u210E");s(z,c,_,"h","\u210E");var G;for(Re=0;Re<Br.length;Re++)de=Br.charAt(Re),G=String.fromCharCode(55349,56320+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56372+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56424+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56580+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56684+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56736+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56788+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56840+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56944+Re),s(o,c,_,de,G),s(z,c,y,de,G),Re<26&&(G=String.fromCharCode(55349,56632+Re),s(o,c,_,de,G),s(z,c,y,de,G),G=String.fromCharCode(55349,56476+Re),s(o,c,_,de,G),s(z,c,y,de,G));var de,Re;G="\u{1D55C}";s(o,c,_,"k",G);s(z,c,y,"k",G);for(N0=0;N0<10;N0++)w0=N0.toString(),G=String.fromCharCode(55349,57294+N0),s(o,c,_,w0,G),s(z,c,y,w0,G),G=String.fromCharCode(55349,57314+N0),s(o,c,_,w0,G),s(z,c,y,w0,G),G=String.fromCharCode(55349,57324+N0),s(o,c,_,w0,G),s(z,c,y,w0,G),G=String.fromCharCode(55349,57334+N0),s(o,c,_,w0,G),s(z,c,y,w0,G);var w0,N0,Ja="\xD0\xDE\xFE";for(Ar=0;Ar<Ja.length;Ar++)Ht=Ja.charAt(Ar),s(o,c,_,Ht,Ht),s(z,c,y,Ht,Ht);var Ht,Ar,en={mathClass:"mathbf",textClass:"textbf",font:"Main-Bold"},Vi={mathClass:"mathnormal",textClass:"textit",font:"Math-Italic"},Yi={mathClass:"boldsymbol",textClass:"boldsymbol",font:"Main-BoldItalic"},ou={mathClass:"mathscr",textClass:"textscr",font:"Script-Regular"},et={mathClass:"",textClass:"",font:""},Xi={mathClass:"mathfrak",textClass:"textfrak",font:"Fraktur-Regular"},Zi={mathClass:"mathbb",textClass:"textbb",font:"AMS-Regular"},Ki={mathClass:"mathboldfrak",textClass:"textboldfrak",font:"Fraktur-Regular"},tn={mathClass:"mathsf",textClass:"textsf",font:"SansSerif-Regular"},rn={mathClass:"mathboldsf",textClass:"textboldsf",font:"SansSerif-Bold"},Qi={mathClass:"mathitsf",textClass:"textitsf",font:"SansSerif-Italic"},an={mathClass:"mathtt",textClass:"texttt",font:"Typewriter-Regular"},Ji=[en,en,Vi,Vi,Yi,Yi,ou,et,et,et,Xi,Xi,Zi,Zi,Ki,Ki,tn,tn,rn,rn,Qi,Qi,et,et,an,an],uu=[en,et,tn,rn,an],cu=r=>{var e=r.charCodeAt(0),t=r.charCodeAt(1),a=(e-55296)*1024+(t-56320)+65536;if(119808<=a&&a<120484){var n=Math.floor((a-119808)/26);return Ji[n]}else if(120782<=a&&a<=120831){var i=Math.floor((a-120782)/10);return uu[i]}else{if(a===120485||a===120486)return Ji[0];if(120486<a&&a<120782)return et;throw new C("Unsupported character: "+r)}},Fr=function(e,t,a){if(he[a][e]){var n=he[a][e].replace;n&&(e=n)}return{value:e,metrics:yn(e,t,a)}},Oe=function(e,t,a,n,i){var l=Fr(e,t,a),u=l.metrics;e=l.value;var h;if(u){var d=u.italic;(a==="text"||n&&n.font==="mathit")&&(d=0),h=new Ne(e,u.height,u.depth,d,u.skew,u.width,i)}else typeof console<"u"&&console.warn("No character metrics "+("for '"+e+"' in style '"+t+"' and mode '"+a+"'")),h=new Ne(e,0,0,0,0,0,i);if(n){h.maxFontSize=n.sizeMultiplier,n.style.isTight()&&h.classes.push("mtight");var f=n.getColor();f&&(h.style.color=f)}return h},xn=function(e,t,a,n){return n===void 0&&(n=[]),a.font==="boldsymbol"&&Fr(e,"Main-Bold",t).metrics?Oe(e,"Main-Bold",t,a,n.concat(["mathbf"])):e==="\\"||he[t][e].font==="main"?Oe(e,"Main-Regular",t,a,n):Oe(e,"AMS-Regular",t,a,n.concat(["amsrm"]))},hu=function(e,t,a){return a!=="textord"&&Fr(e,"Math-BoldItalic",t).metrics?{fontName:"Math-BoldItalic",fontClass:"boldsymbol"}:{fontName:"Main-Bold",fontClass:"mathbf"}},_r=function(e,t){var a=e.type==="mathord"?"mathord":"textord",n=e.mode,i=e.text,l=["mord"],u=t.font,h=t.fontFamily,d=t.fontWeight,f=t.fontShape,b=n==="math"||n==="text"&&!!u,k=b?u:h,w="",M="";if(i.charCodeAt(0)===55349){var D=cu(i);w=D.font,M=D[n+"Class"]}if(w)return Oe(i,w,n,t,l.concat(M));if(k){var E,N;if(k==="boldsymbol"){var B=hu(i,n,a);E=B.fontName,N=[B.fontClass]}else b?(E=nn[u].fontName,N=[u]):(E=zr(h,d,f),N=[h,d,f]);if(Fr(i,E,n).metrics)return Oe(i,E,n,t,l.concat(N));if(Object.prototype.hasOwnProperty.call(Cs,i)&&E.slice(0,10)==="Typewriter"){for(var F=[],H=0;H<i.length;H++)F.push(Oe(i[H],E,n,t,l.concat(N)));return z0(F)}}if(a==="mathord")return Oe(i,"Math-Italic",n,t,l.concat(["mathnormal"]));if(a==="textord"){var V=he[n][i]&&he[n][i].font;if(V==="ams"){var j=zr("amsrm",d,f);return Oe(i,j,n,t,l.concat("amsrm",d,f))}else if(V==="main"||!V){var $=zr("textrm",d,f);return Oe(i,$,n,t,l.concat(d,f))}else{var X=zr(V,d,f);return Oe(i,X,n,t,l.concat(X,d,f))}}else throw new Error("unexpected type: "+a+" in makeOrd")},mu=(r,e)=>{if(P0(r.classes)!==P0(e.classes)||r.skew!==e.skew||r.maxFontSize!==e.maxFontSize||r.italic!==0&&r.hasClass("mathnormal"))return!1;if(r.classes.length===1){var t=r.classes[0];if(t==="mbin"||t==="mord")return!1}for(var a of Object.keys(r.style))if(r.style[a]!==e.style[a])return!1;for(var n of Object.keys(e.style))if(r.style[n]!==e.style[n])return!1;return!0},Is=r=>{for(var e=0;e<r.length-1;e++){var t=r[e],a=r[e+1];t instanceof Ne&&a instanceof Ne&&mu(t,a)&&(t.text+=a.text,t.height=Math.max(t.height,a.height),t.depth=Math.max(t.depth,a.depth),t.italic=a.italic,r.splice(e+1,1),e--)}return r},wn=function(e){for(var t=0,a=0,n=0,i=0;i<e.children.length;i++){var l=e.children[i];l.height>t&&(t=l.height),l.depth>a&&(a=l.depth),l.maxFontSize>n&&(n=l.maxFontSize)}e.height=t,e.depth=a,e.maxFontSize=n},R=function(e,t,a,n){var i=new F0(e,t,a,n);return wn(i),i},_0=(r,e,t,a)=>new F0(r,e,t,a),wt=function(e,t,a){var n=R([e],[],t);return n.height=Math.max(a||t.fontMetrics().defaultRuleThickness,t.minRuleThickness),n.style.borderBottomWidth=O(n.height),n.maxFontSize=1,n},du=function(e,t,a,n){var i=new xt(e,t,a,n);return wn(i),i},z0=function(e){var t=new q0(e);return wn(t),t},kt=function(e,t){return e instanceof q0?R([],[e],t):e},pu=function(e){if(e.positionType==="individualShift"){for(var t=e.children,a=[t[0]],n=-t[0].shift-t[0].elem.depth,i=n,l=1;l<t.length;l++){var u=-t[l].shift-i-t[l].elem.depth,h=u-(t[l-1].elem.height+t[l-1].elem.depth);i=i+u,a.push({type:"kern",size:h}),a.push(t[l])}return{children:a,depth:n}}var d;if(e.positionType==="top"){for(var f=e.positionData,b=0;b<e.children.length;b++){var k=e.children[b];f-=k.type==="kern"?k.size:k.elem.height+k.elem.depth}d=f}else if(e.positionType==="bottom")d=-e.positionData;else{var w=e.children[0];if(w.type!=="elem")throw new Error('First child must have type "elem".');if(e.positionType==="shift")d=-w.elem.depth-e.positionData;else if(e.positionType==="firstBaseline")d=-w.elem.depth;else throw new Error("Invalid positionType "+e.positionType+".")}return{children:e.children,depth:d}},re=function(e,t){for(var a=pu(e),n=a.children,i=a.depth,l=0,u=0;u<n.length;u++){var h=n[u];if(h.type==="elem"){var d=h.elem;l=Math.max(l,d.maxFontSize,d.height)}}l+=2;var f=R(["pstrut"],[]);f.style.height=O(l);for(var b=[],k=i,w=i,M=i,D=0;D<n.length;D++){var E=n[D];if(E.type==="kern")M+=E.size;else{var N=E.elem,B=E.wrapperClasses||[],F=E.wrapperStyle||{},H=R(B,[f,N],void 0,F);H.style.top=O(-l-M-N.depth),E.marginLeft&&(H.style.marginLeft=E.marginLeft),E.marginRight&&(H.style.marginRight=E.marginRight),b.push(H),M+=N.height+N.depth}k=Math.min(k,M),w=Math.max(w,M)}var V=R(["vlist"],b);V.style.height=O(w);var j;if(k<0){var $=R([],[]),X=R(["vlist"],[$]);X.style.height=O(-k);var ee=R(["vlist-s"],[new Ne("\u200B")]);j=[R(["vlist-r"],[V,ee]),R(["vlist-r"],[X])]}else j=[R(["vlist-r"],[V])];var ae=R(["vlist-t"],j);return j.length===2&&ae.classes.push("vlist-t2"),ae.height=w,ae.depth=-k,ae},Os=(r,e)=>{var t=R(["mspace"],[],e),a=fe(r,e);return t.style.marginRight=O(a),t},zr=(r,e,t)=>{var a,n;switch(r){case"amsrm":a="AMS";break;case"textrm":a="Main";break;case"textsf":a="SansSerif";break;case"texttt":a="Typewriter";break;default:a=r}return e==="textbf"&&t==="textit"?n="BoldItalic":e==="textbf"?n="Bold":t==="textit"?n="Italic":n="Regular",a+"-"+n},nn={mathbf:{variant:"bold",fontName:"Main-Bold"},mathrm:{variant:"normal",fontName:"Main-Regular"},textit:{variant:"italic",fontName:"Main-Italic"},mathit:{variant:"italic",fontName:"Main-Italic"},mathnormal:{variant:"italic",fontName:"Math-Italic"},mathsfit:{variant:"sans-serif-italic",fontName:"SansSerif-Italic"},mathbb:{variant:"double-struck",fontName:"AMS-Regular"},mathcal:{variant:"script",fontName:"Caligraphic-Regular"},mathfrak:{variant:"fraktur",fontName:"Fraktur-Regular"},mathscr:{variant:"script",fontName:"Script-Regular"},mathsf:{variant:"sans-serif",fontName:"SansSerif-Regular"},mathtt:{variant:"monospace",fontName:"Typewriter-Regular"}},Bs={vec:["vec",.471,.714],oiintSize1:["oiintSize1",.957,.499],oiintSize2:["oiintSize2",1.472,.659],oiiintSize1:["oiiintSize1",1.304,.499],oiiintSize2:["oiiintSize2",1.98,.659]},Ns=function(e,t){var a=Bs[e],n=a[0],i=a[1],l=a[2],u=new f0(n),h=new o0([u],{width:O(i),height:O(l),style:"width:"+O(i),viewBox:"0 0 "+1e3*i+" "+1e3*l,preserveAspectRatio:"xMinYMin"}),d=_0(["katex-overlay"],[h],t);return d.height=l,d.style.height=O(l),d.style.width=O(i),d},pe={number:3,unit:"mu"},J0={number:4,unit:"mu"},k0={number:5,unit:"mu"},fu={mord:{mop:pe,mbin:J0,mrel:k0,minner:pe},mop:{mord:pe,mop:pe,mrel:k0,minner:pe},mbin:{mord:J0,mop:J0,mopen:J0,minner:J0},mrel:{mord:k0,mop:k0,mopen:k0,minner:k0},mopen:{},mclose:{mop:pe,mbin:J0,mrel:k0,minner:pe},mpunct:{mord:pe,mop:pe,mrel:k0,mopen:pe,mclose:pe,mpunct:pe,minner:pe},minner:{mord:pe,mop:pe,mbin:J0,mrel:k0,mopen:pe,mpunct:pe,minner:pe}},vu={mord:{mop:pe},mop:{mord:pe,mop:pe},mbin:{},mrel:{},mopen:{},mclose:{mop:pe},mpunct:{},minner:{mop:pe}},Ls={},Vt={},Yt={};function L(r){for(var e=r.type,t=r.names,a=r.htmlBuilder,n=r.mathmlBuilder,i=0;i<t.length;++i)Ls[t[i]]=r;e&&(a&&(Vt[e]=a),n&&(Yt[e]=n))}function tt(r){var e=r.type,t=r.htmlBuilder,a=r.mathmlBuilder;t&&(Vt[e]=t),a&&(Yt[e]=a)}var Xt=function(e){return e.type==="ordgroup"&&e.body.length===1?e.body[0]:e},ye=function(e){return e.type==="ordgroup"?e.body:[e]},gu=new Set(["leftmost","mbin","mopen","mrel","mop","mpunct"]),bu=new Set(["rightmost","mrel","mclose","mpunct"]),yu={display:W.DISPLAY,text:W.TEXT,script:W.SCRIPT,scriptscript:W.SCRIPTSCRIPT},xu={mord:"mord",mop:"mop",mbin:"mbin",mrel:"mrel",mopen:"mopen",mclose:"mclose",mpunct:"mpunct",minner:"minner"},Se=function(e,t,a,n){n===void 0&&(n=[null,null]);for(var i=[],l=0;l<e.length;l++){var u=te(e[l],t);if(u instanceof q0){var h=u.children;i.push(...h)}else i.push(u)}if(Is(i),!a)return i;var d=t;if(e.length===1){var f=e[0];f.type==="sizing"?d=t.havingSize(f.size):f.type==="styling"&&(d=t.havingStyle(yu[f.style]))}var b=R([n[0]||"leftmost"],[],t),k=R([n[1]||"rightmost"],[],t),w=a==="root";return sn(i,(M,D)=>{var E=D.classes[0],N=M.classes[0];E==="mbin"&&bu.has(N)?D.classes[0]="mord":N==="mbin"&&gu.has(E)&&(M.classes[0]="mord")},{node:b},k,w),sn(i,(M,D)=>{var E,N,B=on(D),F=on(M),H=B&&F?M.hasClass("mtight")?(E=vu[B])==null?void 0:E[F]:(N=fu[B])==null?void 0:N[F]:null;if(H)return Os(H,d)},{node:b},k,w),i},sn=function(e,t,a,n,i){n&&e.push(n);for(var l=0;l<e.length;l++){var u=e[l],h=qs(u);if(h){sn(h.children,t,a,null,i);continue}var d=!u.hasClass("mspace");if(d){var f=t(u,a.node);f&&(a.insertAfter?a.insertAfter(f):(e.unshift(f),l++))}d?a.node=u:i&&u.hasClass("katex-newline")&&(a.node=R(["leftmost"])),a.insertAfter=(b=>k=>{e.splice(b+1,0,k),l++})(l)}n&&e.pop()},qs=function(e){return e instanceof q0||e instanceof xt||e instanceof F0&&e.hasClass("enclosing")?e:null},ln=function(e,t){var a=qs(e);if(a){var n=a.children;if(n.length){if(t==="right")return ln(n[n.length-1],"right");if(t==="left")return ln(n[0],"left")}}return e},on=function(e,t){if(!e)return null;t&&(e=ln(e,t));var a=e.classes[0];return xu[a]||null},Zt=function(e,t){var a=["nulldelimiter"].concat(e.baseSizingClasses());return R(t.concat(a))},te=function(e,t,a){if(!e)return R();if(Vt[e.type]){var n=Vt[e.type](e,t);if(a&&t.size!==a.size){n=R(t.sizingClasses(a),[n],t);var i=t.sizeMultiplier/a.sizeMultiplier;n.height*=i,n.depth*=i}return n}else throw new C("Got group of unknown type: '"+e.type+"'")};function Mr(r,e){var t=R(["katex-base"],r,e),a=R(["katex-strut"]);return a.style.height=O(t.height+t.depth),t.depth&&(a.style.verticalAlign=O(-t.depth)),t.children.unshift(a),t}function un(r,e){var t=null;r.length===1&&r[0].type==="tag"&&(t=r[0].tag,r=r[0].body);var a=Se(r,e,"root"),n;a.length===2&&a[1].hasClass("katex-tag")&&(n=a.pop());for(var i=[],l=[],u=0;u<a.length;u++)if(l.push(a[u]),a[u].hasClass("mbin")||a[u].hasClass("mrel")||a[u].hasClass("allowbreak")){for(var h=!1;u<a.length-1&&a[u+1].hasClass("mspace")&&!a[u+1].hasClass("katex-newline");)u++,l.push(a[u]),a[u].hasClass("nobreak")&&(h=!0);h||(i.push(Mr(l,e)),l=[])}else a[u].hasClass("katex-newline")&&(l.pop(),l.length>0&&(i.push(Mr(l,e)),l=[]),i.push(a[u]));l.length>0&&i.push(Mr(l,e));var d;t?(d=Mr(Se(t,e,!0),e),d.classes=["katex-tag"],i.push(d)):n&&i.push(n);var f=R(["katex-html"],i);if(f.setAttribute("aria-hidden","true"),d){var b=d.children[0];b.style.height=O(f.height+f.depth),f.depth&&(b.style.verticalAlign=O(-f.depth))}return f}function Ps(r){return new q0(r)}var I=class{constructor(e,t,a){this.type=void 0,this.attributes=void 0,this.children=void 0,this.classes=void 0,this.type=e,this.attributes={},this.children=t||[],this.classes=a||[]}setAttribute(e,t){this.attributes[e]=t}getAttribute(e){return this.attributes[e]}toNode(){var e=document.createElementNS("http://www.w3.org/1998/Math/MathML",this.type);for(var t of Object.entries(this.attributes)){var a=t[0],n=t[1];e.setAttribute(a,n)}this.classes.length>0&&(e.className=P0(this.classes));for(var i=0;i<this.children.length;i++)if(this.children[i]instanceof ve&&this.children[i+1]instanceof ve){for(var l=this.children[i].toText()+this.children[++i].toText();this.children[i+1]instanceof ve;)l+=this.children[++i].toText();e.appendChild(new ve(l).toNode())}else e.appendChild(this.children[i].toNode());return e}toMarkup(){var e="<"+this.type;for(var t of Object.entries(this.attributes)){var a=t[0],n=t[1];e+=" "+a+'="',e+=De(n),e+='"'}this.classes.length>0&&(e+=' class ="'+De(P0(this.classes))+'"'),e+=">";for(var i=0;i<this.children.length;i++)e+=this.children[i].toMarkup();return e+="</"+this.type+">",e}toText(){return this.children.map(e=>e.toText()).join("")}},ve=class{constructor(e){this.text=void 0,this.text=e}toNode(){return document.createTextNode(this.text)}toMarkup(){return De(this.toText())}toText(){return this.text}},Nr=class{constructor(e){this.width=void 0,this.character=void 0,this.width=e,e>=.05555&&e<=.05556?this.character="\u200A":e>=.1666&&e<=.1667?this.character="\u2009":e>=.2222&&e<=.2223?this.character="\u2005":e>=.2777&&e<=.2778?this.character="\u2005\u200A":e>=-.05556&&e<=-.05555?this.character="\u200A\u2063":e>=-.1667&&e<=-.1666?this.character="\u2009\u2063":e>=-.2223&&e<=-.2222?this.character="\u205F\u2063":e>=-.2778&&e<=-.2777?this.character="\u2005\u2063":this.character=null}toNode(){if(this.character)return document.createTextNode(this.character);var e=document.createElementNS("http://www.w3.org/1998/Math/MathML","mspace");return e.setAttribute("width",O(this.width)),e}toMarkup(){return this.character?"<mtext>"+this.character+"</mtext>":'<mspace width="'+O(this.width)+'"/>'}toText(){return this.character?this.character:" "}},wu=new Set(["\\imath","\\jmath"]),ku=new Set(["mrow","mtable"]),a0=function(e,t,a){var n,i;return he[t][e]&&he[t][e].replace&&e.charCodeAt(0)!==55349&&!(Object.prototype.hasOwnProperty.call(Cs,e)&&((a==null||(n=a.fontFamily)==null?void 0:n.slice(4,6))==="tt"||(a==null||(i=a.font)==null?void 0:i.slice(4,6))==="tt"))&&(e=he[t][e].replace),new ve(e)},kn=function(e){return e.length===1?e[0]:new I("mrow",e)},Su={mathit:"italic",boldsymbol:r=>r.type==="textord"?"bold":"bold-italic",mathbf:"bold",mathbb:"double-struck",mathsfit:"sans-serif-italic",mathfrak:"fraktur",mathscr:"script",mathcal:"script",mathsf:"sans-serif",mathtt:"monospace"},Sn=(r,e)=>{if(r.mode==="text"){if(e.fontFamily==="texttt")return"monospace";if(e.fontFamily==="textsf")return e.fontShape==="textit"&&e.fontWeight==="textbf"?"sans-serif-bold-italic":e.fontShape==="textit"?"sans-serif-italic":e.fontWeight==="textbf"?"bold-sans-serif":"sans-serif";if(e.fontShape==="textit"&&e.fontWeight==="textbf")return"bold-italic";if(e.fontShape==="textit")return"italic";if(e.fontWeight==="textbf")return"bold"}var t=e.font;if(!t||t==="mathnormal")return null;var a=r.mode,n=Su[t];if(n)return typeof n=="function"?n(r):n;var i=r.text;if(wu.has(i))return null;if(he[a][i]){var l=he[a][i].replace;l&&(i=l)}var u=nn[t].fontName;return yn(i,u,a)?nn[t].variant:null};function _a(r){if(!r)return!1;if(r.type==="mi"&&r.children.length===1){var e=r.children[0];return e instanceof ve&&e.text==="."}else if(r.type==="mo"&&r.children.length===1&&r.getAttribute("separator")==="true"&&r.getAttribute("lspace")==="0em"&&r.getAttribute("rspace")==="0em"){var t=r.children[0];return t instanceof ve&&t.text===","}else return!1}var Ke=function(e,t,a){if(e.length===1){var n=se(e[0],t);return a&&n instanceof I&&n.type==="mo"&&(n.setAttribute("lspace","0em"),n.setAttribute("rspace","0em")),[n]}for(var i=[],l,u=0;u<e.length;u++){var h=se(e[u],t);if(h instanceof I&&l instanceof I){if(h.type==="mtext"&&l.type==="mtext"&&h.getAttribute("mathvariant")===l.getAttribute("mathvariant")){l.children.push(...h.children);continue}else if(h.type==="mn"&&l.type==="mn"){l.children.push(...h.children);continue}else if(_a(h)&&l.type==="mn"){l.children.push(...h.children);continue}else if(h.type==="mn"&&_a(l))h.children=[...l.children,...h.children],i.pop();else if((h.type==="msup"||h.type==="msub")&&h.children.length>=1&&(l.type==="mn"||_a(l))){var d=h.children[0];d instanceof I&&d.type==="mn"&&(d.children=[...l.children,...d.children],i.pop())}else if(l.type==="mi"&&l.children.length===1){var f=l.children[0];if(f instanceof ve&&f.text==="\u0338"&&(h.type==="mo"||h.type==="mi"||h.type==="mn")){var b=h.children[0];b instanceof ve&&b.text.length>0&&(b.text=b.text.slice(0,1)+"\u0338"+b.text.slice(1),i.pop())}}}i.push(h),l=h}return i},H0=function(e,t,a){return kn(Ke(e,t,a))},se=function(e,t){if(!e)return new I("mrow");if(Yt[e.type])return Yt[e.type](e,t);throw new C("Got group of unknown type: '"+e.type+"'")};function es(r,e,t,a,n){var i=Ke(r,t),l;i.length===1&&i[0]instanceof I&&ku.has(i[0].type)?l=i[0]:l=new I("mrow",i);var u=new I("annotation",[new ve(e)]);u.setAttribute("encoding","application/x-tex");var h=new I("semantics",[l,u]),d=new I("math",[h]);d.setAttribute("xmlns","http://www.w3.org/1998/Math/MathML"),a&&d.setAttribute("display","block");var f=n?"katex":"katex-mathml";return R([f],[d])}var Tu=[[1,1,1],[2,1,1],[3,1,1],[4,2,1],[5,2,1],[6,3,1],[7,4,2],[8,6,3],[9,7,6],[10,8,7],[11,10,9]],ts=[.5,.6,.7,.8,.9,1,1.2,1.44,1.728,2.074,2.488],rs=function(e,t){return t.size<2?e:Tu[e-1][t.size-1]},Lr=class r{constructor(e){this.style=void 0,this.color=void 0,this.size=void 0,this.textSize=void 0,this.phantom=void 0,this.font=void 0,this.fontFamily=void 0,this.fontWeight=void 0,this.fontShape=void 0,this.sizeMultiplier=void 0,this.maxSize=void 0,this.minRuleThickness=void 0,this._fontMetrics=void 0,this.style=e.style,this.color=e.color,this.size=e.size||r.BASESIZE,this.textSize=e.textSize||this.size,this.phantom=!!e.phantom,this.font=e.font||"",this.fontFamily=e.fontFamily||"",this.fontWeight=e.fontWeight||"",this.fontShape=e.fontShape||"",this.sizeMultiplier=ts[this.size-1],this.maxSize=e.maxSize,this.minRuleThickness=e.minRuleThickness,this._fontMetrics=void 0}extend(e){var t={style:this.style,size:this.size,textSize:this.textSize,color:this.color,phantom:this.phantom,font:this.font,fontFamily:this.fontFamily,fontWeight:this.fontWeight,fontShape:this.fontShape,maxSize:this.maxSize,minRuleThickness:this.minRuleThickness};return Object.assign(t,e),new r(t)}havingStyle(e){return this.style===e?this:this.extend({style:e,size:rs(this.textSize,e)})}havingCrampedStyle(){return this.havingStyle(this.style.cramp())}havingSize(e){return this.size===e&&this.textSize===e?this:this.extend({style:this.style.text(),size:e,textSize:e,sizeMultiplier:ts[e-1]})}havingBaseStyle(e){e=e||this.style.text();var t=rs(r.BASESIZE,e);return this.size===t&&this.textSize===r.BASESIZE&&this.style===e?this:this.extend({style:e,size:t})}havingBaseSizing(){var e;switch(this.style.id){case 4:case 5:e=3;break;case 6:case 7:e=1;break;default:e=6}return this.extend({style:this.style.text(),size:e})}withColor(e){return this.extend({color:e})}withPhantom(){return this.extend({phantom:!0})}withFont(e){return this.extend({font:e})}withTextFontFamily(e){return this.extend({fontFamily:e,font:""})}withTextFontWeight(e){return this.extend({fontWeight:e,font:""})}withTextFontShape(e){return this.extend({fontShape:e,font:""})}sizingClasses(e){return e.size!==this.size?["katex-sizing","reset-size"+e.size,"size"+this.size]:[]}baseSizingClasses(){return this.size!==r.BASESIZE?["katex-sizing","reset-size"+this.size,"size"+r.BASESIZE]:[]}fontMetrics(){return this._fontMetrics||(this._fontMetrics=lu(this.size)),this._fontMetrics}getColor(){return this.phantom?"transparent":this.color}};Lr.BASESIZE=6;var Fs=function(e){return new Lr({style:e.displayMode?W.DISPLAY:W.TEXT,maxSize:e.maxSize,minRuleThickness:e.minRuleThickness})},_s=function(e,t){if(t.displayMode){var a=["katex-display"];t.leqno&&a.push("leqno"),t.fleqn&&a.push("fleqn"),e=R(a,[e])}return e},Au=function(e,t,a){var n=Fs(a),i;if(a.output==="mathml")return es(e,t,n,a.displayMode,!0);if(a.output==="html"){var l=un(e,n);i=R(["katex"],[l])}else{var u=es(e,t,n,a.displayMode,!1),h=un(e,n);i=R(["katex"],[u,h])}return _s(i,a)},zu=function(e,t,a){var n=Fs(a),i=un(e,n),l=R(["katex"],[i]);return _s(l,a)},Mu={widehat:"^",widecheck:"\u02C7",widetilde:"~",utilde:"~",overleftarrow:"\u2190",underleftarrow:"\u2190",xleftarrow:"\u2190",overrightarrow:"\u2192",underrightarrow:"\u2192",xrightarrow:"\u2192",underbrace:"\u23DF",overbrace:"\u23DE",underbracket:"\u23B5",overbracket:"\u23B4",overgroup:"\u23E0",undergroup:"\u23E1",overleftrightarrow:"\u2194",underleftrightarrow:"\u2194",xleftrightarrow:"\u2194",Overrightarrow:"\u21D2",xRightarrow:"\u21D2",overleftharpoon:"\u21BC",xleftharpoonup:"\u21BC",overrightharpoon:"\u21C0",xrightharpoonup:"\u21C0",xLeftarrow:"\u21D0",xLeftrightarrow:"\u21D4",xhookleftarrow:"\u21A9",xhookrightarrow:"\u21AA",xmapsto:"\u21A6",xrightharpoondown:"\u21C1",xleftharpoondown:"\u21BD",xrightleftharpoons:"\u21CC",xleftrightharpoons:"\u21CB",xtwoheadleftarrow:"\u219E",xtwoheadrightarrow:"\u21A0",xlongequal:"=",xtofrom:"\u21C4",xrightleftarrows:"\u21C4",xrightequilibrium:"\u21CC",xleftequilibrium:"\u21CB","\\cdrightarrow":"\u2192","\\cdleftarrow":"\u2190","\\cdlongequal":"="},Hr=function(e){var t=new I("mo",[new ve(Mu[e.replace(/^\\/,"")])]);return t.setAttribute("stretchy","true"),t},Eu={overrightarrow:[["rightarrow"],.888,522,"xMaxYMin"],overleftarrow:[["leftarrow"],.888,522,"xMinYMin"],underrightarrow:[["rightarrow"],.888,522,"xMaxYMin"],underleftarrow:[["leftarrow"],.888,522,"xMinYMin"],xrightarrow:[["rightarrow"],1.469,522,"xMaxYMin"],"\\cdrightarrow":[["rightarrow"],3,522,"xMaxYMin"],xleftarrow:[["leftarrow"],1.469,522,"xMinYMin"],"\\cdleftarrow":[["leftarrow"],3,522,"xMinYMin"],Overrightarrow:[["doublerightarrow"],.888,560,"xMaxYMin"],xRightarrow:[["doublerightarrow"],1.526,560,"xMaxYMin"],xLeftarrow:[["doubleleftarrow"],1.526,560,"xMinYMin"],overleftharpoon:[["leftharpoon"],.888,522,"xMinYMin"],xleftharpoonup:[["leftharpoon"],.888,522,"xMinYMin"],xleftharpoondown:[["leftharpoondown"],.888,522,"xMinYMin"],overrightharpoon:[["rightharpoon"],.888,522,"xMaxYMin"],xrightharpoonup:[["rightharpoon"],.888,522,"xMaxYMin"],xrightharpoondown:[["rightharpoondown"],.888,522,"xMaxYMin"],xlongequal:[["longequal"],.888,334,"xMinYMin"],"\\cdlongequal":[["longequal"],3,334,"xMinYMin"],xtwoheadleftarrow:[["twoheadleftarrow"],.888,334,"xMinYMin"],xtwoheadrightarrow:[["twoheadrightarrow"],.888,334,"xMaxYMin"],overleftrightarrow:[["leftarrow","rightarrow"],.888,522],overbrace:[["leftbrace","midbrace","rightbrace"],1.6,548],underbrace:[["leftbraceunder","midbraceunder","rightbraceunder"],1.6,548],underleftrightarrow:[["leftarrow","rightarrow"],.888,522],xleftrightarrow:[["leftarrow","rightarrow"],1.75,522],xLeftrightarrow:[["doubleleftarrow","doublerightarrow"],1.75,560],xrightleftharpoons:[["leftharpoondownplus","rightharpoonplus"],1.75,716],xleftrightharpoons:[["leftharpoonplus","rightharpoondownplus"],1.75,716],xhookleftarrow:[["leftarrow","righthook"],1.08,522],xhookrightarrow:[["lefthook","rightarrow"],1.08,522],overlinesegment:[["leftlinesegment","rightlinesegment"],.888,522],underlinesegment:[["leftlinesegment","rightlinesegment"],.888,522],overbracket:[["leftbracketover","rightbracketover"],1.6,440],underbracket:[["leftbracketunder","rightbracketunder"],1.6,410],overgroup:[["leftgroup","rightgroup"],.888,342],undergroup:[["leftgroupunder","rightgroupunder"],.888,342],xmapsto:[["leftmapsto","rightarrow"],1.5,522],xtofrom:[["leftToFrom","rightToFrom"],1.75,528],xrightleftarrows:[["baraboveleftarrow","rightarrowabovebar"],1.75,901],xrightequilibrium:[["baraboveshortleftharpoon","rightharpoonaboveshortbar"],1.75,716],xleftequilibrium:[["shortbaraboveleftharpoon","shortrightharpoonabovebar"],1.75,716]},Ru=new Set(["widehat","widecheck","widetilde","utilde"]),$r=function(e,t){function a(){var h=4e5,d=e.label.slice(1);if(Ru.has(d)&&"base"in e){var f=e.base.type==="ordgroup"?e.base.body.length:1,b,k,w;if(f>5)d==="widehat"||d==="widecheck"?(b=420,h=2364,w=.42,k=d+"4"):(b=312,h=2340,w=.34,k="tilde4");else{var M=[1,1,2,2,3,3][f];d==="widehat"||d==="widecheck"?(h=[0,1062,2364,2364,2364][M],b=[0,239,300,360,420][M],w=[0,.24,.3,.3,.36,.42][M],k=d+M):(h=[0,600,1033,2339,2340][M],b=[0,260,286,306,312][M],w=[0,.26,.286,.3,.306,.34][M],k="tilde"+M)}var D=new f0(k),E=new o0([D],{width:"100%",height:O(w),viewBox:"0 0 "+h+" "+b,preserveAspectRatio:"none"});return{span:_0([],[E],t),minWidth:0,height:w}}else{var N=[],B=Eu[d];if(!B)throw new Error('No SVG data for "'+d+'".');var F=B[0],H=B[1],V=B[2],j=V/1e3,$=F.length,X,ee;if($===1){if(B.length!==4)throw new Error('Expected 4-tuple for single-path SVG data "'+d+'".');X=["hide-tail"],ee=[B[3]]}else if($===2)X=["halfarrow-left","halfarrow-right"],ee=["xMinYMin","xMaxYMin"];else if($===3)X=["brace-left","brace-center","brace-right"],ee=["xMinYMin","xMidYMin","xMaxYMin"];else throw new Error(`Correct katexImagesData or update code here to support
                    `+$+" children.");for(var ae=0;ae<$;ae++){var Q=new f0(F[ae]),ie=new o0([Q],{width:"400em",height:O(j),viewBox:"0 0 "+h+" "+V,preserveAspectRatio:ee[ae]+" slice"}),$e=_0([X[ae]],[ie],t);if($===1)return{span:$e,minWidth:H,height:j};$e.style.height=O(j),N.push($e)}return{span:R(["katex-stretchy"],N,t),minWidth:H,height:j}}}var n=a(),i=n.span,l=n.minWidth,u=n.height;return i.height=u,i.style.height=O(u),l>0&&(i.style.minWidth=O(l)),i},Du=function(e,t,a,n,i){var l,u=e.height+e.depth+a+n;if(/fbox|color|angl/.test(t)){if(l=R(["katex-stretchy",t],[],i),t==="fbox"){var h=i.color&&i.getColor();h&&(l.style.borderColor=h)}}else{var d=[];/^[bx]cancel$/.test(t)&&d.push(new Wt({x1:"0",y1:"0",x2:"100%",y2:"100%","stroke-width":"0.046em"})),/^x?cancel$/.test(t)&&d.push(new Wt({x1:"0",y1:"100%",x2:"100%",y2:"0","stroke-width":"0.046em"}));var f=new o0(d,{width:"100%",height:O(u)});l=_0([],[f],i)}return l.height=u,l.style.height=O(u),l},Cu=["bin","close","inner","open","punct","rel"],Iu=["accent-token","mathord","op-token","spacing","textord"],Ou=new Set(Cu),Bu=new Set(Iu);function Nu(r){return Ou.has(r)}function K(r,e){if(!r||r.type!==e)throw new Error("Expected node of type "+e+", but got "+(r?"node of type "+r.type:String(r)));return r}function Ur(r){var e=Gr(r);if(!e)throw new Error("Expected node of symbol group type, but got "+(r?"node of type "+r.type:String(r)));return e}function Gr(r){return r.type==="atom"||Bu.has(r.type)?r:null}function Tn(r,e,t){var a="";for(var n of r.body)if(n.type==="textord")a+=n.text;else if(t&&n.type==="spacing"&&n.text===" ")a+=" ";else throw new C(e,r);return a}var Hs=r=>{if(r instanceof Ne)return r;if(iu(r)&&r.children.length===1)return Hs(r.children[0])},$s=(r,e)=>{var t,a,n;r&&r.type==="supsub"?(a=K(r.base,"accent"),t=a.base,r.base=t,n=nu(te(r,e)),r.base=a):(a=K(r,"accent"),t=a.base);var i=te(t,e.havingCrampedStyle()),l=a.isShifty&&T0(t),u=0;if(l){var h,d;u=(h=(d=Hs(i))==null?void 0:d.skew)!=null?h:0}var f=a.label==="\\c",b=f?i.height+i.depth:Math.min(i.height,e.fontMetrics().xHeight),k;if(a.isStretchy)k=$r(a,e),k=re({positionType:"firstBaseline",children:[{type:"elem",elem:i},{type:"elem",elem:k,wrapperClasses:["svg-align"],wrapperStyle:u>0?{width:"calc(100% - "+O(2*u)+")",marginLeft:O(2*u)}:void 0}]});else{var w,M;a.label==="\\vec"?(w=Ns("vec",e),M=Bs.vec[1]):(w=_r({type:"textord",mode:a.mode,text:a.label},e),w=au(w),w.italic=0,M=w.width,f&&(b+=w.depth)),k=R(["accent-body"],[w]);var D=a.label==="\\textcircled";D&&(k.classes.push("accent-full"),b=i.height);var E=u;D||(E-=M/2),k.style.left=O(E),a.label==="\\textcircled"&&(k.style.top=".2em"),k=re({positionType:"firstBaseline",children:[{type:"elem",elem:i},{type:"kern",size:-b},{type:"elem",elem:k}]})}var N=R(["mord","katex-accent"],[k],e);return n?(n.children[0]=N,n.height=Math.max(N.height,n.height),n.classes[0]="mord",n):N},Lu=(r,e)=>{var t=r.isStretchy?Hr(r.label):new I("mo",[a0(r.label,r.mode)]),a=new I("mover",[se(r.base,e),t]);return a.setAttribute("accent","true"),a},qu=new RegExp(["\\acute","\\grave","\\ddot","\\tilde","\\bar","\\breve","\\check","\\hat","\\vec","\\dot","\\mathring"].map(r=>"\\"+r).join("|"));L({type:"accent",names:["\\acute","\\grave","\\ddot","\\tilde","\\bar","\\breve","\\check","\\hat","\\vec","\\dot","\\mathring","\\widecheck","\\widehat","\\widetilde","\\overrightarrow","\\overleftarrow","\\Overrightarrow","\\overleftrightarrow","\\overgroup","\\overlinesegment","\\overleftharpoon","\\overrightharpoon"],numArgs:1,handler:(r,e)=>{var t=Xt(e[0]),a=!qu.test(r.funcName),n=!a||r.funcName==="\\widehat"||r.funcName==="\\widetilde"||r.funcName==="\\widecheck";return{type:"accent",mode:r.parser.mode,label:r.funcName,isStretchy:a,isShifty:n,base:t}},htmlBuilder:$s,mathmlBuilder:Lu});L({type:"accent",names:["\\'","\\`","\\^","\\~","\\=","\\u","\\.",'\\"',"\\c","\\r","\\H","\\v","\\textcircled"],numArgs:1,allowedInText:!0,allowedInMath:!0,argTypes:["primitive"],handler:(r,e)=>{var t=e[0],a=r.parser.mode;return a==="math"&&(r.parser.settings.reportNonstrict("mathVsTextAccents","LaTeX's accent "+r.funcName+" works only in text mode"),a="text"),{type:"accent",mode:a,label:r.funcName,isStretchy:!1,isShifty:!0,base:t}}});L({type:"accentUnder",names:["\\underleftarrow","\\underrightarrow","\\underleftrightarrow","\\undergroup","\\underlinesegment","\\utilde"],numArgs:1,handler:(r,e)=>{var t=r.parser,a=r.funcName,n=e[0];return{type:"accentUnder",mode:t.mode,label:a,base:n}},htmlBuilder:(r,e)=>{var t=te(r.base,e),a=$r(r,e),n=r.label==="\\utilde"?.12:0,i=re({positionType:"top",positionData:t.height,children:[{type:"elem",elem:a,wrapperClasses:["svg-align"]},{type:"kern",size:n},{type:"elem",elem:t}]});return R(["mord","accentunder"],[i],e)},mathmlBuilder:(r,e)=>{var t=Hr(r.label),a=new I("munder",[se(r.base,e),t]);return a.setAttribute("accentunder","true"),a}});var Er=r=>{var e=new I("mpadded",r?[r]:[]);return e.setAttribute("width","+0.6em"),e.setAttribute("lspace","0.3em"),e};L({type:"xArrow",names:["\\xleftarrow","\\xrightarrow","\\xLeftarrow","\\xRightarrow","\\xleftrightarrow","\\xLeftrightarrow","\\xhookleftarrow","\\xhookrightarrow","\\xmapsto","\\xrightharpoondown","\\xrightharpoonup","\\xleftharpoondown","\\xleftharpoonup","\\xrightleftharpoons","\\xleftrightharpoons","\\xlongequal","\\xtwoheadrightarrow","\\xtwoheadleftarrow","\\xtofrom","\\xrightleftarrows","\\xrightequilibrium","\\xleftequilibrium","\\\\cdrightarrow","\\\\cdleftarrow","\\\\cdlongequal"],numArgs:1,numOptionalArgs:1,handler(r,e,t){var a=r.parser,n=r.funcName;return{type:"xArrow",mode:a.mode,label:n,body:e[0],below:t[0]}},htmlBuilder(r,e){var t=e.style,a=e.havingStyle(t.sup()),n=kt(te(r.body,a,e),e),i=r.label.slice(0,2)==="\\x"?"x":"cd";n.classes.push(i+"-arrow-pad");var l;r.below&&(a=e.havingStyle(t.sub()),l=kt(te(r.below,a,e),e),l.classes.push(i+"-arrow-pad"));var u=$r(r,e),h=-e.fontMetrics().axisHeight+.5*u.height,d=-e.fontMetrics().axisHeight-.5*u.height-.111;(n.depth>.25||r.label==="\\xleftequilibrium")&&(d-=n.depth);var f;if(l){var b=-e.fontMetrics().axisHeight+l.height+.5*u.height+.111;f=re({positionType:"individualShift",children:[{type:"elem",elem:n,shift:d},{type:"elem",elem:u,shift:h,wrapperClasses:["svg-align"]},{type:"elem",elem:l,shift:b}]})}else f=re({positionType:"individualShift",children:[{type:"elem",elem:n,shift:d},{type:"elem",elem:u,shift:h,wrapperClasses:["svg-align"]}]});return R(["mrel","x-arrow"],[f],e)},mathmlBuilder(r,e){var t=Hr(r.label);t.setAttribute("minsize",r.label.charAt(0)==="x"?"1.75em":"3.0em");var a;if(r.body){var n=Er(se(r.body,e));if(r.below){var i=Er(se(r.below,e));a=new I("munderover",[t,i,n])}else a=new I("mover",[t,n])}else if(r.below){var l=Er(se(r.below,e));a=new I("munder",[t,l])}else a=Er(),a=new I("mover",[t,a]);return a}});function Pu(r,e){var t=Se(r.body,e,!0);return R([r.mclass],t,e)}function Fu(r,e){var t,a=Ke(r.body,e);return r.mclass==="minner"?t=new I("mpadded",a):r.mclass==="mord"?r.isCharacterBox?(t=a[0],t.type="mi"):t=new I("mi",a):(r.isCharacterBox?(t=a[0],t.type="mo"):t=new I("mo",a),r.mclass==="mbin"?(t.attributes.lspace="0.22em",t.attributes.rspace="0.22em"):r.mclass==="mpunct"?(t.attributes.lspace="0em",t.attributes.rspace="0.17em"):(r.mclass==="mopen"||r.mclass==="mclose")&&(t.attributes.lspace="0em",t.attributes.rspace="0em")),t}L({type:"mclass",names:["\\mathord","\\mathbin","\\mathrel","\\mathopen","\\mathclose","\\mathpunct","\\mathinner"],numArgs:1,primitive:!0,handler(r,e){var t=r.parser,a=r.funcName,n=e[0];return{type:"mclass",mode:t.mode,mclass:"m"+a.slice(5),body:ye(n),isCharacterBox:T0(n)}},htmlBuilder:Pu,mathmlBuilder:Fu});var jr=r=>{var e=r.type==="ordgroup"&&r.body.length?r.body[0]:r;return e.type==="atom"&&(e.family==="bin"||e.family==="rel")?"m"+e.family:"mord"};L({type:"mclass",names:["\\@binrel"],numArgs:2,handler(r,e){var t=r.parser;return{type:"mclass",mode:t.mode,mclass:jr(e[0]),body:ye(e[1]),isCharacterBox:T0(e[1])}}});L({type:"mclass",names:["\\stackrel","\\overset","\\underset"],numArgs:2,handler(r,e){var t=r.parser,a=r.funcName,n=e[1],i=e[0],l;a!=="\\stackrel"?l=jr(n):l="mrel";var u={type:"op",mode:n.mode,limits:!0,alwaysHandleSupSub:!0,parentIsSupSub:!1,symbol:!1,suppressBaseShift:a!=="\\stackrel",body:ye(n)},h=a==="\\underset"?{type:"supsub",mode:i.mode,base:u,sub:i}:{type:"supsub",mode:i.mode,base:u,sup:i};return{type:"mclass",mode:t.mode,mclass:l,body:[h],isCharacterBox:T0(h)}}});L({type:"pmb",names:["\\pmb"],numArgs:1,allowedInText:!0,handler(r,e){var t=r.parser;return{type:"pmb",mode:t.mode,mclass:jr(e[0]),body:ye(e[0])}},htmlBuilder(r,e){var t=Se(r.body,e,!0),a=R([r.mclass],t,e);return a.style.textShadow="0.02em 0.01em 0.04px",a},mathmlBuilder(r,e){var t=Ke(r.body,e),a=new I("mstyle",t);return a.setAttribute("style","text-shadow: 0.02em 0.01em 0.04px"),a}});var _u={">":"\\\\cdrightarrow","<":"\\\\cdleftarrow","=":"\\\\cdlongequal",A:"\\uparrow",V:"\\downarrow","|":"\\Vert",".":"no arrow"},as=()=>({type:"styling",body:[],mode:"math",style:"display",resetFont:!0}),ns=r=>r.type==="textord"&&r.text==="@",Hu=(r,e)=>(r.type==="mathord"||r.type==="atom")&&r.text===e;function $u(r,e,t){var a=_u[r];switch(a){case"\\\\cdrightarrow":case"\\\\cdleftarrow":return t.callFunction(a,[e[0]],[e[1]]);case"\\uparrow":case"\\downarrow":{var n=t.callFunction("\\\\cdleft",[e[0]],[]),i={type:"atom",text:a,mode:"math",family:"rel"},l=t.callFunction("\\Big",[i],[]),u=t.callFunction("\\\\cdright",[e[1]],[]),h={type:"ordgroup",mode:"math",body:[n,l,u]};return t.callFunction("\\\\cdparent",[h],[])}case"\\\\cdlongequal":return t.callFunction("\\\\cdlongequal",[],[]);case"\\Vert":{var d={type:"textord",text:"\\Vert",mode:"math"};return t.callFunction("\\Big",[d],[])}default:return{type:"textord",text:" ",mode:"math"}}}function Uu(r){var e=[];for(r.gullet.beginGroup(),r.gullet.macros.set("\\cr","\\\\\\relax"),r.gullet.beginGroup();;){e.push(r.parseExpression(!1,"\\\\")),r.gullet.endGroup(),r.gullet.beginGroup();var t=r.fetch().text;if(t==="&"||t==="\\\\")r.consume();else if(t==="\\end"){e[e.length-1].length===0&&e.pop();break}else throw new C("Expected \\\\ or \\cr or \\end",r.nextToken)}for(var a=[],n=[a],i=0;i<e.length;i++){for(var l=e[i],u=as(),h=0;h<l.length;h++)if(!ns(l[h]))u.body.push(l[h]);else{a.push(u),h+=1;var d=Ur(l[h]).text,f=new Array(2);if(f[0]={type:"ordgroup",mode:"math",body:[]},f[1]={type:"ordgroup",mode:"math",body:[]},!"=|.".includes(d))if("<>AV".includes(d))for(var b=0;b<2;b++){for(var k=!0,w=h+1;w<l.length;w++){if(Hu(l[w],d)){k=!1,h=w;break}if(ns(l[w]))throw new C("Missing a "+d+" character to complete a CD arrow.",l[w]);f[b].body.push(l[w])}if(k)throw new C("Missing a "+d+" character to complete a CD arrow.",l[h])}else throw new C('Expected one of "<>AV=|." after @',l[h]);var M=$u(d,f,r),D={type:"styling",body:[M],mode:"math",style:"display",resetFont:!0};a.push(D),u=as()}i%2===0?a.push(u):a.shift(),a=[],n.push(a)}r.gullet.endGroup(),r.gullet.endGroup();var E=new Array(n[0].length).fill({type:"align",align:"c",pregap:.25,postgap:.25});return{type:"array",mode:"math",body:n,arraystretch:1,addJot:!0,rowGaps:[null],cols:E,colSeparationType:"CD",hLinesBeforeRow:new Array(n.length+1).fill([])}}L({type:"cdlabel",names:["\\\\cdleft","\\\\cdright"],numArgs:1,handler(r,e){var t=r.parser,a=r.funcName;return{type:"cdlabel",mode:t.mode,side:a.slice(4),label:e[0]}},htmlBuilder(r,e){var t=e.havingStyle(e.style.sup()),a=kt(te(r.label,t,e),e);return a.classes.push("cd-label-"+r.side),a.style.bottom=O(.8-a.depth),a.height=0,a.depth=0,a},mathmlBuilder(r,e){var t=new I("mrow",[se(r.label,e)]);return t=new I("mpadded",[t]),t.setAttribute("width","0"),r.side==="left"&&t.setAttribute("lspace","-1width"),t.setAttribute("voffset","0.7em"),t=new I("mstyle",[t]),t.setAttribute("displaystyle","false"),t.setAttribute("scriptlevel","1"),t}});L({type:"cdlabelparent",names:["\\\\cdparent"],numArgs:1,handler(r,e){var t=r.parser;return{type:"cdlabelparent",mode:t.mode,fragment:e[0]}},htmlBuilder(r,e){var t=kt(te(r.fragment,e),e);return t.classes.push("cd-vert-arrow"),t},mathmlBuilder(r,e){return new I("mrow",[se(r.fragment,e)])}});L({type:"textord",names:["\\@char"],numArgs:1,allowedInText:!0,handler(r,e){var t=r.parser,a=K(e[0],"ordgroup"),n=Tn(a,"\\@char has non-numeric argument"),i=parseInt(n),l;if(isNaN(i))throw new C("\\@char has non-numeric argument "+n);if(i<0||i>1114111)throw new C("\\@char with invalid code point "+n);return i<=65535?l=String.fromCharCode(i):(i-=65536,l=String.fromCharCode((i>>10)+55296,(i&1023)+56320)),{type:"textord",mode:t.mode,text:l}}});var Gu=(r,e)=>{var t=Se(r.body,e.withColor(r.color),!1);return z0(t)},ju=(r,e)=>{var t=Ke(r.body,e.withColor(r.color)),a=new I("mstyle",t);return a.setAttribute("mathcolor",r.color),a};L({type:"color",names:["\\textcolor"],numArgs:2,allowedInText:!0,argTypes:["color","original"],handler(r,e){var t=r.parser,a=K(e[0],"color-token").color,n=e[1];return{type:"color",mode:t.mode,color:a,body:ye(n)}},htmlBuilder:Gu,mathmlBuilder:ju});L({type:"color",names:["\\color"],numArgs:1,allowedInText:!0,argTypes:["color"],handler(r,e){var t=r.parser,a=r.breakOnTokenText,n=K(e[0],"color-token").color;t.gullet.macros.set("\\current@color",n);var i=t.parseExpression(!0,a);return{type:"color",mode:t.mode,color:n,body:i}}});L({type:"cr",names:["\\\\"],numArgs:0,numOptionalArgs:0,allowedInText:!0,handler(r,e,t){var a=r.parser,n=a.gullet.future().text==="["?a.parseSizeGroup(!0):null,i=!a.settings.displayMode||!a.settings.useStrictBehavior("newLineInDisplayMode","In LaTeX, \\\\ or \\newline does nothing in display mode");return{type:"cr",mode:a.mode,newLine:i,size:n&&K(n,"size").value}},htmlBuilder(r,e){var t=R(["mspace"],[],e);return r.newLine&&(t.classes.push("katex-newline"),r.size&&(t.style.marginTop=O(fe(r.size,e)))),t},mathmlBuilder(r,e){var t=new I("mspace");return r.newLine&&(t.setAttribute("linebreak","newline"),r.size&&t.setAttribute("height",O(fe(r.size,e)))),t}});var cn={"\\global":"\\global","\\long":"\\\\globallong","\\\\globallong":"\\\\globallong","\\def":"\\gdef","\\gdef":"\\gdef","\\edef":"\\xdef","\\xdef":"\\xdef","\\let":"\\\\globallet","\\futurelet":"\\\\globalfuture"},Us=r=>{var e=r.text;if(/^(?:[\\{}$&#^_]|EOF)$/.test(e))throw new C("Expected a control sequence",r);return e},Wu=r=>{var e=r.gullet.popToken();return e.text==="="&&(e=r.gullet.popToken(),e.text===" "&&(e=r.gullet.popToken())),e},Gs=(r,e,t,a)=>{var n=r.gullet.macros.get(t.text);n==null&&(t.noexpand=!0,n={tokens:[t],numArgs:0,unexpandable:!r.gullet.isExpandable(t.text)}),r.gullet.macros.set(e,n,a)};L({type:"internal",names:["\\global","\\long","\\\\globallong"],numArgs:0,allowedInText:!0,handler(r){var e=r.parser,t=r.funcName;e.consumeSpaces();var a=e.fetch();if(cn[a.text])return(t==="\\global"||t==="\\\\globallong")&&(a.text=cn[a.text]),K(e.parseFunction(),"internal");throw new C("Invalid token after macro prefix",a)}});L({type:"internal",names:["\\def","\\gdef","\\edef","\\xdef"],numArgs:0,allowedInText:!0,primitive:!0,handler(r){var e=r.parser,t=r.funcName,a=e.gullet.popToken(),n=a.text;if(/^(?:[\\{}$&#^_]|EOF)$/.test(n))throw new C("Expected a control sequence",a);for(var i=0,l,u=[[]];e.gullet.future().text!=="{";)if(a=e.gullet.popToken(),a.text==="#"){if(e.gullet.future().text==="{"){l=e.gullet.future(),u[i].push("{");break}if(a=e.gullet.popToken(),!/^[1-9]$/.test(a.text))throw new C('Invalid argument number "'+a.text+'"');if(parseInt(a.text)!==i+1)throw new C('Argument number "'+a.text+'" out of order');i++,u.push([])}else{if(a.text==="EOF")throw new C("Expected a macro definition");u[i].push(a.text)}var h=e.gullet.consumeArg(),d=h.tokens;return l&&d.unshift(l),(t==="\\edef"||t==="\\xdef")&&(d=e.gullet.expandTokens(d),d.reverse()),e.gullet.macros.set(n,{tokens:d,numArgs:i,delimiters:u},t===cn[t]),{type:"internal",mode:e.mode}}});L({type:"internal",names:["\\let","\\\\globallet"],numArgs:0,allowedInText:!0,primitive:!0,handler(r){var e=r.parser,t=r.funcName,a=Us(e.gullet.popToken());e.gullet.consumeSpaces();var n=Wu(e);return Gs(e,a,n,t==="\\\\globallet"),{type:"internal",mode:e.mode}}});L({type:"internal",names:["\\futurelet","\\\\globalfuture"],numArgs:0,allowedInText:!0,primitive:!0,handler(r){var e=r.parser,t=r.funcName,a=Us(e.gullet.popToken()),n=e.gullet.popToken(),i=e.gullet.popToken();return Gs(e,a,i,t==="\\\\globalfuture"),e.gullet.pushToken(i),e.gullet.pushToken(n),{type:"internal",mode:e.mode}}});var $t=function(e,t,a){var n=he.math[e]&&he.math[e].replace,i=yn(n||e,t,a);if(!i)throw new Error("Unsupported symbol "+e+" and font size "+t+".");return i},An=function(e,t,a,n){var i=a.havingBaseStyle(t),l=R(n.concat(i.sizingClasses(a)),[e],a),u=i.sizeMultiplier/a.sizeMultiplier;return l.height*=u,l.depth*=u,l.maxFontSize=i.sizeMultiplier,l},js=function(e,t,a){var n=t.havingBaseStyle(a),i=(1-t.sizeMultiplier/n.sizeMultiplier)*t.fontMetrics().axisHeight;e.classes.push("delimcenter"),e.style.top=O(i),e.height-=i,e.depth+=i},Vu=function(e,t,a,n,i,l){var u=Oe(e,"Main-Regular",i,n),h=An(u,t,n,l);return a&&js(h,n,t),h},Yu=function(e,t,a,n){return Oe(e,"Size"+t+"-Regular",a,n)},Ws=function(e,t,a,n,i,l){var u=Yu(e,t,i,n),h=An(R(["delimsizing","size"+t],[u],n),W.TEXT,n,l);return a&&js(h,n,W.TEXT),h},Ha=function(e,t,a){var n;t==="Size1-Regular"?n="delim-size1":n="delim-size4";var i=R(["delimsizinginner",n],[R([],[Oe(e,t,a)])]);return{type:"elem",elem:i}},$a=function(e,t,a){var n=p0["Size4-Regular"][e.charCodeAt(0)]?p0["Size4-Regular"][e.charCodeAt(0)][4]:p0["Size1-Regular"][e.charCodeAt(0)][4],i=new f0("inner",Ko(e,Math.round(1e3*t))),l=new o0([i],{width:O(n),height:O(t),style:"width:"+O(n),viewBox:"0 0 "+1e3*n+" "+Math.round(1e3*t),preserveAspectRatio:"xMinYMin"}),u=_0([],[l],a);return u.height=t,u.style.height=O(t),u.style.width=O(n),{type:"elem",elem:u}},hn=.008,Rr={type:"kern",size:-1*hn},Xu=new Set(["|","\\lvert","\\rvert","\\vert"]),Zu=new Set(["\\|","\\lVert","\\rVert","\\Vert"]),Vs=function(e,t,a,n,i,l){var u,h,d,f,b="",k=0;u=d=f=e,h=null;var w="Size1-Regular";e==="\\uparrow"?d=f="\u23D0":e==="\\Uparrow"?d=f="\u2016":e==="\\downarrow"?u=d="\u23D0":e==="\\Downarrow"?u=d="\u2016":e==="\\updownarrow"?(u="\\uparrow",d="\u23D0",f="\\downarrow"):e==="\\Updownarrow"?(u="\\Uparrow",d="\u2016",f="\\Downarrow"):Xu.has(e)?(d="\u2223",b="vert",k=333):Zu.has(e)?(d="\u2225",b="doublevert",k=556):e==="["||e==="\\lbrack"?(u="\u23A1",d="\u23A2",f="\u23A3",w="Size4-Regular",b="lbrack",k=667):e==="]"||e==="\\rbrack"?(u="\u23A4",d="\u23A5",f="\u23A6",w="Size4-Regular",b="rbrack",k=667):e==="\\lfloor"||e==="\u230A"?(d=u="\u23A2",f="\u23A3",w="Size4-Regular",b="lfloor",k=667):e==="\\lceil"||e==="\u2308"?(u="\u23A1",d=f="\u23A2",w="Size4-Regular",b="lceil",k=667):e==="\\rfloor"||e==="\u230B"?(d=u="\u23A5",f="\u23A6",w="Size4-Regular",b="rfloor",k=667):e==="\\rceil"||e==="\u2309"?(u="\u23A4",d=f="\u23A5",w="Size4-Regular",b="rceil",k=667):e==="("||e==="\\lparen"?(u="\u239B",d="\u239C",f="\u239D",w="Size4-Regular",b="lparen",k=875):e===")"||e==="\\rparen"?(u="\u239E",d="\u239F",f="\u23A0",w="Size4-Regular",b="rparen",k=875):e==="\\{"||e==="\\lbrace"?(u="\u23A7",h="\u23A8",f="\u23A9",d="\u23AA",w="Size4-Regular"):e==="\\}"||e==="\\rbrace"?(u="\u23AB",h="\u23AC",f="\u23AD",d="\u23AA",w="Size4-Regular"):e==="\\lgroup"||e==="\u27EE"?(u="\u23A7",f="\u23A9",d="\u23AA",w="Size4-Regular"):e==="\\rgroup"||e==="\u27EF"?(u="\u23AB",f="\u23AD",d="\u23AA",w="Size4-Regular"):e==="\\lmoustache"||e==="\u23B0"?(u="\u23A7",f="\u23AD",d="\u23AA",w="Size4-Regular"):(e==="\\rmoustache"||e==="\u23B1")&&(u="\u23AB",f="\u23A9",d="\u23AA",w="Size4-Regular");var M=$t(u,w,i),D=M.height+M.depth,E=$t(d,w,i),N=E.height+E.depth,B=$t(f,w,i),F=B.height+B.depth,H=0,V=1;if(h!==null){var j=$t(h,w,i);H=j.height+j.depth,V=2}var $=D+F+H,X=Math.max(0,Math.ceil((t-$)/(V*N))),ee=$+X*V*N,ae=n.fontMetrics().axisHeight;a&&(ae*=n.sizeMultiplier);var Q=ee/2-ae,ie=[];if(b.length>0){var $e=ee-D-F,Ue=Math.round(ee*1e3),ze=Qo(b,Math.round($e*1e3)),n0=new f0(b,ze),Ge=O(k/1e3),M0=O(Ue/1e3),Tt=new o0([n0],{width:Ge,height:M0,viewBox:"0 0 "+k+" "+Ue}),je=_0([],[Tt],n);je.height=Ue/1e3,je.style.width=Ge,je.style.height=M0,ie.push({type:"elem",elem:je})}else{if(ie.push(Ha(f,w,i)),ie.push(Rr),h===null){var Qe=ee-D-F+2*hn;ie.push($a(d,Qe,n))}else{var E0=(ee-D-F-H)/2+2*hn;ie.push($a(d,E0,n)),ie.push(Rr),ie.push(Ha(h,w,i)),ie.push(Rr),ie.push($a(d,E0,n))}ie.push(Rr),ie.push(Ha(u,w,i))}var We=n.havingBaseStyle(W.TEXT),rt=re({positionType:"bottom",positionData:Q,children:ie});return An(R(["delimsizing","mult"],[rt],We),W.TEXT,n,l)},Ua=80,Ga=.08,ja=function(e,t,a,n,i){var l=Zo(e,n,a),u=new f0(e,l),h=new o0([u],{width:"400em",height:O(t),viewBox:"0 0 400000 "+a,preserveAspectRatio:"xMinYMin slice"});return _0(["hide-tail"],[h],i)},Ku=function(e,t){var a=t.havingBaseSizing(),n=Qs("\\surd",e*a.sizeMultiplier,Ks,a),i=a.sizeMultiplier,l=Math.max(0,t.minRuleThickness-t.fontMetrics().sqrtRuleThickness),u,h,d,f,b;return n.type==="small"?(f=1e3+1e3*l+Ua,e<1?i=1:e<1.4&&(i=.7),h=(1+l+Ga)/i,d=(1+l)/i,u=ja("sqrtMain",h,f,l,t),u.style.minWidth="0.853em",b=.833/i):n.type==="large"?(f=(1e3+Ua)*Ut[n.size],d=(Ut[n.size]+l)/i,h=(Ut[n.size]+l+Ga)/i,u=ja("sqrtSize"+n.size,h,f,l,t),u.style.minWidth="1.02em",b=1/i):(h=e+l+Ga,d=e+l,f=Math.floor(1e3*e+l)+Ua,u=ja("sqrtTall",h,f,l,t),u.style.minWidth="0.742em",b=1.056),u.height=d,u.style.height=O(h),{span:u,advanceWidth:b,ruleWidth:(t.fontMetrics().sqrtRuleThickness+l)*i}},Ys=new Set(["(","\\lparen",")","\\rparen","[","\\lbrack","]","\\rbrack","\\{","\\lbrace","\\}","\\rbrace","\\lfloor","\\rfloor","\u230A","\u230B","\\lceil","\\rceil","\u2308","\u2309","\\surd"]),Qu=new Set(["\\uparrow","\\downarrow","\\updownarrow","\\Uparrow","\\Downarrow","\\Updownarrow","|","\\|","\\vert","\\Vert","\\lvert","\\rvert","\\lVert","\\rVert","\\lgroup","\\rgroup","\u27EE","\u27EF","\\lmoustache","\\rmoustache","\u23B0","\u23B1"]),Xs=new Set(["<",">","\\langle","\\rangle","/","\\backslash","\\lt","\\gt"]),Ut=[0,1.2,1.8,2.4,3],Zs=function(e,t,a,n,i){if(e==="<"||e==="\\lt"||e==="\u27E8"?e="\\langle":(e===">"||e==="\\gt"||e==="\u27E9")&&(e="\\rangle"),Ys.has(e)||Xs.has(e))return Ws(e,t,!1,a,n,i);if(Qu.has(e))return Vs(e,Ut[t],!1,a,n,i);throw new C("Illegal delimiter: '"+e+"'")},Ju=[{type:"small",style:W.SCRIPTSCRIPT},{type:"small",style:W.SCRIPT},{type:"small",style:W.TEXT},{type:"large",size:1},{type:"large",size:2},{type:"large",size:3},{type:"large",size:4}],e4=[{type:"small",style:W.SCRIPTSCRIPT},{type:"small",style:W.SCRIPT},{type:"small",style:W.TEXT},{type:"stack"}],Ks=[{type:"small",style:W.SCRIPTSCRIPT},{type:"small",style:W.SCRIPT},{type:"small",style:W.TEXT},{type:"large",size:1},{type:"large",size:2},{type:"large",size:3},{type:"large",size:4},{type:"stack"}],t4=function(e){if(e.type==="small")return"Main-Regular";if(e.type==="large")return"Size"+e.size+"-Regular";if(e.type==="stack")return"Size4-Regular";var t=e.type;throw new Error("Add support for delim type '"+t+"' here.")},Qs=function(e,t,a,n){for(var i=Math.min(2,3-n.style.size),l=i;l<a.length;l++){var u=a[l];if(u.type==="stack")break;var h=$t(e,t4(u),"math"),d=h.height+h.depth;if(u.type==="small"){var f=n.havingBaseStyle(u.style);d*=f.sizeMultiplier}if(d>t)return u}return a[a.length-1]},mn=function(e,t,a,n,i,l){e==="<"||e==="\\lt"||e==="\u27E8"?e="\\langle":(e===">"||e==="\\gt"||e==="\u27E9")&&(e="\\rangle");var u;Xs.has(e)?u=Ju:Ys.has(e)?u=Ks:u=e4;var h=Qs(e,t,u,n);return h.type==="small"?Vu(e,h.style,a,n,i,l):h.type==="large"?Ws(e,h.size,a,n,i,l):Vs(e,t,a,n,i,l)},Wa=function(e,t,a,n,i,l){var u=n.fontMetrics().axisHeight*n.sizeMultiplier,h=901,d=5/n.fontMetrics().ptPerEm,f=Math.max(t-u,a+u),b=Math.max(f/500*h,2*f-d);return mn(e,b,!0,n,i,l)},is={"\\bigl":{mclass:"mopen",size:1},"\\Bigl":{mclass:"mopen",size:2},"\\biggl":{mclass:"mopen",size:3},"\\Biggl":{mclass:"mopen",size:4},"\\bigr":{mclass:"mclose",size:1},"\\Bigr":{mclass:"mclose",size:2},"\\biggr":{mclass:"mclose",size:3},"\\Biggr":{mclass:"mclose",size:4},"\\bigm":{mclass:"mrel",size:1},"\\Bigm":{mclass:"mrel",size:2},"\\biggm":{mclass:"mrel",size:3},"\\Biggm":{mclass:"mrel",size:4},"\\big":{mclass:"mord",size:1},"\\Big":{mclass:"mord",size:2},"\\bigg":{mclass:"mord",size:3},"\\Bigg":{mclass:"mord",size:4}},r4=new Set(["(","\\lparen",")","\\rparen","[","\\lbrack","]","\\rbrack","\\{","\\lbrace","\\}","\\rbrace","\\lfloor","\\rfloor","\u230A","\u230B","\\lceil","\\rceil","\u2308","\u2309","<",">","\\langle","\u27E8","\\rangle","\u27E9","\\lt","\\gt","\\lvert","\\rvert","\\lVert","\\rVert","\\lgroup","\\rgroup","\u27EE","\u27EF","\\lmoustache","\\rmoustache","\u23B0","\u23B1","/","\\backslash","|","\\vert","\\|","\\Vert","\\uparrow","\\Uparrow","\\downarrow","\\Downarrow","\\updownarrow","\\Updownarrow","."]);function ss(r){return"isMiddle"in r}function Wr(r,e){var t=Gr(r);if(t&&r4.has(t.text))return t;throw t?new C("Invalid delimiter '"+t.text+"' after '"+e.funcName+"'",r):new C("Invalid delimiter type '"+r.type+"'",r)}L({type:"delimsizing",names:["\\bigl","\\Bigl","\\biggl","\\Biggl","\\bigr","\\Bigr","\\biggr","\\Biggr","\\bigm","\\Bigm","\\biggm","\\Biggm","\\big","\\Big","\\bigg","\\Bigg"],numArgs:1,argTypes:["primitive"],handler:(r,e)=>{var t=Wr(Xt(e[0]),r);return{type:"delimsizing",mode:r.parser.mode,size:is[r.funcName].size,mclass:is[r.funcName].mclass,delim:t.text}},htmlBuilder:(r,e)=>r.delim==="."?R([r.mclass]):Zs(r.delim,r.size,e,r.mode,[r.mclass]),mathmlBuilder:r=>{var e=[];r.delim!=="."&&e.push(a0(r.delim,r.mode));var t=new I("mo",e);r.mclass==="mopen"||r.mclass==="mclose"?t.setAttribute("fence","true"):t.setAttribute("fence","false"),t.setAttribute("stretchy","true");var a=O(Ut[r.size]);return t.setAttribute("minsize",a),t.setAttribute("maxsize",a),t}});function ls(r){if(!r.body)throw new Error("Bug: The leftright ParseNode wasn't fully parsed.")}L({type:"leftright-right",names:["\\right"],numArgs:1,primitive:!0,handler:(r,e)=>{var t=r.parser.gullet.macros.get("\\current@color");if(t&&typeof t!="string")throw new C("\\current@color set to non-string in \\right");return{type:"leftright-right",mode:r.parser.mode,delim:Wr(e[0],r).text,color:t}}});L({type:"leftright",names:["\\left"],numArgs:1,primitive:!0,handler:(r,e)=>{var t=Wr(e[0],r),a=r.parser;++a.leftrightDepth;var n=a.parseExpression(!1);--a.leftrightDepth,a.expect("\\right",!1);var i=K(a.parseFunction(),"leftright-right");return{type:"leftright",mode:a.mode,body:n,left:t.text,right:i.delim,rightColor:i.color}},htmlBuilder:(r,e)=>{ls(r);for(var t=Se(r.body,e,!0,["mopen","mclose"]),a=0,n=0,i=!1,l=0;l<t.length;l++){var u=t[l];ss(u)?i=!0:(a=Math.max(t[l].height,a),n=Math.max(t[l].depth,n))}a*=e.sizeMultiplier,n*=e.sizeMultiplier;var h;if(r.left==="."?h=Zt(e,["mopen"]):h=Wa(r.left,a,n,e,r.mode,["mopen"]),t.unshift(h),i)for(var d=1;d<t.length;d++){var f=t[d];if(ss(f)){var b=f.isMiddle;t[d]=Wa(b.delim,a,n,b.options,r.mode,[])}}var k;if(r.right===".")k=Zt(e,["mclose"]);else{var w=r.rightColor?e.withColor(r.rightColor):e;k=Wa(r.right,a,n,w,r.mode,["mclose"])}return t.push(k),R(["minner"],t,e)},mathmlBuilder:(r,e)=>{ls(r);var t=Ke(r.body,e);if(r.left!=="."){var a=new I("mo",[a0(r.left,r.mode)]);a.setAttribute("fence","true"),t.unshift(a)}if(r.right!=="."){var n=new I("mo",[a0(r.right,r.mode)]);n.setAttribute("fence","true"),r.rightColor&&n.setAttribute("mathcolor",r.rightColor),t.push(n)}return kn(t)}});L({type:"middle",names:["\\middle"],numArgs:1,primitive:!0,handler:(r,e)=>{var t=Wr(e[0],r);if(!r.parser.leftrightDepth)throw new C("\\middle without preceding \\left",t);return{type:"middle",mode:r.parser.mode,delim:t.text}},htmlBuilder:(r,e)=>{var t;return r.delim==="."?t=Zt(e,[]):(t=Zs(r.delim,1,e,r.mode,[]),t.isMiddle={delim:r.delim,options:e}),t},mathmlBuilder:(r,e)=>{var t=r.delim==="\\vert"||r.delim==="|"?a0("|","text"):a0(r.delim,r.mode),a=new I("mo",[t]);return a.setAttribute("fence","true"),a.setAttribute("lspace","0.05em"),a.setAttribute("rspace","0.05em"),a}});var a4=(r,e)=>{var t=kt(te(r.body,e),e),a=r.label.slice(1),n=e.sizeMultiplier,i,l,u=T0(r.body);if(a==="sout")i=R(["katex-stretchy","katex-sout"]),i.height=e.fontMetrics().defaultRuleThickness/n,l=-.5*e.fontMetrics().xHeight;else if(a==="phase"){var h=fe({number:.6,unit:"pt"},e),d=fe({number:.35,unit:"ex"},e),f=e.havingBaseSizing();n=n/f.sizeMultiplier;var b=t.height+t.depth+h+d;t.style.paddingLeft=O(b/2+h);var k=Math.floor(1e3*b*n),w=Yo(k),M=new o0([new f0("phase",w)],{width:"400em",height:O(k/1e3),viewBox:"0 0 400000 "+k,preserveAspectRatio:"xMinYMin slice"});i=_0(["hide-tail"],[M],e),i.style.height=O(b),l=t.depth+h+d}else{/cancel/.test(a)?u||t.classes.push("cancel-pad"):a==="angl"?t.classes.push("anglpad"):t.classes.push("boxpad");var D,E,N=0;/box/.test(a)?(N=Math.max(e.fontMetrics().fboxrule,e.minRuleThickness),D=e.fontMetrics().fboxsep+(a==="colorbox"?0:N),E=D):a==="angl"?(N=Math.max(e.fontMetrics().defaultRuleThickness,e.minRuleThickness),D=4*N,E=Math.max(0,.25-t.depth)):(D=u?.2:0,E=D),i=Du(t,a,D,E,e),/fbox|boxed|fcolorbox/.test(a)?(i.style.borderStyle="solid",i.style.borderWidth=O(N)):a==="angl"&&N!==.049&&(i.style.borderTopWidth=O(N),i.style.borderRightWidth=O(N)),l=t.depth+E,r.backgroundColor&&(i.style.backgroundColor=r.backgroundColor,r.borderColor&&(i.style.borderColor=r.borderColor))}var B;if(r.backgroundColor)B=re({positionType:"individualShift",children:[{type:"elem",elem:i,shift:l},{type:"elem",elem:t,shift:0}]});else{var F=/cancel|phase/.test(a)?["svg-align"]:[];B=re({positionType:"individualShift",children:[{type:"elem",elem:t,shift:0},{type:"elem",elem:i,shift:l,wrapperClasses:F}]})}return/cancel/.test(a)&&(B.height=t.height,B.depth=t.depth),/cancel/.test(a)&&!u?R(["mord","cancel-lap"],[B],e):R(["mord"],[B],e)},n4=(r,e)=>{var t,a=new I(r.label.includes("colorbox")?"mpadded":"menclose",[se(r.body,e)]);switch(r.label){case"\\cancel":a.setAttribute("notation","updiagonalstrike");break;case"\\bcancel":a.setAttribute("notation","downdiagonalstrike");break;case"\\phase":a.setAttribute("notation","phasorangle");break;case"\\sout":a.setAttribute("notation","horizontalstrike");break;case"\\fbox":a.setAttribute("notation","box");break;case"\\angl":a.setAttribute("notation","actuarial");break;case"\\fcolorbox":case"\\colorbox":if(t=e.fontMetrics().fboxsep*e.fontMetrics().ptPerEm,a.setAttribute("width","+"+2*t+"pt"),a.setAttribute("height","+"+2*t+"pt"),a.setAttribute("lspace",t+"pt"),a.setAttribute("voffset",t+"pt"),r.label==="\\fcolorbox"){var n=Math.max(e.fontMetrics().fboxrule,e.minRuleThickness);a.setAttribute("style","border: "+O(n)+" solid "+r.borderColor)}break;case"\\xcancel":a.setAttribute("notation","updiagonalstrike downdiagonalstrike");break}return r.backgroundColor&&a.setAttribute("mathbackground",r.backgroundColor),a};L({type:"enclose",names:["\\colorbox"],numArgs:2,allowedInText:!0,argTypes:["color","hbox"],handler(r,e,t){var a=r.parser,n=r.funcName,i=K(e[0],"color-token").color,l=e[1];return{type:"enclose",mode:a.mode,label:n,backgroundColor:i,body:l}},htmlBuilder:a4,mathmlBuilder:n4});L({type:"enclose",names:["\\fcolorbox"],numArgs:3,allowedInText:!0,argTypes:["color","color","hbox"],handler(r,e,t){var a=r.parser,n=r.funcName,i=K(e[0],"color-token").color,l=K(e[1],"color-token").color,u=e[2];return{type:"enclose",mode:a.mode,label:n,backgroundColor:l,borderColor:i,body:u}}});L({type:"enclose",names:["\\fbox"],numArgs:1,argTypes:["hbox"],allowedInText:!0,handler(r,e){var t=r.parser;return{type:"enclose",mode:t.mode,label:"\\fbox",body:e[0]}}});L({type:"enclose",names:["\\cancel","\\bcancel","\\xcancel","\\phase"],numArgs:1,handler(r,e){var t=r.parser,a=r.funcName,n=e[0];return{type:"enclose",mode:t.mode,label:a,body:n}}});L({type:"enclose",names:["\\sout"],numArgs:1,allowedInText:!0,handler(r,e){var t=r.parser,a=r.funcName;t.mode==="math"&&t.settings.reportNonstrict("mathVsSout","LaTeX's \\sout works only in text mode");var n=e[0];return{type:"enclose",mode:t.mode,label:a,body:n}}});L({type:"enclose",names:["\\angl"],numArgs:1,argTypes:["hbox"],allowedInText:!1,handler(r,e){var t=r.parser;return{type:"enclose",mode:t.mode,label:"\\angl",body:e[0]}}});var Js={};function v0(r){for(var e=r.type,t=r.names,a=r.props,n=r.handler,i=r.htmlBuilder,l=r.mathmlBuilder,u={type:e,numArgs:a.numArgs||0,allowedInText:!1,numOptionalArgs:0,handler:n},h=0;h<t.length;++h)Js[t[h]]=u;i&&(Vt[e]=i),l&&(Yt[e]=l)}var el={};function m(r,e){el[r]=e}var He=class r{constructor(e,t,a){this.lexer=void 0,this.start=void 0,this.end=void 0,this.lexer=e,this.start=t,this.end=a}static range(e,t){return t?!e||!e.loc||!t.loc||e.loc.lexer!==t.loc.lexer?null:new r(e.loc.lexer,e.loc.start,t.loc.end):e&&e.loc}},Xe=class r{constructor(e,t){this.text=void 0,this.loc=void 0,this.noexpand=void 0,this.treatAsRelax=void 0,this.text=e,this.loc=t}range(e,t){return new r(t,He.range(this,e))}};function os(r){var e=[];r.consumeSpaces();var t=r.fetch().text;for(t==="\\relax"&&(r.consume(),r.consumeSpaces(),t=r.fetch().text);t==="\\hline"||t==="\\hdashline";)r.consume(),e.push(t==="\\hdashline"),r.consumeSpaces(),t=r.fetch().text;return e}var Vr=r=>{var e=r.parser.settings;if(!e.displayMode)throw new C("{"+r.envName+"} can be used only in display mode.")},i4=new Set(["gather","gather*"]);function zn(r){if(!r.includes("ed"))return!r.includes("*")}function $0(r,e,t){var a=e.hskipBeforeAndAfter,n=e.addJot,i=e.cols,l=e.arraystretch,u=e.colSeparationType,h=e.autoTag,d=e.singleRow,f=e.emptySingleRow,b=e.maxNumCols,k=e.leqno;if(r.gullet.beginGroup(),d||r.gullet.macros.set("\\cr","\\\\\\relax"),!l){var w=r.gullet.expandMacroAsText("\\arraystretch");if(w==null)l=1;else if(l=parseFloat(w),!l||l<0)throw new C("Invalid \\arraystretch: "+w)}r.gullet.beginGroup();var M=[],D=[M],E=[],N=[],B=h!=null?[]:void 0;function F(){h&&r.gullet.macros.set("\\@eqnsw","1",!0)}function H(){B&&(r.gullet.macros.get("\\df@tag")?(B.push(r.subparse([new Xe("\\df@tag")])),r.gullet.macros.set("\\df@tag",void 0,!0)):B.push(!!h&&r.gullet.macros.get("\\@eqnsw")==="1"))}for(F(),N.push(os(r));;){var V=r.parseExpression(!1,d?"\\end":"\\\\");r.gullet.endGroup(),r.gullet.beginGroup();var j={type:"ordgroup",mode:r.mode,body:V};t&&(j={type:"styling",mode:r.mode,style:t,resetFont:!0,body:[j]}),M.push(j);var $=r.fetch().text;if($==="&"){if(b&&M.length===b){if(d||u)throw new C("Too many tab characters: &",r.nextToken);r.settings.reportNonstrict("textEnv","Too few columns specified in the {array} column argument.")}r.consume()}else if($==="\\end"){H(),M.length===1&&j.type==="styling"&&j.body.length===1&&j.body[0].type==="ordgroup"&&j.body[0].body.length===0&&(D.length>1||!f)&&!Array.isArray(B?.[B.length-1])&&!(h&&B?.[B.length-1]===!0)&&D.pop(),N.length<D.length+1&&N.push([]);break}else if($==="\\\\"){r.consume();var X=void 0;r.gullet.future().text!==" "&&(X=r.parseSizeGroup(!0)),E.push(X?X.value:null),H(),N.push(os(r)),M=[],D.push(M),F()}else throw new C("Expected & or \\\\ or \\cr or \\end",r.nextToken)}return r.gullet.endGroup(),r.gullet.endGroup(),{type:"array",mode:r.mode,addJot:n,arraystretch:l,body:D,cols:i,rowGaps:E,hskipBeforeAndAfter:a,hLinesBeforeRow:N,colSeparationType:u,tags:B,leqno:k}}function Mn(r){return r.slice(0,1)==="d"?"display":"text"}var g0=function(e,t){var a,n,i=e.body.length,l=e.hLinesBeforeRow,u=0,h=new Array(i),d=[],f=Math.max(t.fontMetrics().arrayRuleWidth,t.minRuleThickness),b=1/t.fontMetrics().ptPerEm,k=5*b;if(e.colSeparationType&&e.colSeparationType==="small"){var w=t.havingStyle(W.SCRIPT).sizeMultiplier;k=.2778*(w/t.sizeMultiplier)}var M=e.colSeparationType==="CD"?fe({number:3,unit:"ex"},t):12*b,D=3*b,E=e.arraystretch*M,N=.7*E,B=.3*E,F=0;function H(qe){for(var e0=0;e0<qe.length;++e0)e0>0&&(F+=.25),d.push({pos:F,isDashed:qe[e0]})}for(H(l[0]),a=0;a<e.body.length;++a){var V=e.body[a],j=N,$=B;u<V.length&&(u=V.length);var X={cells:new Array(V.length),height:0,depth:0,pos:0};for(n=0;n<V.length;++n){var ee=te(V[n],t);$<ee.depth&&($=ee.depth),j<ee.height&&(j=ee.height),X.cells[n]=ee}var ae=e.rowGaps[a],Q=0;ae&&(Q=fe(ae,t),Q>0&&(Q+=B,$<Q&&($=Q),Q=0)),e.addJot&&a<e.body.length-1&&($+=D),X.height=j,X.depth=$,F+=j,X.pos=F,F+=$+Q,h[a]=X,H(l[a+1])}var ie=F/2+t.fontMetrics().axisHeight,$e=e.cols||[],Ue=[],ze,n0,Ge=[];if(e.tags&&e.tags.some(qe=>qe))for(a=0;a<i;++a){var M0=h[a],Tt=M0.pos-ie,je=e.tags[a],Qe=void 0;je===!0?Qe=R(["eqn-num"],[],t):je===!1?Qe=R([],[],t):Qe=R([],Se(je,t,!0),t),Qe.depth=M0.depth,Qe.height=M0.height,Ge.push({type:"elem",elem:Qe,shift:Tt})}for(n=0,n0=0;n<u||n0<$e.length;++n,++n0){for(var E0,We=$e[n0],rt=!0;((Qt=We)==null?void 0:Qt.type)==="separator";){var Qt;if(rt||(ze=R(["arraycolsep"],[]),ze.style.width=O(t.fontMetrics().doubleRuleSep),Ue.push(ze)),We.separator==="|"||We.separator===":"){var le=We.separator==="|"?"solid":"dashed",R0=R(["vertical-separator"],[],t);R0.style.height=O(F),R0.style.borderRightWidth=O(f),R0.style.borderRightStyle=le,R0.style.margin="0 "+O(-f/2);var Jt=F-ie;Jt&&(R0.style.verticalAlign=O(-Jt)),Ue.push(R0)}else throw new C("Invalid separator type: "+We.separator);n0++,We=$e[n0],rt=!1}if(!(n>=u)){var D0=void 0;if(n>0||e.hskipBeforeAndAfter){var er,tr;D0=(er=(tr=We)==null?void 0:tr.pregap)!=null?er:k,D0!==0&&(ze=R(["arraycolsep"],[]),ze.style.width=O(D0),Ue.push(ze))}var rr=[];for(a=0;a<i;++a){var U0=h[a],at=U0.cells[n];if(at){var ar=U0.pos-ie;at.depth=U0.depth,at.height=U0.height,rr.push({type:"elem",elem:at,shift:ar})}}var ue=re({positionType:"individualShift",children:rr}),At=R(["col-align-"+(((E0=We)==null?void 0:E0.align)||"c")],[ue]);if(Ue.push(At),n<u-1||e.hskipBeforeAndAfter){var oe,nt;D0=(oe=(nt=We)==null?void 0:nt.postgap)!=null?oe:k,D0!==0&&(ze=R(["arraycolsep"],[]),ze.style.width=O(D0),Ue.push(ze))}}}var Ce=R(["mtable"],Ue);if(d.length>0){for(var G0=wt("katex-hline",t,f),nr=wt("katex-hdashline",t,f),Je=[{type:"elem",elem:Ce,shift:0}];d.length>0;){var zt=d.pop(),it=zt.pos-ie;zt.isDashed?Je.push({type:"elem",elem:nr,shift:it}):Je.push({type:"elem",elem:G0,shift:it})}Ce=re({positionType:"individualShift",children:Je})}if(Ge.length===0)return R(["mord"],[Ce],t);var ir=re({positionType:"individualShift",children:Ge}),Mt=R(["katex-tag"],[ir],t);return z0([Ce,Mt])},s4={c:"center ",l:"left ",r:"right "},b0=function(e,t){for(var a=[],n=new I("mtd",[],["mtr-glue"]),i=new I("mtd",[],["mml-eqn-num"]),l=0;l<e.body.length;l++){for(var u=e.body[l],h=[],d=0;d<u.length;d++)h.push(new I("mtd",[se(u[d],t)]));e.tags&&e.tags[l]&&(h.unshift(n),h.push(n),e.leqno?h.unshift(i):h.push(i)),a.push(new I("mtr",h))}var f=new I("mtable",a),b=e.arraystretch===.5?.1:.16+e.arraystretch-1+(e.addJot?.09:0);f.setAttribute("rowspacing",O(b));var k="",w="";if(e.cols&&e.cols.length>0){var M=e.cols,D="",E=!1,N=0,B=M.length;M[0].type==="separator"&&(k+="top ",N=1),M[M.length-1].type==="separator"&&(k+="bottom ",B-=1);for(var F=N;F<B;F++){var H=M[F];H.type==="align"?(w+=s4[H.align],E&&(D+="none "),E=!0):H.type==="separator"&&E&&(D+=H.separator==="|"?"solid ":"dashed ",E=!1)}f.setAttribute("columnalign",w.trim()),/[sd]/.test(D)&&f.setAttribute("columnlines",D.trim())}if(e.colSeparationType==="align"){for(var V=e.cols||[],j="",$=1;$<V.length;$++)j+=$%2?"0em ":"1em ";f.setAttribute("columnspacing",j.trim())}else e.colSeparationType==="alignat"||e.colSeparationType==="gather"?f.setAttribute("columnspacing","0em"):e.colSeparationType==="small"?f.setAttribute("columnspacing","0.2778em"):e.colSeparationType==="CD"?f.setAttribute("columnspacing","0.5em"):f.setAttribute("columnspacing","1em");var X="",ee=e.hLinesBeforeRow;k+=ee[0].length>0?"left ":"",k+=ee[ee.length-1].length>0?"right ":"";for(var ae=1;ae<ee.length-1;ae++)X+=ee[ae].length===0?"none ":ee[ae][0]?"dashed ":"solid ";return/[sd]/.test(X)&&f.setAttribute("rowlines",X.trim()),k!==""&&(f=new I("menclose",[f]),f.setAttribute("notation",k.trim())),e.arraystretch&&e.arraystretch<1&&(f=new I("mstyle",[f]),f.setAttribute("scriptlevel","1")),f},tl=function(e,t){e.envName.includes("ed")||Vr(e);var a=[],n=e.envName==="split",i=$0(e.parser,{cols:a,addJot:!0,autoTag:n?void 0:zn(e.envName),emptySingleRow:!0,colSeparationType:e.envName.includes("at")?"alignat":"align",maxNumCols:n?2:void 0,leqno:e.parser.settings.leqno},"display"),l=0,u=0,h={type:"ordgroup",mode:e.mode,body:[]};if(t[0]&&t[0].type==="ordgroup"){var d="Number of columns should be a positive integer",f=Tn(t[0],d);if(!/^[0-9]+$/.test(f)||Number(f)<1)throw new C(d,t[0]);l=Number(f),u=l*2}var b=!u;i.body.forEach(function(D){for(var E=1;E<D.length;E+=2){var N=K(D[E],"styling"),B=K(N.body[0],"ordgroup");B.body.unshift(h)}if(b)u<D.length&&(u=D.length);else{var F=D.length/2;if(l<F)throw new C("Too many math in a row: "+("expected "+l+", but got "+F),D[0])}});for(var k=0;k<u;++k){var w="r",M=0;k%2===1?w="l":k>0&&b&&(M=1),a[k]={type:"align",align:w,pregap:M,postgap:0}}return i.colSeparationType=b?"align":"alignat",i};v0({type:"array",names:["array","darray"],props:{numArgs:1},handler(r,e){var t=Gr(e[0]),a=t?[e[0]]:K(e[0],"ordgroup").body,n=a.map(function(l){var u=Ur(l),h=u.text;if("lcr".includes(h))return{type:"align",align:h};if(h==="|")return{type:"separator",separator:"|"};if(h===":")return{type:"separator",separator:":"};throw new C("Unknown column alignment: "+h,l)}),i={cols:n,hskipBeforeAndAfter:!0,maxNumCols:n.length};return $0(r.parser,i,Mn(r.envName))},htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["matrix","pmatrix","bmatrix","Bmatrix","vmatrix","Vmatrix","matrix*","pmatrix*","bmatrix*","Bmatrix*","vmatrix*","Vmatrix*"],props:{numArgs:0},handler(r){var e={matrix:null,pmatrix:["(",")"],bmatrix:["[","]"],Bmatrix:["\\{","\\}"],vmatrix:["|","|"],Vmatrix:["\\Vert","\\Vert"]}[r.envName.replace("*","")],t="c",a={hskipBeforeAndAfter:!1,cols:[{type:"align",align:t}]};if(r.envName.charAt(r.envName.length-1)==="*"){var n=r.parser;if(n.consumeSpaces(),n.fetch().text==="["){if(n.consume(),n.consumeSpaces(),t=n.fetch().text,!"lcr".includes(t))throw new C("Expected l or c or r",n.nextToken);n.consume(),n.consumeSpaces(),n.expect("]"),n.consume(),a.cols=[{type:"align",align:t}]}}var i=$0(r.parser,a,Mn(r.envName)),l=Math.max(0,...i.body.map(u=>u.length));return i.cols=new Array(l).fill({type:"align",align:t}),e?{type:"leftright",mode:r.mode,body:[i],left:e[0],right:e[1],rightColor:void 0}:i},htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["smallmatrix"],props:{numArgs:0},handler(r){var e={arraystretch:.5},t=$0(r.parser,e,"script");return t.colSeparationType="small",t},htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["subarray"],props:{numArgs:1},handler(r,e){var t=Gr(e[0]),a=t?[e[0]]:K(e[0],"ordgroup").body,n=a.map(function(u){var h=Ur(u),d=h.text;if("lc".includes(d))return{type:"align",align:d};throw new C("Unknown column alignment: "+d,u)});if(n.length>1)throw new C("{subarray} can contain only one column");var i={cols:n,hskipBeforeAndAfter:!1,arraystretch:.5},l=$0(r.parser,i,"script");if(l.body.length>0&&l.body[0].length>1)throw new C("{subarray} can contain only one column");return l},htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["cases","dcases","rcases","drcases"],props:{numArgs:0},handler(r){var e={arraystretch:1.2,cols:[{type:"align",align:"l",pregap:0,postgap:1},{type:"align",align:"l",pregap:0,postgap:0}]},t=$0(r.parser,e,Mn(r.envName));return{type:"leftright",mode:r.mode,body:[t],left:r.envName.includes("r")?".":"\\{",right:r.envName.includes("r")?"\\}":".",rightColor:void 0}},htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["align","align*","aligned","split"],props:{numArgs:0},handler:tl,htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["gathered","gather","gather*"],props:{numArgs:0},handler(r){i4.has(r.envName)&&Vr(r);var e={cols:[{type:"align",align:"c"}],addJot:!0,colSeparationType:"gather",autoTag:zn(r.envName),emptySingleRow:!0,leqno:r.parser.settings.leqno};return $0(r.parser,e,"display")},htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["alignat","alignat*","alignedat"],props:{numArgs:1},handler:tl,htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["equation","equation*"],props:{numArgs:0},handler(r){Vr(r);var e={autoTag:zn(r.envName),emptySingleRow:!0,singleRow:!0,maxNumCols:1,leqno:r.parser.settings.leqno};return $0(r.parser,e,"display")},htmlBuilder:g0,mathmlBuilder:b0});v0({type:"array",names:["CD"],props:{numArgs:0},handler(r){return Vr(r),Uu(r.parser)},htmlBuilder:g0,mathmlBuilder:b0});m("\\nonumber","\\gdef\\@eqnsw{0}");m("\\notag","\\nonumber");L({type:"text",names:["\\hline","\\hdashline"],numArgs:0,allowedInText:!0,allowedInMath:!0,handler(r,e){throw new C(r.funcName+" valid only within array environment")}});var us=Js;L({type:"environment",names:["\\begin","\\end"],numArgs:1,argTypes:["text"],handler(r,e){var t=r.parser,a=r.funcName,n=e[0];if(n.type!=="ordgroup")throw new C("Invalid environment name",n);var i=Tn(n,"Environment name should contain only text characters and spaces",!0);if(a==="\\begin"){if(!Object.prototype.hasOwnProperty.call(us,i))throw new C("No such environment: "+i,n);var l=us[i],u=t.parseArguments("\\begin{"+i+"}",l),h=u.args,d=u.optArgs,f={mode:t.mode,envName:i,parser:t},b=l.handler(f,h,d);t.expect("\\end",!1);var k=t.nextToken,w=K(t.parseFunction(),"environment");if(w.name!==i)throw new C("Mismatch: \\begin{"+i+"} matched by \\end{"+w.name+"}",k);return b}return{type:"environment",mode:t.mode,name:i,nameGroup:n}}});var l4=(r,e)=>{var t=r.font,a=e.withFont(t);return te(r.body,a)},o4=(r,e)=>{var t=r.font,a=e.withFont(t);return se(r.body,a)},cs={"\\Bbb":"\\mathbb","\\bold":"\\mathbf","\\frak":"\\mathfrak"};L({type:"font",names:["\\mathrm","\\mathit","\\mathbf","\\mathnormal","\\mathsfit","\\mathbb","\\mathcal","\\mathfrak","\\mathscr","\\mathsf","\\mathtt","\\Bbb","\\bold","\\frak"],numArgs:1,allowedInArgument:!0,handler:(r,e)=>{var t=r.parser,a=r.funcName,n=Xt(e[0]),i=a in cs?cs[a]:a;return{type:"font",mode:t.mode,font:i.slice(1),body:n}},htmlBuilder:l4,mathmlBuilder:o4});L({type:"mclass",names:["\\boldsymbol","\\bm"],numArgs:1,handler:(r,e)=>{var t=r.parser,a=e[0];return{type:"mclass",mode:t.mode,mclass:jr(a),body:[{type:"font",mode:t.mode,font:"boldsymbol",body:a}],isCharacterBox:T0(a)}}});L({type:"font",names:["\\rm","\\sf","\\tt","\\bf","\\it","\\cal"],numArgs:0,allowedInText:!0,handler:(r,e)=>{var t=r.parser,a=r.funcName,n=r.breakOnTokenText,i=t.mode,l=t.parseExpression(!0,n);return{type:"font",mode:i,font:"math"+a.slice(1),body:{type:"ordgroup",mode:t.mode,body:l}}}});var u4=(r,e)=>{var t=e.style,a=t.fracNum(),n=t.fracDen(),i;i=e.havingStyle(a);var l=te(r.numer,i,e);if(r.continued){var u=8.5/e.fontMetrics().ptPerEm,h=3.5/e.fontMetrics().ptPerEm;l.height=l.height<u?u:l.height,l.depth=l.depth<h?h:l.depth}i=e.havingStyle(n);var d=te(r.denom,i,e),f,b,k;r.hasBarLine?(r.barSize?(b=fe(r.barSize,e),f=wt("frac-line",e,b)):f=wt("frac-line",e),b=f.height,k=f.height):(f=null,b=0,k=e.fontMetrics().defaultRuleThickness);var w,M,D;t.size===W.DISPLAY.size?(w=e.fontMetrics().num1,b>0?M=3*k:M=7*k,D=e.fontMetrics().denom1):(b>0?(w=e.fontMetrics().num2,M=k):(w=e.fontMetrics().num3,M=3*k),D=e.fontMetrics().denom2);var E;if(f){var B=e.fontMetrics().axisHeight;w-l.depth-(B+.5*b)<M&&(w+=M-(w-l.depth-(B+.5*b))),B-.5*b-(d.height-D)<M&&(D+=M-(B-.5*b-(d.height-D)));var F=-(B-.5*b);E=re({positionType:"individualShift",children:[{type:"elem",elem:d,shift:D},{type:"elem",elem:f,shift:F},{type:"elem",elem:l,shift:-w}]})}else{var N=w-l.depth-(d.height-D);N<M&&(w+=.5*(M-N),D+=.5*(M-N)),E=re({positionType:"individualShift",children:[{type:"elem",elem:d,shift:D},{type:"elem",elem:l,shift:-w}]})}i=e.havingStyle(t),E.height*=i.sizeMultiplier/e.sizeMultiplier,E.depth*=i.sizeMultiplier/e.sizeMultiplier;var H;t.size===W.DISPLAY.size?H=e.fontMetrics().delim1:t.size===W.SCRIPTSCRIPT.size?H=e.havingStyle(W.SCRIPT).fontMetrics().delim2:H=e.fontMetrics().delim2;var V,j;return r.leftDelim==null?V=Zt(e,["mopen"]):V=mn(r.leftDelim,H,!0,e.havingStyle(t),r.mode,["mopen"]),r.continued?j=R([]):r.rightDelim==null?j=Zt(e,["mclose"]):j=mn(r.rightDelim,H,!0,e.havingStyle(t),r.mode,["mclose"]),R(["mord"].concat(i.sizingClasses(e)),[V,R(["mfrac"],[E]),j],e)},c4=(r,e)=>{var t=new I("mfrac",[se(r.numer,e),se(r.denom,e)]);if(!r.hasBarLine)t.setAttribute("linethickness","0px");else if(r.barSize){var a=fe(r.barSize,e);t.setAttribute("linethickness",O(a))}if(r.leftDelim!=null||r.rightDelim!=null){var n=[];if(r.leftDelim!=null){var i=new I("mo",[new ve(r.leftDelim.replace("\\",""))]);i.setAttribute("fence","true"),n.push(i)}if(n.push(t),r.rightDelim!=null){var l=new I("mo",[new ve(r.rightDelim.replace("\\",""))]);l.setAttribute("fence","true"),n.push(l)}return kn(n)}return t},rl=(r,e)=>{if(!e)return r;var t={type:"styling",mode:r.mode,style:e,body:[r]};return t};L({type:"genfrac",names:["\\cfrac","\\dfrac","\\frac","\\tfrac","\\dbinom","\\binom","\\tbinom","\\\\atopfrac","\\\\bracefrac","\\\\brackfrac"],numArgs:2,allowedInArgument:!0,handler:(r,e)=>{var t=r.parser,a=r.funcName,n=e[0],i=e[1],l,u=null,h=null;switch(a){case"\\cfrac":case"\\dfrac":case"\\frac":case"\\tfrac":l=!0;break;case"\\\\atopfrac":l=!1;break;case"\\dbinom":case"\\binom":case"\\tbinom":l=!1,u="(",h=")";break;case"\\\\bracefrac":l=!1,u="\\{",h="\\}";break;case"\\\\brackfrac":l=!1,u="[",h="]";break;default:throw new Error("Unrecognized genfrac command")}var d=a==="\\cfrac",f=null;return d||a.startsWith("\\d")?f="display":a.startsWith("\\t")&&(f="text"),rl({type:"genfrac",mode:t.mode,numer:n,denom:i,continued:d,hasBarLine:l,leftDelim:u,rightDelim:h,barSize:null},f)},htmlBuilder:u4,mathmlBuilder:c4});L({type:"infix",names:["\\over","\\choose","\\atop","\\brace","\\brack"],numArgs:0,infix:!0,handler(r){var e=r.parser,t=r.funcName,a=r.token,n;switch(t){case"\\over":n="\\frac";break;case"\\choose":n="\\binom";break;case"\\atop":n="\\\\atopfrac";break;case"\\brace":n="\\\\bracefrac";break;case"\\brack":n="\\\\brackfrac";break;default:throw new Error("Unrecognized infix genfrac command")}return{type:"infix",mode:e.mode,replaceWith:n,token:a}}});var hs=["display","text","script","scriptscript"],ms=function(e){var t=null;return e.length>0&&(t=e,t=t==="."?null:t),t};L({type:"genfrac",names:["\\genfrac"],numArgs:6,allowedInArgument:!0,argTypes:["math","math","size","text","math","math"],handler(r,e){var t=r.parser,a=e[4],n=e[5],i=Xt(e[0]),l=i.type==="atom"&&i.family==="open"?ms(i.text):null,u=Xt(e[1]),h=u.type==="atom"&&u.family==="close"?ms(u.text):null,d=K(e[2],"size"),f,b=null;d.isBlank?f=!0:(b=d.value,f=b.number>0);var k=null,w=e[3];if(w.type==="ordgroup"){if(w.body.length>0){var M=K(w.body[0],"textord");k=hs[Number(M.text)]}}else w=K(w,"textord"),k=hs[Number(w.text)];return rl({type:"genfrac",mode:t.mode,numer:a,denom:n,continued:!1,hasBarLine:f,barSize:b,leftDelim:l,rightDelim:h},k)}});L({type:"infix",names:["\\above"],numArgs:1,argTypes:["size"],infix:!0,handler(r,e){var t=r.parser;r.funcName;var a=r.token;return{type:"infix",mode:t.mode,replaceWith:"\\\\abovefrac",size:K(e[0],"size").value,token:a}}});L({type:"genfrac",names:["\\\\abovefrac"],numArgs:3,argTypes:["math","size","math"],handler:(r,e)=>{var t=r.parser;r.funcName;var a=e[0],n=K(e[1],"infix").size;if(!n)throw new Error("\\\\abovefrac expected size, but got "+String(n));var i=e[2],l=n.number>0;return{type:"genfrac",mode:t.mode,numer:a,denom:i,continued:!1,hasBarLine:l,barSize:n,leftDelim:null,rightDelim:null}}});var al=(r,e)=>{var t=e.style,a,n;r.type==="supsub"?(a=r.sup?te(r.sup,e.havingStyle(t.sup()),e):te(r.sub,e.havingStyle(t.sub()),e),n=K(r.base,"horizBrace")):n=K(r,"horizBrace");var i=te(n.base,e.havingBaseStyle(W.DISPLAY)),l=$r(n,e),u;if(n.isOver?u=re({positionType:"firstBaseline",children:[{type:"elem",elem:i},{type:"kern",size:.1},{type:"elem",elem:l,wrapperClasses:["svg-align"]}]}):u=re({positionType:"bottom",positionData:i.depth+.1+l.height,children:[{type:"elem",elem:l,wrapperClasses:["svg-align"]},{type:"kern",size:.1},{type:"elem",elem:i}]}),a){var h=R(["minner",n.isOver?"mover":"munder"],[u],e);n.isOver?u=re({positionType:"firstBaseline",children:[{type:"elem",elem:h},{type:"kern",size:.2},{type:"elem",elem:a}]}):u=re({positionType:"bottom",positionData:h.depth+.2+a.height+a.depth,children:[{type:"elem",elem:a},{type:"kern",size:.2},{type:"elem",elem:h}]})}return R(["minner",n.isOver?"mover":"munder"],[u],e)},h4=(r,e)=>{var t=Hr(r.label);return new I(r.isOver?"mover":"munder",[se(r.base,e),t])};L({type:"horizBrace",names:["\\overbrace","\\underbrace","\\overbracket","\\underbracket"],numArgs:1,handler(r,e){var t=r.parser,a=r.funcName;return{type:"horizBrace",mode:t.mode,label:a,isOver:a.includes("\\over"),base:e[0]}},htmlBuilder:al,mathmlBuilder:h4});L({type:"href",names:["\\href"],numArgs:2,argTypes:["url","original"],allowedInText:!0,handler:(r,e)=>{var t=r.parser,a=e[1],n=K(e[0],"url").url;return t.settings.isTrusted({command:"\\href",url:n})?{type:"href",mode:t.mode,href:n,body:ye(a)}:t.formatUnsupportedCmd("\\href")},htmlBuilder:(r,e)=>{var t=Se(r.body,e,!1);return du(r.href,[],t,e)},mathmlBuilder:(r,e)=>{var t=H0(r.body,e);return t instanceof I||(t=new I("mrow",[t])),t.setAttribute("href",r.href),t}});L({type:"href",names:["\\url"],numArgs:1,argTypes:["url"],allowedInText:!0,handler:(r,e)=>{var t=r.parser,a=K(e[0],"url").url;if(!t.settings.isTrusted({command:"\\url",url:a}))return t.formatUnsupportedCmd("\\url");for(var n=[],i=0;i<a.length;i++){var l=a[i];l==="~"&&(l="\\textasciitilde"),n.push({type:"textord",mode:"text",text:l})}var u={type:"text",mode:t.mode,font:"\\texttt",body:n};return{type:"href",mode:t.mode,href:a,body:ye(u)}}});L({type:"hbox",names:["\\hbox"],numArgs:1,argTypes:["text"],allowedInText:!0,primitive:!0,handler(r,e){var t=r.parser;return{type:"hbox",mode:t.mode,body:ye(e[0])}},htmlBuilder(r,e){var t=Se(r.body,e.withFont(""),!1);return z0(t)},mathmlBuilder(r,e){return new I("mrow",Ke(r.body,e.withFont("")))}});L({type:"html",names:["\\htmlClass","\\htmlId","\\htmlStyle","\\htmlData"],numArgs:2,argTypes:["raw","original"],allowedInText:!0,handler:(r,e)=>{var t=r.parser,a=r.funcName;r.token;var n=K(e[0],"raw").string,i=e[1];t.settings.strict&&t.settings.reportNonstrict("htmlExtension","HTML extension is disabled on strict mode");var l,u={};switch(a){case"\\htmlClass":u.class=n,l={command:"\\htmlClass",class:n};break;case"\\htmlId":u.id=n,l={command:"\\htmlId",id:n};break;case"\\htmlStyle":u.style=n,l={command:"\\htmlStyle",style:n};break;case"\\htmlData":{for(var h="{,}",d=[],f="",b=0;b<n.length;b++)n.startsWith(h,b)?(f+=",",b+=h.length-1):n[b]===","?(d.push(f),f=""):f+=n[b];d.push(f);for(var k=0;k<d.length;k++){var w=d[k],M=w.indexOf("=");if(M<0)throw new C("\\htmlData key/value '"+w+"' missing equals sign");var D=w.slice(0,M),E=w.slice(M+1);u["data-"+D.trim()]=E}l={command:"\\htmlData",attributes:u};break}default:throw new Error("Unrecognized html command")}return t.settings.isTrusted(l)?{type:"html",mode:t.mode,attributes:u,body:ye(i)}:t.formatUnsupportedCmd(a)},htmlBuilder:(r,e)=>{var t=Se(r.body,e,!1),a=["enclosing"];r.attributes.class&&a.push(...r.attributes.class.trim().split(/\s+/));var n=R(a,t,e);for(var i of Object.entries(r.attributes)){var l=i[0],u=i[1];l!=="class"&&n.setAttribute(l,u)}return n},mathmlBuilder:(r,e)=>H0(r.body,e)});L({type:"htmlmathml",names:["\\html@mathml"],numArgs:2,allowedInArgument:!0,allowedInText:!0,handler:(r,e)=>{var t=r.parser;return{type:"htmlmathml",mode:t.mode,html:ye(e[0]),mathml:ye(e[1])}},htmlBuilder:(r,e)=>{var t=Se(r.html,e,!1);return z0(t)},mathmlBuilder:(r,e)=>H0(r.mathml,e)});var Va=function(e){if(/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))return{number:+e,unit:"bp"};var t=/([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);if(!t)throw new C("Invalid size: '"+e+"' in \\includegraphics");var a={number:+(t[1]+t[2]),unit:t[3]};if(!Ms(a))throw new C("Invalid unit: '"+a.unit+"' in \\includegraphics.");return a};L({type:"includegraphics",names:["\\includegraphics"],numArgs:1,numOptionalArgs:1,argTypes:["raw","url"],allowedInText:!1,handler:(r,e,t)=>{var a=r.parser,n={number:0,unit:"em"},i={number:.9,unit:"em"},l={number:0,unit:"em"},u="";if(t[0])for(var h=K(t[0],"raw").string,d=h.split(","),f=0;f<d.length;f++){var b=d[f].split("=");if(b.length===2){var k=b[1].trim();switch(b[0].trim()){case"alt":u=k;break;case"width":n=Va(k);break;case"height":i=Va(k);break;case"totalheight":l=Va(k);break;default:throw new C("Invalid key: '"+b[0]+"' in \\includegraphics.")}}}var w=K(e[0],"url").url;return u===""&&(u=w,u=u.replace(/^.*[\\/]/,""),u=u.substring(0,u.lastIndexOf("."))),a.settings.isTrusted({command:"\\includegraphics",url:w})?{type:"includegraphics",mode:a.mode,alt:u,width:n,height:i,totalheight:l,src:w}:a.formatUnsupportedCmd("\\includegraphics")},htmlBuilder:(r,e)=>{var t=fe(r.height,e),a=0;r.totalheight.number>0&&(a=fe(r.totalheight,e)-t);var n=0;r.width.number>0&&(n=fe(r.width,e));var i={height:O(t+a)};n>0&&(i.width=O(n)),a>0&&(i.verticalAlign=O(-a));var l=new Qa(r.src,r.alt,i);return l.height=t,l.depth=a,l},mathmlBuilder:(r,e)=>{var t=new I("mglyph",[]);t.setAttribute("alt",r.alt);var a=fe(r.height,e),n=0;if(r.totalheight.number>0&&(n=fe(r.totalheight,e)-a,t.setAttribute("valign",O(-n))),t.setAttribute("height",O(a+n)),r.width.number>0){var i=fe(r.width,e);t.setAttribute("width",O(i))}return t.setAttribute("src",r.src),t}});L({type:"kern",names:["\\kern","\\mkern","\\hskip","\\mskip"],numArgs:1,argTypes:["size"],primitive:!0,allowedInText:!0,handler(r,e){var t=r.parser,a=r.funcName,n=K(e[0],"size");if(t.settings.strict){var i=a[1]==="m",l=n.value.unit==="mu";i?(l||t.settings.reportNonstrict("mathVsTextUnits","LaTeX's "+a+" supports only mu units, "+("not "+n.value.unit+" units")),t.mode!=="math"&&t.settings.reportNonstrict("mathVsTextUnits","LaTeX's "+a+" works only in math mode")):l&&t.settings.reportNonstrict("mathVsTextUnits","LaTeX's "+a+" doesn't support mu units")}return{type:"kern",mode:t.mode,dimension:n.value}},htmlBuilder(r,e){return Os(r.dimension,e)},mathmlBuilder(r,e){var t=fe(r.dimension,e);return new Nr(t)}});L({type:"lap",names:["\\mathllap","\\mathrlap","\\mathclap"],numArgs:1,allowedInText:!0,handler:(r,e)=>{var t=r.parser,a=r.funcName,n=e[0];return{type:"lap",mode:t.mode,alignment:a.slice(5),body:n}},htmlBuilder:(r,e)=>{var t;r.alignment==="clap"?(t=R([],[te(r.body,e)]),t=R(["katex-inner"],[t],e)):t=R(["katex-inner"],[te(r.body,e)]);var a=R(["katex-fix"],[]),n=R([r.alignment],[t,a],e),i=R(["katex-strut"]);return i.style.height=O(n.height+n.depth),n.depth&&(i.style.verticalAlign=O(-n.depth)),n.children.unshift(i),n=R(["katex-thinbox"],[n],e),R(["mord","katex-vbox"],[n],e)},mathmlBuilder:(r,e)=>{var t=new I("mpadded",[se(r.body,e)]);if(r.alignment!=="rlap"){var a=r.alignment==="llap"?"-1":"-0.5";t.setAttribute("lspace",a+"width")}return t.setAttribute("width","0px"),t}});L({type:"styling",names:["\\(","$"],numArgs:0,allowedInText:!0,allowedInMath:!1,handler(r,e){var t=r.funcName,a=r.parser,n=a.mode;a.switchMode("math");var i=t==="\\("?"\\)":"$",l=a.parseExpression(!1,i);return a.expect(i),a.switchMode(n),{type:"styling",mode:a.mode,style:"text",resetFont:!0,body:l}}});L({type:"text",names:["\\)","\\]"],numArgs:0,allowedInText:!0,allowedInMath:!1,handler(r,e){throw new C("Mismatched "+r.funcName)}});var ds=(r,e)=>{switch(e.style.size){case W.DISPLAY.size:return r.display;case W.TEXT.size:return r.text;case W.SCRIPT.size:return r.script;case W.SCRIPTSCRIPT.size:return r.scriptscript;default:return r.text}};L({type:"mathchoice",names:["\\mathchoice"],numArgs:4,primitive:!0,handler:(r,e)=>{var t=r.parser;return{type:"mathchoice",mode:t.mode,display:ye(e[0]),text:ye(e[1]),script:ye(e[2]),scriptscript:ye(e[3])}},htmlBuilder:(r,e)=>{var t=ds(r,e),a=Se(t,e,!1);return z0(a)},mathmlBuilder:(r,e)=>{var t=ds(r,e);return H0(t,e)}});var nl=(r,e,t,a,n,i,l)=>{r=R([],[r]);var u=t&&T0(t),h,d;if(e){var f=te(e,a.havingStyle(n.sup()),a);d={elem:f,kern:Math.max(a.fontMetrics().bigOpSpacing1,a.fontMetrics().bigOpSpacing3-f.depth)}}if(t){var b=te(t,a.havingStyle(n.sub()),a);h={elem:b,kern:Math.max(a.fontMetrics().bigOpSpacing2,a.fontMetrics().bigOpSpacing4-b.height)}}var k;if(d&&h){var w=a.fontMetrics().bigOpSpacing5+h.elem.height+h.elem.depth+h.kern+r.depth+l;k=re({positionType:"bottom",positionData:w,children:[{type:"kern",size:a.fontMetrics().bigOpSpacing5},{type:"elem",elem:h.elem,marginLeft:O(-i)},{type:"kern",size:h.kern},{type:"elem",elem:r},{type:"kern",size:d.kern},{type:"elem",elem:d.elem,marginLeft:O(i)},{type:"kern",size:a.fontMetrics().bigOpSpacing5}]})}else if(h){var M=r.height-l;k=re({positionType:"top",positionData:M,children:[{type:"kern",size:a.fontMetrics().bigOpSpacing5},{type:"elem",elem:h.elem,marginLeft:O(-i)},{type:"kern",size:h.kern},{type:"elem",elem:r}]})}else if(d){var D=r.depth+l;k=re({positionType:"bottom",positionData:D,children:[{type:"elem",elem:r},{type:"kern",size:d.kern},{type:"elem",elem:d.elem,marginLeft:O(i)},{type:"kern",size:a.fontMetrics().bigOpSpacing5}]})}else return r;var E=[k];if(h&&i!==0&&!u){var N=R(["mspace"],[],a);N.style.marginRight=O(i),E.unshift(N)}return R(["mop","op-limits"],E,a)},il=new Set(["\\smallint"]),sl=(r,e)=>{var t,a,n=!1,i;r.type==="supsub"?(t=r.sup,a=r.sub,i=K(r.base,"op"),n=!0):i=K(r,"op");var l=e.style,u=!1;l.size===W.DISPLAY.size&&i.symbol&&!il.has(i.name)&&(u=!0);var h,d;if(i.symbol){var f=u?"Size2-Regular":"Size1-Regular",b="";if((i.name==="\\oiint"||i.name==="\\oiiint")&&(b=i.name.slice(1),i.name=b==="oiint"?"\\iint":"\\iiint"),h=Oe(i.name,f,"math",e,["mop","op-symbol",u?"large-op":"small-op"]),d=h.italic,b.length>0){var k=Ns(b+"Size"+(u?"2":"1"),e);h=re({positionType:"individualShift",children:[{type:"elem",elem:h,shift:0},{type:"elem",elem:k,shift:u?.08:0}]}),i.name="\\"+b,h.classes.unshift("mop"),h.italic=d}}else if(i.body){var w=Se(i.body,e,!0);w.length===1&&w[0]instanceof Ne?(h=w[0],h.classes[0]="mop"):h=R(["mop"],w,e)}else{for(var M=[],D=1;D<i.name.length;D++)M.push(xn(i.name[D],i.mode,e));h=R(["mop"],M,e)}var E=0,N=0;if((h instanceof Ne||i.name==="\\oiint"||i.name==="\\oiiint")&&!i.suppressBaseShift){var B;E=(h.height-h.depth)/2-e.fontMetrics().axisHeight,N=(B=h.italic)!=null?B:0}return n?nl(h,t,a,e,l,N,E):(E&&(h.style.position="relative",h.style.top=O(E)),h)},m4=(r,e)=>{var t;if(r.symbol)t=new I("mo",[a0(r.name,r.mode)]),il.has(r.name)&&t.setAttribute("largeop","false");else if(r.body)t=new I("mo",Ke(r.body,e));else{t=new I("mi",[new ve(r.name.slice(1))]);var a=new I("mo",[a0("\u2061","text")]);r.parentIsSupSub?t=new I("mrow",[t,a]):t=Ps([t,a])}return t},d4={"\u220F":"\\prod","\u2210":"\\coprod","\u2211":"\\sum","\u22C0":"\\bigwedge","\u22C1":"\\bigvee","\u22C2":"\\bigcap","\u22C3":"\\bigcup","\u2A00":"\\bigodot","\u2A01":"\\bigoplus","\u2A02":"\\bigotimes","\u2A04":"\\biguplus","\u2A06":"\\bigsqcup"};L({type:"op",names:["\\coprod","\\bigvee","\\bigwedge","\\biguplus","\\bigcap","\\bigcup","\\intop","\\prod","\\sum","\\bigotimes","\\bigoplus","\\bigodot","\\bigsqcup","\\smallint","\u220F","\u2210","\u2211","\u22C0","\u22C1","\u22C2","\u22C3","\u2A00","\u2A01","\u2A02","\u2A04","\u2A06"],numArgs:0,handler:(r,e)=>{var t=r.parser,a=r.funcName,n=a;return n.length===1&&(n=d4[n]),{type:"op",mode:t.mode,limits:!0,parentIsSupSub:!1,symbol:!0,name:n}},htmlBuilder:sl,mathmlBuilder:m4});L({type:"op",names:["\\mathop"],numArgs:1,primitive:!0,handler:(r,e)=>{var t=r.parser,a=e[0];return{type:"op",mode:t.mode,limits:!1,parentIsSupSub:!1,symbol:!1,body:ye(a)}}});var p4={"\u222B":"\\int","\u222C":"\\iint","\u222D":"\\iiint","\u222E":"\\oint","\u222F":"\\oiint","\u2230":"\\oiiint"};L({type:"op",names:["\\arcsin","\\arccos","\\arctan","\\arctg","\\arcctg","\\arg","\\ch","\\cos","\\cosec","\\cosh","\\cot","\\cotg","\\coth","\\csc","\\ctg","\\cth","\\deg","\\dim","\\exp","\\hom","\\ker","\\lg","\\ln","\\log","\\sec","\\sin","\\sinh","\\sh","\\tan","\\tanh","\\tg","\\th"],numArgs:0,handler(r){var e=r.parser,t=r.funcName;return{type:"op",mode:e.mode,limits:!1,parentIsSupSub:!1,symbol:!1,name:t}}});L({type:"op",names:["\\det","\\gcd","\\inf","\\lim","\\max","\\min","\\Pr","\\sup"],numArgs:0,handler(r){var e=r.parser,t=r.funcName;return{type:"op",mode:e.mode,limits:!0,parentIsSupSub:!1,symbol:!1,name:t}}});L({type:"op",names:["\\int","\\iint","\\iiint","\\oint","\\oiint","\\oiiint","\u222B","\u222C","\u222D","\u222E","\u222F","\u2230"],numArgs:0,allowedInArgument:!0,handler(r){var e=r.parser,t=r.funcName,a=t;return a.length===1&&(a=p4[a]),{type:"op",mode:e.mode,limits:!1,parentIsSupSub:!1,symbol:!0,name:a}}});var ll=(r,e)=>{var t,a,n=!1,i;r.type==="supsub"?(t=r.sup,a=r.sub,i=K(r.base,"operatorname"),n=!0):i=K(r,"operatorname");var l;if(i.body.length>0){for(var u=i.body.map(b=>{var k="text"in b?b.text:void 0;return typeof k=="string"?{type:"textord",mode:b.mode,text:k}:b}),h=Se(u,e.withFont("mathrm"),!0),d=0;d<h.length;d++){var f=h[d];f instanceof Ne&&(f.text=f.text.replace(/\u2212/,"-").replace(/\u2217/,"*"))}l=R(["mop"],h,e)}else l=R(["mop"],[],e);return n?nl(l,t,a,e,e.style,0,0):l},f4=(r,e)=>{for(var t=Ke(r.body,e.withFont("mathrm")),a=!0,n=0;n<t.length;n++){var i=t[n];if(!(i instanceof Nr))if(i instanceof I)switch(i.type){case"mi":case"mn":case"mspace":case"mtext":break;case"mo":{var l=i.children[0];i.children.length===1&&l instanceof ve?l.text=l.text.replace(/\u2212/,"-").replace(/\u2217/,"*"):a=!1;break}default:a=!1}else a=!1}if(a){var u=t.map(f=>f.toText()).join("");t=[new ve(u)]}var h=new I("mi",t);h.setAttribute("mathvariant","normal");var d=new I("mo",[a0("\u2061","text")]);return r.parentIsSupSub?new I("mrow",[h,d]):Ps([h,d])};L({type:"operatorname",names:["\\operatorname@","\\operatornamewithlimits"],numArgs:1,handler:(r,e)=>{var t=r.parser,a=r.funcName,n=e[0];return{type:"operatorname",mode:t.mode,body:ye(n),alwaysHandleSupSub:a==="\\operatornamewithlimits",limits:!1,parentIsSupSub:!1}},htmlBuilder:ll,mathmlBuilder:f4});m("\\operatorname","\\@ifstar\\operatornamewithlimits\\operatorname@");tt({type:"ordgroup",htmlBuilder(r,e){return r.semisimple?z0(Se(r.body,e,!1)):R(["mord"],Se(r.body,e,!0),e)},mathmlBuilder(r,e){return H0(r.body,e,!0)}});L({type:"overline",names:["\\overline"],numArgs:1,handler(r,e){var t=r.parser,a=e[0];return{type:"overline",mode:t.mode,body:a}},htmlBuilder(r,e){var t=te(r.body,e.havingCrampedStyle()),a=wt("overline-line",e),n=e.fontMetrics().defaultRuleThickness,i=re({positionType:"firstBaseline",children:[{type:"elem",elem:t},{type:"kern",size:3*n},{type:"elem",elem:a},{type:"kern",size:n}]});return R(["mord","katex-overline"],[i],e)},mathmlBuilder(r,e){var t=new I("mo",[new ve("\u203E")]);t.setAttribute("stretchy","true");var a=new I("mover",[se(r.body,e),t]);return a.setAttribute("accent","true"),a}});L({type:"phantom",names:["\\phantom"],numArgs:1,allowedInText:!0,handler:(r,e)=>{var t=r.parser,a=e[0];return{type:"phantom",mode:t.mode,body:ye(a)}},htmlBuilder:(r,e)=>{var t=Se(r.body,e.withPhantom(),!1);return z0(t)},mathmlBuilder:(r,e)=>{var t=Ke(r.body,e);return new I("mphantom",t)}});m("\\hphantom","\\smash{\\phantom{#1}}");L({type:"vphantom",names:["\\vphantom"],numArgs:1,allowedInText:!0,handler:(r,e)=>{var t=r.parser,a=e[0];return{type:"vphantom",mode:t.mode,body:a}},htmlBuilder:(r,e)=>{var t=R(["katex-inner"],[te(r.body,e.withPhantom())]),a=R(["katex-fix"],[]);return R(["mord","rlap"],[t,a],e)},mathmlBuilder:(r,e)=>{var t=Ke(ye(r.body),e),a=new I("mphantom",t),n=new I("mpadded",[a]);return n.setAttribute("width","0px"),n}});L({type:"raisebox",names:["\\raisebox"],numArgs:2,argTypes:["size","hbox"],allowedInText:!0,handler(r,e){var t=r.parser,a=K(e[0],"size").value,n=e[1];return{type:"raisebox",mode:t.mode,dy:a,body:n}},htmlBuilder(r,e){var t=te(r.body,e),a=fe(r.dy,e);return re({positionType:"shift",positionData:-a,children:[{type:"elem",elem:t}]})},mathmlBuilder(r,e){var t=new I("mpadded",[se(r.body,e)]),a=r.dy.number+r.dy.unit;return t.setAttribute("voffset",a),t}});var ol=(r,e)=>{var t=r.parser;return{type:"reflectbox",mode:t.mode,body:e[0]}};L({type:"reflectbox",names:["\\reflectbox"],numArgs:1,argTypes:["hbox"],allowedInText:!0,handler:ol,htmlBuilder(r,e){return R(["mord","reflectbox"],[te(r.body,e)],e)},mathmlBuilder(r,e){return se(r.body,e)}});L({type:"reflectbox",names:["\\mathreflectbox"],numArgs:1,argTypes:["math"],handler:ol});L({type:"internal",names:["\\relax"],numArgs:0,allowedInText:!0,allowedInArgument:!0,handler(r){var e=r.parser;return{type:"internal",mode:e.mode}}});L({type:"rule",names:["\\rule"],numArgs:2,numOptionalArgs:1,allowedInText:!0,allowedInMath:!0,argTypes:["size","size","size"],handler(r,e,t){var a=r.parser,n=t[0],i=K(e[0],"size"),l=K(e[1],"size");return{type:"rule",mode:a.mode,shift:n&&K(n,"size").value,width:i.value,height:l.value}},htmlBuilder(r,e){var t=R(["mord","katex-rule"],[],e),a=fe(r.width,e),n=fe(r.height,e),i=r.shift?fe(r.shift,e):0;return t.style.borderRightWidth=O(a),t.style.borderTopWidth=O(n),t.style.bottom=O(i),t.width=a,t.height=n+i,t.depth=-i,t.maxFontSize=n*1.125*e.sizeMultiplier,t},mathmlBuilder(r,e){var t=fe(r.width,e),a=fe(r.height,e),n=r.shift?fe(r.shift,e):0,i=e.color&&e.getColor()||"black",l=new I("mspace");l.setAttribute("mathbackground",i),l.setAttribute("width",O(t)),l.setAttribute("height",O(a));var u=new I("mpadded",[l]);return n>=0?u.setAttribute("height",O(n)):(u.setAttribute("height",O(n)),u.setAttribute("depth",O(-n))),u.setAttribute("voffset",O(n)),u}});function ul(r,e,t){for(var a=Se(r,e,!1),n=e.sizeMultiplier/t.sizeMultiplier,i=0;i<a.length;i++){var l=a[i].classes.indexOf("katex-sizing");l<0?Array.prototype.push.apply(a[i].classes,e.sizingClasses(t)):a[i].classes[l+1]==="reset-size"+e.size&&(a[i].classes[l+1]="reset-size"+t.size),a[i].height*=n,a[i].depth*=n}return z0(a)}var ps=["\\tiny","\\sixptsize","\\scriptsize","\\footnotesize","\\small","\\normalsize","\\large","\\Large","\\LARGE","\\huge","\\Huge"],v4=(r,e)=>{var t=e.havingSize(r.size);return ul(r.body,t,e)};L({type:"sizing",names:ps,numArgs:0,allowedInText:!0,handler:(r,e)=>{var t=r.breakOnTokenText,a=r.funcName,n=r.parser,i=n.parseExpression(!1,t);return{type:"sizing",mode:n.mode,size:ps.indexOf(a)+1,body:i}},htmlBuilder:v4,mathmlBuilder:(r,e)=>{var t=e.havingSize(r.size),a=Ke(r.body,t),n=new I("mstyle",a);return n.setAttribute("mathsize",O(t.sizeMultiplier)),n}});L({type:"smash",names:["\\smash"],numArgs:1,numOptionalArgs:1,allowedInText:!0,handler:(r,e,t)=>{var a=r.parser,n=!1,i=!1,l=t[0]&&K(t[0],"ordgroup");if(l)for(var u,h=0;h<l.body.length;++h){var d=l.body[h];if(u=Ur(d).text,u==="t")n=!0;else if(u==="b")i=!0;else{n=!1,i=!1;break}}else n=!0,i=!0;var f=e[0];return{type:"smash",mode:a.mode,body:f,smashHeight:n,smashDepth:i}},htmlBuilder:(r,e)=>{var t=R([],[te(r.body,e)]);if(!r.smashHeight&&!r.smashDepth)return t;if(r.smashHeight&&(t.height=0),r.smashDepth&&(t.depth=0),r.smashHeight&&r.smashDepth)return R(["mord","katex-smash"],[t],e);if(t.children)for(var a=0;a<t.children.length;a++)r.smashHeight&&(t.children[a].height=0),r.smashDepth&&(t.children[a].depth=0);var n=re({positionType:"firstBaseline",children:[{type:"elem",elem:t}]});return R(["mord"],[n],e)},mathmlBuilder:(r,e)=>{var t=new I("mpadded",[se(r.body,e)]);return r.smashHeight&&t.setAttribute("height","0px"),r.smashDepth&&t.setAttribute("depth","0px"),t}});L({type:"sqrt",names:["\\sqrt"],numArgs:1,numOptionalArgs:1,handler(r,e,t){var a=r.parser,n=t[0],i=e[0];return{type:"sqrt",mode:a.mode,body:i,index:n}},htmlBuilder(r,e){var t=te(r.body,e.havingCrampedStyle());t.height===0&&(t.height=e.fontMetrics().xHeight),t=kt(t,e);var a=e.fontMetrics(),n=a.defaultRuleThickness,i=n;e.style.id<W.TEXT.id&&(i=e.fontMetrics().xHeight);var l=n+i/4,u=t.height+t.depth+l+n,h=Ku(u,e),d=h.span,f=h.ruleWidth,b=h.advanceWidth,k=d.height-f;k>t.height+t.depth+l&&(l=(l+k-t.height-t.depth)/2);var w=d.height-t.height-l-f;t.style.paddingLeft=O(b);var M=re({positionType:"firstBaseline",children:[{type:"elem",elem:t,wrapperClasses:["svg-align"]},{type:"kern",size:-(t.height+w)},{type:"elem",elem:d},{type:"kern",size:f}]});if(r.index){var D=e.havingStyle(W.SCRIPTSCRIPT),E=te(r.index,D,e),N=.6*(M.height-M.depth),B=re({positionType:"shift",positionData:-N,children:[{type:"elem",elem:E}]}),F=R(["katex-root"],[B]);return R(["mord","sqrt"],[F,M],e)}else return R(["mord","sqrt"],[M],e)},mathmlBuilder(r,e){var t=r.body,a=r.index;return a?new I("mroot",[se(t,e),se(a,e)]):new I("msqrt",[se(t,e)])}});var dn={display:W.DISPLAY,text:W.TEXT,script:W.SCRIPT,scriptscript:W.SCRIPTSCRIPT};function g4(r){return r in dn}L({type:"styling",names:["\\displaystyle","\\textstyle","\\scriptstyle","\\scriptscriptstyle"],numArgs:0,allowedInText:!0,primitive:!0,handler(r,e){var t=r.breakOnTokenText,a=r.funcName,n=r.parser,i=n.parseExpression(!0,t),l=a.slice(1,a.length-5);if(!g4(l))throw new Error("Unknown style: "+l);return{type:"styling",mode:n.mode,style:l,body:i}},htmlBuilder(r,e){var t=dn[r.style],a=e.havingStyle(t);return r.resetFont&&(a=a.withFont("")),ul(r.body,a,e)},mathmlBuilder(r,e){var t=dn[r.style],a=e.havingStyle(t);r.resetFont&&(a=a.withFont(""));var n=Ke(r.body,a),i=new I("mstyle",n),l={display:["0","true"],text:["0","false"],script:["1","false"],scriptscript:["2","false"]},u=l[r.style];return i.setAttribute("scriptlevel",u[0]),i.setAttribute("displaystyle",u[1]),i}});var b4=function(e,t){var a=e.base;if(a)if(a.type==="op"){var n=a.limits&&(t.style.size===W.DISPLAY.size||a.alwaysHandleSupSub);return n?sl:null}else if(a.type==="operatorname"){var i=a.alwaysHandleSupSub&&(t.style.size===W.DISPLAY.size||a.limits);return i?ll:null}else{if(a.type==="accent")return T0(a.base)?$s:null;if(a.type==="horizBrace"){var l=!e.sub;return l===a.isOver?al:null}else return null}else return null};tt({type:"supsub",htmlBuilder(r,e){var t=b4(r,e);if(t)return t(r,e);var a=r.base,n=r.sup,i=r.sub,l=te(a,e),u,h,d=e.fontMetrics(),f=0,b=0,k=a&&T0(a);if(n){var w=e.havingStyle(e.style.sup());u=te(n,w,e),k||(f=l.height-w.fontMetrics().supDrop*w.sizeMultiplier/e.sizeMultiplier)}if(i){var M=e.havingStyle(e.style.sub());h=te(i,M,e),k||(b=l.depth+M.fontMetrics().subDrop*M.sizeMultiplier/e.sizeMultiplier)}var D;e.style===W.DISPLAY?D=d.sup1:e.style.cramped?D=d.sup3:D=d.sup2;var E=e.sizeMultiplier,N=O(.5/d.ptPerEm/E),B=null;if(h){var F=r.base&&r.base.type==="op"&&r.base.name&&(r.base.name==="\\oiint"||r.base.name==="\\oiiint");if(l instanceof Ne||F){var H;B=O(-((H=l.italic)!=null?H:0))}}var V;if(u&&h){f=Math.max(f,D,u.depth+.25*d.xHeight),b=Math.max(b,d.sub2);var j=d.defaultRuleThickness,$=4*j;if(f-u.depth-(h.height-b)<$){b=$-(f-u.depth)+h.height;var X=.8*d.xHeight-(f-u.depth);X>0&&(f+=X,b-=X)}var ee=[{type:"elem",elem:h,shift:b,marginRight:N,marginLeft:B},{type:"elem",elem:u,shift:-f,marginRight:N}];V=re({positionType:"individualShift",children:ee})}else if(h){b=Math.max(b,d.sub1,h.height-.8*d.xHeight);var ae=[{type:"elem",elem:h,marginLeft:B,marginRight:N}];V=re({positionType:"shift",positionData:b,children:ae})}else if(u)f=Math.max(f,D,u.depth+.25*d.xHeight),V=re({positionType:"shift",positionData:-f,children:[{type:"elem",elem:u,marginRight:N}]});else throw new Error("supsub must have either sup or sub.");var Q=on(l,"right")||"mord";return R([Q],[l,R(["msupsub"],[V])],e)},mathmlBuilder(r,e){var t=!1,a,n;r.base&&r.base.type==="horizBrace"&&(n=!!r.sup,n===r.base.isOver&&(t=!0,a=r.base.isOver)),r.base&&(r.base.type==="op"||r.base.type==="operatorname")&&(r.base.parentIsSupSub=!0);var i=[se(r.base,e)];r.sub&&i.push(se(r.sub,e)),r.sup&&i.push(se(r.sup,e));var l;if(t)l=a?"mover":"munder";else if(r.sub)if(r.sup){var d=r.base;d&&d.type==="op"&&d.limits&&e.style===W.DISPLAY||d&&d.type==="operatorname"&&d.alwaysHandleSupSub&&(e.style===W.DISPLAY||d.limits)?l="munderover":l="msubsup"}else{var h=r.base;h&&h.type==="op"&&h.limits&&(e.style===W.DISPLAY||h.alwaysHandleSupSub)||h&&h.type==="operatorname"&&h.alwaysHandleSupSub&&(h.limits||e.style===W.DISPLAY)?l="munder":l="msub"}else{var u=r.base;u&&u.type==="op"&&u.limits&&(e.style===W.DISPLAY||u.alwaysHandleSupSub)||u&&u.type==="operatorname"&&u.alwaysHandleSupSub&&(u.limits||e.style===W.DISPLAY)?l="mover":l="msup"}return new I(l,i)}});tt({type:"atom",htmlBuilder(r,e){return xn(r.text,r.mode,e,["m"+r.family])},mathmlBuilder(r,e){var t=new I("mo",[a0(r.text,r.mode)]);if(r.family==="bin"){var a=Sn(r,e);a==="bold-italic"&&t.setAttribute("mathvariant",a)}else r.family==="punct"?t.setAttribute("separator","true"):(r.family==="open"||r.family==="close")&&t.setAttribute("stretchy","false");return t}});var cl={mi:"italic",mn:"normal",mtext:"normal"};tt({type:"mathord",htmlBuilder(r,e){return _r(r,e)},mathmlBuilder(r,e){var t=new I("mi",[a0(r.text,r.mode,e)]),a=Sn(r,e)||"italic";return a!==cl[t.type]&&t.setAttribute("mathvariant",a),t}});tt({type:"textord",htmlBuilder(r,e){return _r(r,e)},mathmlBuilder(r,e){var t=a0(r.text,r.mode,e),a=Sn(r,e)||"normal",n;return r.mode==="text"?n=new I("mtext",[t]):/[0-9]/.test(r.text)?n=new I("mn",[t]):r.text==="\\prime"?n=new I("mo",[t]):n=new I("mi",[t]),a!==cl[n.type]&&n.setAttribute("mathvariant",a),n}});var fs=new Map([["\\nobreak","nobreak"],["\\allowbreak","allowbreak"]]),vs=new Map([[" ",{}],["\\ ",{}],["~",{className:"nobreak"}],["\\space",{}],["\\nobreakspace",{className:"nobreak"}]]);tt({type:"spacing",htmlBuilder(r,e){var t=vs.get(r.text),a=fs.get(r.text);if(t){var n=t.className||"";if(r.mode==="text"){var i=_r(r,e);return i.classes.push(n),i}else return R(["mspace",n],[xn(r.text,r.mode,e)],e)}else{if(a)return R(["mspace",a],[],e);throw new C('Unknown type of space "'+r.text+'"')}},mathmlBuilder(r,e){var t;if(vs.has(r.text))t=new I("mtext",[new ve("\xA0")]);else{if(fs.has(r.text))return new I("mspace");throw new C('Unknown type of space "'+r.text+'"')}return t}});var gs=()=>{var r=new I("mtd",[]);return r.setAttribute("width","50%"),r};tt({type:"tag",mathmlBuilder(r,e){var t=new I("mtable",[new I("mtr",[gs(),new I("mtd",[H0(r.body,e)]),gs(),new I("mtd",[H0(r.tag,e)])])]);return t.setAttribute("width","100%"),t}});var bs={"\\text":void 0,"\\textrm":"textrm","\\textsf":"textsf","\\texttt":"texttt","\\textnormal":"textrm"},ys={"\\textbf":"textbf","\\textmd":"textmd"},y4={"\\textit":"textit","\\textup":"textup"},xs=(r,e)=>{var t=r.font;if(t){if(bs[t])return e.withTextFontFamily(bs[t]);if(ys[t])return e.withTextFontWeight(ys[t]);if(t==="\\emph")return e.fontShape==="textit"?e.withTextFontShape("textup"):e.withTextFontShape("textit")}else return e;return e.withTextFontShape(y4[t])};L({type:"text",names:["\\text","\\textrm","\\textsf","\\texttt","\\textnormal","\\textbf","\\textmd","\\textit","\\textup","\\emph"],numArgs:1,argTypes:["text"],allowedInArgument:!0,allowedInText:!0,handler(r,e){var t=r.parser,a=r.funcName,n=e[0];return{type:"text",mode:t.mode,body:ye(n),font:a}},htmlBuilder(r,e){var t=xs(r,e),a=Se(r.body,t,!0);return R(["mord","text"],a,t)},mathmlBuilder(r,e){var t=xs(r,e);return H0(r.body,t)}});L({type:"underline",names:["\\underline"],numArgs:1,allowedInText:!0,handler(r,e){var t=r.parser;return{type:"underline",mode:t.mode,body:e[0]}},htmlBuilder(r,e){var t=te(r.body,e),a=wt("underline-line",e),n=e.fontMetrics().defaultRuleThickness,i=re({positionType:"top",positionData:t.height,children:[{type:"kern",size:n},{type:"elem",elem:a},{type:"kern",size:3*n},{type:"elem",elem:t}]});return R(["mord","katex-underline"],[i],e)},mathmlBuilder(r,e){var t=new I("mo",[new ve("\u203E")]);t.setAttribute("stretchy","true");var a=new I("munder",[se(r.body,e),t]);return a.setAttribute("accentunder","true"),a}});L({type:"vcenter",names:["\\vcenter"],numArgs:1,argTypes:["original"],allowedInText:!1,handler(r,e){var t=r.parser;return{type:"vcenter",mode:t.mode,body:e[0]}},htmlBuilder(r,e){var t=te(r.body,e),a=e.fontMetrics().axisHeight,n=.5*(t.height-a-(t.depth+a));return re({positionType:"shift",positionData:n,children:[{type:"elem",elem:t}]})},mathmlBuilder(r,e){var t=new I("mpadded",[se(r.body,e)],["vcenter"]);return new I("mrow",[t])}});L({type:"verb",names:["\\verb"],numArgs:0,allowedInText:!0,handler(r,e,t){throw new C("\\verb ended by end of line instead of matching delimiter")},htmlBuilder(r,e){for(var t=ws(r),a=[],n=e.havingStyle(e.style.text()),i=0;i<t.length;i++){var l=t[i];l==="~"&&(l="\\textasciitilde"),a.push(Oe(l,"Typewriter-Regular",r.mode,n,["mord","texttt"]))}return R(["mord","text"].concat(n.sizingClasses(e)),Is(a),n)},mathmlBuilder(r,e){var t=new ve(ws(r)),a=new I("mtext",[t]);return a.setAttribute("mathvariant","monospace"),a}});var ws=r=>r.body.replace(/ /g,r.star?"\u2423":"\xA0"),L0=Ls,hl=`[ \r
	]`,x4="\\\\[a-zA-Z@]+",w4="\\\\[^\uD800-\uDFFF]",k4="("+x4+")"+hl+"*",S4=`\\\\(
|[ \r	]+
?)[ \r	]*`,pn="[\u0300-\u036F]",T4=new RegExp(pn+"+$"),A4="("+hl+"+)|"+(S4+"|")+"([!-\\[\\]-\u2027\u202A-\uD7FF\uF900-\uFFFF]"+(pn+"*")+"|[\uD800-\uDBFF][\uDC00-\uDFFF]"+(pn+"*")+"|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5"+("|"+k4)+("|"+w4+")"),qr=class{constructor(e,t){this.input=void 0,this.settings=void 0,this.tokenRegex=void 0,this.catcodes=void 0,this.input=e,this.settings=t,this.tokenRegex=new RegExp(A4,"g"),this.catcodes={"%":14,"~":13}}setCatcode(e,t){this.catcodes[e]=t}lex(){var e=this.input,t=this.tokenRegex.lastIndex;if(t===e.length)return new Xe("EOF",new He(this,t,t));var a=this.tokenRegex.exec(e);if(a===null||a.index!==t)throw new C("Unexpected character: '"+e[t]+"'",new Xe(e[t],new He(this,t,t+1)));var n=a[6]||a[3]||(a[2]?"\\ ":" ");if(this.catcodes[n]===14){var i=e.indexOf(`
`,this.tokenRegex.lastIndex);return i===-1?(this.tokenRegex.lastIndex=e.length,this.settings.reportNonstrict("commentAtEnd","% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")):this.tokenRegex.lastIndex=i+1,this.lex()}return new Xe(n,new He(this,t,this.tokenRegex.lastIndex))}},fn=class{constructor(e,t){e===void 0&&(e={}),t===void 0&&(t={}),this.current=void 0,this.builtins=void 0,this.undefStack=void 0,this.current=t,this.builtins=e,this.undefStack=[]}beginGroup(){this.undefStack.push({})}endGroup(){if(this.undefStack.length===0)throw new C("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");var e=this.undefStack.pop();for(var t of Object.keys(e))e[t]===void 0?delete this.current[t]:this.current[t]=e[t]}endGroups(){for(;this.undefStack.length>0;)this.endGroup()}has(e){return Object.prototype.hasOwnProperty.call(this.current,e)||Object.prototype.hasOwnProperty.call(this.builtins,e)}get(e){return Object.prototype.hasOwnProperty.call(this.current,e)?this.current[e]:Object.prototype.hasOwnProperty.call(this.builtins,e)?this.builtins[e]:void 0}set(e,t,a){if(a===void 0&&(a=!1),a){for(var n=0;n<this.undefStack.length;n++)delete this.undefStack[n][e];this.undefStack.length>0&&(this.undefStack[this.undefStack.length-1][e]=t)}else{var i=this.undefStack[this.undefStack.length-1];i&&!Object.prototype.hasOwnProperty.call(i,e)&&(i[e]=Object.prototype.hasOwnProperty.call(this.current,e)?this.current[e]:void 0)}t==null?delete this.current[e]:this.current[e]=t}},z4=el;m("\\noexpand",function(r){var e=r.popToken();return r.isExpandable(e.text)&&(e.noexpand=!0,e.treatAsRelax=!0),{tokens:[e],numArgs:0}});m("\\expandafter",function(r){var e=r.popToken();return r.expandOnce(!0),{tokens:[e],numArgs:0}});m("\\@firstoftwo",function(r){var e=r.consumeArgs(2);return{tokens:e[0],numArgs:0}});m("\\@secondoftwo",function(r){var e=r.consumeArgs(2);return{tokens:e[1],numArgs:0}});m("\\@ifnextchar",function(r){var e=r.consumeArgs(3);r.consumeSpaces();var t=r.future();return e[0].length===1&&e[0][0].text===t.text?{tokens:e[1],numArgs:0}:{tokens:e[2],numArgs:0}});m("\\@ifstar","\\@ifnextchar *{\\@firstoftwo{#1}}");m("\\TextOrMath",function(r){var e=r.consumeArgs(2);return r.mode==="text"?{tokens:e[0],numArgs:0}:{tokens:e[1],numArgs:0}});var ks={0:0,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,a:10,A:10,b:11,B:11,c:12,C:12,d:13,D:13,e:14,E:14,f:15,F:15};m("\\char",function(r){var e=r.popToken(),t,a=0;if(e.text==="'")t=8,e=r.popToken();else if(e.text==='"')t=16,e=r.popToken();else if(e.text==="`")if(e=r.popToken(),e.text[0]==="\\")a=e.text.charCodeAt(1);else{if(e.text==="EOF")throw new C("\\char` missing argument");a=e.text.charCodeAt(0)}else t=10;if(t){if(a=ks[e.text],a==null||a>=t)throw new C("Invalid base-"+t+" digit "+e.text);for(var n;(n=ks[r.future().text])!=null&&n<t;)a*=t,a+=n,r.popToken()}return"\\@char{"+a+"}"});var En=(r,e,t,a)=>{var n=r.consumeArg().tokens;if(n.length!==1)throw new C("\\newcommand's first argument must be a macro name");var i=n[0].text,l=r.isDefined(i);if(l&&!e)throw new C("\\newcommand{"+i+"} attempting to redefine "+(i+"; use \\renewcommand"));if(!l&&!t)throw new C("\\renewcommand{"+i+"} when command "+i+" does not yet exist; use \\newcommand");var u=0;if(n=r.consumeArg().tokens,n.length===1&&n[0].text==="["){for(var h="",d=r.expandNextToken();d.text!=="]"&&d.text!=="EOF";)h+=d.text,d=r.expandNextToken();if(!h.match(/^\s*[0-9]+\s*$/))throw new C("Invalid number of arguments: "+h);u=parseInt(h),n=r.consumeArg().tokens}return l&&a||r.macros.set(i,{tokens:n,numArgs:u}),""};m("\\newcommand",r=>En(r,!1,!0,!1));m("\\renewcommand",r=>En(r,!0,!1,!1));m("\\providecommand",r=>En(r,!0,!0,!0));m("\\message",r=>{var e=r.consumeArgs(1)[0];return console.log(e.reverse().map(t=>t.text).join("")),""});m("\\errmessage",r=>{var e=r.consumeArgs(1)[0];return console.error(e.reverse().map(t=>t.text).join("")),""});m("\\show",r=>{var e=r.popToken(),t=e.text;return console.log(e,r.macros.get(t),L0[t],he.math[t],he.text[t]),""});m("\\bgroup","{");m("\\egroup","}");m("~","\\nobreakspace");m("\\lq","`");m("\\rq","'");m("\\aa","\\r a");m("\\AA","\\r A");m("\\textcopyright","\\html@mathml{\\textcircled{c}}{\\char`\xA9}");m("\\copyright","\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");m("\\textregistered","\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`\xAE}");m("\u212C","\\mathscr{B}");m("\u2130","\\mathscr{E}");m("\u2131","\\mathscr{F}");m("\u210B","\\mathscr{H}");m("\u2110","\\mathscr{I}");m("\u2112","\\mathscr{L}");m("\u2133","\\mathscr{M}");m("\u211B","\\mathscr{R}");m("\u212D","\\mathfrak{C}");m("\u210C","\\mathfrak{H}");m("\u2128","\\mathfrak{Z}");m("\\Bbbk","\\Bbb{k}");m("\\llap","\\mathllap{\\textrm{#1}}");m("\\rlap","\\mathrlap{\\textrm{#1}}");m("\\clap","\\mathclap{\\textrm{#1}}");m("\\mathstrut","\\vphantom{(}");m("\\underbar","\\underline{\\text{#1}}");m("\\not",'\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char"338}');m("\\neq","\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`\u2260}}");m("\\ne","\\neq");m("\u2260","\\neq");m("\\notin","\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`\u2209}}");m("\u2209","\\notin");m("\u2258","\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`\u2258}}");m("\u2259","\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`\u2258}}");m("\u225A","\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`\u225A}}");m("\u225B","\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`\u225B}}");m("\u225D","\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`\u225D}}");m("\u225E","\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`\u225E}}");m("\u225F","\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`\u225F}}");m("\u27C2","\\perp");m("\u203C","\\mathclose{!\\mkern-0.8mu!}");m("\u220C","\\notni");m("\u231C","\\ulcorner");m("\u231D","\\urcorner");m("\u231E","\\llcorner");m("\u231F","\\lrcorner");m("\xA9","\\copyright");m("\xAE","\\textregistered");m("\\ulcorner",'\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');m("\\urcorner",'\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');m("\\llcorner",'\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');m("\\lrcorner",'\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');m("\\vdots","{\\varvdots\\rule{0pt}{15pt}}");m("\u22EE","\\vdots");m("\\varGamma","\\mathit{\\Gamma}");m("\\varDelta","\\mathit{\\Delta}");m("\\varTheta","\\mathit{\\Theta}");m("\\varLambda","\\mathit{\\Lambda}");m("\\varXi","\\mathit{\\Xi}");m("\\varPi","\\mathit{\\Pi}");m("\\varSigma","\\mathit{\\Sigma}");m("\\varUpsilon","\\mathit{\\Upsilon}");m("\\varPhi","\\mathit{\\Phi}");m("\\varPsi","\\mathit{\\Psi}");m("\\varOmega","\\mathit{\\Omega}");m("\\substack","\\begin{subarray}{c}#1\\end{subarray}");m("\\colon","\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");m("\\boxed","\\fbox{$\\displaystyle{#1}$}");m("\\iff","\\DOTSB\\;\\Longleftrightarrow\\;");m("\\implies","\\DOTSB\\;\\Longrightarrow\\;");m("\\impliedby","\\DOTSB\\;\\Longleftarrow\\;");m("\\dddot","{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");m("\\ddddot","{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");var Ss={",":"\\dotsc","\\not":"\\dotsb","+":"\\dotsb","=":"\\dotsb","<":"\\dotsb",">":"\\dotsb","-":"\\dotsb","*":"\\dotsb",":":"\\dotsb","\\DOTSB":"\\dotsb","\\coprod":"\\dotsb","\\bigvee":"\\dotsb","\\bigwedge":"\\dotsb","\\biguplus":"\\dotsb","\\bigcap":"\\dotsb","\\bigcup":"\\dotsb","\\prod":"\\dotsb","\\sum":"\\dotsb","\\bigotimes":"\\dotsb","\\bigoplus":"\\dotsb","\\bigodot":"\\dotsb","\\bigsqcup":"\\dotsb","\\And":"\\dotsb","\\longrightarrow":"\\dotsb","\\Longrightarrow":"\\dotsb","\\longleftarrow":"\\dotsb","\\Longleftarrow":"\\dotsb","\\longleftrightarrow":"\\dotsb","\\Longleftrightarrow":"\\dotsb","\\mapsto":"\\dotsb","\\longmapsto":"\\dotsb","\\hookrightarrow":"\\dotsb","\\doteq":"\\dotsb","\\mathbin":"\\dotsb","\\mathrel":"\\dotsb","\\relbar":"\\dotsb","\\Relbar":"\\dotsb","\\xrightarrow":"\\dotsb","\\xleftarrow":"\\dotsb","\\DOTSI":"\\dotsi","\\int":"\\dotsi","\\oint":"\\dotsi","\\iint":"\\dotsi","\\iiint":"\\dotsi","\\iiiint":"\\dotsi","\\idotsint":"\\dotsi","\\DOTSX":"\\dotsx"},M4=new Set(["bin","rel"]);m("\\dots",function(r){var e="\\dotso",t=r.expandAfterFuture().text;return t in Ss?e=Ss[t]:(t.slice(0,4)==="\\not"||t in he.math&&M4.has(he.math[t].group))&&(e="\\dotsb"),e});var Rn={")":!0,"]":!0,"\\rbrack":!0,"\\}":!0,"\\rbrace":!0,"\\rangle":!0,"\\rceil":!0,"\\rfloor":!0,"\\rgroup":!0,"\\rmoustache":!0,"\\right":!0,"\\bigr":!0,"\\biggr":!0,"\\Bigr":!0,"\\Biggr":!0,$:!0,";":!0,".":!0,",":!0};m("\\dotso",function(r){var e=r.future().text;return e in Rn?"\\ldots\\,":"\\ldots"});m("\\dotsc",function(r){var e=r.future().text;return e in Rn&&e!==","?"\\ldots\\,":"\\ldots"});m("\\cdots",function(r){var e=r.future().text;return e in Rn?"\\@cdots\\,":"\\@cdots"});m("\\dotsb","\\cdots");m("\\dotsm","\\cdots");m("\\dotsi","\\!\\cdots");m("\\dotsx","\\ldots\\,");m("\\DOTSI","\\relax");m("\\DOTSB","\\relax");m("\\DOTSX","\\relax");m("\\tmspace","\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");m("\\,","\\tmspace+{3mu}{.1667em}");m("\\thinspace","\\,");m("\\>","\\mskip{4mu}");m("\\:","\\tmspace+{4mu}{.2222em}");m("\\medspace","\\:");m("\\;","\\tmspace+{5mu}{.2777em}");m("\\thickspace","\\;");m("\\!","\\tmspace-{3mu}{.1667em}");m("\\negthinspace","\\!");m("\\negmedspace","\\tmspace-{4mu}{.2222em}");m("\\negthickspace","\\tmspace-{5mu}{.277em}");m("\\enspace","\\kern.5em ");m("\\enskip","\\hskip.5em\\relax");m("\\quad","\\hskip1em\\relax");m("\\qquad","\\hskip2em\\relax");m("\\tag","\\@ifstar\\tag@literal\\tag@paren");m("\\tag@paren","\\tag@literal{({#1})}");m("\\tag@literal",r=>{if(r.macros.get("\\df@tag"))throw new C("Multiple \\tag");return"\\gdef\\df@tag{\\text{#1}}"});m("\\bmod","\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");m("\\pod","\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");m("\\pmod","\\pod{{\\rm mod}\\mkern6mu#1}");m("\\mod","\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");m("\\newline","\\\\\\relax");m("\\TeX","\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");var ml=O(p0["Main-Regular"][84][1]-.7*p0["Main-Regular"][65][1]);m("\\LaTeX","\\textrm{\\html@mathml{"+("L\\kern-.36em\\raisebox{"+ml+"}{\\scriptstyle A}")+"\\kern-.15em\\TeX}{LaTeX}}");m("\\KaTeX","\\textrm{\\html@mathml{"+("K\\kern-.17em\\raisebox{"+ml+"}{\\scriptstyle A}")+"\\kern-.15em\\TeX}{KaTeX}}");m("\\hspace","\\@ifstar\\@hspacer\\@hspace");m("\\@hspace","\\hskip #1\\relax");m("\\@hspacer","\\rule{0pt}{0pt}\\hskip #1\\relax");m("\\ordinarycolon",":");m("\\vcentcolon","\\mathrel{\\mathop\\ordinarycolon}");m("\\dblcolon",'\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');m("\\coloneqq",'\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');m("\\Coloneqq",'\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');m("\\coloneq",'\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');m("\\Coloneq",'\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');m("\\eqqcolon",'\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');m("\\Eqqcolon",'\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');m("\\eqcolon",'\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');m("\\Eqcolon",'\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');m("\\colonapprox",'\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');m("\\Colonapprox",'\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');m("\\colonsim",'\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');m("\\Colonsim",'\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');m("\u2237","\\dblcolon");m("\u2239","\\eqcolon");m("\u2254","\\coloneqq");m("\u2255","\\eqqcolon");m("\u2A74","\\Coloneqq");m("\\ratio","\\vcentcolon");m("\\coloncolon","\\dblcolon");m("\\colonequals","\\coloneqq");m("\\coloncolonequals","\\Coloneqq");m("\\equalscolon","\\eqqcolon");m("\\equalscoloncolon","\\Eqqcolon");m("\\colonminus","\\coloneq");m("\\coloncolonminus","\\Coloneq");m("\\minuscolon","\\eqcolon");m("\\minuscoloncolon","\\Eqcolon");m("\\coloncolonapprox","\\Colonapprox");m("\\coloncolonsim","\\Colonsim");m("\\simcolon","\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");m("\\simcoloncolon","\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");m("\\approxcolon","\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");m("\\approxcoloncolon","\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");m("\\notni","\\html@mathml{\\not\\ni}{\\mathrel{\\char`\u220C}}");m("\\limsup","\\DOTSB\\operatorname*{lim\\,sup}");m("\\liminf","\\DOTSB\\operatorname*{lim\\,inf}");m("\\injlim","\\DOTSB\\operatorname*{inj\\,lim}");m("\\projlim","\\DOTSB\\operatorname*{proj\\,lim}");m("\\varlimsup","\\DOTSB\\operatorname*{\\overline{lim}}");m("\\varliminf","\\DOTSB\\operatorname*{\\underline{lim}}");m("\\varinjlim","\\DOTSB\\operatorname*{\\underrightarrow{lim}}");m("\\varprojlim","\\DOTSB\\operatorname*{\\underleftarrow{lim}}");m("\\gvertneqq","\\html@mathml{\\@gvertneqq}{\u2269}");m("\\lvertneqq","\\html@mathml{\\@lvertneqq}{\u2268}");m("\\ngeqq","\\html@mathml{\\@ngeqq}{\u2271}");m("\\ngeqslant","\\html@mathml{\\@ngeqslant}{\u2271}");m("\\nleqq","\\html@mathml{\\@nleqq}{\u2270}");m("\\nleqslant","\\html@mathml{\\@nleqslant}{\u2270}");m("\\nshortmid","\\html@mathml{\\@nshortmid}{\u2224}");m("\\nshortparallel","\\html@mathml{\\@nshortparallel}{\u2226}");m("\\nsubseteqq","\\html@mathml{\\@nsubseteqq}{\u2288}");m("\\nsupseteqq","\\html@mathml{\\@nsupseteqq}{\u2289}");m("\\varsubsetneq","\\html@mathml{\\@varsubsetneq}{\u228A}");m("\\varsubsetneqq","\\html@mathml{\\@varsubsetneqq}{\u2ACB}");m("\\varsupsetneq","\\html@mathml{\\@varsupsetneq}{\u228B}");m("\\varsupsetneqq","\\html@mathml{\\@varsupsetneqq}{\u2ACC}");m("\\imath","\\html@mathml{\\@imath}{\u0131}");m("\\jmath","\\html@mathml{\\@jmath}{\u0237}");m("\\llbracket","\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`\u27E6}}");m("\\rrbracket","\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`\u27E7}}");m("\u27E6","\\llbracket");m("\u27E7","\\rrbracket");m("\\lBrace","\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`\u2983}}");m("\\rBrace","\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`\u2984}}");m("\u21A4","\\mapsfrom");m("\\mapsfrom","\\html@mathml{\\mathrel{\\mathreflectbox{\\mapsto}}}{\\mathrel{\\char`\u21A4}}");m("\u2983","\\lBrace");m("\u2984","\\rBrace");m("\\minuso","\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`\u29B5}}");m("\u29B5","\\minuso");m("\\darr","\\downarrow");m("\\dArr","\\Downarrow");m("\\Darr","\\Downarrow");m("\\lang","\\langle");m("\\rang","\\rangle");m("\\uarr","\\uparrow");m("\\uArr","\\Uparrow");m("\\Uarr","\\Uparrow");m("\\N","\\mathbb{N}");m("\\R","\\mathbb{R}");m("\\Z","\\mathbb{Z}");m("\\alef","\\aleph");m("\\alefsym","\\aleph");m("\\Alpha","\\mathrm{A}");m("\\Beta","\\mathrm{B}");m("\\bull","\\bullet");m("\\Chi","\\mathrm{X}");m("\\clubs","\\clubsuit");m("\\cnums","\\mathbb{C}");m("\\Complex","\\mathbb{C}");m("\\Dagger","\\ddagger");m("\\diamonds","\\diamondsuit");m("\\empty","\\emptyset");m("\\Epsilon","\\mathrm{E}");m("\\Eta","\\mathrm{H}");m("\\exist","\\exists");m("\\harr","\\leftrightarrow");m("\\hArr","\\Leftrightarrow");m("\\Harr","\\Leftrightarrow");m("\\hearts","\\heartsuit");m("\\image","\\Im");m("\\infin","\\infty");m("\\Iota","\\mathrm{I}");m("\\isin","\\in");m("\\Kappa","\\mathrm{K}");m("\\larr","\\leftarrow");m("\\lArr","\\Leftarrow");m("\\Larr","\\Leftarrow");m("\\lrarr","\\leftrightarrow");m("\\lrArr","\\Leftrightarrow");m("\\Lrarr","\\Leftrightarrow");m("\\Mu","\\mathrm{M}");m("\\natnums","\\mathbb{N}");m("\\Nu","\\mathrm{N}");m("\\Omicron","\\mathrm{O}");m("\\plusmn","\\pm");m("\\rarr","\\rightarrow");m("\\rArr","\\Rightarrow");m("\\Rarr","\\Rightarrow");m("\\real","\\Re");m("\\reals","\\mathbb{R}");m("\\Reals","\\mathbb{R}");m("\\Rho","\\mathrm{P}");m("\\sdot","\\cdot");m("\\sect","\\S");m("\\spades","\\spadesuit");m("\\sub","\\subset");m("\\sube","\\subseteq");m("\\supe","\\supseteq");m("\\Tau","\\mathrm{T}");m("\\thetasym","\\vartheta");m("\\weierp","\\wp");m("\\Zeta","\\mathrm{Z}");m("\\argmin","\\DOTSB\\operatorname*{arg\\,min}");m("\\argmax","\\DOTSB\\operatorname*{arg\\,max}");m("\\plim","\\DOTSB\\mathop{\\operatorname{plim}}\\limits");m("\\bra","\\mathinner{\\langle{#1}|}");m("\\ket","\\mathinner{|{#1}\\rangle}");m("\\braket","\\mathinner{\\langle{#1}\\rangle}");m("\\Bra","\\left\\langle#1\\right|");m("\\Ket","\\left|#1\\right\\rangle");var dl=r=>e=>{var t=e.consumeArg().tokens,a=e.consumeArg().tokens,n=e.consumeArg().tokens,i=e.consumeArg().tokens,l=e.macros.get("|"),u=e.macros.get("\\|");e.macros.beginGroup();var h=b=>k=>{r&&(k.macros.set("|",l),n.length&&k.macros.set("\\|",u));var w=b;if(!b&&n.length){var M=k.future();M.text==="|"&&(k.popToken(),w=!0)}return{tokens:w?n:a,numArgs:0}};e.macros.set("|",h(!1)),n.length&&e.macros.set("\\|",h(!0));var d=e.consumeArg().tokens,f=e.expandTokens([...i,...d,...t]);return e.macros.endGroup(),{tokens:f.reverse(),numArgs:0}};m("\\bra@ket",dl(!1));m("\\bra@set",dl(!0));m("\\Braket","\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");m("\\Set","\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");m("\\set","\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");m("\\angln","{\\angl n}");m("\\blue","\\textcolor{##6495ed}{#1}");m("\\orange","\\textcolor{##ffa500}{#1}");m("\\pink","\\textcolor{##ff00af}{#1}");m("\\red","\\textcolor{##df0030}{#1}");m("\\green","\\textcolor{##28ae7b}{#1}");m("\\gray","\\textcolor{gray}{#1}");m("\\purple","\\textcolor{##9d38bd}{#1}");m("\\blueA","\\textcolor{##ccfaff}{#1}");m("\\blueB","\\textcolor{##80f6ff}{#1}");m("\\blueC","\\textcolor{##63d9ea}{#1}");m("\\blueD","\\textcolor{##11accd}{#1}");m("\\blueE","\\textcolor{##0c7f99}{#1}");m("\\tealA","\\textcolor{##94fff5}{#1}");m("\\tealB","\\textcolor{##26edd5}{#1}");m("\\tealC","\\textcolor{##01d1c1}{#1}");m("\\tealD","\\textcolor{##01a995}{#1}");m("\\tealE","\\textcolor{##208170}{#1}");m("\\greenA","\\textcolor{##b6ffb0}{#1}");m("\\greenB","\\textcolor{##8af281}{#1}");m("\\greenC","\\textcolor{##74cf70}{#1}");m("\\greenD","\\textcolor{##1fab54}{#1}");m("\\greenE","\\textcolor{##0d923f}{#1}");m("\\goldA","\\textcolor{##ffd0a9}{#1}");m("\\goldB","\\textcolor{##ffbb71}{#1}");m("\\goldC","\\textcolor{##ff9c39}{#1}");m("\\goldD","\\textcolor{##e07d10}{#1}");m("\\goldE","\\textcolor{##a75a05}{#1}");m("\\redA","\\textcolor{##fca9a9}{#1}");m("\\redB","\\textcolor{##ff8482}{#1}");m("\\redC","\\textcolor{##f9685d}{#1}");m("\\redD","\\textcolor{##e84d39}{#1}");m("\\redE","\\textcolor{##bc2612}{#1}");m("\\maroonA","\\textcolor{##ffbde0}{#1}");m("\\maroonB","\\textcolor{##ff92c6}{#1}");m("\\maroonC","\\textcolor{##ed5fa6}{#1}");m("\\maroonD","\\textcolor{##ca337c}{#1}");m("\\maroonE","\\textcolor{##9e034e}{#1}");m("\\purpleA","\\textcolor{##ddd7ff}{#1}");m("\\purpleB","\\textcolor{##c6b9fc}{#1}");m("\\purpleC","\\textcolor{##aa87ff}{#1}");m("\\purpleD","\\textcolor{##7854ab}{#1}");m("\\purpleE","\\textcolor{##543b78}{#1}");m("\\mintA","\\textcolor{##f5f9e8}{#1}");m("\\mintB","\\textcolor{##edf2df}{#1}");m("\\mintC","\\textcolor{##e0e5cc}{#1}");m("\\grayA","\\textcolor{##f6f7f7}{#1}");m("\\grayB","\\textcolor{##f0f1f2}{#1}");m("\\grayC","\\textcolor{##e3e5e6}{#1}");m("\\grayD","\\textcolor{##d6d8da}{#1}");m("\\grayE","\\textcolor{##babec2}{#1}");m("\\grayF","\\textcolor{##888d93}{#1}");m("\\grayG","\\textcolor{##626569}{#1}");m("\\grayH","\\textcolor{##3b3e40}{#1}");m("\\grayI","\\textcolor{##21242c}{#1}");m("\\kaBlue","\\textcolor{##314453}{#1}");m("\\kaGreen","\\textcolor{##71B307}{#1}");var pl={"^":!0,_:!0,"\\limits":!0,"\\nolimits":!0},vn=class{constructor(e,t,a){this.settings=void 0,this.expansionCount=void 0,this.lexer=void 0,this.macros=void 0,this.stack=void 0,this.mode=void 0,this.settings=t,this.expansionCount=0,this.feed(e),this.macros=new fn(z4,t.macros),this.mode=a,this.stack=[]}feed(e){this.lexer=new qr(e,this.settings)}switchMode(e){this.mode=e}beginGroup(){this.macros.beginGroup()}endGroup(){this.macros.endGroup()}endGroups(){this.macros.endGroups()}future(){return this.stack.length===0&&this.pushToken(this.lexer.lex()),this.stack[this.stack.length-1]}popToken(){return this.future(),this.stack.pop()}pushToken(e){this.stack.push(e)}pushTokens(e){this.stack.push(...e)}scanArgument(e){var t,a,n;if(e){if(this.consumeSpaces(),this.future().text!=="[")return null;t=this.popToken();var i=this.consumeArg(["]"]);n=i.tokens,a=i.end}else{var l=this.consumeArg();n=l.tokens,t=l.start,a=l.end}return this.pushToken(new Xe("EOF",a.loc)),this.pushTokens(n),new Xe("",He.range(t,a))}consumeSpaces(){for(;;){var e=this.future();if(e.text===" ")this.stack.pop();else break}}consumeArg(e){var t=[],a=e&&e.length>0;a||this.consumeSpaces();var n=this.future(),i,l=0,u=0;do{if(i=this.popToken(),t.push(i),i.text==="{")++l;else if(i.text==="}"){if(--l,l===-1)throw new C("Extra }",i)}else if(i.text==="EOF")throw new C("Unexpected end of input in a macro argument, expected '"+(e&&a?e[u]:"}")+"'",i);if(e&&a)if((l===0||l===1&&e[u]==="{")&&i.text===e[u]){if(++u,u===e.length){t.splice(-u,u);break}}else u=0}while(l!==0||a);return n.text==="{"&&t[t.length-1].text==="}"&&(t.pop(),t.shift()),t.reverse(),{tokens:t,start:n,end:i}}consumeArgs(e,t){if(t){if(t.length!==e+1)throw new C("The length of delimiters doesn't match the number of args!");for(var a=t[0],n=0;n<a.length;n++){var i=this.popToken();if(a[n]!==i.text)throw new C("Use of the macro doesn't match its definition",i)}}for(var l=[],u=0;u<e;u++)l.push(this.consumeArg(t&&t[u+1]).tokens);return l}countExpansion(e){if(this.expansionCount+=e,this.expansionCount>this.settings.maxExpand)throw new C("Too many expansions: infinite loop or need to increase maxExpand setting")}expandOnce(e){var t=this.popToken(),a=t.text,n=t.noexpand?null:this._getExpansion(a);if(n==null||e&&n.unexpandable){if(e&&n==null&&a[0]==="\\"&&!this.isDefined(a))throw new C("Undefined control sequence: "+a);return this.pushToken(t),!1}this.countExpansion(1);var i=n.tokens,l=this.consumeArgs(n.numArgs,n.delimiters);if(n.numArgs){i=i.slice();for(var u=i.length-1;u>=0;--u){var h=i[u];if(h.text==="#"){if(u===0)throw new C("Incomplete placeholder at end of macro body",h);if(h=i[--u],h.text==="#")i.splice(u+1,1);else if(/^[1-9]$/.test(h.text))i.splice(u,2,...l[+h.text-1]);else throw new C("Not a valid argument number",h)}}}return this.pushTokens(i),i.length}expandAfterFuture(){return this.expandOnce(),this.future()}expandNextToken(){for(;;)if(this.expandOnce()===!1){var e=this.stack.pop();return e.treatAsRelax&&(e.text="\\relax"),e}}expandMacro(e){return this.macros.has(e)?this.expandTokens([new Xe(e)]):void 0}expandTokens(e){var t=[],a=this.stack.length;for(this.pushTokens(e);this.stack.length>a;)if(this.expandOnce(!0)===!1){var n=this.stack.pop();n.treatAsRelax&&(n.noexpand=!1,n.treatAsRelax=!1),t.push(n)}return this.countExpansion(t.length),t}expandMacroAsText(e){var t=this.expandMacro(e);return t&&t.map(a=>a.text).join("")}_getExpansion(e){var t=this.macros.get(e);if(t==null)return t;if(e.length===1){var a=this.lexer.catcodes[e];if(a!=null&&a!==13)return}var n=typeof t=="function"?t(this):t;if(typeof n=="string"){var i=0;if(n.includes("#"))for(var l=n.replace(/##/g,"");l.includes("#"+(i+1));)++i;for(var u=new qr(n,this.settings),h=[],d=u.lex();d.text!=="EOF";)h.push(d),d=u.lex();h.reverse();var f={tokens:h,numArgs:i};return f}return n}isDefined(e){return this.macros.has(e)||Object.prototype.hasOwnProperty.call(L0,e)||Object.prototype.hasOwnProperty.call(he.math,e)||Object.prototype.hasOwnProperty.call(he.text,e)||Object.prototype.hasOwnProperty.call(pl,e)}isExpandable(e){var t=this.macros.get(e);return t!=null?typeof t=="string"||typeof t=="function"||!t.unexpandable:Object.prototype.hasOwnProperty.call(L0,e)&&!L0[e].primitive}},Ts=/^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/,Dr=Object.freeze({"\u208A":"+","\u208B":"-","\u208C":"=","\u208D":"(","\u208E":")","\u2080":"0","\u2081":"1","\u2082":"2","\u2083":"3","\u2084":"4","\u2085":"5","\u2086":"6","\u2087":"7","\u2088":"8","\u2089":"9","\u2090":"a","\u2091":"e","\u2095":"h","\u1D62":"i","\u2C7C":"j","\u2096":"k","\u2097":"l","\u2098":"m","\u2099":"n","\u2092":"o","\u209A":"p","\u1D63":"r","\u209B":"s","\u209C":"t","\u1D64":"u","\u1D65":"v","\u2093":"x","\u1D66":"\u03B2","\u1D67":"\u03B3","\u1D68":"\u03C1","\u1D69":"\u03D5","\u1D6A":"\u03C7","\u207A":"+","\u207B":"-","\u207C":"=","\u207D":"(","\u207E":")","\u2070":"0","\xB9":"1","\xB2":"2","\xB3":"3","\u2074":"4","\u2075":"5","\u2076":"6","\u2077":"7","\u2078":"8","\u2079":"9","\u1D2C":"A","\u1D2E":"B","\u1D30":"D","\u1D31":"E","\u1D33":"G","\u1D34":"H","\u1D35":"I","\u1D36":"J","\u1D37":"K","\u1D38":"L","\u1D39":"M","\u1D3A":"N","\u1D3C":"O","\u1D3E":"P","\u1D3F":"R","\u1D40":"T","\u1D41":"U","\u2C7D":"V","\u1D42":"W","\u1D43":"a","\u1D47":"b","\u1D9C":"c","\u1D48":"d","\u1D49":"e","\u1DA0":"f","\u1D4D":"g",\u02B0:"h","\u2071":"i",\u02B2:"j","\u1D4F":"k",\u02E1:"l","\u1D50":"m",\u207F:"n","\u1D52":"o","\u1D56":"p",\u02B3:"r",\u02E2:"s","\u1D57":"t","\u1D58":"u","\u1D5B":"v",\u02B7:"w",\u02E3:"x",\u02B8:"y","\u1DBB":"z","\u1D5D":"\u03B2","\u1D5E":"\u03B3","\u1D5F":"\u03B4","\u1D60":"\u03D5","\u1D61":"\u03C7","\u1DBF":"\u03B8"}),Ya={"\u0301":{text:"\\'",math:"\\acute"},"\u0300":{text:"\\`",math:"\\grave"},"\u0308":{text:'\\"',math:"\\ddot"},"\u0303":{text:"\\~",math:"\\tilde"},"\u0304":{text:"\\=",math:"\\bar"},"\u0306":{text:"\\u",math:"\\breve"},"\u030C":{text:"\\v",math:"\\check"},"\u0302":{text:"\\^",math:"\\hat"},"\u0307":{text:"\\.",math:"\\dot"},"\u030A":{text:"\\r",math:"\\mathring"},"\u030B":{text:"\\H"},"\u0327":{text:"\\c"}},As={\u00E1:"a\u0301",\u00E0:"a\u0300",\u00E4:"a\u0308",\u01DF:"a\u0308\u0304",\u00E3:"a\u0303",\u0101:"a\u0304",\u0103:"a\u0306",\u1EAF:"a\u0306\u0301",\u1EB1:"a\u0306\u0300",\u1EB5:"a\u0306\u0303",\u01CE:"a\u030C",\u00E2:"a\u0302",\u1EA5:"a\u0302\u0301",\u1EA7:"a\u0302\u0300",\u1EAB:"a\u0302\u0303",\u0227:"a\u0307",\u01E1:"a\u0307\u0304",\u00E5:"a\u030A",\u01FB:"a\u030A\u0301",\u1E03:"b\u0307",\u0107:"c\u0301",\u1E09:"c\u0327\u0301",\u010D:"c\u030C",\u0109:"c\u0302",\u010B:"c\u0307",\u00E7:"c\u0327",\u010F:"d\u030C",\u1E0B:"d\u0307",\u1E11:"d\u0327",\u00E9:"e\u0301",\u00E8:"e\u0300",\u00EB:"e\u0308",\u1EBD:"e\u0303",\u0113:"e\u0304",\u1E17:"e\u0304\u0301",\u1E15:"e\u0304\u0300",\u0115:"e\u0306",\u1E1D:"e\u0327\u0306",\u011B:"e\u030C",\u00EA:"e\u0302",\u1EBF:"e\u0302\u0301",\u1EC1:"e\u0302\u0300",\u1EC5:"e\u0302\u0303",\u0117:"e\u0307",\u0229:"e\u0327",\u1E1F:"f\u0307",\u01F5:"g\u0301",\u1E21:"g\u0304",\u011F:"g\u0306",\u01E7:"g\u030C",\u011D:"g\u0302",\u0121:"g\u0307",\u0123:"g\u0327",\u1E27:"h\u0308",\u021F:"h\u030C",\u0125:"h\u0302",\u1E23:"h\u0307",\u1E29:"h\u0327",\u00ED:"i\u0301",\u00EC:"i\u0300",\u00EF:"i\u0308",\u1E2F:"i\u0308\u0301",\u0129:"i\u0303",\u012B:"i\u0304",\u012D:"i\u0306",\u01D0:"i\u030C",\u00EE:"i\u0302",\u01F0:"j\u030C",\u0135:"j\u0302",\u1E31:"k\u0301",\u01E9:"k\u030C",\u0137:"k\u0327",\u013A:"l\u0301",\u013E:"l\u030C",\u013C:"l\u0327",\u1E3F:"m\u0301",\u1E41:"m\u0307",\u0144:"n\u0301",\u01F9:"n\u0300",\u00F1:"n\u0303",\u0148:"n\u030C",\u1E45:"n\u0307",\u0146:"n\u0327",\u00F3:"o\u0301",\u00F2:"o\u0300",\u00F6:"o\u0308",\u022B:"o\u0308\u0304",\u00F5:"o\u0303",\u1E4D:"o\u0303\u0301",\u1E4F:"o\u0303\u0308",\u022D:"o\u0303\u0304",\u014D:"o\u0304",\u1E53:"o\u0304\u0301",\u1E51:"o\u0304\u0300",\u014F:"o\u0306",\u01D2:"o\u030C",\u00F4:"o\u0302",\u1ED1:"o\u0302\u0301",\u1ED3:"o\u0302\u0300",\u1ED7:"o\u0302\u0303",\u022F:"o\u0307",\u0231:"o\u0307\u0304",\u0151:"o\u030B",\u1E55:"p\u0301",\u1E57:"p\u0307",\u0155:"r\u0301",\u0159:"r\u030C",\u1E59:"r\u0307",\u0157:"r\u0327",\u015B:"s\u0301",\u1E65:"s\u0301\u0307",\u0161:"s\u030C",\u1E67:"s\u030C\u0307",\u015D:"s\u0302",\u1E61:"s\u0307",\u015F:"s\u0327",\u1E97:"t\u0308",\u0165:"t\u030C",\u1E6B:"t\u0307",\u0163:"t\u0327",\u00FA:"u\u0301",\u00F9:"u\u0300",\u00FC:"u\u0308",\u01D8:"u\u0308\u0301",\u01DC:"u\u0308\u0300",\u01D6:"u\u0308\u0304",\u01DA:"u\u0308\u030C",\u0169:"u\u0303",\u1E79:"u\u0303\u0301",\u016B:"u\u0304",\u1E7B:"u\u0304\u0308",\u016D:"u\u0306",\u01D4:"u\u030C",\u00FB:"u\u0302",\u016F:"u\u030A",\u0171:"u\u030B",\u1E7D:"v\u0303",\u1E83:"w\u0301",\u1E81:"w\u0300",\u1E85:"w\u0308",\u0175:"w\u0302",\u1E87:"w\u0307",\u1E98:"w\u030A",\u1E8D:"x\u0308",\u1E8B:"x\u0307",\u00FD:"y\u0301",\u1EF3:"y\u0300",\u00FF:"y\u0308",\u1EF9:"y\u0303",\u0233:"y\u0304",\u0177:"y\u0302",\u1E8F:"y\u0307",\u1E99:"y\u030A",\u017A:"z\u0301",\u017E:"z\u030C",\u1E91:"z\u0302",\u017C:"z\u0307",\u00C1:"A\u0301",\u00C0:"A\u0300",\u00C4:"A\u0308",\u01DE:"A\u0308\u0304",\u00C3:"A\u0303",\u0100:"A\u0304",\u0102:"A\u0306",\u1EAE:"A\u0306\u0301",\u1EB0:"A\u0306\u0300",\u1EB4:"A\u0306\u0303",\u01CD:"A\u030C",\u00C2:"A\u0302",\u1EA4:"A\u0302\u0301",\u1EA6:"A\u0302\u0300",\u1EAA:"A\u0302\u0303",\u0226:"A\u0307",\u01E0:"A\u0307\u0304",\u00C5:"A\u030A",\u01FA:"A\u030A\u0301",\u1E02:"B\u0307",\u0106:"C\u0301",\u1E08:"C\u0327\u0301",\u010C:"C\u030C",\u0108:"C\u0302",\u010A:"C\u0307",\u00C7:"C\u0327",\u010E:"D\u030C",\u1E0A:"D\u0307",\u1E10:"D\u0327",\u00C9:"E\u0301",\u00C8:"E\u0300",\u00CB:"E\u0308",\u1EBC:"E\u0303",\u0112:"E\u0304",\u1E16:"E\u0304\u0301",\u1E14:"E\u0304\u0300",\u0114:"E\u0306",\u1E1C:"E\u0327\u0306",\u011A:"E\u030C",\u00CA:"E\u0302",\u1EBE:"E\u0302\u0301",\u1EC0:"E\u0302\u0300",\u1EC4:"E\u0302\u0303",\u0116:"E\u0307",\u0228:"E\u0327",\u1E1E:"F\u0307",\u01F4:"G\u0301",\u1E20:"G\u0304",\u011E:"G\u0306",\u01E6:"G\u030C",\u011C:"G\u0302",\u0120:"G\u0307",\u0122:"G\u0327",\u1E26:"H\u0308",\u021E:"H\u030C",\u0124:"H\u0302",\u1E22:"H\u0307",\u1E28:"H\u0327",\u00CD:"I\u0301",\u00CC:"I\u0300",\u00CF:"I\u0308",\u1E2E:"I\u0308\u0301",\u0128:"I\u0303",\u012A:"I\u0304",\u012C:"I\u0306",\u01CF:"I\u030C",\u00CE:"I\u0302",\u0130:"I\u0307",\u0134:"J\u0302",\u1E30:"K\u0301",\u01E8:"K\u030C",\u0136:"K\u0327",\u0139:"L\u0301",\u013D:"L\u030C",\u013B:"L\u0327",\u1E3E:"M\u0301",\u1E40:"M\u0307",\u0143:"N\u0301",\u01F8:"N\u0300",\u00D1:"N\u0303",\u0147:"N\u030C",\u1E44:"N\u0307",\u0145:"N\u0327",\u00D3:"O\u0301",\u00D2:"O\u0300",\u00D6:"O\u0308",\u022A:"O\u0308\u0304",\u00D5:"O\u0303",\u1E4C:"O\u0303\u0301",\u1E4E:"O\u0303\u0308",\u022C:"O\u0303\u0304",\u014C:"O\u0304",\u1E52:"O\u0304\u0301",\u1E50:"O\u0304\u0300",\u014E:"O\u0306",\u01D1:"O\u030C",\u00D4:"O\u0302",\u1ED0:"O\u0302\u0301",\u1ED2:"O\u0302\u0300",\u1ED6:"O\u0302\u0303",\u022E:"O\u0307",\u0230:"O\u0307\u0304",\u0150:"O\u030B",\u1E54:"P\u0301",\u1E56:"P\u0307",\u0154:"R\u0301",\u0158:"R\u030C",\u1E58:"R\u0307",\u0156:"R\u0327",\u015A:"S\u0301",\u1E64:"S\u0301\u0307",\u0160:"S\u030C",\u1E66:"S\u030C\u0307",\u015C:"S\u0302",\u1E60:"S\u0307",\u015E:"S\u0327",\u0164:"T\u030C",\u1E6A:"T\u0307",\u0162:"T\u0327",\u00DA:"U\u0301",\u00D9:"U\u0300",\u00DC:"U\u0308",\u01D7:"U\u0308\u0301",\u01DB:"U\u0308\u0300",\u01D5:"U\u0308\u0304",\u01D9:"U\u0308\u030C",\u0168:"U\u0303",\u1E78:"U\u0303\u0301",\u016A:"U\u0304",\u1E7A:"U\u0304\u0308",\u016C:"U\u0306",\u01D3:"U\u030C",\u00DB:"U\u0302",\u016E:"U\u030A",\u0170:"U\u030B",\u1E7C:"V\u0303",\u1E82:"W\u0301",\u1E80:"W\u0300",\u1E84:"W\u0308",\u0174:"W\u0302",\u1E86:"W\u0307",\u1E8C:"X\u0308",\u1E8A:"X\u0307",\u00DD:"Y\u0301",\u1EF2:"Y\u0300",\u0178:"Y\u0308",\u1EF8:"Y\u0303",\u0232:"Y\u0304",\u0176:"Y\u0302",\u1E8E:"Y\u0307",\u0179:"Z\u0301",\u017D:"Z\u030C",\u1E90:"Z\u0302",\u017B:"Z\u0307",\u03AC:"\u03B1\u0301",\u1F70:"\u03B1\u0300",\u1FB1:"\u03B1\u0304",\u1FB0:"\u03B1\u0306",\u03AD:"\u03B5\u0301",\u1F72:"\u03B5\u0300",\u03AE:"\u03B7\u0301",\u1F74:"\u03B7\u0300",\u03AF:"\u03B9\u0301",\u1F76:"\u03B9\u0300",\u03CA:"\u03B9\u0308",\u0390:"\u03B9\u0308\u0301",\u1FD2:"\u03B9\u0308\u0300",\u1FD1:"\u03B9\u0304",\u1FD0:"\u03B9\u0306",\u03CC:"\u03BF\u0301",\u1F78:"\u03BF\u0300",\u03CD:"\u03C5\u0301",\u1F7A:"\u03C5\u0300",\u03CB:"\u03C5\u0308",\u03B0:"\u03C5\u0308\u0301",\u1FE2:"\u03C5\u0308\u0300",\u1FE1:"\u03C5\u0304",\u1FE0:"\u03C5\u0306",\u03CE:"\u03C9\u0301",\u1F7C:"\u03C9\u0300",\u038E:"\u03A5\u0301",\u1FEA:"\u03A5\u0300",\u03AB:"\u03A5\u0308",\u1FE9:"\u03A5\u0304",\u1FE8:"\u03A5\u0306",\u038F:"\u03A9\u0301",\u1FFA:"\u03A9\u0300"},Pr=class r{constructor(e,t){this.mode=void 0,this.gullet=void 0,this.settings=void 0,this.leftrightDepth=void 0,this.nextToken=void 0,this.mode="math",this.gullet=new vn(e,t,this.mode),this.settings=t,this.leftrightDepth=0,this.nextToken=null}expect(e,t){if(t===void 0&&(t=!0),this.fetch().text!==e)throw new C("Expected '"+e+"', got '"+this.fetch().text+"'",this.fetch());t&&this.consume()}consume(){this.nextToken=null}fetch(){return this.nextToken==null&&(this.nextToken=this.gullet.expandNextToken()),this.nextToken}switchMode(e){this.mode=e,this.gullet.switchMode(e)}parse(){this.settings.globalGroup||this.gullet.beginGroup(),this.settings.colorIsTextColor&&this.gullet.macros.set("\\color","\\textcolor");try{var e=this.parseExpression(!1);return this.expect("EOF"),this.settings.globalGroup||this.gullet.endGroup(),e}finally{this.gullet.endGroups()}}subparse(e){var t=this.nextToken;this.consume(),this.gullet.pushToken(new Xe("}")),this.gullet.pushTokens(e);var a=this.parseExpression(!1);return this.expect("}"),this.nextToken=t,a}parseExpression(e,t){for(var a=[];;){this.mode==="math"&&this.consumeSpaces();var n=this.fetch();if(r.endOfExpression.has(n.text)||t&&n.text===t||e&&L0[n.text]&&L0[n.text].infix)break;var i=this.parseAtom(t);if(i){if(i.type==="internal")continue}else break;a.push(i)}return this.mode==="text"&&this.formLigatures(a),this.handleInfixNodes(a)}handleInfixNodes(e){for(var t=-1,a,n=0;n<e.length;n++){var i=e[n];if(i.type==="infix"){if(t!==-1)throw new C("only one infix operator per group",i.token);t=n,a=i.replaceWith}}if(t!==-1&&a){var l,u,h=e.slice(0,t),d=e.slice(t+1);h.length===1&&h[0].type==="ordgroup"?l=h[0]:l={type:"ordgroup",mode:this.mode,body:h},d.length===1&&d[0].type==="ordgroup"?u=d[0]:u={type:"ordgroup",mode:this.mode,body:d};var f;return a==="\\\\abovefrac"?f=this.callFunction(a,[l,e[t],u],[]):f=this.callFunction(a,[l,u],[]),[f]}else return e}handleSupSubscript(e){var t=this.fetch(),a=t.text;this.consume(),this.consumeSpaces();var n;do{var i;n=this.parseGroup(e)}while(((i=n)==null?void 0:i.type)==="internal");if(!n)throw new C("Expected group after '"+a+"'",t);return n}formatUnsupportedCmd(e){for(var t=[],a=0;a<e.length;a++)t.push({type:"textord",mode:"text",text:e[a]});var n={type:"text",mode:this.mode,body:t},i={type:"color",mode:this.mode,color:this.settings.errorColor,body:[n]};return i}parseAtom(e){var t=this.parseGroup("atom",e);if(t?.type==="internal"||this.mode==="text")return t;for(var a,n;;){this.consumeSpaces();var i=this.fetch();if(i.text==="\\limits"||i.text==="\\nolimits"){if(t&&t.type==="op")t.limits=i.text==="\\limits",t.alwaysHandleSupSub=!0;else if(t&&t.type==="operatorname")t.alwaysHandleSupSub&&(t.limits=i.text==="\\limits");else throw new C("Limit controls must follow a math operator",i);this.consume()}else if(i.text==="^"){if(a)throw new C("Double superscript",i);a=this.handleSupSubscript("superscript")}else if(i.text==="_"){if(n)throw new C("Double subscript",i);n=this.handleSupSubscript("subscript")}else if(i.text==="'"){if(a)throw new C("Double superscript",i);var l={type:"textord",mode:this.mode,text:"\\prime"},u=[l];for(this.consume();this.fetch().text==="'";)u.push(l),this.consume();this.fetch().text==="^"&&u.push(this.handleSupSubscript("superscript")),a={type:"ordgroup",mode:this.mode,body:u}}else if(Dr[i.text]){var h=Ts.test(i.text),d=[];for(d.push(new Xe(Dr[i.text])),this.consume();;){var f=this.fetch().text;if(!Dr[f]||Ts.test(f)!==h)break;d.unshift(new Xe(Dr[f])),this.consume()}var b=this.subparse(d);h?n={type:"ordgroup",mode:"math",body:b}:a={type:"ordgroup",mode:"math",body:b}}else break}return a&&n?{type:"supsub",mode:this.mode,base:t,sup:a,sub:n}:a?{type:"supsub",mode:this.mode,base:t,sup:a}:n?{type:"supsub",mode:this.mode,base:t,sub:n}:t}parseFunction(e,t){var a=this.fetch(),n=a.text,i=L0[n];if(!i)return null;if(this.consume(),t&&t!=="atom"&&!i.allowedInArgument)throw new C("Got function '"+n+"' with no arguments"+(t?" as "+t:""),a);if(this.mode==="text"&&!i.allowedInText)throw new C("Can't use function '"+n+"' in text mode",a);if(this.mode==="math"&&i.allowedInMath===!1)throw new C("Can't use function '"+n+"' in math mode",a);var l=this.parseArguments(n,i),u=l.args,h=l.optArgs;return this.callFunction(n,u,h,a,e)}callFunction(e,t,a,n,i){var l={funcName:e,parser:this,token:n,breakOnTokenText:i},u=L0[e];if(u&&u.handler)return u.handler(l,t,a);throw new C("No function handler for "+e)}parseArguments(e,t){var a,n=(a=t.numOptionalArgs)!=null?a:0,i=t.numArgs+n;if(i===0)return{args:[],optArgs:[]};for(var l=[],u=[],h=0;h<i;h++){var d,f=(d=t.argTypes)==null?void 0:d[h],b=h<n;("primitive"in t&&t.primitive&&f==null||t.type==="sqrt"&&h===1&&u[0]==null)&&(f="primitive");var k=this.parseGroupOfType("argument to '"+e+"'",f,b);if(b)u.push(k);else if(k!=null)l.push(k);else throw new C("Null argument, please report this as a bug")}return{args:l,optArgs:u}}parseGroupOfType(e,t,a){switch(t){case"color":return this.parseColorGroup(a);case"size":return this.parseSizeGroup(a);case"url":return this.parseUrlGroup(a);case"math":case"text":return this.parseArgumentGroup(a,t);case"hbox":{var n=this.parseArgumentGroup(a,"text");return n!=null?{type:"styling",mode:n.mode,body:[n],style:"text",resetFont:!0}:null}case"raw":{var i=this.parseStringGroup(a);return i!=null?{type:"raw",mode:"text",string:i.text}:null}case"primitive":{if(a)throw new C("A primitive argument cannot be optional");var l=this.parseGroup(e);if(l==null)throw new C("Expected group as "+e,this.fetch());return l}case"original":case void 0:return this.parseArgumentGroup(a);default:throw new C("Unknown group type as "+e,this.fetch())}}consumeSpaces(){for(;this.fetch().text===" ";)this.consume()}parseStringGroup(e){var t=this.gullet.scanArgument(e);if(t==null)return null;for(var a="",n;(n=this.fetch()).text!=="EOF";)a+=n.text,this.consume();return this.consume(),t.text=a,t}parseRegexGroup(e,t){for(var a=this.fetch(),n=a,i="",l;(l=this.fetch()).text!=="EOF"&&e.test(i+l.text);)n=l,i+=n.text,this.consume();if(i==="")throw new C("Invalid "+t+": '"+a.text+"'",a);return a.range(n,i)}parseColorGroup(e){var t=this.parseStringGroup(e);if(t==null)return null;var a=/^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(t.text);if(!a)throw new C("Invalid color: '"+t.text+"'",t);var n=a[0];return/^[0-9a-f]{6}$/i.test(n)&&(n="#"+n),{type:"color-token",mode:this.mode,color:n}}parseSizeGroup(e){var t,a=!1;if(this.gullet.consumeSpaces(),!e&&this.gullet.future().text!=="{"?t=this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/,"size"):t=this.parseStringGroup(e),!t)return null;!e&&t.text.length===0&&(t.text="0pt",a=!0);var n=/([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t.text);if(!n)throw new C("Invalid size: '"+t.text+"'",t);var i={number:+(n[1]+n[2]),unit:n[3]};if(!Ms(i))throw new C("Invalid unit: '"+i.unit+"'",t);return{type:"size",mode:this.mode,value:i,isBlank:a}}parseUrlGroup(e){this.gullet.lexer.setCatcode("%",13),this.gullet.lexer.setCatcode("~",12);var t=this.parseStringGroup(e);if(this.gullet.lexer.setCatcode("%",14),this.gullet.lexer.setCatcode("~",13),t==null)return null;var a=t.text.replace(/\\([#$%&~_^{}])/g,"$1");return{type:"url",mode:this.mode,url:a}}parseArgumentGroup(e,t){var a=this.gullet.scanArgument(e);if(a==null)return null;var n=this.mode;t&&this.switchMode(t),this.gullet.beginGroup();var i=this.parseExpression(!1,"EOF");this.expect("EOF"),this.gullet.endGroup();var l={type:"ordgroup",mode:this.mode,loc:a.loc,body:i};return t&&this.switchMode(n),l}parseGroup(e,t){var a=this.fetch(),n=a.text,i;if(n==="{"||n==="\\begingroup"){this.consume();var l=n==="{"?"}":"\\endgroup";this.gullet.beginGroup();var u=this.parseExpression(!1,l),h=this.fetch();this.expect(l),this.gullet.endGroup(),i={type:"ordgroup",mode:this.mode,loc:He.range(a,h),body:u,semisimple:n==="\\begingroup"||void 0}}else if(i=this.parseFunction(t,e)||this.parseSymbol(),i==null&&n[0]==="\\"&&!Object.prototype.hasOwnProperty.call(pl,n)){if(this.settings.throwOnError)throw new C("Undefined control sequence: "+n,a);i=this.formatUnsupportedCmd(n),this.consume()}return i}formLigatures(e){for(var t=e.length-1,a=0;a<t;++a){var n=e[a];if(n.type==="textord"){var i=n.text,l=e[a+1];if(!(!l||l.type!=="textord")){if(i==="-"&&l.text==="-"){var u=e[a+2];a+1<t&&u&&u.type==="textord"&&u.text==="-"?(e.splice(a,3,{type:"textord",mode:"text",loc:He.range(n,u),text:"---"}),t-=2):(e.splice(a,2,{type:"textord",mode:"text",loc:He.range(n,l),text:"--"}),t-=1)}(i==="'"||i==="`")&&l.text===i&&(e.splice(a,2,{type:"textord",mode:"text",loc:He.range(n,l),text:i+i}),t-=1)}}}}parseSymbol(){var e=this.fetch(),t=e.text;if(/^\\verb[^a-zA-Z]/.test(t)){this.consume();var a=t.slice(5),n=a.charAt(0)==="*";if(n&&(a=a.slice(1)),a.length<2||a.charAt(0)!==a.slice(-1))throw new C(`\\verb assertion failed --
                    please report what input caused this bug`);return a=a.slice(1,-1),{type:"verb",mode:"text",body:a,star:n}}Object.prototype.hasOwnProperty.call(As,t[0])&&!he[this.mode][t[0]]&&(this.settings.strict&&this.mode==="math"&&this.settings.reportNonstrict("unicodeTextInMathMode",'Accented Unicode text character "'+t[0]+'" used in math mode',e),t=As[t[0]]+t.slice(1));var i=T4.exec(t);i&&(t=t.substring(0,i.index),t==="i"?t="\u0131":t==="j"&&(t="\u0237"));var l;if(he[this.mode][t]){this.settings.strict&&this.mode==="math"&&Ja.includes(t)&&this.settings.reportNonstrict("unicodeTextInMathMode",'Latin-1/Unicode text character "'+t[0]+'" used in math mode',e);var u=he[this.mode][t].group,h=He.range(e),d;Nu(u)?d={type:"atom",mode:this.mode,family:u,loc:h,text:t}:d={type:u,mode:this.mode,loc:h,text:t},l=d}else if(t.charCodeAt(0)>=128)this.settings.strict&&(zs(t.charCodeAt(0))?this.mode==="math"&&this.settings.reportNonstrict("unicodeTextInMathMode",'Unicode text character "'+t[0]+'" used in math mode',e):this.settings.reportNonstrict("unknownSymbol",'Unrecognized Unicode character "'+t[0]+'"'+(" ("+t.charCodeAt(0)+")"),e)),l={type:"textord",mode:"text",loc:He.range(e),text:t};else return null;if(this.consume(),i)for(var f=0;f<i[0].length;f++){var b=i[0][f];if(!Ya[b])throw new C("Unknown accent ' "+b+"'",e);var k=Ya[b][this.mode]||Ya[b].text;if(!k)throw new C("Accent "+b+" unsupported in "+this.mode+" mode",e);l={type:"accent",mode:this.mode,loc:He.range(e),label:k,isStretchy:!1,isShifty:!0,base:l}}return l}};Pr.endOfExpression=new Set(["}","\\endgroup","\\end","\\right","&"]);var Dn=function(e,t){if(!(typeof e=="string"||e instanceof String))throw new TypeError("KaTeX can only parse string typed expression");var a=new Pr(e,t);delete a.gullet.macros.current["\\df@tag"];var n=a.parse();if(delete a.gullet.macros.current["\\current@color"],delete a.gullet.macros.current["\\color"],a.gullet.macros.get("\\df@tag")){if(!t.displayMode)throw new C("\\tag works only in display equations");n=[{type:"tag",mode:"text",body:n,tag:a.subparse([new Xe("\\df@tag")])}]}return n},fl=function(e,t,a){t.textContent="";var n=Cn(e,a).toNode();t.appendChild(n)};typeof document<"u"&&document.compatMode!=="CSS1Compat"&&(typeof console<"u"&&console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."),fl=function(){throw new C("KaTeX doesn't work in quirks mode.")});var E4=function(e,t){var a=Cn(e,t).toMarkup();return a},R4=function(e,t){var a=new Gt(t);return Dn(e,a)},vl=function(e,t,a){if(a.throwOnError||!(e instanceof C))throw e;var n=R(["katex-error"],[new Ne(t)]);return n.setAttribute("title",e.toString()),n.setAttribute("style","color:"+a.errorColor),n},Cn=function(e,t){var a=new Gt(t);try{var n=Dn(e,a);return Au(n,e,a)}catch(i){return vl(i,e,a)}},D4=function(e,t){var a=new Gt(t);try{var n=Dn(e,a);return zu(n,e,a)}catch(i){return vl(i,e,a)}},C4="0.18.10",I4={Span:F0,Anchor:xt,SymbolNode:Ne,SvgNode:o0,PathNode:f0,LineNode:Wt},gl={version:C4,render:fl,renderToString:E4,ParseError:C,SETTINGS_SCHEMA:Xa,__parse:R4,__renderToDomTree:Cn,__renderToHTMLTree:D4,__setFontMetrics:su,__defineSymbol:s,__defineFunction:L,__defineMacro:m,__domTree:I4};var O4=/^(\${1,2})(?!\$)((?:\\.|[^\\\n])*?(?:\\.|[^\\\n\$]))\1(?=[\s?!\.,:？！。，：]|$)/,B4=/^(\${1,2})(?!\$)((?:\\.|[^\\\n])*?(?:\\.|[^\\\n\$]))\1/,N4=/^(\${1,2})\n((?:\\[^]|[^\\])+?)\n\1(?:\n|$)/;function yl(r={}){return{extensions:[L4(r,bl(r,!1)),q4(r,bl(r,!0))]}}function bl(r,e){return t=>gl.renderToString(t.text,{...r,displayMode:t.displayMode})+(e?`
`:"")}function L4(r,e){let t=r&&r.nonStandard,a=t?B4:O4;return{name:"inlineKatex",level:"inline",start(n){let i,l=n;for(;l;){if(i=l.indexOf("$"),i===-1)return;if((t?i>-1:i===0||l.charAt(i-1)===" ")&&l.substring(i).match(a))return i;l=l.substring(i+1).replace(/^\$+/,"")}},tokenizer(n,i){let l=n.match(a);if(l)return{type:"inlineKatex",raw:l[0],text:l[2].trim(),displayMode:l[1].length===2}},renderer:e}}function q4(r,e){return{name:"blockKatex",level:"block",tokenizer(t,a){let n=t.match(N4);if(n)return{type:"blockKatex",raw:n[0],text:n[2].trim(),displayMode:n[1].length===2}},renderer:e}}var P4=$i(window);ne.use(yl({output:"mathml",throwOnError:!1,trust:!1,strict:"ignore",nonStandard:!0}));function F4(r){return P4.sanitize(ne.parse(String(r),{async:!1,gfm:!0}),{FORBID_TAGS:["style","script","iframe","form","input","button","textarea","select","object","embed","link","meta"],FORBID_ATTR:["style","srcdoc","id","name"],SANITIZE_NAMED_PROPS:!0})}return jl(_4);})();
  var ExhlojPinyin=(()=>{var m=Object.defineProperty;var H=Object.getOwnPropertyDescriptor;var V=Object.getOwnPropertyNames;var G=Object.prototype.hasOwnProperty;var J=(n,g)=>{for(var i in g)m(n,i,{get:g[i],enumerable:!0})},K=(n,g,i,h)=>{if(g&&typeof g=="object"||typeof g=="function")for(let u of V(g))!G.call(n,u)&&u!==i&&m(n,u,{get:()=>g[u],enumerable:!(h=H(g,u))||h.enumerable});return n};var Q=n=>K(m({},"__esModule",{value:!0}),n);var tn={};J(tn,{polyphonic:()=>b});var k=/^[\uD800-\uDBFF]$/,w=/^[\uDC00-\uDFFF]$/,y=/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,a;(function(n){n[n.Unknown=1e-13]="Unknown",n[n.Rule=1e-12]="Rule",n[n.DICT=2e-8]="DICT",n[n.Surname=1]="Surname",n[n.Custom=1]="Custom"})(a||(a={}));var T={Normal:1,Surname:10,Custom:100};function D(n){var g;return n.length-(((g=n.match(y))===null||g===void 0?void 0:g.length)||0)}function P(n){if(y.lastIndex=0,!y.test(n))return n.split("");let g=[],i=0;for(;i<n.length;){let h=n[i];k.test(h)&&w.test(n[i+1])?(g.push(n.substring(i,i+2)),i+=2):(g.push(h),i+=1)}return g}var l=class{constructor(){this.NumberDICT=[],this.StringDICT=new Map}get(g){if(g.length>1)return this.StringDICT.get(g);{let i=g.charCodeAt(0);return this.NumberDICT[i]}}set(g,i){if(g.length>1)this.StringDICT.set(g,i);else{let h=g.charCodeAt(0);this.NumberDICT[h]=i}}clear(){this.NumberDICT=[],this.StringDICT.clear()}};var v=["zh","ch","sh","z","c","s","b","p","m","f","d","t","n","l","g","k","h","j","q","x","r","y","w",""],I=["j","q","x"],N=["u\u0101n","u\xE1n","u\u01CEn","u\xE0n","uan","u\u0113","u\xE9","u\u011B","u\xE8","ue","\u016Bn","\xFAn","\u01D4n","\xF9n","un","\u016B","\xFA","\u01D4","\xF9","u"],_={u\u0101n:"\xFC\u0101n",u\u00E1n:"\xFC\xE1n",u\u01CEn:"\xFC\u01CEn",u\u00E0n:"\xFC\xE0n",uan:"\xFCan",u\u0113:"\xFC\u0113",u\u00E9:"\xFC\xE9",u\u011B:"\xFC\u011B",u\u00E8:"\xFC\xE8",ue:"\xFCe",\u016Bn:"\u01D6n",\u00FAn:"\u01D8n",\u01D4n:"\u01DAn",\u00F9n:"\u01DCn",un:"\xFCn",\u016B:"\u01D6",\u00FA:"\u01D8",\u01D4:"\u01DA",\u00F9:"\u01DC",u:"\xFC"},C=["ia","ian","iang","iao","ie","iu","iong","ua","uai","uan","uang","ue","ui","uo","\xFCan","\xFCe","van","ve"],Z={\u4E00:"y\xEC",\u4E8C:"\xE8r",\u4E09:"s\u0101n",\u56DB:"s\xEC",\u4E94:"w\u01D4",\u516D:"li\xF9",\u4E03:"q\u012B",\u516B:"b\u0101",\u4E5D:"ji\u01D4",\u5341:"sh\xED",\u767E:"b\u01CEi",\u5343:"qi\u0101n",\u4E07:"w\xE0n",\u4EBF:"y\xEC",\u5355:"d\u0101n",\u4E24:"li\u01CEng",\u53CC:"shu\u0101ng",\u591A:"du\u014D",\u51E0:"j\u01D0",\u5341\u4E00:"sh\xED y\u012B",\u96F6\u4E00:"l\xEDng y\u012B",\u7B2C\u4E00:"d\xEC y\u012B",\u4E00\u5341:"y\u012B sh\xED",\u4E00\u5341\u4E00:"y\u012B sh\xED y\u012B"},F={\u91CD:"ch\xF3ng",\u884C:"h\xE1ng",\u6597:"d\u01D2u",\u66F4:"g\u0113ng"};function X(){let n={\u96F6\u4E00:"l\xEDng y\u012B","\u3007\u4E00":"l\xEDng y\u012B",\u5341\u4E00:"sh\xED y\u012B",\u4E00\u5341:"y\u012B sh\xED",\u7B2C\u4E00:"d\xEC y\u012B",\u4E00\u5341\u4E00:"y\u012B sh\xED y\u012B"};for(let g in Z)for(let i in F){let h=`${g}${i}`,u=`${Z[g]} ${F[i]}`;n[h]=u}return n}var S=X(),zn=Object.keys(S).map(n=>({zh:n,pinyin:S[n],probability:1e-12,length:D(n),priority:T.Normal,dict:Symbol("rule")})),L={\u4E0D:{b\u00FA:[4]},\u4E00:{y\u00ED:[4],y\u00EC:[1,2,3]}};var Y=Object.keys(L);var O={"b\u01CEng p\xE1ng p\u0101ng":["\u8180"],l\u00EDng:["\u3007","\u4F36","\u51CC","\u5222","\u56F9","\u577D","\u590C","\u59C8","\u5A48","\u5B41","\u5CBA","\u5F7E","\u6395","\u6624","\u670E","\u67C3","\u68C2","\u6AFA","\u6B1E","\u6CE0","\u6DE9","\u6FAA","\u7075","\u71EF","\u7227","\u72D1","\u73B2","\u740C","\u74F4","\u768A","\u7831","\u797E","\u79E2","\u7ADB","\u7B2D","\u7D37","\u7DBE","\u7EEB","\u7F90","\u7F9A","\u7FCE","\u8046","\u8232","\u82D3","\u83F1","\u84E4","\u8506","\u8576","\u86C9","\u8851","\u88EC","\u8A45","\u8DC9","\u8EE8","\u8F18","\u9143","\u91BD","\u9234","\u9302","\u94C3","\u959D","\u9675","\u96F6","\u970A","\u9717","\u971B","\u971D","\u9748","\u99D6","\u9B7F","\u9BEA","\u9CAE","\u9D12","\u9E30","\u9E77","\u9EA2","\u9F61","\u9F62","\u9F84","\u9F97","\u3944"],y\u012B:["\u4E00","\u4E4A","\u4F0A","\u4F9D","\u533B","\u541A","\u54BF","\u566B","\u58F1","\u58F9","\u5901","\u5ADB","\u5B04","\u5F0C","\u63D6","\u648E","\u6AB9","\u6BC9","\u6D22","\u6E0F","\u6F2A","\u747F","\u7569","\u794E","\u7995","\u7A26","\u7E44","\u86DC","\u8864","\u8B69","\u8FB7","\u90FC","\u91AB","\u92A5","\u94F1","\u9DD6","\u9E65","\u9EDF","\u9EF3"],"d\u012Bng zh\u0113ng":["\u4E01"],"k\u01CEo qi\u01CEo y\xFA":["\u4E02"],q\u012B:["\u4E03","\u501B","\u50DB","\u51C4","\u5601","\u5884","\u5A38","\u60BD","\u617C","\u617D","\u621A","\u637F","\u67D2","\u6864","\u687C","\u68F2","\u69BF","\u6B3A","\u6C8F","\u6DD2","\u6F06","\u7D2A","\u7DC0","\u840B","\u8904","\u8AC6","\u8FC9","\u90EA","\u93DA","\u970B","\u9B4C","\u9D88"],sh\u00E0ng:["\u4E04","\u5C19","\u5C1A","\u6066","\u7DD4","\u7EF1"],xi\u00E0:["\u4E05","\u4E0B","\u4E64","\u5737","\u590F","\u5913","\u61D7","\u68BA","\u759C","\u7771","\u7F45","\u93BC","\u93EC"],h\u01CEn:["\u4E06","\u558A","\u6D6B","\u7F55","\u8C43","\u360E"],"w\xE0n m\xF2":["\u4E07"],zh\u00E0ng:["\u4E08","\u4ED7","\u5887","\u5D82","\u5E10","\u5E33","\u5E5B","\u6259","\u6756","\u6DB1","\u75EE","\u762C","\u7634","\u7795","\u7C80","\u80C0","\u8139","\u8CEC","\u8D26","\u969C"],s\u0101n:["\u4E09","\u5381","\u53C1","\u5F0E","\u6BF5","\u6BF6","\u6BFF","\u7299","\u9B16"],"sh\xE0ng sh\u01CEng shang":["\u4E0A"],"q\xED j\u012B":["\u4E0C","\u5176","\u5947"],"b\xF9 f\u01D2u":["\u4E0D"],"y\u01D4 y\xF9 y\xFA":["\u4E0E"],mi\u01CEn:["\u4E0F","\u506D","\u514D","\u5195","\u52C9","\u52D4","\u5595","\u5A29","\u6110","\u6C45","\u6C94","\u6E4E","\u774C","\u7DEC","\u7F05","\u817C","\u8442","\u9766","\u9BB8","\u{29F83}"],g\u00E0i:["\u4E10","\u4E62","\u5303","\u5304","\u6224","\u6982","\u69E9","\u69EA","\u6E89","\u6F11","\u74C2","\u8462","\u9223","\u9499","\u{2CBBF}"],ch\u01D2u:["\u4E11","\u4E12","\u4FB4","\u541C","\u677D","\u7785","\u77C1","\u919C","\u9B57"],zhu\u0101n:["\u4E13","\u53C0","\u5AE5","\u5C02","\u5C08","\u747C","\u750E","\u7816","\u78D7","\u78DA","\u87E4","\u8AEF","\u911F","\u9853","\u989B","\u9C44","\u43DD"],"qi\u011B j\u016B":["\u4E14"],p\u012B:["\u4E15","\u4F13","\u4F3E","\u567C","\u576F","\u5CAF","\u61B5","\u6279","\u62AB","\u708B","\u72C9","\u72D3","\u7812","\u78C7","\u7914","\u7915","\u79DB","\u79E0","\u801A","\u8C7E","\u90B3","\u921A","\u925F","\u9294","\u9303","\u930D","\u9739","\u99D3","\u9AEC","\u9B7E","\u{2CCF5}"],sh\u00EC:["\u4E16","\u4E17","\u4E8A","\u4E8B","\u4ED5","\u4F8D","\u519F","\u52BF","\u52E2","\u534B","\u5469","\u55DC","\u566C","\u58EB","\u596D","\u5B15","\u5BA4","\u5E02","\u5F0F","\u5F11","\u5F12","\u6040","\u6043","\u623A","\u62ED","\u63D3","\u662F","\u6630","\u67BE","\u67FF","\u683B","\u6FA8","\u70D2","\u7176","\u7702","\u770E","\u7721","\u7757","\u793A","\u793B","\u7B6E","\u7C2D","\u8210","\u8213","\u896B","\u8996","\u89C6","\u89E2","\u8A66","\u8A93","\u8AE1","\u8B1A","\u8BD5","\u8C25","\u8CB0","\u8D33","\u8EFE","\u8F7C","\u901D","\u907E","\u91C8","\u91CA","\u91CB","\u9230","\u9243","\u927D","\u94C8","\u98FE","\u9919","\u991D","\u9970","\u9C18","\u43E1","\u{2C90A}"],qi\u016B:["\u4E18","\u4E20","\u5775","\u5A9D","\u6058","\u6077","\u6978","\u79CB","\u79CC","\u7A50","\u7BCD","\u7DE7","\u8429","\u8612","\u86AF","\u8775","\u87D7","\u8824","\u8DA5","\u90B1","\u97A6","\u97A7","\u9C0C","\u9C0D","\u9CC5","\u9D96","\u9E59","\u9F9D"],b\u01D0ng:["\u4E19","\u5C5B","\u6032","\u62A6","\u661E","\u663A","\u67C4","\u68C5","\u70B3","\u7980","\u79C9","\u7A1F","\u82EA","\u86C3","\u90B4","\u9235","\u9643","\u9786","\u9905","\u9920","\u997C"],y\u00E8:["\u4E1A","\u4EB1","\u50F7","\u58B7","\u591C","\u5DAA","\u5DAB","\u62B4","\u6359","\u64DB","\u64EA","\u64EB","\u6654","\u66C4","\u66C5","\u66D7","\u66F3","\u66F5","\u67BC","\u67BD","\u696D","\u6D02","\u6DB2","\u6FB2","\u70E8","\u71C1","\u7217","\u748D","\u76A3","\u77B1","\u77B8","\u790F","\u814B","\u8449","\u8B01","\u8C12","\u90BA","\u9134","\u9371","\u9437","\u9765","\u9768","\u9801","\u9875","\u9923","\u9941","\u998C","\u9A5C","\u9D7A","\u9E08"],c\u00F3ng:["\u4E1B","\u4ECE","\u53E2","\u5A43","\u5B6E","\u5F93","\u5F94","\u5F96","\u60B0","\u6A37","\u6B09","\u6DD9","\u7047","\u721C","\u742E","\u85C2","\u8AB4","\u8CE8","\u8CE9","\u931D"],d\u014Dng:["\u4E1C","\u5032","\u51AC","\u549A","\u57EC","\u5CBD","\u5D2C","\u5F9A","\u6638","\u6771","\u6C21","\u6C2D","\u6DB7","\u7B17","\u82F3","\u83C4","\u8740","\u9B97","\u9BDF","\u9D87","\u9DAB","\u9E2B","\u9F15","\u{2C7FD}"],s\u012B:["\u4E1D","\u4FEC","\u51D8","\u53AE","\u53F8","\u549D","\u5636","\u565D","\u5AA4","\u5EDD","\u6056","\u6495","\u65AF","\u6952","\u6CC0","\u6F8C","\u71CD","\u7997","\u79A0","\u79C1","\u7CF9","\u7D72","\u7DE6","\u7E9F","\u7F0C","\u7F73","\u856C","\u8652","\u86F3","\u8724","\u8784","\u87D6","\u87F4","\u9270","\u92AF","\u9376","\u9401","\u9536","\u98B8","\u98D4","\u9A26","\u9DE5","\u9E36","\u9F36","\u37C3"],ch\u00E9ng:["\u4E1E","\u5448","\u57CE","\u57D5","\u5818","\u584D","\u5856","\u5BAC","\u5CF8","\u60E9","\u61F2","\u6210","\u627F","\u6330","\u6381","\u63E8","\u67A8","\u68D6","\u6A59","\u6A99","\u6D06","\u6E97","\u6F82","\u73F5","\u73F9","\u757B","\u7A0B","\u7A9A","\u7B6C","\u7D7E","\u812D","\u837F","\u8AA0","\u8BDA","\u90D5","\u9172","\u92EE","\u94D6","\u9A2C","\u9BCE"],di\u016B:["\u4E1F","\u4E22","\u92A9","\u94E5"],li\u01CEng:["\u4E21","\u4E24","\u5169","\u5521","\u5562","\u639A","\u7DC9","\u813C","\u873D","\u88F2","\u9B49","\u9B4E","\u{2C72F}"],y\u01D2u:["\u4E23","\u5363","\u53CB","\u6884","\u6E75","\u7256","\u7989","\u7F91","\u8048","\u82C3","\u83A0","\u870F","\u9149","\u92AA","\u94D5","\u9EDD"],y\u00E1n:["\u4E25","\u53B3","\u5571","\u55A6","\u56B4","\u5869","\u58DB","\u58E7","\u598D","\u59F8","\u5A2B","\u5A2E","\u5CA9","\u5D52","\u5D53","\u5DCC","\u5DD6","\u5DD7","\u5EF6","\u63C5","\u6616","\u694C","\u6A90","\u6AE9","\u6B15","\u6CBF","\u708E","\u708F","\u72FF","\u7402","\u76D0","\u789E","\u7B75","\u7C37","\u839A","\u8505","\u8664","\u8712","\u8A00","\u8A01","\u8A2E","\u8A7D","\u8BA0","\u90D4","\u9586","\u95BB","\u95EB","\u960E","\u984F","\u9854","\u989C","\u9E7D","\u9EA3","\u{2B127}"],b\u00ECng:["\u4E26","\u4F75","\u5002","\u50A1","\u57AA","\u6452","\u6824","\u75C5","\u7A89","\u7ADD","\u8A81","\u9750","\u9BA9"],"s\xE0ng s\u0101ng":["\u4E27"],g\u01D4n:["\u4E28","\u60C3","\u6EDA","\u6EFE","\u78D9","\u7DC4","\u7EF2","\u84D8","\u8509","\u886E","\u889E","\u8F25","\u8F8A","\u9B8C","\u9BC0","\u9CA7"],ji\u016B:["\u4E29","\u52FC","\u557E","\u63EA","\u63EB","\u673B","\u7A76","\u7CFE","\u7EA0","\u841B","\u8D73","\u9604","\u9B0F","\u9B2E","\u9CE9","\u9E20"],"g\xE8 g\u011B":["\u4E2A","\u500B","\u5404"],y\u0101:["\u4E2B","\u5727","\u5B72","\u5E98","\u62BC","\u6792","\u6860","\u690F","\u930F","\u941A","\u9D09","\u9D28","\u9D76","\u9E26","\u9E2D"],p\u00E1n:["\u4E2C","\u5ABB","\u5E4B","\u69C3","\u6D00","\u700A","\u723F","\u76D8","\u76E4","\u78D0","\u7E0F","\u84B0","\u87E0","\u8E52","\u8E63","\u939C","\u97B6"],"zh\u014Dng zh\xF2ng":["\u4E2D"],j\u01D0:["\u4E2E","\u5980","\u5DF1","\u621F","\u6324","\u638E","\u64A0","\u64E0","\u6A76","\u6CF2","\u72B1","\u810A","\u866E","\u87E3","\u9B62","\u9C7E","\u9E82"],ji\u00E8:["\u4E2F","\u4ECB","\u501F","\u5536","\u583A","\u5C46","\u5C4A","\u5C95","\u5E8E","\u5FA3","\u6212","\u6950","\u7297","\u73A0","\u743E","\u754C","\u754D","\u75A5","\u780E","\u86A7","\u86F6","\u8878","\u892F","\u8AA1","\u8BEB","\u9385","\u9AB1","\u9B6A"],f\u0113ng:["\u4E30","\u4EF9","\u5051","\u50FC","\u51E8","\u51EC","\u51EE","\u59A6","\u5BF7","\u5C01","\u5CEF","\u5CF0","\u5D36","\u67AB","\u6953","\u6A92","\u6CA3","\u6CA8","\u6E22","\u7043","\u70FD","\u728E","\u7326","\u7412","\u75AF","\u760B","\u76FD","\u781C","\u78B8","\u7BC8","\u8634","\u8702","\u882D","\u8C50","\u9137","\u9146","\u92D2","\u93BD","\u93E0","\u950B","\u973B","\u974A","\u98CC","\u9EB7"],"gu\xE0n ku\xE0ng":["\u4E31"],chu\u00E0n:["\u4E32","\u6C4C","\u7394","\u8CD7","\u91E7","\u948F"],ch\u01CEn:["\u4E33","\u4EA7","\u5181","\u5277","\u56C5","\u5D7C","\u65F5","\u6D50","\u6EFB","\u705B","\u7522","\u7523","\u7C05","\u8487","\u8546","\u8AC2","\u8B42","\u8B87","\u8C04","\u93DF","\u94F2","\u95B3","\u95E1","\u9610","\u9AA3","\u{2C2A4}"],l\u00EDn:["\u4E34","\u51A7","\u58E3","\u5D0A","\u5D99","\u65B4","\u667D","\u66BD","\u6797","\u6F7E","\u7036","\u71D0","\u7433","\u7498","\u77B5","\u7884","\u78F7","\u7CA6","\u7CBC","\u7E57","\u7FF7","\u81E8","\u8F54","\u8F9A","\u9074","\u90BB","\u9130","\u93FB","\u963E","\u96A3","\u9716","\u9A4E","\u9C57","\u9CDE","\u9E90","\u9E9F","\u{2CD0A}","\u{2CB78}"],zhu\u00F3:["\u4E35","\u5285","\u5353","\u5544","\u5734","\u59B0","\u5A3A","\u64AF","\u64C6","\u64E2","\u65AB","\u65AE","\u65B1","\u65B2","\u65B5","\u666B","\u6913","\u6D4A","\u6D5E","\u6FC1","\u707C","\u70F5","\u7438","\u787A","\u799A","\u7AA1","\u7C57","\u7C71","\u7F6C","\u8301","\u8817","\u883F","\u8AC1","\u8AD1","\u8B36","\u8BFC","\u914C","\u9432","\u956F","\u9D6B","\u9DDF","\u44EC","\u{2CE26}"],zh\u01D4:["\u4E36","\u4E3B","\u52AF","\u5631","\u56D1","\u5B94","\u5E3E","\u62C4","\u6E1A","\u6FD0","\u7151","\u716E","\u71DD","\u77A9","\u77DA","\u7F5C","\u8A5D","\u967C","\u9E00","\u9E88","\u{2C8DE}"],b\u0101:["\u4E37","\u4EC8","\u516B","\u53ED","\u54F5","\u593F","\u5C9C","\u5DF4","\u634C","\u6733","\u7390","\u75A4","\u7B06","\u7C91","\u7F93","\u82AD","\u8686","\u8C5D","\u91DF"],w\u00E1n:["\u4E38","\u5213","\u5B8C","\u5C8F","\u628F","\u6356","\u6C4D","\u70F7","\u73A9","\u7413","\u7B02","\u7D08","\u7EA8","\u7FEB","\u8284","\u8CA6","\u9811","\u987D"],d\u0101n:["\u4E39","\u52EF","\u5330","\u5358","\u5989","\u5A85","\u6B9A","\u6BAB","\u7514","\u7708","\u7803","\u7BAA","\u7C1E","\u803C","\u803D","\u8043","\u8078","\u891D","\u894C","\u8EAD","\u90F8","\u9132","\u9156","\u9815"],"w\xE8i w\xE9i":["\u4E3A"],"j\u01D0ng d\u01CEn":["\u4E3C"],"l\xEC l\xED":["\u4E3D"],j\u01D4:["\u4E3E","\u5F06","\u6319","\u64E7","\u6907","\u6989","\u6998","\u6AF8","\u6B05","\u77E9","\u7B65","\u8065","\u8209","\u8392","\u849F","\u8977","\u8E3D","\u9F5F","\u9F83"],pi\u011B:["\u4E3F","\u82E4","\u9405","\u{2CB6F}"],f\u00FA:["\u4E40","\u4F0F","\u4FD8","\u51EB","\u521C","\u5310","\u5488","\u54F9","\u5798","\u5B5A","\u5CAA","\u5DFF","\u5E17","\u5E45","\u5E5E","\u5F17","\u5F7F","\u602B","\u6276","\u67EB","\u683F","\u6874","\u6C1F","\u6CED","\u6D6E","\u6DAA","\u6F93","\u70A5","\u73B8","\u7536","\u7549","\u7641","\u7953","\u798F","\u7A2A","\u7B26","\u7B99","\u7D31","\u7D3C","\u7D65","\u7D8D","\u7EC2","\u7ECB","\u7F58","\u7F66","\u7FC7","\u8240","\u8299","\u82A3","\u82FB","\u8300","\u832F","\u83D4","\u844D","\u8659","\u86A8","\u8709","\u8760","\u889A","\u88B1","\u8946","\u8965","\u8AE8","\u8C67","\u8E3E","\u8F3B","\u8F90","\u90DB","\u9258","\u925C","\u97CD","\u97E8","\u98AB","\u9AF4","\u9B84","\u9BB2","\u9CE7","\u9CEC","\u9D14","\u9D69","\u9EFB"],"y\xED j\xED":["\u4E41"],y\u00EC:["\u4E42","\u4E49","\u4E84","\u4EA6","\u4EBF","\u4F07","\u4F3F","\u4F7E","\u4FCB","\u5104","\u517F","\u5208","\u5293","\u52AE","\u52DA","\u52E9","\u5307","\u5453","\u546D","\u5479","\u5508","\u56C8","\u571B","\u5744","\u57BC","\u57F8","\u5955","\u5AD5","\u5B11","\u5BF1","\u5C79","\u5CC4","\u5DA7","\u5E1F","\u5E20","\u5E46","\u5ED9","\u5F02","\u5F08","\u5F0B","\u5F79","\u5FC6","\u6008","\u603F","\u6092","\u610F","\u61B6","\u61CC","\u61FF","\u6291","\u6339","\u6561","\u6613","\u6679","\u66C0","\u66CE","\u6759","\u678D","\u68ED","\u698F","\u69F8","\u6A8D","\u6B5D","\u6B94","\u6BAA","\u6BB9","\u6BC5","\u6D42","\u6D65","\u6D73","\u6E59","\u6EA2","\u6F69","\u6FBA","\u7037","\u7088","\u7132","\u71A0","\u71A4","\u71BC","\u71DA","\u71E1","\u71F1","\u7348","\u73B4","\u7570","\u75AB","\u75EC","\u7617","\u761E","\u7631","\u7654","\u76CA","\u7796","\u7A53","\u7AE9","\u7BD2","\u7E0A","\u7E76","\u7E79","\u7ECE","\u7F22","\u7FA9","\u7FBF","\u7FCA","\u7FCC","\u7FF3","\u7FFC","\u8034","\u8084","\u808A","\u8189","\u81C6","\u8257","\u827A","\u8285","\u82C5","\u841F","\u84FA","\u858F","\u85D9","\u85DD","\u8619","\u8649","\u8734","\u87A0","\u886A","\u88A3","\u88D4","\u88DB","\u8939","\u897C","\u8A32","\u8A33","\u8A4D","\u8A63","\u8ABC","\u8B6F","\u8B70","\u8B9B","\u8BAE","\u8BD1","\u8BE3","\u8C0A","\u8C59","\u8C5B","\u8C77","\u8C96","\u8D00","\u8DC7","\u8F76","\u9038","\u9091","\u9113","\u91B7","\u91F4","\u9220","\u93B0","\u943F","\u9552","\u9571","\u9623","\u96BF","\u972C","\u9950","\u99C5","\u9A5B","\u9A7F","\u9AAE","\u9BA8","\u9D82","\u9D83","\u9D8D","\u9DC1","\u9DCA","\u9DE7","\u9DFE","\u9E03","\u9E5D","\u9E62","\u9ED3","\u9F78","\u{2CB29}","\u344A","\u{2B137}","\u{2C7C1}"],n\u01CEi:["\u4E43","\u5037","\u5976","\u5B2D","\u5EFC","\u6C16","\u7593","\u827F","\u8FFA","\u91E2"],w\u01D4:["\u4E44","\u4E94","\u4EF5","\u4F0D","\u4FAE","\u5035","\u511B","\u5348","\u554E","\u59A9","\u5A2C","\u5AF5","\u5E91","\u5EE1","\u5FE4","\u6003","\u61AE","\u6440","\u6B66","\u6F55","\u7193","\u727E","\u739D","\u73F7","\u7466","\u7512","\u7894","\u821E","\u8E8C","\u8FD5","\u901C","\u965A","\u9D61","\u9E49","\u{23C98}"],ji\u01D4:["\u4E45","\u4E46","\u4E5D","\u4E63","\u597A","\u6766","\u6C63","\u7078","\u7396","\u7D24","\u820F","\u9152","\u9579","\u97ED","\u97EE"],"tu\u014D zh\xE9":["\u4E47","\u6754","\u99B2"],"me m\xF3 ma y\u0101o":["\u4E48"],zh\u012B:["\u4E4B","\u5001","\u536E","\u5DF5","\u6418","\u652F","\u6800","\u6894","\u6925","\u69B0","\u6C41","\u6CDC","\u75B7","\u7957","\u796C","\u79D3","\u7A19","\u7D95","\u80A2","\u80D1","\u80DD","\u8102","\u829D","\u8635","\u8718","\u887C","\u96BB","\u9CF7","\u9D32","\u9F05","\u{26B5C}"],"w\u016B w\xF9":["\u4E4C"],zh\u00E0:["\u4E4D","\u54A4","\u5BB1","\u643E","\u69A8","\u6EA0","\u75C4","\u86B1","\u8A50","\u8BC8","\u91A1","\u9705","\u40CE"],h\u016B:["\u4E4E","\u4E6F","\u5322","\u532B","\u547C","\u553F","\u5611","\u5780","\u5BE3","\u5E60","\u5FFD","\u60DA","\u6612","\u6B51","\u6CD8","\u6DF4","\u6EF9","\u70C0","\u82F8","\u864D","\u8656","\u8B3C","\u8EE4","\u8F77","\u96D0"],f\u00E1:["\u4E4F","\u4F10","\u50A0","\u577A","\u57A1","\u58A2","\u59C2","\u6830","\u6D4C","\u7782","\u7B29","\u7B4F","\u7F5A","\u7F70","\u7F78","\u85C5","\u95A5","\u9600"],"l\xE8 yu\xE8 y\xE0o l\xE0o":["\u4E50","\u6A02"],y\u00EDn:["\u4E51","\u541F","\u5656","\u569A","\u5701","\u57A0","\u5924","\u5A6C","\u5BC5","\u5CFE","\u5D1F","\u5D2F","\u6AAD","\u6BA5","\u6CFF","\u6DEB","\u6EDB","\u70CE","\u72BE","\u72FA","\u748C","\u784D","\u7892","\u8376","\u8529","\u8A14","\u8A1A","\u8A21","\u8ABE","\u911E","\u921D","\u9280","\u94F6","\u972A","\u9DE3","\u9F66"],p\u012Bng:["\u4E52","\u4FDC","\u5A09","\u6D84","\u7539","\u782F","\u8060","\u8275","\u9829"],p\u0101ng:["\u4E53","\u6EC2","\u80EE","\u8196","\u96F1","\u9736"],qi\u00E1o:["\u4E54","\u4FA8","\u50D1","\u5AF6","\u6194","\u6865","\u69D7","\u6A35","\u6A4B","\u6AF5","\u729E","\u77A7","\u785A","\u7904","\u834D","\u835E","\u854E","\u85EE","\u8B59","\u8DAB","\u9408","\u9792","\u97BD","\u9866"],h\u01D4:["\u4E55","\u7425","\u8400","\u864E","\u865D","\u933F","\u9BF1"],gu\u0101i:["\u4E56"],"ch\xE9ng sh\xE8ng":["\u4E57","\u4E58","\u5A0D"],y\u01D0:["\u4E59","\u4E5B","\u4EE5","\u501A","\u506F","\u5B1F","\u5D3A","\u5DF2","\u5EA1","\u6246","\u653A","\u657C","\u65D1","\u65D6","\u6AA5","\u77E3","\u7912","\u7B16","\u8223","\u8264","\u82E1","\u82E2","\u8681","\u8798","\u87FB","\u88FF","\u8E26","\u8F22","\u8F59","\u9018","\u914F","\u91D4","\u9218","\u926F","\u9487","\u9857","\u9CE6","\u9F6E","\u{2B5AE}","\u{2CE88}"],"h\xE1o y\u01D0":["\u4E5A"],"ni\xE8 mi\u0113":["\u4E5C"],q\u01D0:["\u4E5E","\u4F01","\u542F","\u5518","\u5553","\u5554","\u555F","\u5A4D","\u5C7A","\u675E","\u68E8","\u7398","\u76C0","\u7DBA","\u7EEE","\u8291","\u8AEC","\u8D77","\u9094","\u95D9"],y\u011B:["\u4E5F","\u51B6","\u5622","\u57DC","\u58C4","\u6F1C","\u91CE"],x\u00ED:["\u4E60","\u55BA","\u5AB3","\u5D8D","\u5E2D","\u693A","\u6A84","\u6F1D","\u7FD2","\u84C6","\u88AD","\u8972","\u89A1","\u89CB","\u8B35","\u8D98","\u90CB","\u93B4","\u96B0","\u972B","\u98C1","\u9A31","\u9A3D","\u9A68","\u9C3C","\u9CDB","\u{20164}","\u{2B62C}"],xi\u0101ng:["\u4E61","\u53A2","\u5EC2","\u5FC0","\u697F","\u6B00","\u6E58","\u74D6","\u7A25","\u7BB1","\u7DD7","\u7F03","\u81B7","\u8297","\u842B","\u8459","\u858C","\u8944","\u90F7","\u9109","\u910A","\u9115","\u9472","\u9576","\u9999","\u9A64","\u9AA7","\u9C5C","\u9E98","\u{2C64B}"],sh\u016B:["\u4E66","\u500F","\u5010","\u5135","\u53D4","\u59DD","\u5C17","\u6292","\u6393","\u6445","\u6504","\u66F8","\u67A2","\u68B3","\u6A1E","\u6B8A","\u6BB3","\u6BF9","\u6BFA","\u6DD1","\u702D","\u7102","\u758E","\u758F","\u7D13","\u7D80","\u7EBE","\u8212","\u83FD","\u852C","\u8E08","\u8ED7","\u8F38","\u8F93","\u9103","\u964E","\u9B9B","\u9D68"],d\u01D2u:["\u4E67","\u6296","\u6793","\u86AA","\u9204","\u9627","\u9661"],sh\u01D0:["\u4E68","\u4F7F","\u5158","\u53F2","\u59CB","\u5BA9","\u5C4E","\u6981","\u77E2","\u7B36","\u8C55","\u9242","\u99DB","\u9A76"],j\u012B:["\u4E69","\u50DF","\u51FB","\u5209","\u520F","\u525E","\u53FD","\u5527","\u559E","\u55D8","\u5630","\u573E","\u57FA","\u58BC","\u59EC","\u5C50","\u5D46","\u5D47","\u6483","\u64CA","\u671E","\u673A","\u6785","\u6A2D","\u6A5F","\u6BC4","\u6FC0","\u7284","\u7391","\u74A3","\u7578","\u757F","\u766A","\u77F6","\u78EF","\u79EF","\u7A4D","\u7B04","\u7B53","\u7B95","\u7C0A","\u7DC1","\u7F81","\u7F87","\u7F88","\u802D","\u808C","\u82A8","\u8640","\u8989","\u898A","\u8B4F","\u8B64","\u8BA5","\u8CEB","\u8CF7","\u8D4D","\u8DFB","\u8E11","\u8E8B","\u8EB8","\u9288","\u9324","\u9416","\u9447","\u9459","\u96AE","\u96DE","\u97BF","\u97F2","\u98E2","\u9951","\u9965","\u9B55","\u9CEE","\u9D8F","\u9DBA","\u9DC4","\u9E04","\u9E21","\u9F4E","\u9F4F","\u9F51","\u{2CBC0}","\u{2B4EF}","\u{2B4F9}","\u{2B300}"],n\u00E1ng:["\u4E6A","\u56A2","\u6B1C","\u8830","\u9962"],ji\u0101:["\u4E6B","\u4F73","\u50A2","\u52A0","\u5609","\u62B8","\u67B7","\u689C","\u6BE0","\u6CC7","\u6D43","\u6D79","\u728C","\u7333","\u73C8","\u75C2","\u7B33","\u7CD8","\u801E","\u8175","\u846D","\u8888","\u8C6D","\u8C91","\u8DCF","\u8FE6","\u926B","\u93B5","\u9553","\u9D10","\u9E9A","\u{2C0A9}"],j\u00F9:["\u4E6C","\u5028","\u5036","\u5177","\u5267","\u5287","\u52EE","\u57E7","\u57FE","\u58C9","\u59D6","\u5C66","\u5C68","\u5CA0","\u5DE8","\u5DEA","\u6007","\u60E7","\u6133","\u61C5","\u61FC","\u62D2","\u62E0","\u661B","\u6B6B","\u6D30","\u6FBD","\u70AC","\u70E5","\u728B","\u79EC","\u7AAD","\u7AB6","\u7C34","\u7C94","\u801F","\u805A","\u8661","\u86B7","\u8A4E","\u8BB5","\u8C66","\u8DDD","\u8E1E","\u8E86","\u907D","\u90AD","\u91B5","\u9245","\u943B","\u949C","\u98B6","\u98D3","\u99CF","\u9B94"],sh\u00ED:["\u4E6D","\u5341","\u57D8","\u5852","\u59FC","\u5B9E","\u5B9F","\u5BD4","\u5BE6","\u5CD5","\u5D75","\u65F6","\u65F9","\u6642","\u69AF","\u6E5C","\u6EA1","\u70BB","\u794F","\u7ACD","\u8680","\u8755","\u8FBB","\u9048","\u9250","\u98E0","\u9963","\u9B96","\u9C23","\u9CA5","\u9F2B","\u9F2D"],m\u01CEo:["\u4E6E","\u5187","\u536F","\u5CC1","\u623C","\u6634","\u6CD6","\u7B37","\u84E9","\u925A","\u94C6"],m\u01CEi:["\u4E70","\u562A","\u836C","\u8552","\u8CB7","\u9DF6"],lu\u00E0n:["\u4E71","\u4E82","\u91E0"],r\u01D4:["\u4E73","\u64E9","\u6C5D","\u8097","\u8FB1","\u910F"],xu\u00E9:["\u4E74","\u5B66","\u5B78","\u5CC3","\u5DA8","\u6588","\u6CF6","\u6FA9","\u71E2","\u7A74","\u8313","\u8895","\u8E05","\u9DFD","\u9E34"],y\u01CEn:["\u4DAE","\u4E75","\u4FE8","\u5043","\u513C","\u5156","\u5157","\u53A3","\u53B4","\u565E","\u5B4D","\u5D43","\u5DD8","\u5DDA","\u5F07","\u611D","\u622D","\u624A","\u6281","\u63A9","\u63DC","\u66EE","\u693C","\u6ABF","\u6C87","\u6E37","\u6F14","\u7430","\u7517","\u773C","\u7F68","\u8412","\u8758","\u884D","\u8917","\u8EBD","\u9043","\u90FE","\u9692","\u9869","\u9B47","\u9B58","\u9C0B","\u9DA0","\u9EE1","\u9EE4","\u9EEC","\u9EED","\u9EF6","\u9F34","\u9F39","\u9F74","\u9F91","\u{2CE18}","\u{2C642}","\u{2AA58}"],f\u01D4:["\u4E76","\u4FCC","\u4FDB","\u4FEF","\u5E9C","\u5F23","\u629A","\u62CA","\u64AB","\u65A7","\u6928","\u6ECF","\u7124","\u752B","\u76D9","\u7C20","\u8150","\u8151","\u8705","\u8F14","\u8F85","\u90D9","\u91DC","\u91E1","\u961D","\u982B","\u9B34","\u9EFC","\u356E","\u{2B5AF}"],sh\u0101:["\u4E77","\u5526","\u6740","\u686C","\u6BBA","\u6BEE","\u7300","\u75E7","\u7802","\u7870","\u7D17","\u7E7A","\u7EB1","\u8531","\u88DF","\u93A9","\u94E9","\u95B7","\u9AFF","\u9B66","\u9BCA","\u9BCB","\u9CA8"],n\u01CE:["\u4E78","\u96EB"],qi\u00E1n:["\u4E79","\u4E81","\u4EF1","\u5042","\u524D","\u5898","\u5A8A","\u5C92","\u62D1","\u63AE","\u69A9","\u6A6C","\u6B6C","\u6F5B","\u6F5C","\u6FF3","\u704A","\u7B9D","\u8465","\u8654","\u8EE1","\u9210","\u9257","\u92AD","\u9322","\u9386","\u94A4","\u94B1","\u94B3","\u976C","\u9A1A","\u9A1D","\u9C2C","\u9ED4","\u9EDA"],su\u01D2:["\u4E7A","\u5522","\u55E9","\u6240","\u669B","\u6E91","\u6EB9","\u7410","\u7411","\u7463","\u7D22","\u8928","\u9396","\u93BB","\u93C1","\u9501"],y\u00FA:["\u4E7B","\u4E8E","\u4E90","\u4F03","\u4F59","\u5823","\u582C","\u59A4","\u5A1B","\u5A2F","\u5A31","\u5B29","\u5D33","\u5D4E","\u5D5B","\u611A","\u6275","\u63C4","\u65DF","\u6961","\u6970","\u6986","\u6B24","\u6B48","\u6B5F","\u6B76","\u6E14","\u6E1D","\u6E61","\u6F01","\u6F9E","\u724F","\u72F3","\u7397","\u7399","\u745C","\u74B5","\u76C2","\u776E","\u7AAC","\u7AFD","\u7C45","\u7FAD","\u8174","\u81FE","\u8201","\u8206","\u8245","\u8330","\u842E","\u8438","\u854D","\u861B","\u865E","\u8676","\u8753","\u87B8","\u8867","\u8915","\u89A6","\u89CE","\u8ADB","\u8B23","\u8C00","\u8E30","\u8F3F","\u8F5D","\u903E","\u9098","\u9151","\u935D","\u9685","\u96D3","\u96E9","\u9918","\u9980","\u9A1F","\u9AAC","\u9AC3","\u9B5A","\u9B63","\u9BBD","\u9BF2","\u9C05","\u9C7C","\u9DE0","\u9E06","\u9F75"],zh\u00F9:["\u4E7C","\u4F2B","\u4F47","\u4F4F","\u577E","\u58B8","\u58F4","\u5D40","\u62C0","\u677C","\u67F1","\u6A26","\u6BB6","\u6CE8","\u70B7","\u75B0","\u771D","\u795D","\u7969","\u7ADA","\u7B6F","\u7BB8","\u7BEB","\u7C17","\u7D35","\u7D38","\u7EBB","\u7F9C","\u7FE5","\u82CE","\u8387","\u86C0","\u8A3B","\u8CAF","\u8D2E","\u8DD3","\u8EF4","\u9252","\u92F3","\u9444","\u94F8","\u99B5","\u99D0","\u9A7B"],zh\u011B:["\u4E7D","\u8005","\u8936","\u8975","\u8D6D","\u8E37","\u937A","\u9517"],"qi\xE1n g\u0101n":["\u4E7E"],"zh\xEC lu\xE0n":["\u4E7F"],gu\u012B:["\u4E80","\u572D","\u59AB","\u5AAF","\u5AE2","\u5B00","\u5E30","\u5F52","\u646B","\u691D","\u69FB","\u69FC","\u6AF7","\u6B78","\u73EA","\u7470","\u749D","\u74CC","\u7688","\u77A1","\u7845","\u8325","\u862C","\u898F","\u89C4","\u90BD","\u90CC","\u95A8","\u95FA","\u9A29","\u9B36","\u9B39"],"l\u01D0n l\xECn":["\u4E83"],ju\u00E9:["\u4E85","\u51B3","\u5214","\u5282","\u5337","\u53A5","\u564A","\u5B52","\u5B53","\u5D1B","\u5D2B","\u5DA5","\u5F4F","\u61A0","\u61B0","\u6204","\u6289","\u6317","\u6398","\u652B","\u6877","\u6A5B","\u6A5C","\u6B2E","\u6C12","\u6C7A","\u704D","\u7133","\u71A6","\u7211","\u7234","\u7235","\u7357","\u7383","\u73A6","\u73A8","\u73CF","\u7474","\u761A","\u77CD","\u77E1","\u7804","\u7D55","\u7D76","\u7EDD","\u81C4","\u82B5","\u855D","\u8568","\u8673","\u87E8","\u87E9","\u89D6","\u89EE","\u89FC","\u8A23","\u8B4E","\u8BC0","\u8C32","\u8C9C","\u8D7D","\u8D89","\u8E77","\u8EA9","\u920C","\u940D","\u941D","\u9481","\u9562","\u9D02","\u9D03","\u9DE2","\u{2B61D}","\u3D50","\u{2B50E}"],"le li\u01CEo":["\u4E86"],"g\xE8 m\u0101":["\u4E87"],"y\u01D4 y\xFA":["\u4E88","\u61D9"],zh\u0113ng:["\u4E89","\u4F42","\u51E7","\u59C3","\u5A9C","\u5CE5","\u5D1D","\u5D22","\u5F81","\u5FB0","\u70A1","\u70DD","\u722D","\u72F0","\u7319","\u7665","\u7710","\u7741","\u775C","\u7B5D","\u7B8F","\u7BDC","\u8047","\u8100","\u84B8","\u8E2D","\u9266","\u931A","\u93F3","\u9B07"],\u00E8r:["\u4E8C","\u5235","\u54A1","\u5F0D","\u5F10","\u6A32","\u8A80","\u8CAE","\u8CB3","\u8D30","\u9AF6"],ch\u00F9:["\u4E8D","\u5097","\u510A","\u6035","\u61B7","\u6410","\u65B6","\u6B5C","\u73FF","\u7421","\u77D7","\u7ACC","\u7D40","\u7ECC","\u81C5","\u89E6","\u89F8","\u8C56","\u9110","\u95A6","\u9EDC"],ku\u012B:["\u4E8F","\u5232","\u5CBF","\u5DCB","\u76D4","\u7AA5","\u7ABA","\u8067","\u8667","\u95DA","\u985D"],y\u00FAn:["\u4E91","\u4F1D","\u52FB","\u5300","\u56E9","\u5998","\u612A","\u62A3","\u6600","\u6A52","\u6C84","\u6DA2","\u6EB3","\u6F90","\u7189","\u7547","\u79D0","\u7B7C","\u7BD4","\u7D1C","\u7E1C","\u7EAD","\u8018","\u82B8","\u84B7","\u8553","\u90E7","\u9116","\u92C6","\u96F2"],h\u00F9:["\u4E92","\u51B1","\u55C0","\u569B","\u5A5F","\u5AED","\u5AEE","\u5CB5","\u5E0D","\u5F16","\u6019","\u6236","\u6237","\u6238","\u623D","\u6248","\u62A4","\u6608","\u69F4","\u6C8D","\u6CAA","\u6EEC","\u71A9","\u74E0","\u795C","\u7B0F","\u7C04","\u7C90","\u7D94","\u8530","\u8B77","\u8C70","\u9120","\u9359","\u9800","\u9C6F","\u9CE0","\u9CF8","\u9E0C","\u9E71"],q\u00ED:["\u4E93","\u5258","\u57FC","\u5C90","\u5C93","\u5D0E","\u5D5C","\u612D","\u6391","\u6589","\u658A","\u65C2","\u65D7","\u68CA","\u68CB","\u6AB1","\u6AC0","\u6B67","\u6DC7","\u6FDD","\u7309","\u7382","\u7426","\u742A","\u7482","\u7566","\u75A7","\u7881","\u7895","\u7941","\u7948","\u797A","\u79A5","\u7AD2","\u7C2F","\u7C31","\u7C4F","\u7CB8","\u7DA5","\u7DA6","\u80B5","\u8110","\u81CD","\u8269","\u82AA","\u8401","\u8415","\u8572","\u85C4","\u8604","\u8691","\u869A","\u86F4","\u871D","\u871E","\u87A7","\u8810","\u8900","\u8EDD","\u913F","\u91EE","\u9321","\u951C","\u966D","\u980E","\u9880","\u9A0E","\u9A0F","\u9A39","\u9A90","\u9A91","\u9B10","\u9B3F","\u9BD5","\u9C2D","\u9CAF","\u9CCD","\u9D78","\u9D80","\u9E92","\u9EA1","\u{28678}","\u{2CA02}","\u44EB"],j\u01D0ng:["\u4E95","\u5106","\u522D","\u5244","\u5753","\u5B91","\u5E5C","\u61AC","\u66BB","\u6B8C","\u6C6B","\u6C6C","\u6F8B","\u7484","\u749F","\u74A5","\u7A7D","\u80BC","\u87FC","\u8B66","\u9631","\u981A","\u9838"],s\u00EC:["\u4E96","\u4F40","\u4FA1","\u5129","\u5155","\u55E3","\u56DB","\u59D2","\u5A30","\u5B60","\u5BFA","\u5DF3","\u67F6","\u69B9","\u6C5C","\u6CD7","\u6CE4","\u6D0D","\u6D20","\u6D98","\u7003","\u726D","\u7940","\u79A9","\u7AE2","\u7B25","\u801C","\u8082","\u8086","\u857C","\u8997","\u8C84","\u91F2","\u9236","\u923B","\u98E4","\u98FC","\u9972","\u99DF","\u9A03","\u9A77"],su\u00EC:["\u4E97","\u5B18","\u5C81","\u5D57","\u65DE","\u6A96","\u6B72","\u6B73","\u6FBB","\u716B","\u71E7","\u74B2","\u7815","\u788E","\u795F","\u79AD","\u7A42","\u7A57","\u7A5F","\u7E40","\u7E50","\u7E78","\u895A","\u8AB6","\u8B62","\u8C07","\u8CE5","\u9083","\u9406","\u9429","\u96A7","\u97E2","\u{2B7E6}","\u{2CB7C}"],g\u00E8n:["\u4E98","\u4E99","\u63EF","\u6404","\u831B"],y\u00E0:["\u4E9A","\u4E9C","\u4FF9","\u51B4","\u529C","\u5714","\u5720","\u57E1","\u5A05","\u5A6D","\u63E0","\u6C29","\u6C2C","\u72BD","\u7811","\u7A0F","\u8050","\u897E","\u8980","\u8A1D","\u8BB6","\u8FD3","\u9F7E"],"xi\u0113 su\xF2":["\u4E9B"],"q\xED zh\u0101i":["\u4E9D","\u9F4A"],"y\u0101 y\xE0":["\u4E9E","\u538B","\u57AD","\u58D3","\u94D4"],"j\xED q\xEC":["\u4E9F","\u710F"],t\u00F3u:["\u4EA0","\u6295","\u982D","\u9AB0"],"w\xE1ng w\xFA":["\u4EA1"],"k\xE0ng h\xE1ng g\u0101ng":["\u4EA2"],d\u00E0:["\u4EA3","\u7714"],ji\u0101o:["\u4EA4","\u50EC","\u5A07","\u5B0C","\u5CE7","\u5D95","\u5DA3","\u618D","\u6912","\u6D47","\u6F86","\u7126","\u7901","\u7A5A","\u7C25","\u80F6","\u81A0","\u81B2","\u832D","\u832E","\u8549","\u8660","\u86DF","\u87ED","\u8DE4","\u8F47","\u90CA","\u940E","\u9A55","\u9A84","\u9BAB","\u9C9B","\u9D41","\u9DE6","\u9DEE","\u9E6A","\u4D14"],h\u00E0i:["\u4EA5","\u55D0","\u5BB3","\u6C26","\u9900","\u995A","\u99ED","\u99F4","\u9A87"],"h\u0113ng p\u0113ng":["\u4EA8"],m\u01D4:["\u4EA9","\u59C6","\u5CD4","\u62C7","\u6BCD","\u7261","\u7273","\u7542","\u7546","\u7552","\u755D","\u755E","\u756E","\u782A","\u80DF","\u8E07","\u9267","\u{2CB41}","\u{27FF9}"],ye:["\u4EAA"],xi\u01CEng:["\u4EAB","\u4EAF","\u54CD","\u60F3","\u6651","\u8683","\u8801","\u97FF","\u98E8","\u9909","\u9957","\u9977","\u9B9D","\u9BD7","\u9C76","\u9C9E"],j\u012Bng:["\u4EAC","\u4EB0","\u5162","\u5755","\u5759","\u5A5B","\u60CA","\u65CC","\u65CD","\u6676","\u6A78","\u6CFE","\u6D87","\u7304","\u775B","\u79D4","\u7A09","\u7CB3","\u7CBE","\u7D4C","\u7D93","\u7DA1","\u8059","\u8148","\u830E","\u8346","\u834A","\u83C1","\u844F","\u9A5A","\u9BE8","\u9CB8","\u9D81","\u9D84","\u9E96","\u9EA0","\u9F31","\u4D16"],t\u00EDng:["\u4EAD","\u505C","\u5A77","\u5D49","\u5EAD","\u5EF7","\u695F","\u69B3","\u7B73","\u8064","\u839B","\u8476","\u8713","\u874F","\u8AEA","\u9092","\u9706","\u9F2E","\u45F4"],li\u00E0ng:["\u4EAE","\u55A8","\u60A2","\u667E","\u6E78","\u8AD2","\u8C05","\u8F0C","\u8F1B","\u8F86","\u9344"],"q\u012Bn q\xECng":["\u4EB2","\u89AA"],b\u00F3:["\u4EB3","\u4EE2","\u4FBC","\u50F0","\u535A","\u5E1B","\u613D","\u61EA","\u632C","\u640F","\u6B02","\u6D61","\u6DFF","\u6E24","\u717F","\u7254","\u72DB","\u74DD","\u7934","\u79E1","\u7B94","\u7C19","\u7CEA","\u80C9","\u8116","\u818A","\u8236","\u824A","\u8421","\u8467","\u88AF","\u894F","\u896E","\u8B08","\u8E23","\u90E3","\u9238","\u9251","\u92CD","\u939B","\u946E","\u94B9","\u94C2","\u9548","\u993A","\u998E","\u999B","\u999E","\u99C1","\u99EE","\u9A73","\u9AC6","\u9D53","\u9E41"],y\u00F2u:["\u4EB4","\u4F51","\u4F66","\u4F91","\u53C8","\u53F3","\u54CA","\u5500","\u56FF","\u59F7","\u5BA5","\u5CDF","\u5E7C","\u72D6","\u7950","\u86B4","\u8A98","\u8BF1","\u8C81","\u8FF6","\u916D","\u91C9","\u9F2C"],xi\u00E8:["\u4EB5","\u4F33","\u505E","\u5070","\u50C1","\u5368","\u5378","\u5667","\u586E","\u5911","\u5A9F","\u5C51","\u5C67","\u5EE8","\u5FA2","\u61C8","\u66AC","\u68B0","\u698D","\u69AD","\u6CFB","\u6D29","\u6E2B","\u6FA5","\u7009","\u7023","\u707A","\u70A7","\u70A8","\u71EE","\u7215","\u736C","\u7944","\u79BC","\u7CCF","\u7D32","\u7D4F","\u7D6C","\u7E72","\u7E88","\u7EC1","\u7F37","\u85A2","\u85A4","\u87F9","\u880F","\u8909","\u893B","\u8B1D","\u8C22","\u8E9E","\u9082","\u977E","\u97F0","\u9F42","\u9F58","\u9F5B","\u9F65","\u{2CE7C}","\u{24AC9}"],"d\u01CEn d\xE0n":["\u4EB6","\u99BE"],li\u00E1n:["\u4EB7","\u5286","\u5332","\u5333","\u55F9","\u5652","\u5941","\u5969","\u5AFE","\u5E18","\u5EC9","\u601C","\u6190","\u6D9F","\u6F23","\u6FC2","\u6FD3","\u702E","\u7191","\u71EB","\u7C3E","\u7C62","\u7C68","\u7E3A","\u7FF4","\u8054","\u8068","\u806B","\u806E","\u806F","\u81C1","\u83B2","\u84EE","\u8595","\u878A","\u880A","\u88E2","\u8933","\u899D","\u8B30","\u8E65","\u8FDE","\u9023","\u938C","\u942E","\u9570","\u9B11","\u9C31","\u9CA2"],du\u01D2:["\u4EB8","\u54DA","\u56B2","\u57F5","\u5D1C","\u6735","\u6736","\u7D9E","\u7F0D","\u8D93","\u8EB1","\u8EB2","\u8EC3"],"w\u011Bi m\xE9n":["\u4EB9","\u6596"],r\u00E9n:["\u4EBA","\u4EBB","\u4EC1","\u58EC","\u5FC8","\u5FCE","\u6732","\u79C2","\u82A2","\u9B5C","\u9D40"],j\u00ED:["\u4EBC","\u4EBD","\u4F0B","\u4F76","\u506E","\u5359","\u5373","\u537D","\u53CA","\u53DD","\u5409","\u5832","\u5849","\u59DE","\u5AC9","\u5C8C","\u5D74","\u5DAF","\u5F76","\u5FE3","\u6025","\u6131","\u6222","\u63E4","\u6781","\u68D8","\u696B","\u6975","\u69C9","\u6A9D","\u6B9B","\u6C72","\u6E52","\u6F57","\u75BE","\u7620","\u768D","\u7B08","\u7BBF","\u7C4D","\u7D1A","\u7EA7","\u818C","\u8265","\u84BA","\u8540","\u857A","\u874D","\u878F","\u894B","\u89D9","\u8C3B","\u8E16","\u8E50","\u8EA4","\u8F2F","\u8F5A","\u8F91","\u90C6","\u92A1","\u9353","\u93F6","\u96C6","\u96E7","\u9735","\u9E61","\u3D14"],w\u00E1ng:["\u4EBE","\u4EFC","\u5166","\u83A3","\u869F"],"sh\xE9n sh\xED":["\u4EC0"],l\u00E8:["\u4EC2","\u53FB","\u5FC7","\u6C3B","\u6CD0","\u738F","\u7833","\u7C15","\u827B","\u961E","\u97F7","\u990E","\u9C33","\u9C73","\u9CD3"],d\u012Bng:["\u4EC3","\u53EE","\u5E04","\u738E","\u7594","\u76EF","\u8035","\u8670","\u976A"],z\u00E8:["\u4EC4","\u5D31","\u5E82","\u6351","\u6603","\u6617","\u6C44"],"j\u01D0n j\xECn":["\u4EC5","\u50C5","\u5AE4"],"p\xFA p\u016B":["\u4EC6"],"ch\xF3u qi\xFA":["\u4EC7"],zh\u01CEng:["\u4EC9","\u5E65","\u638C","\u7903"],j\u012Bn:["\u4ECA","\u583B","\u5DFE","\u60CD","\u65A4","\u6D25","\u73D2","\u743B","\u74A1","\u781B","\u7B4B","\u8355","\u887F","\u895F","\u89D4","\u91D1","\u91D2","\u91FF","\u9485","\u9E76","\u9EC5","\u{2CB31}"],b\u012Bng:["\u4ECC","\u4ED2","\u5175","\u51AB","\u51B0","\u63A4","\u6C37","\u92F2"],r\u00E9ng:["\u4ECD","\u793D","\u82BF","\u8FB8","\u967E"],f\u00F3:["\u4ECF","\u5772","\u68BB"],"j\u012Bn s\u01CEn":["\u4ED0"],l\u00FAn:["\u4ED1","\u4F26","\u4F96","\u502B","\u56F5","\u5707","\u5A68","\u5D18","\u5D19","\u68C6","\u6CA6","\u6DEA","\u78EE","\u8140","\u83D5","\u8726","\u8E1A","\u8F2A","\u8F6E","\u9300","\u966F","\u9BE9","\u{2CB2D}"],c\u0101ng:["\u4ED3","\u4EFA","\u5009","\u51D4","\u5D62","\u6CA7","\u6EC4","\u6FF8","\u734A","\u8231","\u8259","\u82CD","\u84BC","\u87A5","\u9E27"],"z\u01CEi z\u01D0 z\u012B":["\u4ED4"],t\u0101:["\u4ED6","\u584C","\u5B83","\u6999","\u6EBB","\u7260","\u7942","\u891F","\u8DBF","\u9062","\u95E7"],f\u00F9:["\u4ED8","\u5069","\u5085","\u51A8","\u526F","\u5490","\u577F","\u590D","\u5987","\u5A66","\u5A8D","\u5B14","\u5BCC","\u5FA9","\u6931","\u7954","\u79A3","\u7ACE","\u7DEE","\u7E1B","\u7F1A","\u8179","\u842F","\u8567","\u86B9","\u86D7","\u875C","\u876E","\u889D","\u8907","\u8984","\u8986","\u8A03","\u8A42","\u8BA3","\u8CA0","\u8CE6","\u8CFB","\u8D1F","\u8D4B","\u8D59","\u8D74","\u8F39","\u9351","\u9362","\u961C","\u9644","\u99A5","\u99D9","\u9A78","\u9B92","\u9C12","\u9C8B","\u9CC6","\u3CC7"],xi\u0101n:["\u4ED9","\u4EDA","\u4F61","\u50CA","\u50F2","\u5148","\u5615","\u597E","\u5C73","\u5EEF","\u5FFA","\u61B8","\u6380","\u66B9","\u6774","\u6C19","\u73D7","\u7946","\u79C8","\u7C7C","\u7E4A","\u7E8E","\u7E96","\u82EE","\u893C","\u8973","\u8DF9","\u8E6E","\u8E9A","\u9170","\u9341","\u9528","\u97EF","\u97F1","\u99A6","\u9C7B","\u9DB1","\u{2CE23}"],"tu\u014D ch\xE0 du\xF3":["\u4EDB"],h\u00F3ng:["\u4EDC","\u5430","\u57AC","\u5985","\u5A02","\u5B8F","\u5B96","\u5F18","\u5F4B","\u6C6F","\u6CD3","\u6D2A","\u6D64","\u6E31","\u6F42","\u7392","\u739C","\u7AD1","\u7AE4","\u7BCA","\u7CA0","\u7D18","\u7D2D","\u7D8B","\u7EAE","\u7FC3","\u7FDD","\u803E","\u82F0","\u836D","\u8452","\u8453","\u8C39","\u8C3C","\u921C","\u9277","\u92D0","\u958E","\u95F3","\u9710","\u971F","\u9783","\u9B5F","\u9D3B","\u9E3F","\u9EC9","\u9ECC","\u{2B7F9}","\u{2CB4E}"],t\u00F3ng:["\u4EDD","\u4F5F","\u54C3","\u5CC2","\u5CDD","\u5E9D","\u5F64","\u664D","\u66C8","\u6850","\u6C03","\u6D75","\u6F7C","\u729D","\u735E","\u772E","\u77B3","\u783C","\u79F1","\u7AE5","\u7CA1","\u81A7","\u833C","\u8692","\u8A77","\u8D68","\u916E","\u9256","\u9275","\u9285","\u94DC","\u9907","\u9BA6","\u9C96","\u{2B363}","\u{2648D}"],r\u00E8n:["\u4EDE","\u4EED","\u5203","\u5204","\u598A","\u59D9","\u5C7B","\u5C83","\u6268","\u7263","\u794D","\u7D09","\u7D1D","\u7D4D","\u7EAB","\u7EB4","\u8095","\u814D","\u887D","\u88B5","\u8A12","\u8A8D","\u8BA4","\u8BB1","\u8ED4","\u8F6B","\u9213","\u976D","\u9771","\u97CC","\u97E7","\u98EA","\u9901","\u996A"],qi\u0101n:["\u4EDF","\u4F65","\u50C9","\u5343","\u5732","\u5977","\u5B6F","\u5C8D","\u60AD","\u6106","\u6173","\u6266","\u62EA","\u6434","\u6481","\u6510","\u6511","\u6513","\u6744","\u6ACF","\u6C58","\u6C67","\u7275","\u727D","\u7ACF","\u7B7E","\u7C3D","\u7C56","\u7C64","\u7C81","\u828A","\u833E","\u8688","\u8930","\u8AD0","\u8B19","\u8C26","\u8C38","\u8FC1","\u9077","\u91FA","\u9206","\u925B","\u93F2","\u948E","\u9621","\u97C6","\u9845","\u9A2B","\u9A9E","\u9B1C","\u9B1D","\u9D6E","\u9E50"],"g\u01CEn h\xE0n":["\u4EE0"],"y\xEC g\u0113":["\u4EE1"],d\u00E0i:["\u4EE3","\u4FA2","\u53C7","\u5788","\u57ED","\u5CB1","\u5E12","\u5E26","\u5E2F","\u5E36","\u5ED7","\u6020","\u6234","\u66C3","\u67CB","\u6B86","\u703B","\u73B3","\u7447","\u7519","\u7C24","\u7D3F","\u7DFF","\u7ED0","\u825C","\u8773","\u888B","\u8976","\u8CA3","\u8D37","\u8E5B","\u8ED1","\u8EDA","\u8EE9","\u8F6A","\u8FE8","\u9734","\u9746","\u9D0F","\u9EDB","\u9EF1"],"l\xECng l\xEDng l\u01D0ng":["\u4EE4"],ch\u00E0o:["\u4EE6","\u8016","\u89D8"],"ch\xE1ng zh\u01CEng":["\u4EE7","\u514F","\u9577","\u957F"],s\u0101:["\u4EE8"],ch\u00E1ng:["\u4EE9","\u507F","\u511F","\u5617","\u5690","\u5AE6","\u5C1D","\u5E38","\u5F9C","\u747A","\u74FA","\u751E","\u80A0","\u8178","\u8193","\u82CC","\u8407","\u9578","\u9C68","\u9CBF"],y\u00ED:["\u4EEA","\u4F87","\u5100","\u519D","\u531C","\u54A6","\u572F","\u5937","\u59E8","\u5B90","\u5B9C","\u5BA7","\u5BF2","\u5CD3","\u5DAC","\u5DB7","\u5DF8","\u5F5B","\u5F5C","\u5F5D","\u5F5E","\u6021","\u605E","\u6245","\u6686","\u6818","\u692C","\u6938","\u6C82","\u6D1F","\u71AA","\u74F5","\u75CD","\u79FB","\u7C03","\u7C4E","\u7FA0","\u80F0","\u8413","\u86E6","\u8794","\u89FA","\u8B3B","\u8CBD","\u8D3B","\u8DE0","\u8FFB","\u907A","\u93D4","\u9809","\u9824","\u9825","\u984A","\u9890","\u9974","\u9BA7","\u9D3A"],m\u00F9:["\u4EEB","\u51E9","\u52DF","\u5893","\u5E55","\u5E59","\u6154","\u6155","\u66AE","\u66AF","\u6728","\u6958","\u6BE3","\u6C90","\u7091","\u7267","\u72C7","\u76EE","\u7766","\u7A46","\u8252","\u82DC","\u83AF","\u869E","\u926C","\u94BC","\u96EE","\u9702"],"men m\xE9n":["\u4EEC"],f\u01CEn:["\u4EEE","\u53CD","\u6A4E","\u8FD4"],"ch\xE0o mi\u01CEo":["\u4EEF"],"y\u01CEng \xE1ng":["\u4EF0"],zh\u00F2ng:["\u4EF2","\u4F17","\u5839","\u5995","\u5A91","\u72C6","\u773E","\u794C","\u7B57","\u833D","\u869B","\u8846","\u8876","\u8AE5"],"p\u01D0 p\xED":["\u4EF3"],w\u00F2:["\u4EF4","\u5053","\u5367","\u5A89","\u5E44","\u63E1","\u6943","\u6C83","\u6E25","\u6FE3","\u74C1","\u7783","\u786A","\u809F","\u815B","\u81E5","\u9F77","\u9F8C"],ji\u00E0n:["\u4EF6","\u4FF4","\u5065","\u50ED","\u5251","\u5263","\u5271","\u528D","\u528E","\u5292","\u5294","\u58B9","\u5BCB","\u5EFA","\u5FA4","\u64F6","\u65D4","\u6957","\u6BFD","\u6D0A","\u6DA7","\u6F97","\u726E","\u73D4","\u77B7","\u78F5","\u7900","\u7BAD","\u7CCB","\u7E5D","\u8171","\u81F6","\u8230","\u8266","\u8350","\u85A6","\u89B8","\u8AD3","\u8AEB","\u8B5B","\u8C0F","\u8CCE","\u8CE4","\u8D31","\u8D9D","\u8DF5","\u8E10","\u8E3A","\u8F5E","\u9274","\u9373","\u9375","\u9431","\u9451","\u9452","\u946C","\u9473","\u952E","\u9593","\u991E","\u996F","\u{2C8E1}"],"ji\xE0 ji\xE8 jie":["\u4EF7"],"y\u01CEo f\xF3":["\u4EF8"],"r\xE8n r\xE9n":["\u4EFB"],"f\xE8n b\u012Bn":["\u4EFD"],d\u012B:["\u4EFE","\u4F4E","\u5572","\u57DE","\u5824","\u5CBB","\u5F7D","\u6A00","\u6EF4","\u78FE","\u79EA","\u7F9D","\u889B","\u8D86","\u9684","\u97AE","\u40C5"],f\u01CEng:["\u4EFF","\u5023","\u65CA","\u6609","\u6618","\u74EC","\u7706","\u7D21","\u7EBA","\u822B","\u8A2A","\u8BBF","\u9AE3","\u9DAD"],zh\u014Dng:["\u4F00","\u5223","\u5990","\u5E52","\u5F78","\u5FE0","\u67CA","\u6C77","\u6CC8","\u7082","\u76C5","\u7C66","\u7D42","\u7EC8","\u822F","\u8520","\u8719","\u87A4","\u87BD","\u8873","\u8877","\u8E71","\u9221","\u937E","\u9418","\u949F","\u953A","\u9D24","\u9F28"],p\u00E8i:["\u4F02","\u4F69","\u59F5","\u5E14","\u65BE","\u65C6","\u6C9B","\u6D7F","\u73EE","\u84DC","\u8F61","\u8F94","\u914D","\u9708","\u99B7"],di\u00E0o:["\u4F04","\u540A","\u5F14","\u6389","\u7639","\u76C4","\u7A8E","\u7AB5","\u7AE8","\u8A0B","\u91E3","\u921F","\u92B1","\u92FD","\u9443","\u9493","\u94DE","\u96FF","\u9B61"],d\u00F9n:["\u4F05","\u6F61","\u7096","\u71C9","\u76FE","\u7818","\u78B7","\u8E32","\u9007","\u9041","\u906F","\u920D","\u949D"],w\u011Bn:["\u4F06","\u520E","\u543B","\u5445","\u6286","\u687D","\u7A33","\u7A4F","\u7A69","\u7D0A","\u80B3","\u8117"],x\u01D0n:["\u4F08"],k\u00E0ng:["\u4F09","\u531F","\u56E5","\u6297","\u7095","\u9227","\u94AA"],\u00E0i:["\u4F0C","\u50FE","\u5867","\u58D2","\u5AD2","\u5B21","\u611B","\u61D3","\u66A7","\u66D6","\u7231","\u7477","\u74A6","\u76A7","\u77B9","\u7839","\u784B","\u788D","\u7919","\u8586","\u8B7A","\u8CF9","\u9440","\u9698","\u9749","\u9932","\u99A4","\u9C6B","\u9D31"],"j\xEC q\xED":["\u4F0E","\u85BA"],"xi\u016B x\u01D4":["\u4F11"],"j\xECn y\xEDn":["\u4F12"],d\u01CEn:["\u4F14","\u5210","\u64A2","\u73AC","\u74ED","\u7D1E","\u80C6","\u81BD","\u8874","\u8CE7","\u8D55","\u9ED5","\u{2C618}"],f\u016B:["\u4F15","\u544B","\u5A10","\u5B75","\u5C03","\u6024","\u61EF","\u6577","\u65C9","\u739E","\u7806","\u7A03","\u7B5F","\u7CD0","\u7D92","\u80A4","\u819A","\u8342","\u8374","\u886D","\u8DBA","\u8DD7","\u909E","\u911C","\u915C","\u9207","\u9EA9","\u9EAC","\u9EB1","\u9EB8","\u{2B4E7}"],t\u01CEng:["\u4F16","\u50A5","\u513B","\u57EB","\u6203","\u66ED","\u7223","\u77D8","\u8EBA","\u93B2","\u9482","\u954B"],y\u014Du:["\u4F18","\u512A","\u5466","\u5698","\u5CF3","\u5E7D","\u5FE7","\u60A0","\u6182","\u6538","\u6ACC","\u6EFA","\u7000","\u7E8B","\u7FAA","\u8030","\u900C","\u913E","\u9E80"],hu\u01D2:["\u4F19","\u5925","\u706B","\u7177","\u90A9","\u9225","\u94AC"],"hu\xEC ku\xE0i":["\u4F1A","\u6703","\u6D4D","\u74AF"],y\u01D4:["\u4F1B","\u4FC1","\u4FE3","\u504A","\u50B4","\u532C","\u5673","\u5704","\u5709","\u5B87","\u5BD9","\u5C7F","\u5DBC","\u5EBE","\u6327","\u6554","\u659E","\u6940","\u7440","\u7610","\u7964","\u79B9","\u7A65","\u7AB3","\u7FBD","\u8207","\u842D","\u8C90","\u9105","\u9828","\u9E8C","\u9F6C","\u9F89","\u3E84"],cu\u00EC:["\u4F1C","\u555B","\u5FF0","\u60B4","\u6BF3","\u6DEC","\u7120","\u75A9","\u7601","\u7AC1","\u7C8B","\u7CB9","\u7D23","\u7DB7","\u7FC6","\u7FE0","\u8103","\u8106","\u813A","\u81AC","\u81B5","\u81CE","\u8403","\u894A","\u9847"],s\u01CEn:["\u4F1E","\u5098","\u7CE4","\u7E56","\u994A","\u9993"],w\u011Bi:["\u4F1F","\u4F2A","\u5049","\u507D","\u50DE","\u5130","\u5A13","\u5BEA","\u5C57","\u5D23","\u5D89","\u5FAB","\u6107","\u6364","\u6690","\u68B6","\u6D27","\u6D58","\u6E28","\u709C","\u7152","\u7325","\u73AE","\u744B","\u75FF","\u7DEF","\u7EAC","\u8172","\u8249","\u829B","\u82C7","\u8371","\u840E","\u8466","\u848D","\u853F","\u873C","\u8AC9","\u8BFF","\u8E13","\u9361","\u97D1","\u97D9","\u97E1","\u97EA","\u9820","\u98B9","\u9AA9","\u9AAA","\u9AAB","\u9BAA","\u9C94","\u{2B1ED}","\u{2C029}","\u{2CC5F}"],"chu\xE1n zhu\xE0n":["\u4F20","\u50B3"],"ch\u0113 j\u016B":["\u4F21","\u4FE5","\u8F66"],"j\u016B ch\u0113":["\u8ECA"],y\u00E1:["\u4F22","\u5391","\u5393","\u5810","\u5C88","\u5D15","\u5D16","\u6DAF","\u6F04","\u7259","\u73A1","\u740A","\u775A","\u7B0C","\u82BD","\u869C","\u8859","\u9F56"],qi\u00E0n:["\u4F23","\u4FD4","\u5029","\u5119","\u520B","\u58CD","\u5B31","\u6093","\u68C8","\u6920","\u69E7","\u6B20","\u6B49","\u7698","\u7BCF","\u7BDF","\u7E34","\u82A1","\u84A8","\u8533","\u8F24","\u{2C62C}"],sh\u0101ng:["\u4F24","\u50B7","\u5546","\u5892","\u616F","\u6B87","\u6BA4","\u6EF3","\u6F21","\u71B5","\u850F","\u87AA","\u89DE","\u89F4","\u8B2A","\u9B3A"],ch\u0101ng:["\u4F25","\u5000","\u5A3C","\u660C","\u6919","\u6DD0","\u7316","\u7429","\u83D6","\u88EE","\u9329","\u9520","\u95B6","\u960A","\u9BE7","\u9CB3","\u9F1A"],"chen c\u0101ng":["\u4F27"],x\u00F9n:["\u4F28","\u4F9A","\u5342","\u5640","\u5DFA","\u5DFD","\u5F87","\u613B","\u6B89","\u6BBE","\u6C5B","\u6F60","\u72E5","\u8548","\u8A0A","\u8A13","\u8A19","\u8BAD","\u8BAF","\u8FC5","\u8FFF","\u900A","\u905C","\u9442","\u9868","\u99B4","\u9A6F"],x\u00ECn:["\u4F29","\u56DF","\u5B5E","\u812A","\u820B","\u8845","\u8A2B","\u91C1","\u9620","\u9856"],ch\u01D0:["\u4F2C","\u4F88","\u5376","\u53FA","\u544E","\u5791","\u6065","\u6B6F","\u803B","\u8094","\u80E3","\u8687","\u88ED","\u892B","\u8C49","\u9279","\u9F52","\u9F7F"],"xi\xE1n xu\xE1n":["\u4F2D"],"n\xFA n\u01D4":["\u4F2E"],"b\xF3 b\u01CEi":["\u4F2F"],"g\u016B g\xF9":["\u4F30"],n\u01D0:["\u4F31","\u4F60","\u511E","\u5B74","\u62DF","\u64EC","\u65CE","\u6672","\u72D4","\u82E8","\u85BF","\u96AC"],"n\xEC n\xED":["\u4F32"],b\u00E0n:["\u4F34","\u529E","\u534A","\u59C5","\u6011","\u626E","\u74E3","\u79DA","\u7D46","\u7ECA","\u8FA6","\u9261","\u977D"],x\u00F9:["\u4F35","\u4F90","\u52D6","\u52D7","\u5379","\u53D9","\u57BF","\u58FB","\u5A7F","\u5E8F","\u6064","\u654D","\u6558","\u65ED","\u662B","\u6702","\u69D2","\u6B30","\u6B88","\u6C7F","\u6C80","\u6D2B","\u6E86","\u6F35","\u6F4A","\u70C5","\u70FC","\u7166","\u735D","\u73EC","\u76E2","\u7781","\u7A38","\u7D6E","\u7D9A","\u7DD2","\u7DD6","\u7E8C","\u7EEA","\u7EED","\u8053","\u805F","\u84C4","\u85DA","\u8A39","\u8CC9","\u9157","\u980A","\u9C6E","\u3CDA"],zh\u00F2u:["\u4F37","\u50FD","\u5191","\u546A","\u5492","\u54AE","\u5B99","\u663C","\u665D","\u7503","\u76B1","\u76BA","\u7C40","\u7C52","\u7C55","\u7C99","\u7D02","\u7E10","\u7EA3","\u7EC9","\u80C4","\u836E","\u8464","\u8A4B","\u914E","\u99CE","\u9A5F","\u9AA4","\u3918","\u3447"],sh\u0113n:["\u4F38","\u4F81","\u515F","\u547B","\u5814","\u59BD","\u5A20","\u5C7E","\u5CF7","\u625F","\u6552","\u66D1","\u67DB","\u6C20","\u6DF1","\u71CA","\u73C5","\u7521","\u7527","\u7533","\u7712","\u7837","\u7A7C","\u7C76","\u7C78","\u7CC2","\u7D33","\u7EC5","\u7F59","\u7F67","\u8460","\u84E1","\u8518","\u8593","\u88D1","\u8A37","\u8A75","\u8BDC","\u8EAB","\u99EA","\u9BD3","\u9BF5","\u9C3A","\u9CB9","\u9D62","\u{2CCFD}"],q\u016B:["\u4F39","\u4F49","\u5324","\u547F","\u5765","\u5C48","\u5C96","\u5CB4","\u5D87","\u6188","\u62BE","\u657A","\u6D40","\u7140","\u795B","\u7B41","\u7CAC","\u80E0","\u86C6","\u86D0","\u88AA","\u89BB","\u8A58","\u8BCE","\u8D8D","\u8EAF","\u8EC0","\u9639","\u99C6","\u99C8","\u9A45","\u9A71","\u9AF7","\u9B7C","\u9C38","\u9C4B","\u9D8C","\u9EAF","\u9EB4","\u9EB9","\u9EE2","\u3B55","\u{2AA30}","\u44DB"],"s\xEC c\xEC":["\u4F3A"],b\u0113ng:["\u4F3B","\u5623","\u595F","\u5D29","\u5D6D","\u958D"],"s\xEC sh\xEC":["\u4F3C"],"ji\u0101 qi\xE9 g\u0101":["\u4F3D"],"y\u01D0 ch\xEC":["\u4F41"],"di\xE0n ti\xE1n":["\u4F43","\u94BF"],"h\u0101n g\xE0n":["\u4F44"],m\u00E0i:["\u4F45","\u52A2","\u52F1","\u5356","\u551B","\u58F2","\u8108","\u8847","\u8CE3","\u8FC8","\u9081","\u9721","\u9722","\u9EA5","\u9EA6","\u9FCF"],d\u00E0n:["\u4F46","\u50E4","\u5556","\u5557","\u557F","\u5649","\u56AA","\u5E0E","\u61BA","\u65E6","\u67E6","\u6C2E","\u6C8A","\u6CF9","\u6DE1","\u72DA","\u758D","\u765A","\u79AB","\u7A9E","\u8145","\u840F","\u84DE","\u86CB","\u8711","\u89DB","\u8A11","\u8A95","\u8BDE","\u8D09","\u972E","\u9924","\u994F","\u99F3","\u9AE7","\u9D20","\u{2B8B8}"],b\u00F9:["\u4F48","\u52CF","\u5425","\u5498","\u57D7","\u57E0","\u5E03","\u5ECD","\u6016","\u6091","\u6B65","\u6B68","\u6B69","\u74FF","\u7BF0","\u8379","\u8500","\u8E04","\u90E8","\u90F6","\u9208","\u949A","\u9922"],b\u01D0:["\u4F4A","\u4FFE","\u5315","\u5936","\u59A3","\u5F7C","\u673C","\u67C0","\u6BD4","\u6BDE","\u6C98","\u7595","\u79D5","\u7B14","\u7B46","\u7C83","\u805B","\u822D","\u8C8F","\u9119"],"zh\u0101o sh\xE0o":["\u4F4B"],c\u01D0:["\u4F4C","\u6B64","\u6CDA","\u7689","\u{2B696}"],w\u00E8i:["\u4F4D","\u536B","\u5473","\u5582","\u589B","\u5AA6","\u6170","\u61C0","\u672A","\u6E2D","\u715F","\u71AD","\u729A","\u732C","\u754F","\u7DED","\u7F7B","\u80C3","\u82FF","\u83CB","\u85EF","\u8636","\u875F","\u87B1","\u885B","\u885E","\u893D","\u8B02","\u8B86","\u8B8F","\u8C13","\u8E97","\u8E9B","\u8ECE","\u8F4A","\u93CF","\u9728","\u9927","\u9935","\u9956","\u9B4F","\u9B87","\u9CDA"],zu\u01D2:["\u4F50","\u5DE6","\u7E53"],y\u01CEng:["\u4F52","\u509F","\u517B","\u5771","\u5C9F","\u6143","\u61E9","\u6501","\u6C27","\u6C31","\u70B4","\u75D2","\u7662","\u7922","\u7D3B","\u8746","\u8EEE","\u990A","\u99DA"],"t\u01D0 t\u012B":["\u4F53","\u9AD4"],zh\u00E0n:["\u4F54","\u5061","\u5D98","\u6218","\u6226","\u6230","\u6808","\u685F","\u68E7","\u6E5B","\u7AD9","\u7DBB","\u7EFD","\u83DA","\u8638","\u8665","\u8666","\u8B67","\u8F4F","\u9A4F"],"h\xE9 h\u0113 h\xE8":["\u4F55"],b\u00EC:["\u4F56","\u5487","\u54D4","\u55F6","\u5752","\u581B","\u58C1","\u5970","\u59BC","\u5A62","\u5B16","\u5E01","\u5E63","\u5E64","\u5E87","\u5EB3","\u5EE6","\u5F0A","\u5F3B","\u5F3C","\u5F43","\u5FC5","\u602D","\u610A","\u610E","\u655D","\u6583","\u6890","\u6BD5","\u6BD6","\u6BD9","\u6E62","\u6ED7","\u6EED","\u6F77","\u714F","\u719A","\u72F4","\u7358","\u7359","\u73CC","\u74A7","\u7540","\u7562","\u75AA","\u75F9","\u75FA","\u7695","\u7764","\u78A7","\u7B5A","\u7B85","\u7B86","\u7BE6","\u7BF3","\u7C8A","\u7DBC","\u7E2A","\u7E74","\u7F7C","\u8177","\u82FE","\u835C","\u8406","\u841E","\u84D6","\u84FD","\u853D","\u859C","\u870C","\u8890","\u8945","\u895E","\u8963","\u89F1","\u8A56","\u8BD0","\u8CB1","\u8D14","\u8D51","\u8DF8","\u8E55","\u8E83","\u8E84","\u907F","\u90B2","\u9128","\u912A","\u924D","\u93CE","\u9434","\u94CB","\u9587","\u9589","\u959F","\u95ED","\u965B","\u97E0","\u98F6","\u9946","\u999D","\u99DC","\u9A46","\u9AC0","\u9B53","\u9B85","\u9DDD","\u9DE9","\u9F0A"],tu\u00F3:["\u4F57","\u5768","\u5836","\u5CAE","\u69D6","\u6A50","\u6CB1","\u7823","\u7824","\u78A2","\u7D3D","\u8A51","\u8DCE","\u9161","\u9624","\u9640","\u9641","\u99DD","\u99DE","\u9A28","\u9A52","\u9A5D","\u9A7C","\u9B80","\u9D15","\u9E35","\u9F09","\u9F0D","\u9F27","\u{2CD8D}"],sh\u00E9:["\u4F58","\u820C","\u8675","\u86E5"],"y\xEC di\xE9":["\u4F5A","\u6633","\u6CC6","\u8EFC"],"f\xF3 f\xFA b\xEC b\xF3":["\u4F5B"],"zu\xF2 zu\u014D":["\u4F5C"],g\u014Du:["\u4F5D","\u6C9F","\u6E9D","\u75C0","\u7BDD","\u7C3C","\u7DF1","\u7F11","\u88A7","\u8920","\u920E","\u9264","\u94A9","\u97B2","\u97DD"],n\u00ECng:["\u4F5E","\u4FAB","\u503F","\u5BD5","\u6CDE","\u6F9D","\u6FD8"],q\u00FA:["\u4F62","\u52AC","\u6235","\u65AA","\u6B0B","\u6B14","\u6C0D","\u6DED","\u7048","\u7220","\u7496","\u74A9","\u766F","\u78F2","\u7C67","\u7D47","\u80CA","\u81DE","\u83C3","\u844B","\u8556","\u8627","\u87DD","\u8837","\u883C","\u8850","\u8862","\u8EA3","\u8EE5","\u947A","\u9D1D","\u9E1C","\u9E32","\u9F29"],"y\u014Dng y\xF2ng":["\u4F63"],w\u01CE:["\u4F64","\u5493","\u7819","\u90B7"],k\u01CE:["\u4F67","\u57B0","\u80E9","\u88C3","\u9272"],b\u0101o:["\u4F68","\u52F9","\u5305","\u5B62","\u7172","\u7B23","\u80DE","\u82DE","\u8554","\u88E6","\u8912","\u8943","\u95C1","\u9F59","\u9F85"],"hu\xE1i hu\xED":["\u4F6A"],"g\xE9 h\xE8":["\u4F6B"],l\u01CEo:["\u4F6C","\u54BE","\u6045","\u6833","\u72EB","\u73EF","\u7853","\u8001","\u8002","\u8356","\u86EF","\u8F51","\u92A0","\u94D1","\u9BB1"],xi\u00E1ng:["\u4F6D","\u5EA0","\u6819","\u7965","\u7D74","\u7FD4","\u8A73","\u8DED"],g\u00E9:["\u4F6E","\u530C","\u5444","\u55DD","\u5865","\u6105","\u630C","\u643F","\u69C5","\u6ACA","\u6EC6","\u8188","\u81F5","\u8316","\u89E1","\u8AFD","\u8F35","\u8F55","\u95A3","\u9601","\u9694","\u97B7","\u97D0","\u97DA","\u9A14","\u9ABC","\u9BAF"],y\u00E1ng:["\u4F6F","\u52B7","\u579F","\u5D38","\u5F89","\u626C","\u63DA","\u656D","\u65F8","\u661C","\u6698","\u6768","\u694A","\u6D0B","\u7080","\u73DC","\u75A1","\u760D","\u773B","\u86D8","\u8AF9","\u8F30","\u935A","\u9496","\u9626","\u9633","\u967D","\u9737","\u98BA","\u98CF","\u9C11","\u9D39","\u9E09"],b\u01CEi:["\u4F70","\u636D","\u6446","\u64FA","\u6822","\u767E","\u7AE1","\u7CA8","\u896C"],f\u01CE:["\u4F71","\u5CDC","\u6CD5","\u704B","\u781D","\u9345"],m\u01D0ng:["\u4F72","\u51D5","\u59F3","\u614F","\u9169"],"\xE8r n\xE0i":["\u4F74"],h\u011Bn:["\u4F77","\u5F88","\u72E0","\u8A6A","\u{2C8F3}"],hu\u00F3:["\u4F78","\u6D3B"],gu\u01D0:["\u4F79","\u5326","\u532D","\u53AC","\u579D","\u59FD","\u5B84","\u5E8B","\u5EAA","\u6051","\u6677","\u6E40","\u7678","\u796A","\u7C0B","\u86EB","\u87E1","\u89E4","\u8A6D","\u8BE1","\u8ECC","\u8F68","\u9652","\u9B3C"],qu\u00E1n:["\u4F7A","\u5168","\u5573","\u57E2","\u59FE","\u5CD1","\u5DCF","\u62F3","\u643C","\u6743","\u697E","\u6A29","\u6B0A","\u6CC9","\u6D24","\u6E76","\u7277","\u7288","\u7454","\u75CA","\u7842","\u7B4C","\u7E13","\u8343","\u8472","\u8737","\u8838","\u89E0","\u8A6E","\u8BE0","\u8DE7","\u8E21","\u8F07","\u8F81","\u919B","\u9293","\u94E8","\u95CE","\u9874","\u98A7","\u99E9","\u9A21","\u9B08","\u9C01","\u9CC8","\u9F64"],ti\u0101o:["\u4F7B","\u5EA3","\u65EB","\u7967","\u804E"],ji\u01CEo:["\u4F7C","\u510C","\u5B42","\u6322","\u6405","\u649F","\u64B9","\u652A","\u656B","\u657D","\u657F","\u6648","\u669E","\u66D2","\u705A","\u71DE","\u72E1","\u74AC","\u768E","\u76A6","\u7D5E","\u7E90","\u7EDE","\u8173","\u81EB","\u87DC","\u8B51","\u8CCB","\u8E0B","\u9278","\u94F0","\u9903","\u997A","\u9C4E","\u9FA3"],c\u00EC:["\u4F7D","\u523E","\u5E9B","\u673F","\u6828","\u6B21","\u7D58","\u8326","\u83BF","\u86D3","\u8786","\u8CDC","\u8D50"],x\u00EDng:["\u4F80","\u5211","\u54D8","\u578B","\u5A19","\u5F62","\u6D10","\u784E","\u86F5","\u90A2","\u90C9","\u9203","\u9276","\u9292","\u9498","\u94CF","\u9649","\u9658","\u9933","\u{2BC1B}"],tu\u014D:["\u4F82","\u5483","\u549C","\u572B","\u6258","\u62D5","\u62D6","\u6C51","\u812B","\u8131","\u838C","\u88A5","\u8A17","\u8BAC","\u98E5","\u9966","\u9B60","\u9BB5"],k\u01CEn:["\u4F83","\u5058","\u519A","\u574E","\u60C2","\u780D","\u83B0","\u8F21","\u8F57","\u9851"],zh\u00ED:["\u4F84","\u5024","\u503C","\u57F4","\u57F7","\u59EA","\u5B02","\u6220","\u6267","\u646D","\u690D","\u6A34","\u6DD4","\u6F10","\u76F4","\u7983","\u7D77","\u7E36","\u8040","\u804C","\u8077","\u81B1","\u87D9","\u8DD6","\u8E2F","\u8E60","\u8E91","\u8EC4","\u91DE","\u99BD"],g\u0101i:["\u4F85","\u5793","\u59DF","\u5CD0","\u6650","\u7561","\u7974","\u8344","\u8A72","\u8BE5","\u8C65","\u8CC5","\u8CCC","\u8D45","\u9654"],l\u00E1i:["\u4F86","\u4FEB","\u5008","\u5D03","\u5D0D","\u5EB2","\u6765","\u68BE","\u68F6","\u6D9E","\u6DF6","\u730D","\u741C","\u7B59","\u7B82","\u83B1","\u840A","\u9028","\u90F2","\u9338","\u94FC","\u9A0B","\u9BE0","\u9D86","\u9EB3"],ku\u01CE:["\u4F89","\u54B5","\u57AE","\u9299"],g\u014Dng:["\u4F8A","\u516C","\u529F","\u5311","\u5314","\u5868","\u5BAB","\u5BAE","\u5DE5","\u5E4A","\u5F13","\u606D","\u653B","\u675B","\u78BD","\u7CFC","\u7CFF","\u80B1","\u89E5","\u89F5","\u8EAC","\u8EB3","\u9AF8","\u9F94","\u9F9A","\u48BC"],l\u00EC:["\u4F8B","\u4FD0","\u4FEA","\u5088","\u512E","\u5137","\u51D3","\u5229","\u529B","\u52B1","\u52F5","\u5386","\u5389","\u53A4","\u53AF","\u53B2","\u53D3","\u540F","\u5456","\u550E","\u5533","\u56A6","\u56C7","\u575C","\u585B","\u58E2","\u5A33","\u5A6F","\u5C74","\u5CA6","\u60A7","\u60B7","\u6144","\u623E","\u642E","\u66A6","\u66C6","\u66DE","\u6738","\u67A5","\u6803","\u6817","\u681B","\u6AAA","\u6AD4","\u6AEA","\u6B10","\u6B74","\u6B77","\u6CA5","\u6CB4","\u6D96","\u6EA7","\u6FFF","\u701D","\u720F","\u72A1","\u7301","\u73D5","\u746E","\u74C5","\u74D1","\u74E5","\u75AC","\u75E2","\u7667","\u76ED","\u7759","\u7805","\u783A","\u783E","\u78FF","\u792A","\u792B","\u7930","\u79B2","\u79DD","\u7ACB","\u7B20","\u7BE5","\u7C92","\u7C9D","\u7CF2","\u8137","\u82C8","\u8318","\u8354","\u8385","\u8389","\u849A","\u849E","\u85F6","\u86B8","\u86CE","\u86E0","\u8727","\u8777","\u8807","\u8823","\u8A48","\u8B88","\u8D72","\u8F62","\u8F63","\u8F79","\u9148","\u925D","\u96B6","\u96B7","\u96F3","\u9742","\u974B","\u9B01","\u9CE8","\u9D17","\u9DC5","\u9E9C","\u{2BD77}","\u{2C35B}"],y\u012Bn:["\u4F8C","\u51D0","\u5591","\u567E","\u56D9","\u56E0","\u5794","\u5819","\u59FB","\u5A63","\u6114","\u6147","\u6836","\u6C24","\u6D07","\u6EB5","\u6FE6","\u7616","\u798B","\u79F5","\u7B43","\u7D6A","\u7DF8","\u8335","\u8491","\u852D","\u88C0","\u8AF2","\u92A6","\u94DF","\u95C9","\u9625","\u9634","\u9670","\u967B","\u9682","\u9712","\u9720","\u9787","\u97F3","\u97FE","\u99F0","\u9A83","\u9F57","\u{2C621}","\u{2C907}","\u{2CBB1}"],m\u01D0:["\u4F8E","\u5B4A","\u5F2D","\u6549","\u6D23","\u6E33","\u7056","\u7C73","\u7C8E","\u7F8B","\u8112","\u8288","\u845E","\u851D","\u92A4"],zh\u016B:["\u4F8F","\u682A","\u69E0","\u6A65","\u6AE7","\u6AEB","\u6D19","\u6F74","\u7026","\u732A","\u73E0","\u7843","\u79FC","\u7D51","\u8331","\u854F","\u86DB","\u876B","\u8829","\u88BE","\u8A85","\u8AF8","\u8BDB","\u8BF8","\u8C6C","\u8DE6","\u90BE","\u9296","\u94E2","\u99EF","\u9BA2","\u9BFA","\u9D38","\u9F04"],\u0101n:["\u4F92","\u5063","\u5A95","\u5B89","\u5CD6","\u5EB5","\u6849","\u6C28","\u76E6","\u76EB","\u8164","\u83F4","\u843B","\u844A","\u84ED","\u8A9D","\u8AF3","\u8C19","\u978C","\u978D","\u97FD","\u99A3","\u9B9F","\u9D6A","\u9D95","\u9E4C","\u{29F7E}"],l\u00F9:["\u4F93","\u50C7","\u52CE","\u52E0","\u5725","\u5774","\u5876","\u5A3D","\u5CCD","\u5ED8","\u5F54","\u5F55","\u622E","\u645D","\u6902","\u6A1A","\u6DD5","\u6DE5","\u6E0C","\u6F09","\u6F5E","\u742D","\u7490","\u752A","\u76DD","\u7769","\u7849","\u797F","\u7984","\u7A11","\u7A4B","\u7B93","\u7C0F","\u7C2C","\u7C35","\u7C36","\u7C59","\u7CB6","\u850D","\u8557","\u8642","\u87B0","\u8CC2","\u8D42","\u8DA2","\u8DEF","\u8E1B","\u8E57","\u8F05","\u8F46","\u8F82","\u8F98","\u902F","\u9181","\u9304","\u9332","\u9334","\u93F4","\u9678","\u9A04","\u9A3C","\u9BE5","\u9D3C","\u9D66","\u9D71","\u9DFA","\u9E6D","\u9E7F","\u9E93","\u{2B627}"],m\u00F3u:["\u4F94","\u52BA","\u6048","\u7738","\u86D1","\u8B00","\u8C0B","\u8E0E","\u936A","\u9D3E","\u9EB0"],\u00E9r:["\u4F95","\u513F","\u5150","\u5152","\u5CCF","\u682D","\u6D0F","\u7CAB","\u800C","\u80F9","\u834B","\u88BB","\u8F00","\u8F5C","\u9651","\u96AD","\u9AF5","\u9B9E","\u9C95","\u9D2F","\u9E38"],"d\xF2ng t\u01D2ng t\xF3ng":["\u4F97"],ch\u00E0:["\u4F98","\u597C","\u59F9","\u5C94","\u6C4A","\u8A6B","\u8BE7"],ch\u00EC:["\u4F99","\u50BA","\u52C5","\u52D1","\u53F1","\u557B","\u5F73","\u605C","\u6157","\u618F","\u61D8","\u62B6","\u6555","\u65A5","\u6758","\u6E41","\u707B","\u70BD","\u70FE","\u71BE","\u75D3","\u75F8","\u761B","\u7FC4","\u7FC5","\u7FE4","\u7FE8","\u815F","\u8D64","\u8DA9","\u906B","\u9253","\u96F4","\u98ED","\u996C","\u9D92","\u9DD8"],"g\xF2ng g\u014Dng":["\u4F9B","\u5171"],zh\u014Du:["\u4F9C","\u5468","\u558C","\u5DDE","\u5F9F","\u6D32","\u6DCD","\u70BF","\u70D0","\u73D8","\u77EA","\u821F","\u8B05","\u8B78","\u8BCC","\u8CD9","\u8D52","\u8F08","\u8F16","\u8F80","\u9031","\u90EE","\u9282","\u970C","\u99F2","\u9A06","\u9D43","\u9E3C"],r\u00FA:["\u4F9E","\u5112","\u5685","\u5982","\u5B2C","\u5B7A","\u5E24","\u66D8","\u6847","\u6E2A","\u6FE1","\u7B4E","\u8339","\u8560","\u85B7","\u8761","\u8815","\u88BD","\u8966","\u909A","\u91B9","\u92A3","\u94F7","\u986C","\u98A5","\u9C6C","\u9D11","\u9D3D"],"ji\xE0n c\xFAn":["\u4F9F"],xi\u00E1:["\u4FA0","\u4FE0","\u5323","\u5CE1","\u5CFD","\u656E","\u6687","\u67D9","\u70A0","\u70DA","\u72CE","\u72ED","\u72F9","\u73E8","\u7455","\u7856","\u7864","\u78AC","\u796B","\u7B6A","\u7E16","\u7FC8","\u821D","\u823A","\u8578","\u8D6E","\u8F44","\u8F96","\u9050","\u935C","\u938B","\u965C","\u967F","\u971E","\u9A22","\u9B7B","\u9DB7","\u9EE0"],l\u01DA:["\u4FA3","\u4FB6","\u5122","\u5415","\u5442","\u5C61","\u5C62","\u5C65","\u6314","\u635B","\u65C5","\u68A0","\u7112","\u7963","\u7A06","\u7A6D","\u7D7D","\u7E37","\u7F15","\u8182","\u8190","\u891B","\u8938","\u90D8","\u92C1","\u94DD"],ta:["\u4FA4"],"ji\u01CEo y\xE1o":["\u4FA5","\u50E5","\u5FBA"],zh\u0113n:["\u4FA6","\u5075","\u5BCA","\u5E27","\u5E2A","\u5E40","\u6438","\u659F","\u6862","\u6968","\u699B","\u6A3C","\u6B9D","\u6D48","\u6E5E","\u6F67","\u6FB5","\u7349","\u73CD","\u73CE","\u7467","\u7504","\u771E","\u771F","\u7827","\u78AA","\u796F","\u798E","\u799B","\u7BB4","\u80D7","\u81FB","\u8474","\u8496","\u84C1","\u85BD","\u8C9E","\u8D1E","\u8F43","\u9049","\u9159","\u91DD","\u9241","\u9331","\u937C","\u9488","\u9C75"],"c\xE8 z\xE8 zh\u0101i":["\u4FA7","\u5074"],ku\u00E0i:["\u4FA9","\u5108","\u51F7","\u54D9","\u5672","\u5726","\u5757","\u584A","\u5DDC","\u5EE5","\u5FEB","\u65DD","\u6B33","\u72EF","\u736A","\u7B77","\u7CE9","\u810D","\u81BE","\u90D0","\u9136","\u9C60","\u9C99"],ch\u00E1i:["\u4FAA","\u5115","\u558D","\u67F4","\u72B2","\u7961","\u8C7A"],n\u00F3ng:["\u4FAC","\u5102","\u519C","\u54DD","\u5665","\u6A82","\u6B01","\u6D53","\u6FC3","\u71F6","\u79AF","\u79FE","\u7A60","\u8113","\u81BF","\u857D","\u895B","\u8B68","\u8FB2","\u8FB3","\u91B2","\u9B1E","\u{2CAA9}"],j\u01D0n:["\u4FAD","\u5118","\u537A","\u53AA","\u5DF9","\u69FF","\u6F0C","\u747E","\u7D27","\u7DCA","\u83EB","\u84F3","\u8B39","\u8C28","\u9326","\u9526","\u9949","\u9991"],"h\xF3u h\xF2u":["\u4FAF","\u77E6"],ji\u01D2ng:["\u4FB0","\u50D2","\u518F","\u56E7","\u6CC2","\u6F83","\u70AF","\u70F1","\u715A","\u715B","\u71B2","\u71DB","\u7A98","\u7D97","\u8927","\u8FE5","\u9008","\u9848","\u988E","\u4339"],"ch\u011Bng t\u01D0ng":["\u4FB1"],"zh\xE8n zh\u0113n":["\u4FB2","\u63D5"],zu\u00F2:["\u4FB3","\u505A","\u5511","\u5750","\u5C9D","\u5C9E","\u5EA7","\u795A","\u7CF3","\u80D9","\u8443","\u8444","\u84D9","\u888F","\u963C"],q\u012Bn:["\u4FB5","\u5153","\u5A87","\u5D5A","\u5D94","\u6B3D","\u887E","\u8A9B","\u94A6","\u9849","\u99F8","\u9A8E","\u9BBC"],j\u00FA:["\u4FB7","\u5579","\u5A45","\u5C40","\u5DC8","\u6908","\u6A58","\u6CE6","\u6DD7","\u6E68","\u7117","\u7291","\u72CA","\u7CB7","\u83CA","\u861C","\u8D9C","\u8DFC","\u8E6B","\u8F02","\u90F9","\u95B0","\u99F6","\u9A67","\u9D59","\u9D74","\u9DAA","\u9F30","\u9F33","\u4D17"],"sh\xF9 d\u014Du":["\u4FB8"],t\u01D0ng:["\u4FB9","\u5722","\u5A17","\u633A","\u6D8F","\u70F6","\u73FD","\u8121","\u8247","\u8A94","\u9832","\u988B"],sh\u00E8n:["\u4FBA","\u613C","\u614E","\u661A","\u6D81","\u6E17","\u6EF2","\u7606","\u762E","\u7718","\u7973","\u80BE","\u80C2","\u8124","\u814E","\u8703","\u8704","\u92E0"],"tu\xEC tu\xF3":["\u4FBB"],n\u00E1n:["\u4FBD","\u5583","\u5A1A","\u62A9","\u6694","\u678F","\u67DF","\u6960","\u7537","\u7558","\u83AE","\u8433","\u9056"],xi\u0101o:["\u4FBE","\u54D3","\u5635","\u56BB","\u56C2","\u5A4B","\u5BAF","\u5BB5","\u5EA8","\u5F47","\u63F1","\u67AD","\u67B5","\u689F","\u6AF9","\u6B4A","\u6BCA","\u6D88","\u6F47","\u701F","\u7071","\u7072","\u70CB","\u7107","\u7307","\u7362","\u75DA","\u75DF","\u785D","\u7863","\u7A99","\u7BAB","\u7C18","\u7C2B","\u7D83","\u7EE1","\u7FDB","\u81AE","\u8427","\u856D","\u8648","\u8653","\u87C2","\u87CF","\u87F0","\u8828","\u8E03","\u900D","\u92B7","\u9500","\u9704","\u98B5","\u9A4D","\u9A81","\u9AC7","\u9AD0","\u9B48","\u9D1E","\u9D35","\u9DCD","\u9E2E"],"bi\xE0n pi\xE1n":["\u4FBF","\u7DF6","\u7F0F"],tu\u01D0:["\u4FC0","\u817F","\u8E46","\u9ABD"],x\u00EC:["\u4FC2","\u5338","\u534C","\u546C","\u588D","\u5C43","\u5C53","\u5C6D","\u5FE5","\u602C","\u6044","\u691E","\u6F5D","\u6F5F","\u6F99","\u7182","\u7294","\u78F6","\u798A","\u7D30","\u7D8C","\u7E18","\u7EC6","\u7EE4","\u8203","\u8204","\u856E","\u8669","\u884B","\u89A4","\u8D69","\u8D87","\u90E4","\u91F3","\u960B","\u9699","\u969F","\u973C","\u993C","\u9969","\u9B29","\u9ED6"],c\u00F9:["\u4FC3","\u5AA8","\u61B1","\u731D","\u7604","\u762F","\u7C07","\u7E2C","\u8128","\u851F","\u8A8E","\u8D97","\u8E27","\u8E3F","\u8E59","\u8E74","\u8E75","\u918B","\u9863","\u9F00"],\u00E9:["\u4FC4","\u56EE","\u5A25","\u5CC9","\u5CE8","\u5CE9","\u6D90","\u73F4","\u7692","\u774B","\u78C0","\u83AA","\u8A1B","\u8A90","\u8B4C","\u8BB9","\u8FD7","\u920B","\u92E8","\u9507","\u981F","\u984D","\u989D","\u9B64","\u9D5D","\u9D5E","\u9E45"],qi\u00FA:["\u4FC5","\u53F4","\u5512","\u56DA","\u5D37","\u5DEF","\u5DF0","\u624F","\u6882","\u6B8F","\u6BEC","\u6C42","\u6C53","\u6CC5","\u6D57","\u6E6D","\u716A","\u72B0","\u738C","\u7403","\u7486","\u76B3","\u76DA","\u7D0C","\u7D7F","\u808D","\u8281","\u838D","\u866C","\u866F","\u86F7","\u88D8","\u89D3","\u89E9","\u8A04","\u8A05","\u8CD5","\u8D47","\u900E","\u9011","\u9052","\u914B","\u91DA","\u91FB","\u92B6","\u9804","\u9B82","\u9BC4","\u9C3D","\u9F3D","\u{28C47}"],x\u00FA:["\u4FC6","\u5F90","\u7991"],"gu\xE0ng ku\u0101ng":["\u4FC7"],k\u00F9:["\u4FC8","\u55BE","\u56B3","\u5E93","\u5EAB","\u5EE4","\u7614","\u7D5D","\u7ED4","\u88B4","\u88E4","\u8932","\u9177"],w\u00F9:["\u4FC9","\u52A1","\u52D9","\u52FF","\u537C","\u575E","\u5862","\u5966","\u5A7A","\u5BE4","\u5C7C","\u5C89","\u5D68","\u5FE2","\u609E","\u609F","\u60AE","\u620A","\u6264","\u6664","\u674C","\u6EA9","\u7110","\u7183","\u7269","\u75E6","\u77F9","\u7AB9","\u7C85","\u8601","\u8AA4","\u8BEF","\u92C8","\u9622","\u9696","\u96FE","\u971A","\u9727","\u9770","\u9A16","\u9A9B","\u9DA9","\u9E5C","\u9F3F","\u9F40"],j\u00F9n:["\u4FCA","\u5101","\u5441","\u57C8","\u5BEF","\u5CFB","\u61CF","\u6343","\u651F","\u6659","\u68DE","\u71C7","\u73FA","\u756F","\u7AE3","\u7B9F","\u8720","\u8CD0","\u90E1","\u9656","\u9915","\u9982","\u99FF","\u9A8F","\u9D54","\u9D55","\u9D58","\u4403"],li\u00E1ng:["\u4FCD","\u589A","\u6881","\u690B","\u6A11","\u7CAE","\u7CB1","\u7CE7","\u826F","\u8F2C","\u8F8C","\u{2B7C5}"],z\u01D4:["\u4FCE","\u5528","\u723C","\u7956","\u7D44","\u7EC4","\u8A5B","\u8BC5","\u93BA","\u963B","\u977B"],"qi\xE0o xi\xE0o":["\u4FCF"],y\u01D2ng:["\u4FD1","\u52C7","\u52C8","\u548F","\u57C7","\u584E","\u5D71","\u5F6E","\u603A","\u607F","\u6080","\u60E5","\u6111","\u6139","\u6142","\u67E1","\u6810","\u6C38","\u6CF3","\u6E67","\u752C","\u86F9","\u8A60","\u8E0A","\u8E34","\u9BD2","\u9CAC"],h\u00F9n:["\u4FD2","\u5031","\u5702","\u5C21","\u6141","\u638D","\u6EB7","\u711D","\u7774","\u89E8","\u8AE2","\u8BE8"],j\u00ECng:["\u4FD3","\u50B9","\u5883","\u598C","\u5A59","\u5A67","\u5F2A","\u5F33","\u5F84","\u5F91","\u656C","\u66D4","\u6871","\u68B7","\u6D44","\u701E","\u734D","\u75C9","\u75D9","\u7ADE","\u7ADF","\u7AEB","\u7AF6","\u7AF8","\u80EB","\u811B","\u8396","\u8AA9","\u8E01","\u8FF3","\u9015","\u93E1","\u955C","\u9756","\u9759","\u975C","\u9D5B"],s\u00E0n:["\u4FD5","\u9590"],p\u011Bi:["\u4FD6"],s\u00FA:["\u4FD7"],x\u012B:["\u4FD9","\u50D6","\u516E","\u51DE","\u5365","\u5380","\u5438","\u550F","\u553D","\u563B","\u564F","\u56B1","\u5915","\u595A","\u5B06","\u5B09","\u5C56","\u5D60","\u5DC7","\u5E0C","\u5F86","\u5FAF","\u606F","\u6089","\u6095","\u60C1","\u60DC","\u6614","\u665E","\u6670","\u6673","\u66E6","\u6790","\u6878","\u69BD","\u6A28","\u6A40","\u6B37","\u6C25","\u6C50","\u6D60","\u6DC5","\u6E13","\u6EAA","\u70EF","\u7101","\u7108","\u711F","\u7184","\u7188","\u7199","\u71B9","\u71BA","\u71BB","\u71E8","\u7214","\u727A","\u7280","\u72A0","\u72A7","\u740B","\u761C","\u7699","\u774E","\u77A6","\u77FD","\u7852","\u78CE","\u7902","\u7A00","\u7A78","\u7AB8","\u7C9E","\u7CE6","\u7DC6","\u7E65","\u7FB2","\u7FD5","\u7FD6","\u80B8","\u80B9","\u819D","\u823E","\u8383","\u83E5","\u84A0","\u8725","\u8785","\u87CB","\u8835","\u897F","\u89F9","\u89FD","\u89FF","\u8B46","\u8C3F","\u8C40","\u8C68","\u8C6F","\u8C95","\u8D65","\u909C","\u910E","\u9145","\u91AF","\u91F8","\u932B","\u93ED","\u940A","\u9474","\u9521","\u96B5","\u990F","\u994E","\u997B","\u9BD1","\u9D57","\u9E02","\u9F37"],l\u01D0:["\u4FDA","\u5A0C","\u5CE2","\u5CF2","\u674E","\u6B1A","\u6D6C","\u6FA7","\u7406","\u793C","\u79AE","\u7CB4","\u88CF","\u88E1","\u8C4A","\u9026","\u9090","\u91B4","\u92F0","\u9502","\u9BC9","\u9C67","\u9C71","\u9CA4","\u9CE2"],b\u01CEo:["\u4FDD","\u5822","\u5AAC","\u5B9D","\u5BDA","\u5BF3","\u5BF6","\u73E4","\u7DE5","\u8446","\u85F5","\u8913","\u8CF2","\u974C","\u98F9","\u98FD","\u9971","\u99C2","\u9CF5","\u9D07","\u9E28"],"y\xFA sh\xF9 y\xF9":["\u4FDE"],"s\xEC q\xED":["\u4FDF"],"x\xECn sh\u0113n":["\u4FE1"],xi\u016B:["\u4FE2","\u4FEE","\u54BB","\u5EA5","\u6A07","\u70CC","\u7F9E","\u8119","\u8129","\u81F9","\u8C85","\u929D","\u9380","\u98CD","\u9948","\u9990","\u9AE4","\u9AF9","\u9BB4","\u9C43","\u9D42","\u9E3A","\u45DB"],d\u00EC:["\u4FE4","\u5059","\u50C0","\u57CA","\u5891","\u58AC","\u5A23","\u5E1D","\u601F","\u65F3","\u688A","\u710D","\u7393","\u750B","\u7731","\u7747","\u78B2","\u7976","\u7998","\u7B2C","\u7DE0","\u7F14","\u8163","\u83C2","\u8482","\u8515","\u8743","\u876D","\u87AE","\u8AE6","\u8C1B","\u8E36","\u9012","\u9013","\u905E","\u9070","\u926A","\u{249DB}","\u45D6"],ch\u00F3u:["\u4FE6","\u5114","\u5B26","\u60C6","\u6101","\u61E4","\u6826","\u71FD","\u7574","\u7587","\u7697","\u7A20","\u7B79","\u7C4C","\u7D52","\u7DA2","\u7EF8","\u83D7","\u8A76","\u8B8E","\u8B90","\u8E0C","\u8E8A","\u9167","\u916C","\u91BB","\u96D4","\u96E0","\u96E6"],zh\u00EC:["\u4FE7","\u506B","\u5128","\u5236","\u5295","\u5781","\u5A21","\u5BD8","\u5E19","\u5E1C","\u5E5F","\u5EA2","\u5EA4","\u5ECC","\u5F58","\u5F8F","\u5F9D","\u5FD7","\u5FEE","\u61E5","\u61EB","\u6303","\u631A","\u63B7","\u646F","\u64F2","\u65D8","\u664A","\u667A","\u6809","\u684E","\u68BD","\u6ACD","\u6ADB","\u6CBB","\u6D37","\u6ECD","\u6EDE","\u6EEF","\u6F4C","\u7004","\u7099","\u71AB","\u72FE","\u7318","\u748F","\u74C6","\u75D4","\u75E3","\u7929","\u7951","\u79E9","\u79F7","\u7A1A","\u7A3A","\u7A49","\u7A92","\u7D29","\u7DFB","\u7F6E","\u7FD0","\u81A3","\u81F3","\u81F4","\u8296","\u86ED","\u889F","\u88A0","\u88FD","\u899F","\u89D7","\u89EF","\u89F6","\u8A8C","\u8C51","\u8C52","\u8CAD","\u8CEA","\u8D04","\u8D28","\u8D3D","\u8DF1","\u8E2C","\u8E93","\u8F0A","\u8F7E","\u90C5","\u928D","\u92D5","\u9455","\u94DA","\u9527","\u965F","\u96B2","\u96C9","\u99E4","\u9A2D","\u9A3A","\u9A47","\u9A98","\u9BEF","\u9D19","\u9DD9","\u9E37","\u{2C0CA}"],"li\u01CE li\u01CEng":["\u4FE9"],ji\u01CEn:["\u4FED","\u5039","\u5109","\u51CF","\u526A","\u583F","\u5F3F","\u5F45","\u6229","\u622C","\u62E3","\u6338","\u6361","\u63C0","\u64BF","\u67A7","\u67EC","\u6898","\u68C0","\u691C","\u6AA2","\u6E1B","\u6E55","\u703D","\u7450","\u7751","\u77BC","\u7877","\u78B1","\u7906","\u7B15","\u7B67","\u7B80","\u7C21","\u7D78","\u7E6D","\u7FE6","\u8327","\u85C6","\u8812","\u88E5","\u8947","\u8949","\u897A","\u8A43","\u8B07","\u8B2D","\u8B7E","\u8C2B","\u8DBC","\u8E47","\u9417","\u9B0B","\u9C0E","\u9E78","\u9E7B","\u9E7C"],hu\u00F2:["\u4FF0","\u549F","\u56AF","\u56BF","\u596F","\u5F60","\u60D1","\u6216","\u64ED","\u65E4","\u66E4","\u6AB4","\u6C8E","\u6E71","\u7016","\u7372","\u7668","\u7713","\u77D0","\u7978","\u798D","\u7A6B","\u7AA2","\u802F","\u81DB","\u8267","\u83B7","\u84A6","\u85FF","\u8816","\u8B0B","\u8CA8","\u8D27","\u9343","\u944A","\u956C","\u96D8","\u970D","\u9743","\u97C4","\u3E0C"],"j\xF9 j\u016B":["\u4FF1","\u636E","\u92F8","\u952F"],xi\u00E0o:["\u4FF2","\u509A","\u52B9","\u54B2","\u54EE","\u5578","\u560B","\u5628","\u562F","\u5B5D","\u6548","\u6585","\u6586","\u6B57","\u6D8D","\u71BD","\u7B11","\u8A68","\u8A9F"],p\u00E1i:["\u4FF3","\u5F98","\u724C","\u72A4","\u7305","\u7C30","\u7C32","\u8F2B"],bi\u00E0o:["\u4FF5","\u9C3E","\u9CD4"],"ch\xF9 t\xEC":["\u4FF6"],f\u00E8i:["\u4FF7","\u5255","\u539E","\u5420","\u5C5D","\u5E9F","\u5EC3","\u5EE2","\u6632","\u66CA","\u6AE0","\u6CB8","\u6FF7","\u72D2","\u7648","\u80BA","\u8409","\u8CBB","\u8D39","\u9428","\u9544","\u966B","\u9745","\u9F23"],f\u00E8ng:["\u4FF8","\u51E4","\u5949","\u6E57","\u7128","\u7148","\u8CF5","\u8D57","\u9CEF","\u9CF3","\u9D0C"],\u01CEn:["\u4FFA","\u5535","\u57EF","\u63DE","\u7F6F","\u92A8","\u94F5"],b\u00E8i:["\u4FFB","\u500D","\u505D","\u5079","\u5099","\u50C3","\u5907","\u6096","\u60EB","\u6102","\u618A","\u6601","\u6896","\u7119","\u726C","\u7295","\u72C8","\u72FD","\u73FC","\u7432","\u789A","\u7999","\u7CD2","\u82DD","\u84D3","\u86FD","\u8919","\u8C9D","\u8D1D","\u8EF0","\u8F29","\u8F88","\u90B6","\u90E5","\u9101","\u92C7","\u943E","\u94A1","\u9781","\u97B4","\u{2C1D9}"],y\u00F9:["\u4FFC","\u5125","\u5585","\u55A9","\u55BB","\u57DF","\u5809","\u59AA","\u5AD7","\u5BD3","\u5CEA","\u5D8E","\u5EBD","\u5F67","\u5FA1","\u6108","\u617E","\u622B","\u6631","\u68DB","\u68DC","\u68EB","\u6AF2","\u6B0E","\u6B1D","\u6B32","\u6BD3","\u6D74","\u6DEF","\u6EEA","\u6F4F","\u6FA6","\u706A","\u7134","\u715C","\u71CF","\u71E0","\u7229","\u72F1","\u7344","\u7389","\u7419","\u7609","\u7652","\u7821","\u7862","\u7872","\u7907","\u7916","\u791C","\u79A6","\u79D7","\u7A22","\u7A36","\u7BFD","\u7C5E","\u7C72","\u7C96","\u7DCE","\u7F6D","\u807F","\u8080","\u8248","\u828B","\u828C","\u831F","\u84AE","\u84E3","\u84F9","\u8577","\u860C","\u871F","\u872E","\u88AC","\u88D5","\u8A89","\u8AED","\u8B7D","\u8C15","\u8C6B","\u8EC9","\u8F0D","\u9033","\u9047","\u9079","\u90C1","\u91A7","\u923A","\u92CA","\u9325","\u942D","\u94B0","\u95BE","\u9608","\u96E4","\u9731","\u9810","\u9884","\u98EB","\u9947","\u996B","\u99AD","\u9A48","\u9A6D","\u9B30","\u9B31","\u9B3B","\u9B4A","\u9C4A","\u9CFF","\u9D25","\u9D27","\u9D2A","\u9D52","\u9DF8","\u9E12","\u9E46","\u9E6C"],x\u012Bn:["\u4FFD","\u567A","\u59A1","\u5B1C","\u5EDE","\u5FC3","\u5FC4","\u5FFB","\u60DE","\u65B0","\u6615","\u677A","\u6B23","\u6B46","\u7098","\u76FA","\u85AA","\u8A22","\u8F9B","\u90A4","\u920A","\u92C5","\u946B","\u950C","\u99A8","\u99AB","\u4723","\u{2BDF7}"],"h\u01D4 ch\xED":["\u4FFF"],ji\u00F9:["\u5003","\u50E6","\u5313","\u531B","\u5336","\u53A9","\u548E","\u5C31","\u5EC4","\u5ECF","\u5ED0","\u6166","\u6344","\u6551","\u65E7","\u67E9","\u67FE","\u6855","\u6B0D","\u6BA7","\u759A","\u81FC","\u8205","\u820A","\u9BE6","\u9DF2","\u9E6B","\u9E94","\u9F68","\u3807"],y\u00E1o:["\u5004","\u509C","\u55C2","\u579A","\u582F","\u59DA","\u5AB1","\u5C27","\u5C2D","\u5CE3","\u5DA2","\u5DA4","\u5FAD","\u63FA","\u6416","\u6447","\u647F","\u669A","\u69A3","\u70D1","\u723B","\u733A","\u73E7","\u7464","\u7476","\u78D8","\u7A91","\u7AAF","\u7AB0","\u80B4","\u8628","\u8B20","\u8B21","\u8C23","\u8EFA","\u8F7A","\u9059","\u9065","\u908E","\u9864","\u98BB","\u98D6","\u9906","\u991A","\u9C29","\u9C59","\u9CD0"],"cu\xEC z\xFA":["\u5005"],"li\u01CEng li\u01CE":["\u5006"],w\u01CEn:["\u5007","\u550D","\u5A49","\u60CB","\u633D","\u665A","\u6665","\u6669","\u667C","\u689A","\u6900","\u742C","\u7579","\u7696","\u76CC","\u7897","\u7DA9","\u7DB0","\u7EFE","\u8118","\u8416","\u8E20","\u8F13","\u92D4"],z\u01D2ng:["\u500A","\u506C","\u50AF","\u5D78","\u603B","\u60E3","\u6374","\u6403","\u6460","\u71EA","\u7DCF","\u7DEB","\u7E02","\u7E3D","\u84D7"],gu\u0101n:["\u500C","\u5173","\u5B98","\u68FA","\u761D","\u764F","\u7AA4","\u8484","\u95A2","\u95D7","\u95DC","\u9C25","\u9C5E","\u9CCF"],ti\u01CEn:["\u500E","\u553A","\u5FDD","\u60BF","\u666A","\u6B84","\u6DDF","\u7753","\u8146","\u8214","\u89A5","\u89CD","\u8CDF","\u932A","\u9902"],m\u00E9n:["\u5011","\u626A","\u636B","\u748A","\u83DB","\u864B","\u9346","\u9494","\u9580","\u9585","\u95E8","\u{2B7A9}"],"d\u01CEo d\xE0o":["\u5012"],"t\xE1n t\xE0n":["\u5013","\u57EE"],"ju\xE8 ju\xE9":["\u5014"],chu\u00ED:["\u5015","\u5782","\u57C0","\u6376","\u6425","\u6858","\u68F0","\u69CC","\u7BA0","\u8144","\u83D9","\u9318","\u939A","\u9524","\u9672","\u9840"],x\u00ECng:["\u5016","\u59D3","\u5A5E","\u5B39","\u5E78","\u6027","\u60BB","\u674F","\u6DAC","\u7DC8","\u81D6","\u8347","\u8395","\u8455"],p\u00E9ng:["\u5017","\u50B0","\u585C","\u5873","\u5F38","\u6189","\u6340","\u670B","\u68DA","\u6916","\u6A25","\u787C","\u7A1D","\u7AFC","\u7BF7","\u7E84","\u81A8","\u8283","\u84EC","\u8615","\u87DA","\u87DB","\u88B6","\u8F23","\u930B","\u945D","\u97F8","\u97FC","\u9A2F","\u9AFC","\u9B05","\u9B14","\u9D6C","\u9E4F"],"t\u01CEng ch\xE1ng":["\u5018"],h\u00F2u:["\u5019","\u539A","\u540E","\u5795","\u5820","\u5F8C","\u6D09","\u8329","\u8C5E","\u9005","\u90C8","\u9B9C","\u9C5F","\u9C8E","\u9C98"],t\u00EC:["\u501C","\u5243","\u568F","\u5694","\u5C49","\u5C5C","\u608C","\u6090","\u60D5","\u60D6","\u623B","\u63A6","\u66FF","\u6711","\u6B52","\u6BA2","\u6D95","\u74CB","\u7B39","\u7C4A","\u8599","\u8905","\u9016","\u9037","\u9AF0","\u9B00","\u9B04"],g\u00E0n:["\u501D","\u51CE","\u5E79","\u69A6","\u6A8A","\u6DE6","\u7068","\u76F0","\u7D3A","\u7EC0","\u8A4C","\u8D11","\u8D63","\u9AAD","\u3F4F"],"li\xE0ng j\xECng":["\u501E","\u9753"],su\u012B:["\u5020","\u54F8","\u590A","\u6ED6","\u6FC9","\u772D","\u7762","\u8295","\u837D","\u837E","\u867D","\u96D6","\u9796"],"ch\xE0ng ch\u0101ng":["\u5021"],ji\u00E9:["\u5022","\u507C","\u5091","\u5226","\u5227","\u523C","\u52AB","\u52BC","\u5369","\u536A","\u5A55","\u5AAB","\u5B51","\u5C8A","\u5D28","\u5D65","\u5DBB","\u5DC0","\u5E6F","\u622A","\u6377","\u63B6","\u64EE","\u6605","\u6762","\u6770","\u6840","\u685D","\u696C","\u6976","\u69A4","\u6D01","\u6ED0","\u6F54","\u72E4","\u776B","\u790D","\u7AED","\u7BC0","\u7FAF","\u83AD","\u84F5","\u86E3","\u8710","\u8818","\u881E","\u883D","\u8871","\u88BA","\u8A10","\u8A70","\u8AB1","\u8BA6","\u8E15","\u8FFC","\u9263","\u937B","\u957C","\u9821","\u9B9A","\u9C92","\u36C3"],"k\u01D2ng k\u014Dng":["\u5025"],ju\u00E0n:["\u5026","\u52B5","\u5946","\u617B","\u684A","\u6DC3","\u72F7","\u7367","\u7737","\u774A","\u7760","\u7D6D","\u7D79","\u7EE2","\u7F65","\u7F82","\u8143","\u8528","\u9104","\u990B"],z\u014Dng:["\u5027","\u582B","\u5B97","\u5D4F","\u5D55","\u60FE","\u6721","\u68D5","\u6936","\u71A7","\u7323","\u78EB","\u7DC3","\u7FEA","\u8159","\u847C","\u876C","\u8C75","\u8E28","\u8E2A","\u8E64","\u9350","\u9441","\u9A0C","\u9A23","\u9A94","\u9B03","\u9B09","\u9B37","\u9BEE","\u9BFC"],n\u00ED:["\u502A","\u576D","\u57FF","\u5C3C","\u5C54","\u6029","\u6DE3","\u730A","\u7C7E","\u8063","\u86AD","\u873A","\u89EC","\u8C8E","\u8DDC","\u8F17","\u90F3","\u922E","\u94CC","\u9713","\u999C","\u9BE2","\u9CB5","\u9E91","\u9F6F","\u{2B410}","\u{2B81C}"],zhu\u014D:["\u502C","\u62D9","\u6349","\u684C","\u68B2","\u68C1","\u68F3","\u69D5","\u6DBF","\u7AA7","\u942F","\u4983"],"w\u014D w\u0113i":["\u502D"],lu\u01D2:["\u502E","\u5246","\u66EA","\u7630","\u7673","\u81DD","\u84CF","\u8803","\u88F8","\u8EB6"],s\u014Dng:["\u502F","\u51C7","\u5A00","\u5D27","\u5D69","\u5EBA","\u61BD","\u677E","\u6780","\u67A9","\u67D7","\u68A5","\u6AA7","\u6DDE","\u6FCD","\u7879","\u83D8","\u9B06"],l\u00E8ng:["\u5030","\u580E","\u6123","\u7756","\u8E1C"],z\u00EC:["\u5033","\u525A","\u5B57","\u6063","\u6E0D","\u6F2C","\u7278","\u7725","\u7726","\u80D4","\u80FE","\u81EA","\u8321","\u8362"],b\u00E8n:["\u5034","\u574C","\u6379","\u64AA","\u6E00","\u7B28","\u9029"],c\u01CEi:["\u5038","\u554B","\u5A47","\u5F69","\u63A1","\u68CC","\u6BDD","\u776C","\u7DB5","\u8DF4","\u8E29"],zh\u00E0i:["\u503A","\u50B5","\u5BE8","\u7635","\u7826"],y\u0113:["\u503B","\u5414","\u564E","\u64E8","\u668D","\u6930","\u6B4B","\u6F71","\u882E"],sh\u00E0:["\u503D","\u553C","\u55A2","\u6B43","\u7B91","\u7FDC","\u7FE3","\u8410","\u95AF","\u970E"],q\u012Bng:["\u503E","\u50BE","\u537F","\u570A","\u5BC8","\u6C22","\u6C2B","\u6DF8","\u6E05","\u873B","\u8EFD","\u8F15","\u8F7B","\u90EC","\u9306","\u944B","\u9751","\u9752","\u9BD6"],y\u012Bng:["\u5040","\u5624","\u565F","\u56B6","\u5A74","\u5A96","\u5AC8","\u5B30","\u5B46","\u5B7E","\u6125","\u6484","\u6516","\u6720","\u685C","\u6A31","\u6AFB","\u6E36","\u7150","\u73F1","\u745B","\u748E","\u74D4","\u7507","\u7516","\u78A4","\u792F","\u7DD3","\u7E93","\u7EEC","\u7F28","\u7F42","\u7F43","\u7F4C","\u81BA","\u82F1","\u83BA","\u8621","\u8767","\u8833","\u892E","\u8B7B","\u8CCF","\u8EC8","\u944D","\u9533","\u9719","\u97FA","\u9D2C","\u9D91","\u9DA7","\u9DAF","\u9DEA","\u9DF9","\u9E0E","\u9E1A","\u9E66","\u9E70","\u44E8"],"ch\u0113ng ch\xE8n":["\u5041","\u722F"],ru\u01CEn:["\u5044","\u670A","\u744C","\u74C0","\u789D","\u791D","\u815D","\u8EDF","\u8F2D","\u8F6F","\u962E"],"zh\xF2ng t\xF3ng":["\u5045"],ch\u01D4n:["\u5046","\u60F7","\u7776","\u8436","\u8822","\u8CF0"],"ji\u01CE ji\xE0":["\u5047"],"j\xEC ji\xE9":["\u5048"],"b\u01D0ng b\xECng":["\u504B"],ru\u00F2:["\u504C","\u53D2","\u5D76","\u5F31","\u6949","\u712B","\u7207","\u7BAC","\u7BDB","\u84BB","\u9100","\u9C19","\u9C2F","\u9DB8"],t\u00ED:["\u504D","\u5397","\u557C","\u55C1","\u5D39","\u6F3D","\u7445","\u777C","\u79B5","\u7A0A","\u7DF9","\u7F07","\u7F64","\u855B","\u8906","\u8B15","\u8DA7","\u8E44","\u8E4F","\u918D","\u9357","\u984C","\u9898","\u9A20","\u9BB7","\u9BF7","\u9CC0","\u9D5C","\u9DE4","\u9E48","\u{2B628}"],w\u0113i:["\u504E","\u5371","\u55B4","\u5A01","\u5A99","\u5DB6","\u5DCD","\u5FAE","\u6104","\u63CB","\u63FB","\u6933","\u6972","\u6EA6","\u70D3","\u7168","\u71F0","\u7653","\u7E05","\u8468","\u8473","\u8587","\u8732","\u875B","\u89A3","\u8A74","\u9036","\u9687","\u9688","\u973A","\u9C03","\u9C04","\u9CC2"],pi\u0101n:["\u504F","\u56E8","\u5AA5","\u6944","\u728F","\u7BC7","\u7FE9","\u9342"],y\u00E0n:["\u5050","\u538C","\u53AD","\u5501","\u55AD","\u5688","\u56A5","\u5830","\u599F","\u59F2","\u5B0A","\u5B3F","\u5BB4","\u5F65","\u5F66","\u6565","\u664F","\u66A5","\u66D5","\u66E3","\u6EDF","\u704E","\u7054","\u7067","\u7069","\u7114","\u7130","\u7131","\u7196","\u71C4","\u726A","\u7312","\u781A","\u786F","\u8273","\u8276","\u8277","\u898E","\u89C3","\u89FE","\u8AFA","\u8B8C","\u8B9E","\u8C1A","\u8C33","\u8C53","\u8C54","\u8D0B","\u8D17","\u8D5D","\u8EC5","\u9140","\u917D","\u91BC","\u91C5","\u96C1","\u990D","\u995C","\u9A10","\u9A13","\u9A34","\u9A57","\u9A60","\u9A8C","\u9B33","\u9CEB","\u9D08","\u9D33","\u9DC3","\u9DF0","\u9F5E"],"t\u01CEng d\xE0ng":["\u5052"],\u00E8:["\u5054","\u530E","\u537E","\u5384","\u545D","\u54A2","\u5669","\u57A9","\u580A","\u582E","\u5C8B","\u5D3F","\u5EC5","\u60AA","\u6115","\u6239","\u627C","\u6424","\u6439","\u64DC","\u6AEE","\u6B5E","\u6B7A","\u6E42","\u7427","\u7808","\u7810","\u7846","\u816D","\u82CA","\u843C","\u855A","\u8685","\u8741","\u89A8","\u8AE4","\u8B8D","\u8C14","\u8C5F","\u8EDB","\u8EF6","\u8F6D","\u904C","\u904F","\u907B","\u9102","\u922A","\u9354","\u9469","\u9537","\u9628","\u9638","\u981E","\u984E","\u989A","\u9913","\u9929","\u997F","\u9C10","\u9C2A","\u9C77","\u9CC4","\u9D9A","\u9E57","\u9F43","\u9F76","\u{2BAC7}","\u{25532}"],xi\u00E9:["\u5055","\u52F0","\u534F","\u5354","\u55CB","\u57A5","\u594A","\u604A","\u6136","\u62F9","\u643A","\u64B7","\u64D5","\u64F7","\u651C","\u659C","\u65EA","\u7181","\u71F2","\u7D8A","\u7DF3","\u7E00","\u7F2C","\u7FD3","\u80C1","\u8105","\u8107","\u810B","\u818E","\u8762","\u887A","\u896D","\u8AE7","\u8B97","\u8C10","\u978B","\u97B5","\u9FA4","\u3666"],ch\u011B:["\u5056","\u626F","\u64A6"],sh\u011Bng:["\u5057","\u6E3B","\u771A"],ch\u0101:["\u505B","\u55CF","\u6260","\u633F","\u63D2","\u63F7","\u7580","\u81FF","\u8256","\u929F","\u9364","\u9538","\u9937"],hu\u00E1ng:["\u505F","\u51F0","\u55A4","\u582D","\u58B4","\u5A93","\u5D32","\u5FA8","\u60F6","\u697B","\u6E5F","\u714C","\u735A","\u745D","\u749C","\u7640","\u7687","\u78FA","\u7A54","\u7BC1","\u7C27","\u824E","\u845F","\u8757","\u87E5","\u8AFB","\u8DAA","\u9051","\u9360","\u9404","\u953D","\u968D","\u97F9","\u992D","\u9A1C","\u9C09","\u9C51","\u9CC7","\u9DEC","\u9EC3","\u9EC4","\u{28C51}"],y\u01CEo:["\u5060","\u54AC","\u5A79","\u5B8E","\u5C86","\u6773","\u67FC","\u699A","\u6E94","\u72D5","\u7A85","\u7A88","\u8200","\u82ED","\u95C4","\u9A15","\u9DD5","\u9F69"],"ch\u01D2u qi\xE0o":["\u5062"],y\u00F3u:["\u5064","\u5C24","\u5EAE","\u6023","\u6C8B","\u6CB9","\u6D5F","\u6E38","\u72B9","\u7336","\u7337","\u7531","\u75A3","\u79DE","\u80AC","\u839C","\u83B8","\u8555","\u86B0","\u8763","\u8A27","\u8F0F","\u8F36","\u9030","\u904A","\u90AE","\u90F5","\u923E","\u94C0","\u99C0","\u9B77","\u9B8B","\u9C7F","\u9C89","\u{2CA0E}"],x\u016B:["\u5066","\u589F","\u5AAD","\u5B03","\u6948","\u6B28","\u6B54","\u71F8","\u759E","\u76F1","\u7D87","\u7E03","\u7E7B","\u80E5","\u8566","\u8657","\u865A","\u865B","\u8751","\u88C7","\u8A0F","\u8A31","\u8ADD","\u8B43","\u8C1E","\u9450","\u9700","\u9808","\u987B","\u987C","\u9A49","\u9B1A","\u9B46","\u9B56","\u{2C8D9}","\u{26221}"],zh\u0101:["\u5067","\u54F3","\u62AF","\u6313","\u63F8","\u6463","\u6A1D","\u6E23","\u76B6","\u89F0","\u8B47","\u9F44","\u9F47"],c\u012B:["\u5068","\u75B5","\u8800","\u8D80","\u9AB4","\u9ACA","\u9F79"],b\u012B:["\u506A","\u5C44","\u6945","\u6BF4","\u8C4D","\u903C","\u9C0F","\u9CBE","\u9D56"],x\u00FAn:["\u5071","\u565A","\u5BFB","\u5C0B","\u5CCB","\u5DE1","\u5EF5","\u5FAA","\u6042","\u63D7","\u6533","\u65EC","\u674A","\u6812","\u686A","\u6A33","\u6D35","\u6D54","\u6F6F","\u71C5","\u71D6","\u73E3","\u7495","\u7543","\u7D03","\u8340","\u87F3","\u8A62","\u8BE2","\u9129","\u9C4F","\u9C58","\u9C9F","\u{2C613}","\u{2CA7D}","\u{2C364}","\u{2C288}"],"c\u0101i s\u012B":["\u5072"],du\u0101n:["\u5073","\u5A8F","\u7AEF","\u890D","\u9374"],\u01D2u:["\u5076","\u5418","\u5614","\u8026","\u8162","\u8545","\u85D5","\u{2C27C}","\u{20676}"],t\u014Du:["\u5077","\u5078","\u936E"],"z\xE1n z\xE1 z\u01CE":["\u507A"],"l\u01DA l\xF3u":["\u507B","\u50C2"],f\u00E8n:["\u507E","\u50E8","\u594B","\u596E","\u5F05","\u5FFF","\u6124","\u61A4","\u7035","\u7793","\u79CE","\u7CAA","\u7CDE","\u81B9","\u9C5D","\u9CBC"],"ku\u01D0 gu\u012B":["\u5080"],s\u01D2u:["\u5081","\u53DC","\u53DF","\u55FE","\u6AE2","\u778D","\u85AE","\u85EA"],"zh\xEC s\u012B t\xED":["\u5082"],s\u00F9:["\u5083","\u50F3","\u55C9","\u5850","\u5851","\u5919","\u5ACA","\u612B","\u619F","\u69A1","\u6A0E","\u6A15","\u6B90","\u6CDD","\u6D91","\u6EAF","\u6EB8","\u6F5A","\u6F65","\u738A","\u73DF","\u749B","\u7C0C","\u7C9B","\u7C9F","\u7D20","\u7E24","\u8083","\u8085","\u8186","\u850C","\u85D7","\u89EB","\u8A34","\u8B16","\u8BC9","\u8C21","\u8D9A","\u8E5C","\u901F","\u9061","\u906C","\u92C9","\u9917","\u9A4C","\u9A95","\u9C50","\u9DEB","\u9E54","\u{2B5E7}"],xi\u0101:["\u5084","\u7146","\u778E","\u8672","\u8C3A","\u98AC","\u9C15"],"yu\xE0n yu\xE1n":["\u5086","\u5A9B"],r\u01D2ng:["\u5087","\u5197","\u5B82","\u6C04","\u8EF5"],n\u00F9:["\u5089","\u6012"],y\u00F9n:["\u508A","\u5B55","\u607D","\u60F2","\u6120","\u614D","\u679F","\u816A","\u8574","\u8580","\u85F4","\u860A","\u891E","\u8C9F","\u8FD0","\u904B","\u90D3","\u9106","\u915D","\u9196","\u919E","\u97D7","\u97DE","\u97F5","\u97FB","\u992B"],"g\xF2u ji\u01CEng":["\u508B"],m\u00E0:["\u508C","\u561C","\u69AA","\u7770","\u7943","\u79A1","\u7F75","\u9581","\u99E1","\u9A82","\u9B15"],b\u00E0ng:["\u508D","\u585D","\u68D2","\u73A4","\u7A16","\u8255","\u84A1","\u872F","\u8B17","\u8C24","\u938A","\u9551"],di\u0101n:["\u508E","\u53A7","\u5D6E","\u5DC5","\u5DD3","\u5DD4","\u6382","\u6527","\u6541","\u69C7","\u6EC7","\u766B","\u7672","\u8E4E","\u985A","\u985B","\u98A0","\u9F7B"],t\u00E1ng:["\u508F","\u5510","\u557A","\u5763","\u5802","\u5858","\u642A","\u68E0","\u69B6","\u6E8F","\u6F1F","\u717B","\u746D","\u78C4","\u799F","\u7BD6","\u7CC3","\u7CD6","\u7CDB","\u8185","\u819B","\u84CE","\u8797","\u87B3","\u8D6F","\u8E3C","\u910C","\u91A3","\u9395","\u969A","\u9939","\u9944","\u9DB6","\u48D8"],h\u00E0o:["\u5090","\u54E0","\u604F","\u660A","\u6626","\u6667","\u66A0","\u66A4","\u66AD","\u66CD","\u6D69","\u6DCF","\u6F94","\u704F","\u705D","\u7693","\u769C","\u769E","\u76A1","\u76A5","\u8017","\u8055","\u8583","\u865F","\u9117","\u9865","\u98A2","\u9C1D"],"x\u012B x\xEC":["\u5092"],sh\u0101n:["\u5093","\u5220","\u522A","\u527C","\u5738","\u5C71","\u633B","\u6427","\u67F5","\u6A86","\u6F78","\u6F98","\u717D","\u72E6","\u73CA","\u7B18","\u7E3F","\u7FB4","\u7FB6","\u8120","\u8222","\u829F","\u886B","\u8DDA","\u8ED5","\u9096","\u958A","\u9BC5"],"qi\xE0n ji\u0101n":["\u5094"],"qu\xE8 ju\xE9":["\u5095","\u57C6"],"c\u0101ng chen":["\u5096"],r\u00F3ng:["\u509B","\u5AB6","\u5AC6","\u5B2B","\u5BB9","\u5CF5","\u5D58","\u5DB8","\u620E","\u6408","\u66E7","\u6804","\u6995","\u69AE","\u69B5","\u6BE7","\u6EB6","\u701C","\u70FF","\u7194","\u72E8","\u7462","\u7A41","\u7D68","\u7ED2","\u7FA2","\u809C","\u8319","\u8338","\u8363","\u84C9","\u877E","\u878D","\u878E","\u8811","\u8923","\u9394","\u9555","\u99E5"],"t\xE0 t\xE0n":["\u509D"],su\u014D:["\u509E","\u5506","\u55CD","\u55E6","\u5A11","\u644D","\u686B","\u68AD","\u7743","\u7C11","\u7C14","\u7FA7","\u838F","\u84D1","\u8D96","\u9BBB"],d\u01CEi:["\u50A3","\u6B79"],z\u00E0i:["\u50A4","\u510E","\u518D","\u5728","\u6257","\u6D05","\u8F09","\u9168"],g\u01D4:["\u50A6","\u53E4","\u5552","\u5C33","\u6132","\u6996","\u69BE","\u6C69","\u6DC8","\u6FF2","\u7014","\u726F","\u76B7","\u76BC","\u76EC","\u77BD","\u7A40","\u7F5F","\u7F96","\u80A1","\u8135","\u81CC","\u85A3","\u86CA","\u8831","\u8A41","\u8BC2","\u8F42","\u9027","\u9237","\u94B4","\u9936","\u9989","\u9F13","\u9F14","\u{26676}"],b\u012Bn:["\u50A7","\u5BBE","\u5F6C","\u658C","\u6915","\u6EE8","\u6FD2","\u6FF1","\u6FF5","\u7015","\u7E7D","\u7F24","\u8668","\u8C69","\u8C73","\u8CD3","\u8CD4","\u90A0","\u944C","\u9554","\u9726","\u986E"],ch\u01D4:["\u50A8","\u5132","\u6775","\u6918","\u695A","\u696E","\u6A9A","\u6FCB","\u74B4","\u7840","\u790E","\u7987","\u8655","\u9F6D","\u9F7C","\u{2CE93}"],nu\u00F3:["\u50A9","\u513A","\u632A","\u689B","\u6A60"],"c\u0101n c\xE0n":["\u50AA"],l\u011Bi:["\u50AB","\u5121","\u53BD","\u5792","\u5841","\u58D8","\u58E8","\u6AD0","\u7045","\u7657","\u77CB","\u78CA","\u7928","\u8012","\u854C","\u857E","\u85DF","\u863D","\u881D","\u8A84","\u8B84","\u8BD4","\u9478","\u9E13"],cu\u012B:["\u50AC","\u51D7","\u5894","\u5D14","\u5D5F","\u615B","\u6467","\u69B1","\u7355","\u78EA","\u93D9"],y\u014Dng:["\u50AD","\u55C8","\u5889","\u58C5","\u5ADE","\u5EB8","\u5EF1","\u6175","\u62E5","\u64C1","\u6EFD","\u7049","\u7245","\u75C8","\u7655","\u7670","\u81C3","\u9095","\u90FA","\u9118","\u93DE","\u955B","\u96CD","\u96DD","\u9954","\u9C45","\u9CD9","\u9DDB"],"z\u0101o c\xE1o":["\u50AE"],s\u01D2ng:["\u50B1","\u5D77","\u6002","\u609A","\u612F","\u616B","\u7AE6","\u8038","\u8073","\u99F7","\u39D0"],\u00E0o:["\u50B2","\u5773","\u5787","\u58BA","\u5961","\u5AEF","\u5C99","\u5CB0","\u5DB4","\u61CA","\u64D9","\u6FB3","\u93CA","\u9A41","\u9A9C"],"q\u012B c\xF2u":["\u50B6"],chu\u01CEng:["\u50B8","\u78E2","\u95D6","\u95EF"],sh\u01CE:["\u50BB","\u510D"],h\u00E0n:["\u50BC","\u57BE","\u608D","\u61BE","\u625E","\u634D","\u6496","\u64BC","\u65F1","\u6658","\u66B5","\u6C49","\u6D86","\u6F22","\u701A","\u710A","\u7302","\u7694","\u7745","\u7FF0","\u839F","\u83E1","\u86FF","\u872D","\u8792","\u8B40","\u8F1A","\u91EC","\u92B2","\u92CE","\u96D7","\u9837","\u9844","\u9894","\u99FB","\u9DBE"],zh\u0101ng:["\u50BD","\u5ADC","\u5F20","\u5F35","\u5F70","\u615E","\u66B2","\u6A1F","\u6F33","\u7350","\u748B","\u7AE0","\u7CBB","\u8501","\u87D1","\u9067","\u9123","\u93F1","\u9926","\u9A3F","\u9C46","\u9E9E"],"y\u0101n y\xE0n":["\u50BF","\u5895","\u5B2E"],"pi\xE0o bi\u0101o":["\u50C4","\u9AA0"],li\u00E0n:["\u50C6","\u581C","\u5AA1","\u604B","\u6200","\u695D","\u6B93","\u6BAE","\u6E45","\u6F4B","\u6FB0","\u7032","\u70BC","\u7149","\u7453","\u7DF4","\u7E9E","\u7EC3","\u8430","\u932C","\u934A","\u93C8","\u94FE","\u9C0A","\u{2CDA0}"],m\u00E0n:["\u3D58","\u50C8","\u5881","\u5E54","\u6162","\u66FC","\u6F2B","\u6FB7","\u71B3","\u734C","\u7E35","\u7F26","\u8504","\u8630","\u9124","\u93DD","\u9558","\u{2C72C}"],"t\xE0n t\u01CEn":["\u50CB"],y\u00EDng:["\u50CC","\u55B6","\u584B","\u5B34","\u650D","\u6979","\u6AFF","\u6E81","\u6E8B","\u6EE2","\u6F46","\u6FD9","\u6FDA","\u6FF4","\u7005","\u701B","\u7020","\u702F","\u7050","\u705C","\u7192","\u71DF","\u7469","\u76C1","\u76C8","\u799C","\u7C5D","\u7C6F","\u7E08","\u8314","\u8367","\u83B9","\u8424","\u8425","\u8426","\u843E","\u84E5","\u85C0","\u86CD","\u8747","\u877F","\u87A2","\u8805","\u8B0D","\u8D0F","\u8D62","\u8FCE","\u93A3"],d\u00F2ng:["\u50CD","\u51BB","\u51CD","\u52A8","\u52D5","\u59DB","\u6219","\u630F","\u680B","\u68DF","\u6E69","\u7850","\u80E8","\u80F4","\u8156","\u8FF5","\u9718","\u99E7"],zhu\u00E0n:["\u50CE","\u556D","\u56C0","\u581F","\u64B0","\u7077","\u7451","\u7BC6","\u815E","\u8483","\u8948","\u8B54","\u994C","\u9994"],xi\u00E0ng:["\u50CF","\u52E8","\u5411","\u56AE","\u59E0","\u5D91","\u66CF","\u6A61","\u73E6","\u7F3F","\u87D3","\u8856","\u8950","\u8C61","\u940C","\u9805","\u9879","\u9C4C"],sh\u00E0n:["\u50D0","\u5584","\u58A0","\u58A1","\u5B17","\u64C5","\u657E","\u692B","\u6A3F","\u6B5A","\u6C55","\u7057","\u759D","\u78F0","\u7E55","\u7F2E","\u81B3","\u87EE","\u87FA","\u8A15","\u8B06","\u8B71","\u8BAA","\u8D0D","\u8D61","\u8D78","\u912F","\u9425","\u994D","\u9A38","\u9A9F","\u9C53","\u9C54","\u9CDD","\u{2BB83}"],"tu\xED tu\u01D0":["\u50D3"],z\u01D4n:["\u50D4","\u5642","\u6499","\u8B50"],p\u00FA:["\u50D5","\u530D","\u5724","\u58A3","\u6FEE","\u735B","\u749E","\u77A8","\u7A59","\u8386","\u83D0","\u83E9","\u8461","\u84B1","\u84B2","\u8D0C","\u917A","\u93F7","\u9564"],l\u00E1o:["\u50D7","\u52B3","\u52B4","\u52DE","\u54F0","\u5D02","\u5D97","\u61A5","\u6725","\u6D76","\u7262","\u75E8","\u7646","\u7A82","\u7C29","\u91AA","\u9412","\u94F9","\u985F","\u9ADD","\u{2BB7C}"],ch\u01CEng:["\u50D8","\u53B0","\u5EE0","\u655E","\u6636","\u6C05","\u92F9","\u{2CB2E}"],gu\u0101ng:["\u50D9","\u5149","\u54A3","\u5799","\u59EF","\u6D38","\u706E","\u7097","\u709A","\u709B","\u70E1","\u73D6","\u80F1","\u832A","\u8F04","\u92A7","\u9EC6","\u{28408}"],li\u00E1o:["\u50DA","\u5639","\u5AFD","\u5BE5","\u5BEE","\u5C1E","\u5C6A","\u5D7A","\u5D9A","\u5D9B","\u5EEB","\u6180","\u6579","\u66B8","\u6A51","\u7360","\u7499","\u7597","\u7642","\u7AC2","\u7C1D","\u7E5A","\u7F2D","\u804A","\u818B","\u81AB","\u85D4","\u87DF","\u8C42","\u8CFF","\u8E58","\u8FBD","\u907C","\u98C9","\u9ACE","\u9DEF","\u9E69"],d\u00E8ng:["\u50DC","\u51F3","\u58B1","\u5D9D","\u6AC8","\u77AA","\u78F4","\u89B4","\u9093","\u9127","\u96A5"],"ch\xE1n zh\xE0n zhu\xE0n":["\u50DD"],b\u014D:["\u50E0","\u5D93","\u62E8","\u64A5","\u64AD","\u6CE2","\u6E8A","\u73BB","\u7676","\u76CB","\u7835","\u7886","\u7921","\u7F3D","\u83E0","\u88B0","\u8E73","\u9262","\u94B5","\u9911","\u997D","\u9A4B","\u9C4D","\u{2CB5B}"],hu\u00EC:["\u50E1","\u532F","\u5349","\u5599","\u5612","\u5696","\u571A","\u5B12","\u5BED","\u5C76","\u5C77","\u5F57","\u5F59","\u5F5A","\u5FBB","\u605A","\u6075","\u60E0","\u6167","\u6193","\u61F3","\u6666","\u66B3","\u69E5","\u6A5E","\u6A85","\u6AD8","\u6C47","\u6CCB","\u6ED9","\u6F53","\u70E9","\u71F4","\u7369","\u74A4","\u77BA","\u784A","\u79FD","\u7A62","\u7BF2","\u7D75","\u7E6A","\u7ED8","\u7FD9","\u7FFD","\u835F","\u8527","\u8559","\u8588","\u8589","\u87EA","\u8A6F","\u8AA8","\u8AF1","\u8B53","\u8B7F","\u8BB3","\u8BF2","\u8CC4","\u8D3F","\u942C","\u95E0","\u9613","\u9767","\u982E","\u986A","\u9892","\u992F","\u{2C91D}","\u{2CB6C}"],chu\u01CEn:["\u50E2","\u5598","\u821B","\u8348","\u8E33"],"ti\u011B ji\xE0n":["\u50E3"],s\u0113ng:["\u50E7","\u9B19"],xi\u00E0n:["\u50E9","\u50F4","\u54EF","\u57B7","\u586A","\u59ED","\u5A0A","\u5BAA","\u5C98","\u5CF4","\u61B2","\u648A","\u665B","\u6A4C","\u6A7A","\u6D80","\u7017","\u732E","\u737B","\u73B0","\u73FE","\u770C","\u774D","\u7CAF","\u7CEE","\u7D64","\u7DAB","\u7DDA","\u7EBF","\u7F10","\u7FA1","\u7FA8","\u817A","\u81D4","\u81FD","\u82CB","\u83A7","\u8AA2","\u8C4F","\u92E7","\u930E","\u9650","\u9665","\u9677","\u9730","\u9921","\u9985","\u9EB2","\u9F38","\u{2C02A}","\u{2AFA2}"],"y\xF9 j\xFA":["\u50EA"],"\xE8 w\u016B":["\u50EB"],"t\xF3ng zhu\xE0ng":["\u50EE"],l\u01D0n:["\u50EF","\u51DB","\u51DC","\u5EE9","\u5EEA","\u61CD","\u61D4","\u649B","\u6A81","\u6AA9","\u6F9F","\u765B","\u765D"],g\u00F9:["\u50F1","\u51C5","\u56FA","\u580C","\u5D13","\u5D2E","\u6545","\u688F","\u68DD","\u727F","\u75FC","\u797B","\u932E","\u9522","\u96C7","\u9867","\u987E","\u9BDD","\u9CB4"],ji\u0101ng:["\u50F5","\u58C3","\u59DC","\u6A7F","\u6BAD","\u6C5F","\u7555","\u7585","\u7913","\u7E6E","\u7F30","\u7FDE","\u8333","\u8441","\u8591","\u8780","\u87BF","\u8C47","\u97C1","\u9C42","\u9CC9"],m\u01D0n:["\u50F6","\u51BA","\u5221","\u52C4","\u60AF","\u60FD","\u610D","\u615C","\u61AB","\u62BF","\u6543","\u654F","\u656F","\u6CEF","\u6F63","\u76BF","\u7B22","\u7B3D","\u7C22","\u8820","\u9594","\u95A9","\u95F5","\u95FD","\u9C35","\u9CD8","\u9EFD"],j\u00ECn:["\u50F8","\u51DA","\u5664","\u568D","\u5890","\u58D7","\u5997","\u5B27","\u6422","\u6649","\u664B","\u6783","\u6BA3","\u6D55","\u6D78","\u6E8D","\u6FC5","\u6FDC","\u70EC","\u7161","\u71FC","\u740E","\u7468","\u74B6","\u76E1","\u7972","\u7E09","\u7F19","\u8369","\u85CE","\u89B2","\u89D0","\u8CEE","\u8D10","\u8D46","\u8FD1","\u8FDB","\u9032","\u9773","\u9F7D"],"ji\xE0 jie":["\u50F9"],qi\u00E0o:["\u50FA","\u5CED","\u5E29","\u64AC","\u6BBB","\u7A8D","\u7AC5","\u8A9A","\u8BEE","\u8E88","\u9657","\u97A9","\u97D2","\u9ADA"],p\u00EC:["\u50FB","\u5AB2","\u5AD3","\u5C41","\u6FBC","\u7513","\u7588","\u8B6C","\u95E2","\u9DFF","\u9E0A","\u4D19"],s\u00E0i:["\u50FF","\u7C3A","\u8CFD","\u8D5B"],"ch\xE1n t\u01CEn sh\xE0n":["\u5103"],"d\u0101ng d\xE0ng":["\u5105","\u5F53","\u95E3"],xu\u0101n:["\u5107","\u55A7","\u5847","\u5A97","\u5BA3","\u6103","\u610B","\u63CE","\u660D","\u6684","\u714A","\u7156","\u7444","\u777B","\u77CE","\u79A4","\u7BAE","\u7FE7","\u7FFE","\u8431","\u8432","\u84D2","\u857F","\u85FC","\u8610","\u8756","\u8809","\u8AE0","\u8AFC","\u8B5E","\u8C16","\u8ED2","\u8F69","\u9379","\u99FD","\u9C1A","\u{2B4F6}","\u{2B37D}"],"d\u0101n d\xE0n":["\u510B","\u64D4","\u7605"],c\u00E0n:["\u510F","\u6FAF","\u707F","\u71E6","\u74A8","\u7CB2","\u8592","\u8B32"],"b\u012Bn b\xECn":["\u5110"],"\xE1n \xE0n":["\u5111"],t\u00E1i:["\u5113","\u576E","\u5B2F","\u62AC","\u64E1","\u6AAF","\u70B1","\u70B2","\u7C49","\u81FA","\u85B9","\u8DC6","\u90B0","\u98B1","\u9B90","\u9C90"],l\u00E1n:["\u5116","\u5170","\u56D2","\u5A6A","\u5C9A","\u5D50","\u5E71","\u62E6","\u6514","\u6593","\u6595","\u680F","\u6B04","\u6B17","\u6F9C","\u703E","\u7046","\u7061","\u71E3","\u71F7","\u74BC","\u7BEE","\u7C43","\u7C63","\u7E7F","\u847B","\u84DD","\u85CD","\u862B","\u862D","\u8934","\u8955","\u8964","\u8974","\u897D","\u8B4B","\u8B95","\u8C30","\u8E9D","\u946D","\u9567","\u95CC","\u9611","\u97CA","\u{2C497}"],"n\u01D0 y\xEC \xE0i y\xED":["\u5117"],m\u00E9ng:["\u511A","\u5E6A","\u66DA","\u6726","\u6A57","\u6AAC","\u6C0B","\u6E95","\u6FDB","\u750D","\u753F","\u76DF","\u791E","\u8268","\u8394","\u840C","\u8544","\u867B","\u8771","\u9133","\u9138","\u973F","\u9740","\u986D","\u995B","\u9BCD","\u9E0F","\u9E72","\u{2B461}","\u3813"],n\u00EDng:["\u511C","\u51DD","\u549B","\u5680","\u5B23","\u67E0","\u6A63","\u6AB8","\u72DE","\u7370","\u804D","\u8079","\u85B4","\u944F","\u9B21","\u9E0B"],qi\u00F3ng:["\u511D","\u536D","\u5B86","\u60F8","\u618C","\u684F","\u6A69","\u712A","\u712D","\u7162","\u718D","\u743C","\u74CA","\u7758","\u7A77","\u7A79","\u7AAE","\u7AC6","\u7B3B","\u7B47","\u823C","\u8315","\u85D1","\u85ED","\u86E9","\u86EC","\u8D79","\u8DEB","\u909B","\u928E","\u44D6"],li\u00E8:["\u5120","\u51BD","\u5217","\u52A3","\u52BD","\u57D2","\u57D3","\u59F4","\u5CDB","\u5DE4","\u6312","\u6369","\u6835","\u6D0C","\u6D56","\u70C8","\u70EE","\u716D","\u72A3","\u730E","\u731F","\u7375","\u8057","\u811F","\u8322","\u86DA","\u8D94","\u8E90","\u8FFE","\u98B2","\u9B1B","\u9B23","\u9BA4","\u9C72","\u9D37","\u4D15","\u{2B6AD}"],ku\u01CEng:["\u5123","\u593C","\u61ED"],b\u00E0o:["\u5124","\u52FD","\u5831","\u5FC1","\u62A5","\u62B1","\u66D3","\u7206","\u72A6","\u83E2","\u8663","\u86AB","\u8C79","\u924B","\u9464","\u94C7","\u9AB2","\u9AF1","\u9B91","\u9C8D"],bi\u0101o:["\u5126","\u5882","\u5E56","\u5F6A","\u6807","\u6A19","\u6EEE","\u700C","\u719B","\u7202","\u730B","\u762D","\u78E6","\u8198","\u81D5","\u8B24","\u8D06","\u93E2","\u9463","\u9556","\u9573","\u98AE","\u98B7","\u98C6","\u98C7","\u98C8","\u98CA","\u98D1","\u98D9","\u98DA","\u9A6B","\u9A89","\u9ADF"],z\u01CEn:["\u5127","\u5139","\u5646","\u6505","\u661D","\u8DB1","\u8DB2"],h\u00E1o:["\u512B","\u55E5","\u5637","\u5651","\u568E","\u58D5","\u6903","\u6BDC","\u6BEB","\u6FE0","\u7346","\u7354","\u7AD3","\u7C47","\u869D","\u8814","\u8B79","\u8C6A"],q\u00ECng:["\u512C","\u51CA","\u5E86","\u6176","\u6AE6","\u6FEA","\u7883","\u78EC","\u7F44","\u9758"],ch\u00E8n:["\u512D","\u56AB","\u6987","\u6AEC","\u75A2","\u886C","\u896F","\u8B96","\u8C36","\u8D81","\u8D82","\u9F53","\u9F54","\u9F80"],t\u00E9ng:["\u512F","\u5E50","\u6ED5","\u6F1B","\u75BC","\u7C50","\u7C58","\u7E22","\u817E","\u85E4","\u8645","\u87A3","\u8A8A","\u8B04","\u9086","\u99E6","\u9A30","\u9A63","\u9C27","\u4CA2"],"l\u01D2ng l\xF3ng l\xF2ng":["\u5131"],"ch\xE1n ch\xE0n":["\u5133"],"r\xE1ng xi\u0101ng":["\u5134","\u52F7"],"hu\xEC xi\xE9":["\u5136"],lu\u00F3:["\u5138","\u651E","\u6924","\u6B0F","\u7321","\u7380","\u7BA9","\u7C6E","\u7F57","\u7F85","\u8136","\u8161","\u841D","\u863F","\u87BA","\u89BC","\u903B","\u908F","\u93CD","\u947C","\u9523","\u9559","\u9960","\u9A3E","\u9A58","\u9AA1","\u9E01"],l\u00E9i:["\u513D","\u5AD8","\u6A91","\u6B19","\u74C3","\u757E","\u7E32","\u7E8D","\u7E9D","\u7F27","\u7F4D","\u7FB8","\u8502","\u8632","\u8646","\u8F60","\u9433","\u9458","\u956D","\u96F7","\u9741","\u9C69","\u9F3A"],"n\xE0ng n\u0101ng":["\u513E"],"w\xF9 w\u016B":["\u5140"],y\u01D4n:["\u5141","\u5597","\u593D","\u628E","\u6B92","\u6B9E","\u72C1","\u78D2","\u837A","\u8CF1","\u9217","\u962D","\u9668","\u9695","\u9723","\u99BB","\u9F6B","\u9F73"],z\u0101n:["\u5142","\u6A75","\u7C2A","\u7C2E","\u7CCC","\u9415","\u941F","\u9D64"],yu\u00E1n:["\u5143","\u5186","\u539F","\u53A1","\u53B5","\u56ED","\u5706","\u570E","\u5712","\u5713","\u57A3","\u586C","\u5AB4","\u5AC4","\u63F4","\u699E","\u69AC","\u6A7C","\u6ADE","\u6C85","\u6E72","\u6E90","\u6E92","\u7230","\u7328","\u733F","\u7B0E","\u7DE3","\u7E01","\u7F18","\u7FB1","\u8312","\u8597","\u875D","\u876F","\u8788","\u8881","\u8924","\u8B1C","\u8F45","\u8F95","\u908D","\u90A7","\u915B","\u9228","\u93B1","\u9A35","\u9B6D","\u9DA2","\u9DB0","\u9EFF","\u9F0B","\u{2B62A}"],xi\u014Dng:["\u5144","\u5147","\u51F6","\u5302","\u5308","\u54C5","\u5FF7","\u605F","\u6C79","\u6D36","\u80F7","\u80F8","\u828E","\u8A29","\u8A7E","\u8BBB"],ch\u014Dng:["\u5145","\u5603","\u5FE1","\u6183","\u61A7","\u644F","\u6C96","\u6D7A","\u73EB","\u7F7F","\u7FC0","\u8202","\u825F","\u833A","\u885D","\u8E56","\u3CD8"],zh\u00E0o:["\u5146","\u5797","\u65D0","\u66CC","\u679B","\u6AC2","\u7167","\u71F3","\u72E3","\u77BE","\u7B0A","\u7F40","\u7F69","\u7F84","\u8081","\u8087","\u8088","\u8A54","\u8BCF","\u8D75","\u8D99","\u9BA1","\u{2CD90}"],"du\xEC ru\xEC yu\xE8":["\u514A","\u514C","\u5151"],k\u00E8:["\u514B","\u523B","\u52C0","\u52CA","\u5801","\u5A14","\u5BA2","\u606A","\u6119","\u6C2A","\u6E98","\u78A6","\u7DD9","\u7F02","\u8250","\u8849","\u8AB2","\u8BFE","\u9301","\u951E","\u9A0D","\u9A92"],t\u00F9:["\u514E","\u5154","\u580D","\u8FCC","\u9D75"],d\u01CEng:["\u515A","\u6529","\u6B13","\u8B61","\u8B9C","\u8C20","\u9EE8","\u{235CB}"],d\u014Du:["\u515C","\u5160","\u5517","\u6A77","\u7BFC","\u8538"],hu\u01CEng:["\u5164","\u595B","\u5E4C","\u6033","\u604D","\u6644","\u70BE","\u7180","\u7E28","\u8A64","\u8B0A","\u8C0E"],r\u00F9:["\u5165","\u55D5","\u5AB7","\u6256","\u6741","\u6D33","\u6EBD","\u7E1F","\u7F1B","\u84D0","\u8925","\u9CF0"],n\u00E8i:["\u5167","\u6C1D","\u6C1E","\u9317"],"y\xFA sh\xF9":["\u516A"],"li\xF9 l\xF9":["\u516D"],han:["\u516F","\u7233"],ti\u0101n:["\u5172","\u5929","\u5A56","\u6DFB","\u915F","\u9754","\u975D","\u9EC7"],"x\u012Bng x\xECng":["\u5174"],di\u01CEn:["\u5178","\u56B8","\u594C","\u5A70","\u655F","\u6923","\u70B9","\u7898","\u84A7","\u8547","\u8E2E","\u9EDE"],"z\u012B c\xED":["\u5179"],ji\u0101n:["\u517C","\u51BF","\u56CF","\u575A","\u5805","\u5978","\u59E6","\u59E7","\u5C16","\u5E75","\u60E4","\u620B","\u6214","\u641B","\u693E","\u6A2B","\u6AFC","\u6B7C","\u6BB1","\u6BB2","\u6E54","\u7010","\u7038","\u714E","\u719E","\u71B8","\u724B","\u744A","\u7777","\u791B","\u7937","\u7B3A","\u7B8B","\u7DD8","\u7E11","\u7F04","\u7F23","\u80A9","\u8270","\u8271","\u83C5","\u83FA","\u844C","\u84B9","\u852A","\u8551","\u8573","\u8643","\u8B7C","\u8C5C","\u946F","\u96C3","\u97AF","\u97C0","\u97C9","\u9930","\u99A2","\u9C14","\u9C1C","\u9C39","\u9CA3","\u9CD2","\u9D51","\u9D73","\u9DBC","\u9E63","\u9E89"],sh\u00F2u:["\u517D","\u53D7","\u552E","\u58FD","\u5900","\u5BFF","\u6388","\u72E9","\u7363","\u7378","\u75E9","\u7626","\u7DAC","\u7EF6","\u8184"],j\u00EC:["\u517E","\u5180","\u5242","\u5264","\u5291","\u52E3","\u5756","\u578D","\u5848","\u5993","\u5B63","\u5BC2","\u5BC4","\u5EED","\u5F51","\u5F9B","\u5FCC","\u60B8","\u60CE","\u61FB","\u6280","\u65E1","\u65E2","\u65E3","\u66A8","\u66A9","\u66C1","\u689E","\u6A95","\u6AB5","\u6D0E","\u6F03","\u6F08","\u7031","\u75F5","\u7660","\u799D","\u7A29","\u7A37","\u7A44","\u7A4A","\u7A67","\u7D00","\u7D99","\u7E3E","\u7E4B","\u7E7C","\u7EE7","\u7EE9","\u7F7D","\u81EE","\u82B0","\u830D","\u8324","\u846A","\u84DF","\u8507","\u858A","\u860E","\u862E","\u863B","\u88DA","\u8940","\u89AC","\u89CA","\u8A08","\u8A18","\u8A8B","\u8BA1","\u8BB0","\u8DE1","\u8DFD","\u8E5F","\u8FF9","\u9645","\u969B","\u9701","\u973D","\u9A65","\u9AA5","\u9AFB","\u9B3E","\u9B5D","\u9B65","\u9BDA","\u9BFD","\u9C36","\u9C3F","\u9C40","\u9C6D","\u9C9A","\u9CAB","\u9D4B","\u9DD1","\u9F4C","\u{2A7DD}","\u{2CDA8}","\u{2CDAD}"],ji\u014Dng:["\u5182","\u518B","\u5770","\u57DB","\u6243","\u860F","\u8614","\u99C9","\u99EB","\u{2CCF6}"],m\u00E0o:["\u5183","\u5190","\u5AA2","\u5E3D","\u6117","\u61CB","\u6693","\u67D5","\u6959","\u6BF7","\u7441","\u7683","\u770A","\u7780","\u8004","\u8302","\u843A","\u8750","\u88A4","\u8992","\u8C8C","\u8CBF","\u8D38","\u911A","\u912E"],r\u01CEn:["\u5184","\u5189","\u59CC","\u5AA3","\u67D3","\u73C3","\u82D2","\u8485","\u4383"],"n\xE8i n\xE0":["\u5185"],g\u0101ng:["\u5188","\u51AE","\u521A","\u525B","\u5808","\u583D","\u5CA1","\u6386","\u6443","\u68E1","\u7268","\u7285","\u7598","\u7DB1","\u7EB2","\u7F38","\u7F41","\u7F61","\u809B","\u91ED","\u93A0","\u3B4E"],c\u00E8:["\u518A","\u518C","\u5395","\u53A0","\u5928","\u5EC1","\u607B","\u60FB","\u61A1","\u6547","\u6D4B","\u6E2C","\u7B27","\u7B56","\u7B5E","\u7B74","\u7BA3","\u835D","\u8417","\u8434","\u84DB"],gu\u01CE:["\u518E","\u5250","\u526E","\u53E7","\u5BE1"],"m\xE0o m\xF2":["\u5192"],g\u00F2u:["\u5193","\u5542","\u5778","\u57A2","\u591F","\u5920","\u5ABE","\u5F40","\u6406","\u6480","\u6784","\u69CB","\u7179","\u89AF","\u89CF","\u8A3D","\u8A6C","\u8BDF","\u8CFC","\u8D2D","\u9058","\u96CA"],x\u01D4:["\u5194","\u55A3","\u668A","\u6829","\u73DD","\u76E8","\u7CC8","\u8A61","\u8AFF","\u8BE9","\u9126","\u9191"],m\u00EC:["\u5196","\u51AA","\u5627","\u5853","\u5BBB","\u5BC6","\u5CDA","\u5E42","\u5E4E","\u5E66","\u603D","\u6993","\u6A12","\u6AC1","\u6C68","\u6DE7","\u6EF5","\u6F1E","\u6FD7","\u7190","\u7F83","\u8524","\u871C","\u8993","\u8994","\u899B","\u89C5","\u8B10","\u8C27","\u9F0F"],"y\xF3u y\xEDn":["\u5198"],xi\u011B:["\u5199","\u51A9","\u85DB"],j\u016Bn:["\u519B","\u541B","\u5747","\u687E","\u6C6E","\u76B2","\u76B8","\u76B9","\u7885","\u8399","\u8690","\u8880","\u89A0","\u8ECD","\u921E","\u9281","\u929E","\u9355","\u94A7","\u9835","\u9BB6","\u9CAA","\u9E8F"],m\u00ED:["\u519E","\u64DF","\u7030","\u7222","\u7315","\u737C","\u7962","\u79B0","\u7E3B","\u84BE","\u85CC","\u862A","\u863C","\u88AE","\u8A78","\u8B0E","\u8FF7","\u919A","\u91BE","\u91BF","\u91C4","\u957E","\u9E0D","\u9E8A","\u9E8B","\u9E9B"],"gu\u0101n gu\xE0n":["\u51A0","\u898C","\u89B3","\u89C0","\u89C2"],m\u011Bng:["\u51A1","\u52D0","\u61F5","\u63B9","\u731B","\u7374","\u824B","\u8722","\u8813","\u9333","\u9530","\u9BED","\u9F06"],zh\u01D2ng:["\u51A2","\u585A","\u5C30","\u6B71","\u7144","\u7607","\u80BF","\u816B","\u8E35"],zu\u00EC:["\u51A3","\u5DB5","\u666C","\u6700","\u682C","\u69DC","\u6A87","\u6A8C","\u797D","\u7D4A","\u7F6A","\u855E","\u8FA0","\u9154","\u917B","\u9189","\u930A"],yu\u0101n:["\u51A4","\u5248","\u56E6","\u5B3D","\u5BC3","\u68E9","\u6DF5","\u6E01","\u6E06","\u6E0A","\u6E15","\u7041","\u7722","\u8099","\u847E","\u84AC","\u870E","\u8735","\u99CC","\u9CF6","\u9D1B","\u9D77","\u9E22","\u9E33","\u9E53","\u9F18","\u9F1D"],m\u00EDng:["\u51A5","\u540D","\u660E","\u669D","\u6719","\u69A0","\u6D3A","\u6E9F","\u733D","\u7700","\u7733","\u7791","\u8317","\u879F","\u89AD","\u8A7A","\u910D","\u9298","\u94ED","\u9CF4","\u9E23"],k\u00F2u:["\u51A6","\u53E9","\u5BBC","\u5BC7","\u6263","\u6542","\u6EF1","\u7A9B","\u7B58","\u7C06","\u8532","\u853B","\u91E6","\u9DC7"],t\u00E0i:["\u51AD","\u592A","\u5933","\u5FF2","\u6001","\u614B","\u6C70","\u6C71","\u6CF0","\u6E99","\u80BD","\u8226","\u915E","\u9226","\u949B"],"f\xE9ng p\xEDng":["\u51AF","\u99AE"],"ch\u014Dng ch\xF2ng":["\u51B2"],ku\u00E0ng:["\u51B5","\u5739","\u58D9","\u5CB2","\u61EC","\u65F7","\u663F","\u66E0","\u6846","\u6CC1","\u720C","\u7716","\u7736","\u77FF","\u783F","\u7926","\u7A6C","\u7D4B","\u7D56","\u7E8A","\u7EA9","\u8CBA","\u8D36","\u8EE6","\u909D","\u913A","\u9271","\u92DB","\u945B","\u9ECB"],l\u011Bng:["\u51B7"],p\u00E0n:["\u51B8","\u5224","\u53DB","\u6C9C","\u6CEE","\u6EBF","\u708D","\u7249","\u7554","\u76FC","\u8041","\u88A2","\u897B","\u8A4A","\u92EC","\u947B","\u9816","\u9D65"],f\u0101:["\u51B9","\u5F42","\u6CB7","\u767A","\u767C"],xi\u01CEn:["\u51BC","\u5C1F","\u5C20","\u5D04","\u5DAE","\u5E70","\u6507","\u663E","\u6AF6","\u6BE8","\u7066","\u70CD","\u71F9","\u72DD","\u7303","\u736B","\u736E","\u7381","\u7992","\u7B45","\u7BB2","\u85D3","\u861A","\u86AC","\u8706","\u8B63","\u8D7B","\u8DE3","\u934C","\u9669","\u967A","\u96AA","\u97C5","\u9855","\u986F","\u3B0E"],qi\u00E0:["\u51BE","\u5736","\u5E22","\u6070","\u6B8E","\u6D3D","\u7848","\u80E2","\u9AC2"],"j\xECng ch\u0113ng":["\u51C0","\u51C8","\u6DE8"],s\u014Du:["\u51C1","\u55D6","\u5EC0","\u5ECB","\u635C","\u641C","\u6449","\u6EB2","\u7340","\u8258","\u8490","\u878B","\u910B","\u9199","\u93AA","\u953C","\u98BC","\u98D5","\u993F","\u998A","\u9A2A"],m\u011Bi:["\u51C2","\u5A84","\u5ABA","\u5B0D","\u5D44","\u6334","\u6BCE","\u6BCF","\u6D7C","\u6E3C","\u71D8","\u7F8E","\u8EBE","\u9382","\u9541","\u9EE3"],t\u00FA:["\u51C3","\u56F3","\u56FE","\u5716","\u5717","\u5857","\u5C60","\u5CF9","\u5D5E","\u5EA9","\u5EDC","\u5F92","\u6087","\u63EC","\u6D82","\u760F","\u7B61","\u816F","\u837C","\u84A4","\u8DFF","\u9014","\u9174","\u922F","\u934E","\u999F","\u99FC","\u9D4C","\u9D9F","\u9DCB","\u9DF5","\u{2CCFF}"],zh\u01D4n:["\u51C6","\u51D6","\u57FB","\u6E96","\u{2C62F}"],"li\xE1ng li\xE0ng":["\u51C9","\u6DBC","\u91CF"],di\u0101o:["\u51CB","\u5201","\u521F","\u53FC","\u595D","\u5F34","\u5F6B","\u6C48","\u7431","\u7889","\u7C13","\u866D","\u86C1","\u8C82","\u932D","\u96D5","\u9B89","\u9BDB","\u9CB7","\u9D70","\u9F26"],c\u00F2u:["\u51D1","\u6E4A","\u8160","\u8F33","\u8F8F"],\u00E1i:["\u51D2","\u5540","\u560A","\u6371","\u6EB0","\u764C","\u7691","\u769A"],du\u00F3:["\u51D9","\u526B","\u593A","\u596A","\u75E5","\u8E31","\u922C","\u9438","\u94CE"],d\u00FA:["\u51DF","\u5335","\u5B3B","\u691F","\u6ADD","\u6BB0","\u6D9C","\u724D","\u7258","\u728A","\u72A2","\u72EC","\u7368","\u74C4","\u76BE","\u88FB","\u8AAD","\u8B80","\u8B9F","\u8C44","\u8D15","\u9316","\u945F","\u97C7","\u97E3","\u97E5","\u9A33","\u9AD1","\u9EE9","\u9EF7"],"j\u01D0 j\u012B":["\u51E0"],f\u00E1n:["\u51E1","\u51E2","\u51E3","\u5325","\u58A6","\u674B","\u67C9","\u68E5","\u6A0A","\u703F","\u70E6","\u7169","\u71D4","\u74A0","\u77FE","\u792C","\u7B32","\u7C75","\u7DD0","\u7FB3","\u8224","\u8227","\u85A0","\u8629","\u881C","\u894E","\u8E6F","\u91E9","\u9407","\u9422","\u9492","\u9DED","\u{2B50D}","\u{2CE2A}"],j\u016B:["\u51E5","\u530A","\u5A35","\u5A6E","\u5C45","\u5D0C","\u6285","\u6336","\u63AC","\u68AE","\u6910","\u6A8B","\u6BE9","\u6BF1","\u6CC3","\u6DBA","\u72D9","\u741A","\u75BD","\u7820","\u7F5D","\u8152","\u824D","\u871B","\u88FE","\u8ACA","\u8DD4","\u8E18","\u8EB9","\u9671","\u96CE","\u97A0","\u97AB","\u99D2","\u9A79","\u9B88","\u9D21","\u9D8B","\u{2CD8B}"],"ch\xF9 ch\u01D4":["\u51E6","\u5904"],zh\u01D0:["\u51EA","\u52A7","\u54AB","\u5740","\u5767","\u5E0B","\u6049","\u627A","\u6307","\u65E8","\u67B3","\u6B62","\u6C66","\u6C9A","\u6D14","\u6DFD","\u75BB","\u780B","\u7949","\u79D6","\u7D19","\u7EB8","\u82B7","\u85E2","\u8879","\u8967","\u8A28","\u8DBE","\u8EF9","\u8F75","\u916F","\u962F","\u9EF9"],p\u00EDng:["\u51ED","\u51F4","\u546F","\u576A","\u5840","\u5CBC","\u5E21","\u5E32","\u5E48","\u5E73","\u617F","\u6191","\u67B0","\u6D34","\u7129","\u73B6","\u74F6","\u7501","\u7AEE","\u7BB3","\u7C08","\u7F3E","\u8353","\u840D","\u84F1","\u86B2","\u86E2","\u8A55","\u8BC4","\u8EFF","\u8F27","\u90F1","\u9B83","\u9C86"],k\u01CEi:["\u51EF","\u51F1","\u5240","\u5274","\u57B2","\u584F","\u607A","\u6137","\u6168","\u669F","\u8488","\u8F06","\u9347","\u93A7","\u94E0","\u9534","\u95D3","\u95FF","\u98BD"],g\u0101n:["\u51F2","\u5769","\u5C32","\u5C34","\u5C36","\u5C37","\u67D1","\u6CD4","\u6F27","\u7395","\u7518","\u75B3","\u77F8","\u7AFF","\u7B78","\u7C93","\u809D","\u82F7","\u8FC0","\u9150","\u9B50"],"k\u01CEn qi\u01CEn":["\u51F5"],t\u016B:["\u51F8","\u5817","\u5D80","\u6378","\u6D8B","\u6E65","\u75DC","\u79BF","\u79C3","\u7A81","\u8456","\u92F5","\u9D5A","\u9F35","\u3EEC"],"\u0101o w\u0101":["\u51F9"],ch\u016B:["\u51FA","\u521D","\u5C80","\u6474","\u698B","\u6A17","\u8C99","\u9F63","\u48BA","\u4759"],d\u00E0ng:["\u51FC","\u5735","\u57B1","\u58CB","\u6863","\u6A94","\u6C39","\u7497","\u74FD","\u76EA","\u778A","\u7800","\u78AD","\u7911","\u7C1C","\u8361","\u83EA","\u8569","\u862F","\u8DA4","\u903F","\u96FC","\u{2C361}"],h\u00E1n:["\u51FD","\u51FE","\u542B","\u5705","\u5A22","\u5BD2","\u5D21","\u6657","\u6892","\u6D5B","\u6DB5","\u6F8F","\u7113","\u7400","\u751D","\u7B68","\u872C","\u9097","\u90AF","\u92E1","\u97D3","\u97E9"],z\u00E1o:["\u51FF","\u947F"],d\u0101o:["\u5200","\u5202","\u5FC9","\u6C18","\u8220","\u87A9","\u91D6","\u9B5B","\u9C7D"],chu\u0101ng:["\u5205","\u6450","\u724E","\u7255","\u75AE","\u7621","\u7A93","\u7A97","\u7ABB"],"f\u0113n f\xE8n":["\u5206"],"qi\xE8 qi\u0113":["\u5207"],k\u0101n:["\u520A","\u52D8","\u582A","\u6221","\u681E","\u9F95","\u9F9B"],c\u01D4n:["\u520C","\u5FD6"],ch\u00FA:["\u520D","\u53A8","\u5E6E","\u5EDA","\u6A71","\u6AC9","\u6AE5","\u6EC1","\u7293","\u7BE8","\u8021","\u82BB","\u84A2","\u84AD","\u870D","\u87F5","\u8C60","\u8D8E","\u8E70","\u8E87","\u8E95","\u924F","\u92E4","\u9504","\u9664","\u96CF","\u96DB","\u9DB5"],"hu\xE0 hu\xE1":["\u5212"],l\u00ED:["\u5215","\u5253","\u527A","\u5299","\u5398","\u55B1","\u569F","\u56C4","\u5AE0","\u5B77","\u5EF2","\u60A1","\u68A8","\u68B8","\u68C3","\u6F13","\u7055","\u7281","\u7282","\u72F8","\u740D","\u7483","\u74C8","\u76E0","\u775D","\u79BB","\u7A72","\u7AF0","\u7B63","\u7BF1","\u7C6C","\u7CCE","\u7E2D","\u7F21","\u7F79","\u8243","\u8372","\u83DE","\u84E0","\u853E","\u85DC","\u863A","\u870A","\u87CD","\u87F8","\u882B","\u8935","\u8B27","\u8C8D","\u91A8","\u92EB","\u9305","\u93EB","\u9457","\u96E2","\u9A6A","\u9A8A","\u9BCF","\u9BEC","\u9C7A","\u9CA1","\u9D79","\u9E1D","\u9E42","\u9ECE","\u9EE7","\u3C00"],yu\u00E8:["\u5216","\u5B33","\u5C84","\u5CB3","\u5DBD","\u6071","\u6085","\u60A6","\u6209","\u6288","\u6373","\u6708","\u6A3E","\u7039","\u721A","\u73A5","\u793F","\u79B4","\u7BD7","\u7C46","\u7C65","\u7C70","\u7CA4","\u7CB5","\u8625","\u868E","\u868F","\u8AAC","\u8D8A","\u8DC0","\u8DC3","\u8E8D","\u8ECF","\u9205","\u925E","\u9470","\u94BA","\u95B1","\u95B2","\u9605","\u9E11","\u9E19","\u9EE6","\u9FA0","\u{2B404}","\u{2CE1A}"],li\u00FA:["\u5218","\u5289","\u56A0","\u5AB9","\u5D67","\u65C8","\u65D2","\u69B4","\u6A4A","\u6D41","\u6D4F","\u700F","\u7409","\u7460","\u746C","\u74A2","\u7544","\u7559","\u7571","\u7581","\u7624","\u7645","\u786B","\u84A5","\u84C5","\u87C9","\u88D7","\u938F","\u93D0","\u9402","\u9560","\u98C0","\u98C5","\u98D7","\u99E0","\u99F5","\u9A2E","\u9A51","\u9A9D","\u9C21","\u9DB9","\u9E60","\u9E8D"],z\u00E9:["\u5219","\u5247","\u5567","\u5616","\u5AE7","\u5E3B","\u5E58","\u629E","\u6A0D","\u6B75","\u6CA2","\u6CCE","\u6EAD","\u769F","\u7794","\u77E0","\u790B","\u7BA6","\u7C00","\u8234","\u8536","\u880C","\u8957","\u8B2E","\u8CFE","\u8D5C","\u8FEE","\u9E05","\u9F5A","\u9F70"],"chu\xE0ng chu\u0101ng":["\u521B","\u5275"],q\u00F9:["\u521E","\u53BA","\u53BB","\u95B4","\u95C3","\u9612","\u9EAE","\u9F01"],"bi\xE9 bi\xE8":["\u5225","\u522B"],"p\xE1o b\xE0o":["\u5228"],"ch\u01CEn ch\xE0n":["\u522C","\u5257","\u5E5D"],gu\u0101:["\u522E","\u5280","\u6870","\u6B44","\u7171","\u74DC","\u80CD","\u8E3B","\u98AA","\u98B3","\u9A27","\u9D30","\u9E39"],g\u0113ng:["\u522F","\u5E9A","\u6929","\u6D6D","\u713F","\u754A","\u7D5A","\u7FAE","\u7FB9","\u8015","\u83EE","\u8CE1","\u8D53","\u9D8A","\u9E52"],d\u00E0o:["\u5230","\u5675","\u60BC","\u6921","\u6AA4","\u71FE","\u74D9","\u76D7","\u76DC","\u7A32","\u7A3B","\u7E9B","\u7FFF","\u8254","\u83FF","\u885C","\u885F","\u8EC7","\u9053"],chu\u00E0ng:["\u5231","\u524F","\u5259","\u6006","\u6134"],k\u016B:["\u5233","\u54ED","\u5710","\u5800","\u67AF","\u684D","\u77FB","\u7A9F","\u8DCD","\u90C0","\u9AB7","\u9BAC"],du\u00F2:["\u5234","\u5241","\u58AF","\u5C2E","\u60F0","\u619C","\u6305","\u6857","\u8235","\u8DE5","\u8DFA","\u964A","\u964F","\u98FF","\u9973","\u9D7D"],"shu\u0101 shu\xE0":["\u5237"],"qu\xE0n xu\xE0n":["\u5238"],"ch\xE0 sh\u0101":["\u5239","\u524E"],"c\xEC c\u012B":["\u523A"],gu\u00EC:["\u523D","\u523F","\u528A","\u528C","\u648C","\u6530","\u660B","\u6842","\u6922","\u69F6","\u6A3B","\u6AC3","\u7324","\u79AC","\u7B40","\u84D5","\u8958","\u8CB4","\u8D35","\u8DEA","\u9400","\u944E","\u97BC","\u9C56","\u9C65"],l\u00F3u:["\u5245","\u5A04","\u5A41","\u5ED4","\u697C","\u6A13","\u6E87","\u6F0A","\u71A1","\u8027","\u802C","\u825B","\u848C","\u851E","\u877C","\u87BB","\u8B31","\u8EC1","\u9071","\u97BB","\u9AC5","\u9ACF","\u{2A8FB}"],cu\u00F2:["\u5249","\u5252","\u539D","\u590E","\u632B","\u63AA","\u68E4","\u839D","\u83A1","\u84CC","\u902A","\u92BC","\u932F","\u9509","\u9519"],"xi\u0101o xu\u0113":["\u524A"],"k\u0113i k\xE8":["\u524B","\u5C05"],"l\xE0 l\xE1":["\u524C"],t\u012B:["\u5254","\u68AF","\u8E22","\u92BB","\u9511","\u9DC8","\u9DC9","\u43F2","\u4D18"],p\u014Du:["\u5256"],w\u0101n:["\u525C","\u5846","\u58EA","\u5E35","\u5F2F","\u5F4E","\u6E7E","\u6F6B","\u7063","\u7755","\u873F","\u8C4C"],"b\u0101o b\u014D":["\u525D","\u5265"],du\u014D:["\u525F","\u5484","\u54C6","\u5689","\u591A","\u591B","\u6387","\u6BF2","\u7553","\u88F0","\u364D"],q\u00EDng:["\u5260","\u52CD","\u591D","\u60C5","\u64CE","\u6674","\u6692","\u68FE","\u6A08","\u6AA0","\u6C30","\u7520","\u7858","\u845D","\u9EE5"],"y\u01CEn sh\xE0n":["\u5261"],"d\u016B zhu\xF3":["\u5262"],y\u0101n:["\u5266","\u5AE3","\u5D26","\u5D96","\u6079","\u61D5","\u61E8","\u6A2E","\u6DCA","\u6DF9","\u6F39","\u70DF","\u7109","\u7111","\u7159","\u73DA","\u7BF6","\u80ED","\u81D9","\u83F8","\u9122","\u9183","\u95B9","\u9609","\u9EEB"],hu\u014D:["\u5268","\u5290","\u5419","\u6509","\u79F4","\u8020","\u952A","\u9A1E","\u{2CD03}"],sh\u00E8ng:["\u5269","\u5270","\u52DD","\u5723","\u58AD","\u5D4A","\u6660","\u69BA","\u6A73","\u741E","\u8056","\u8542","\u8CB9","\u8CF8"],"du\u0101n zh\xEC":["\u526C"],w\u016B:["\u526D","\u545C","\u55DA","\u572C","\u5C4B","\u5DEB","\u5F19","\u6747","\u6B4D","\u6C59","\u6C5A","\u6C61","\u6D3F","\u70CF","\u7A8F","\u7BBC","\u8790","\u8A88","\u8AA3","\u8BEC","\u90AC","\u9114","\u93A2","\u94A8","\u9C1E","\u9D2E"],g\u0113:["\u5272","\u54E5","\u572A","\u5F41","\u6208","\u6213","\u6228","\u6B4C","\u6ED2","\u72B5","\u8090","\u88BC","\u8B0C","\u93B6","\u9D1A","\u9D3F","\u9E3D"],"d\xE1 zh\xE1":["\u5273"],chu\u00E1n:["\u5276","\u66B7","\u693D","\u7BC5","\u8221","\u8229","\u8239","\u8F32","\u9044"],"tu\xE1n zhu\u0101n":["\u5278","\u6F19","\u7BFF"],"l\xF9 ji\u016B":["\u5279"],p\u0113ng:["\u527B","\u5309","\u562D","\u6026","\u6072","\u62A8","\u6888","\u70F9","\u7830","\u8EEF","\u99CD"],pi\u0101o:["\u527D","\u52E1","\u6153","\u65DA","\u72A5","\u7FF2","\u87B5","\u98C3","\u98C4","\u98D8","\u9B52"],k\u014Du:["\u527E","\u5F44","\u62A0","\u6473","\u770D","\u7798","\u82A4","\u{2BE29}"],"ji\u01CEo ch\u0101o":["\u527F","\u528B","\u52E6","\u6477"],qi\u0101o:["\u5281","\u52EA","\u589D","\u5E67","\u6572","\u6A47","\u6BC3","\u71C6","\u7857","\u78FD","\u7E51","\u8DAC","\u8DF7","\u8E0D","\u8E7A","\u8E7B","\u90FB","\u9121","\u9125","\u936B","\u936C","\u9430","\u9539","\u981D"],"hu\xE1 hu\xE0":["\u5283"],"zh\u0101 zh\xE1":["\u5284"],"p\u012B p\u01D0":["\u5288","\u6082"],t\u0101ng:["\u528F","\u5621","\u7FB0","\u859A","\u876A","\u8E5A","\u97BA","\u9F1E"],ch\u00E1n:["\u5296","\u56B5","\u58E5","\u5A75","\u5B0B","\u5DC9","\u5EDB","\u68CE","\u6BDA","\u6E79","\u6F79","\u6F7A","\u6FB6","\u700D","\u703A","\u7158","\u7351","\u78DB","\u7DFE","\u7E8F","\u7E92","\u7F20","\u826C","\u8749","\u87D0","\u87EC","\u87FE","\u8A97","\u8B92","\u8C17","\u8E94","\u913D","\u9141","\u92CB","\u9471","\u9575","\u995E","\u998B"],zu\u0101n:["\u5297","\u8E9C","\u8EA6","\u9246","\u945A"],m\u00F3:["\u5298","\u5AEB","\u5B24","\u5B37","\u5C1B","\u6479","\u64F5","\u6A45","\u7CE2","\u819C","\u85E6","\u8611","\u8B28","\u8B29","\u8C1F","\u9943","\u995D","\u998D","\u9ACD","\u9B54","\u9B79"],zh\u00FA:["\u529A","\u65B8","\u66EF","\u6B18","\u705F","\u70A2","\u70DB","\u71ED","\u7225","\u7603","\u7AF9","\u7B01","\u7B1C","\u8233","\u833F","\u84EB","\u880B","\u883E","\u8E85","\u9010","\u902B","\u9483","\u9C41"],qu\u00E0n:["\u529D","\u52E7","\u52F8","\u7276","\u97CF"],"j\xECn j\xECng":["\u52A4","\u52B2","\u52C1"],k\u0113ng:["\u52A5","\u5751","\u727C","\u7841","\u785C","\u8A99","\u92B5","\u935E","\u93D7","\u94FF","\u962C"],"xi\xE9 li\xE8":["\u52A6"],"zh\xF9 ch\xFA":["\u52A9"],n\u01D4:["\u52AA","\u5F29","\u782E","\u80EC"],sh\u00E0o:["\u52AD","\u5372","\u54E8","\u6F72","\u7D39","\u7DA4","\u7ECD","\u8891","\u90B5"],mi\u01CEo:["\u52B0","\u676A","\u6DFC","\u6E3A","\u7707","\u79D2","\u7BCE","\u7DF2","\u7F08","\u85D0","\u9088"],k\u01D2u:["\u52B6","\u53E3"],w\u0101:["\u52B8","\u5A32","\u5AA7","\u5C72","\u6316","\u6528","\u6D3C","\u6E9B","\u6F25","\u74FE","\u7556","\u7A75","\u7A8A","\u7AAA","\u86D9","\u97C8","\u9F03"],ku\u0101ng:["\u52BB","\u5321","\u5329","\u54D0","\u6047","\u6D2D","\u7B50","\u7B7A","\u8A86","\u8BD3","\u8EED","\u90BC"],h\u00E9:["\u52BE","\u548A","\u555D","\u59C0","\u5CC6","\u6546","\u66F7","\u67C7","\u6941","\u6BFC","\u6CB3","\u6DB8","\u6E2E","\u6F95","\u7186","\u76AC","\u76C7","\u76C9","\u76CD","\u76D2","\u79BE","\u7BD5","\u7C7A","\u7CAD","\u7FEE","\u83CF","\u8402","\u8988","\u8A38","\u8A65","\u90C3","\u91DB","\u924C","\u9449","\u95A1","\u95D4","\u9602","\u9616","\u97A8","\u981C","\u9904","\u9978","\u9B7A","\u9E56","\u9EA7","\u9F55","\u9F81","\u9FA2","\u{2C317}"],g\u00E0o:["\u52C2","\u543F","\u544A","\u5CFC","\u796E","\u7970","\u799E","\u7B76","\u8AA5","\u8BF0","\u90DC","\u92EF","\u9506"],"b\xF3 b\xE8i":["\u52C3"],l\u00E1ng:["\u52C6","\u5ACF","\u5ECA","\u658F","\u6879","\u6994","\u6A03","\u6B34","\u72FC","\u7405","\u746F","\u7860","\u7A02","\u8246","\u84C8","\u870B","\u8782","\u8EB4","\u90D2","\u90DE","\u92C3","\u93AF","\u9512"],x\u016Bn:["\u52CB","\u52DB","\u52F2","\u52F3","\u5691","\u5743","\u57D9","\u5864","\u58CE","\u58E6","\u66DB","\u71FB","\u736F","\u77C4","\u7E81","\u81D0","\u85AB","\u85B0","\u860D","\u91BA","\u{2B138}"],"ju\xE0n ju\u0101n":["\u52CC","\u74F9"],"l\xE8 l\u0113i":["\u52D2"],k\u00E0i:["\u52D3","\u708C","\u70D7","\u938E"],"w\u011Bng y\u01CEng":["\u52DC"],q\u00EDn:["\u52E4","\u55EA","\u5659","\u5D9C","\u5E88","\u61C3","\u61C4","\u6366","\u64D2","\u65B3","\u6A8E","\u6FBF","\u73E1","\u7434","\u7439","\u763D","\u79BD","\u79E6","\u8039","\u82A9","\u82B9","\u83E6","\u8793","\u8804","\u9219","\u922B","\u96C2","\u9772","\u9CF9","\u9D6D"],ji\u00E0ng:["\u52E5","\u531E","\u5320","\u5D79","\u5F1C","\u5F36","\u647E","\u6AE4","\u6D1A","\u6EF0","\u729F","\u7CE1","\u7CE8","\u7D73","\u7EDB","\u8B3D","\u9171","\u91A4","\u91AC"],f\u0101n:["\u52EB","\u5B0F","\u5E06","\u5E61","\u5FDB","\u61A3","\u65D9","\u65DB","\u7E59","\u7FFB","\u85E9","\u8F53","\u98BF","\u98DC","\u9C55"],ju\u0101n:["\u52EC","\u59E2","\u5A1F","\u6350","\u6D93","\u8832","\u88D0","\u93B8","\u942B","\u954C","\u9E43"],"t\xF3ng d\xF2ng":["\u52ED","\u70D4","\u71D1","\u72EA"],l\u01DC:["\u52F4","\u578F","\u5D42","\u5F8B","\u616E","\u6C2F","\u6EE4","\u6FFE","\u7208","\u7BBB","\u7DA0","\u7E42","\u819F","\u844E","\u8651","\u9462"],ch\u00E8:["\u52F6","\u577C","\u5F7B","\u5FB9","\u63A3","\u64A4","\u6F88","\u70E2","\u7221","\u77AE","\u7869","\u8045","\u8FE0","\u9819","\u3B1A"],sh\u00E1o:["\u52FA","\u73BF","\u97F6"],"g\u014Du g\xF2u":["\u52FE"],c\u014Dng:["\u5306","\u56EA","\u56F1","\u5FE9","\u6031","\u60A4","\u66B0","\u6A2C","\u6F17","\u747D","\u7481","\u779B","\u7BF5","\u7E71","\u8061","\u8066","\u806A","\u8070","\u82C1","\u8310","\u8471","\u84EF","\u8525","\u87CC","\u936F","\u93D3","\u93E6","\u9A18","\u9A44","\u9AA2"],"t\xE1o y\xE1o":["\u530B","\u9676"],p\u00E1o:["\u530F","\u5486","\u5789","\u5E96","\u722E","\u72CD","\u888D","\u891C","\u8EF3","\u9784","\u9E85"],d\u00E1:["\u5312","\u59B2","\u601B","\u709F","\u71F5","\u7563","\u7B2A","\u7F8D","\u8359","\u8598","\u87FD","\u8A5A","\u8FBE","\u8FCF","\u8FD6","\u8FDA","\u9039","\u9054","\u943D","\u977C","\u9791","\u97C3","\u9F96","\u9F98","\u{2B7FC}"],"hu\xE0 hu\u0101":["\u5316"],"b\u011Bi b\xE8i":["\u5317"],n\u01CEo:["\u5318","\u57B4","\u5816","\u5AD0","\u607C","\u60A9","\u60F1","\u7459","\u78AF","\u8111","\u8133","\u8166"],"ch\xED shi":["\u5319"],f\u0101ng:["\u531A","\u580F","\u65B9","\u6DD3","\u7265","\u82B3","\u90A1","\u9201","\u933A","\u94AB","\u9D0B"],z\u0101:["\u531D","\u5482","\u5E00","\u6C9E","\u81DC","\u81E2","\u8FCA","\u9254","\u9B73"],qi\u00E8:["\u5327","\u5392","\u59BE","\u602F","\u608F","\u60EC","\u611C","\u6308","\u7A55","\u7A83","\u7ACA","\u7B21","\u7BA7","\u7BCB","\u7C61","\u8E25","\u9365","\u9532","\u9BDC"],"z\u0101ng c\xE1ng":["\u5328"],f\u011Bi:["\u532A","\u595C","\u60B1","\u68D0","\u69A7","\u7BDA","\u7FE1","\u855C","\u8AB9","\u8BFD"],"ku\xEC gu\xEC":["\u532E","\u5331"],su\u01CEn:["\u5334"],p\u01D0:["\u5339","\u567D","\u56AD","\u572E","\u5E80","\u75DE","\u7656","\u8134","\u82C9","\u92A2","\u9D04"],"q\u016B \u014Du":["\u533A","\u5340"],"k\u0113 qi\xE0":["\u533C"],"y\u01CEn y\xE0n":["\u533D","\u68EA"],bi\u01CEn:["\u533E","\u60FC","\u63D9","\u78A5","\u7A28","\u7A86","\u85CA","\u890A","\u8CB6","\u8D2C","\u9D18"],n\u00EC:["\u533F","\u5804","\u5ADF","\u5B3A","\u60C4","\u6135","\u6635","\u66B1","\u6C3C","\u7724","\u7768","\u7E0C","\u80D2","\u817B","\u81A9","\u9006","\u{28E99}"],ni\u00E0n:["\u5344","\u5538","\u57DD","\u5EFF","\u5FF5","\u60D7","\u824C"],s\u00E0:["\u5345","\u6AD2","\u810E","\u8428","\u856F","\u85A9","\u9212","\u96A1","\u98AF","\u98D2","\u99BA"],z\u00FA:["\u5346","\u54EB","\u5D2A","\u65CF","\u7BA4","\u8DB3","\u8E24","\u955E"],sh\u0113ng:["\u5347","\u544F","\u58F0","\u6598","\u6607","\u66FB","\u67A1","\u6B85","\u6CE9","\u6E66","\u713A","\u7272","\u73C4","\u751F","\u7525","\u7AD4","\u7B19","\u8072","\u924E","\u935F","\u9629","\u965E","\u9679","\u9D7F","\u9F2A"],w\u00E0n:["\u534D","\u5350","\u5FE8","\u6764","\u77A3","\u8115","\u8155","\u842C","\u87C3","\u8D0E","\u8F10","\u933D","\u{2C1D5}"],"hu\xE1 hu\xE0 hu\u0101":["\u534E","\u83EF"],b\u0113i:["\u5351","\u60B2","\u63F9","\u676F","\u686E","\u76C3","\u7891","\u85E3","\u9D6F","\u9E4E"],"z\xFA c\xF9":["\u5352"],"d\u0101n sh\xE0n ch\xE1n":["\u5355","\u55AE"],"n\xE1n n\u0101":["\u5357"],"shu\xE0i l\u01DC":["\u535B"],"b\u01D4 bo p\xFA":["\u535C"],"ku\xE0ng gu\xE0n":["\u535D"],bi\u00E0n:["\u535E","\u53D8","\u5909","\u5CC5","\u5F01","\u5FA7","\u5FED","\u6283","\u662A","\u6C73","\u6C74","\u73A3","\u8251","\u82C4","\u898D","\u8ADA","\u8B8A","\u8FA1","\u8FA7","\u8FA8","\u8FA9","\u8FAB","\u8FAE","\u8FAF","\u904D","\u91C6","\u{28695}"],b\u01D4:["\u535F","\u54FA","\u6355","\u8865","\u88DC","\u9E14","\u{2CDD5}"],"zh\xE0n zh\u0101n":["\u5360","\u89B1"],"k\u01CE qi\u01CE":["\u5361"],l\u00FA:["\u5362","\u56A7","\u5786","\u58DA","\u5E90","\u5EEC","\u66E5","\u67A6","\u680C","\u6AE8","\u6CF8","\u7018","\u7089","\u7210","\u7379","\u7388","\u74D0","\u76E7","\u77D1","\u7C5A","\u7E91","\u7F4F","\u80EA","\u81DA","\u822E","\u823B","\u826B","\u82A6","\u8606","\u8826","\u8F64","\u8F73","\u9229","\u946A","\u9871","\u9885","\u99BF","\u9AD7","\u9B72","\u9C78","\u9C88","\u9E15","\u9E2C","\u9EF8","\u{2CB3B}"],l\u01D4:["\u5364","\u5877","\u63B3","\u64C4","\u6A10","\u6A79","\u6AD3","\u6C0C","\u6EF7","\u6F9B","\u7002","\u7875","\u78E0","\u7A5E","\u8263","\u826A","\u84FE","\u864F","\u865C","\u93C0","\u942A","\u9465","\u9565","\u9B6F","\u9C81","\u9E75"],gu\u00E0:["\u5366","\u5569","\u6302","\u639B","\u7F63","\u8902","\u8A7F","\u8BD6"],"\xE1ng y\u01CEng":["\u536C"],y\u00ECn:["\u5370","\u57BD","\u5837","\u5ED5","\u616D","\u6196","\u6197","\u61DA","\u6D15","\u6E5A","\u730C","\u764A","\u80E4","\u831A","\u9173","\u9BA3","\u4C9F"],qu\u00E8:["\u5374","\u537B","\u5859","\u5D05","\u60AB","\u6128","\u6164","\u6409","\u69B7","\u71E9","\u7437","\u76B5","\u786E","\u78BA","\u792D","\u95CB","\u9615","\u9D72","\u9E4A","\u{2C488}"],lu\u01CEn:["\u5375"],"ju\xE0n ju\u01CEn":["\u5377","\u5DFB"],"ch\u01CEng \u0101n h\xE0n":["\u5382"],"w\u011Bi y\xE1n":["\u5383"],t\u012Bng:["\u5385","\u539B","\u542C","\u5E81","\u5EF0","\u5EF3","\u6C40","\u70C3","\u70F4","\u7D8E","\u8013","\u8074","\u807C","\u807D","\u9793","\u{2C629}"],"zh\xE9 zh\xE1i":["\u5387"],"h\xE0n \xE0n":["\u5388","\u5C7D"],y\u01CE:["\u538A","\u5516","\u5E8C","\u75D6","\u7602","\u8565"],sh\u00E8:["\u538D","\u5399","\u5F3D","\u6151","\u6174","\u61FE","\u6442","\u6B07","\u6D89","\u6DBB","\u6E09","\u6EE0","\u7044","\u793E","\u820E","\u850E","\u8802","\u8A2D","\u8BBE","\u8D66","\u9A07","\u9E9D"],d\u01D0:["\u538E","\u5467","\u5758","\u5F24","\u62B5","\u62DE","\u638B","\u7274","\u7825","\u83E7","\u89DD","\u8A46","\u8BCB","\u8EE7","\u90B8","\u963A","\u9AB6","\u9BF3"],"zh\u01CE zh\u01CEi":["\u538F"],p\u00E1ng:["\u5390","\u5ACE","\u5E9E","\u5FAC","\u823D","\u8783","\u9004","\u9C1F","\u9CD1","\u9F8E","\u9F90"],"zh\xEC sh\u012B":["\u5394"],m\u00E1ng:["\u5396","\u5402","\u54E4","\u5A0F","\u5FD9","\u607E","\u6757","\u6767","\u6C52","\u6D5D","\u727B","\u75DD","\u76F2","\u786D","\u7B00","\u8292","\u832B","\u8609","\u9099","\u91EF","\u92E9","\u94D3","\u99F9"],zu\u012B:["\u539C","\u6A36","\u7E97","\u87D5"],"sh\xE0 xi\xE0":["\u53A6","\u5EC8"],\u00E1o:["\u53AB","\u55F7","\u55F8","\u5ED2","\u6556","\u6EF6","\u7352","\u7353","\u7488","\u7FF1","\u7FF6","\u7FFA","\u8071","\u851C","\u87AF","\u8B37","\u8B38","\u9068","\u93D6","\u969E","\u9C32","\u9CCC","\u9DD4","\u9F07"],"l\xE1n qi\u0101n":["\u53B1"],"s\u012B m\u01D2u":["\u53B6"],"g\u014Dng h\xF3ng":["\u53B7"],"l\xEDn mi\u01CEo":["\u53B8"],"qi\xFA r\xF3u":["\u53B9"],d\u016B:["\u53BE","\u561F","\u7763","\u918F"],"xi\xE0n xu\xE1n":["\u53BF","\u7E23"],"c\u0101n sh\u0113n c\u0113n s\u0101n":["\u53C2","\u53C3","\u53C4","\u53C5"],"\xE0i y\u01D0":["\u53C6"],"ch\u0101 ch\xE0 ch\u01CE ch\xE1":["\u53C9"],shu\u0101ng:["\u53CC","\u5B40","\u5B47","\u6B06","\u7935","\u826D","\u96D9","\u971C","\u9A3B","\u9A66","\u9AA6","\u9DDE","\u9E18","\u9E74"],sh\u014Du:["\u53CE","\u6536"],gu\u00E1i:["\u53CF"],b\u00E1:["\u53D0","\u59AD","\u629C","\u62D4","\u70A6","\u7679","\u80C8","\u8307","\u83DD","\u8A59","\u8DCB","\u8EF7","\u9B43","\u9F25"],"f\u0101 f\xE0":["\u53D1"],"zhu\xF3 y\u01D0 l\xEC ju\xE9":["\u53D5"],q\u01D4:["\u53D6","\u5A36","\u7AEC","\u877A","\u8A53","\u9F72","\u9F8B"],"ji\u01CE xi\xE1":["\u53DA","\u5FA6"],"w\xE8i y\xF9":["\u53DE","\u5C09","\u851A"],di\u00E9:["\u53E0","\u57A4","\u581E","\u5CCC","\u5E49","\u604E","\u60F5","\u621C","\u66E1","\u6B9C","\u6C0E","\u7243","\u7252","\u74DE","\u7573","\u7582","\u7589","\u758A","\u789F","\u7D70","\u7ED6","\u800A","\u800B","\u80C5","\u8253","\u82F5","\u8728","\u8776","\u890B","\u8A44","\u8ADC","\u8C0D","\u8DEE","\u8E40","\u8FED","\u957B","\u9C08","\u9CBD","\u9D29","\u{2BD87}"],ru\u00EC:["\u53E1","\u6798","\u6C6D","\u745E","\u777F","\u82AE","\u868B","\u8739","\u92B3","\u92ED","\u9510"],"j\xF9 g\u014Du":["\u53E5"],l\u00ECng:["\u53E6","\u5464","\u70A9","\u8626"],"d\u0101o d\xE1o t\u0101o":["\u53E8"],"zh\u012B zh\u01D0":["\u53EA"],ji\u00E0o:["\u53EB","\u544C","\u5602","\u5626","\u564D","\u5B13","\u658D","\u65A0","\u6ED8","\u6F16","\u7365","\u73D3","\u76AD","\u7A96","\u85E0","\u8A06","\u8B65","\u8DAD","\u8F03","\u8F4E","\u8F7F","\u8F83","\u9175","\u91AE","\u91C2"],"zh\xE0o sh\xE0o":["\u53EC"],"k\u011B k\xE8":["\u53EF"],"t\xE1i t\u0101i":["\u53F0","\u82D4"],p\u01D2:["\u53F5","\u5C00","\u7B38","\u7BA5","\u9255","\u94B7","\u99CA"],"y\xE8 xi\xE9":["\u53F6"],"h\xE0o h\xE1o":["\u53F7"],t\u00E0n:["\u53F9","\u5606","\u63A2","\u6B4E","\u6E60","\u70AD","\u78B3","\u8215"],"h\u014Dng h\xF3ng":["\u53FF"],mi\u0113:["\u5400","\u54A9","\u54F6","\u5B6D"],"x\u016B y\u016B y\xF9":["\u5401"],ch\u012B:["\u5403","\u54E7","\u55AB","\u55E4","\u5644","\u599B","\u5AB8","\u5F68","\u5F72","\u645B","\u6521","\u6BA6","\u74FB","\u75F4","\u7661","\u7735","\u779D","\u7B1E","\u7C9A","\u80F5","\u86A9","\u87AD","\u8A35","\u9B51","\u9D1F","\u9D44","\u9E31","\u9ED0","\u9F5D","\u{2B128}"],"xu\u0101n s\xF2ng":["\u5405"],y\u0101o:["\u5406","\u5593","\u592D","\u5996","\u5E7A","\u6946","\u6B80","\u7945","\u8170","\u847D","\u8A1E","\u9080","\u9D01","\u9D22","\u3658"],z\u01D0:["\u5407","\u59C9","\u59CA","\u5B50","\u674D","\u6893","\u699F","\u6A74","\u6ED3","\u77F7","\u79ED","\u7B2B","\u7C7D","\u7D2B","\u8014","\u8678","\u8A3F","\u91E8"],"h\xE9 g\u011B":["\u5408","\u9C84"],"c\xF9n d\xF2u":["\u540B"],"t\xF3ng t\xF2ng":["\u540C"],"t\u01D4 t\xF9":["\u5410","\u550B"],"zh\xE0 zh\u0101":["\u5412","\u5953"],"xi\xE0 h\xE8":["\u5413"],"\u0101 y\u0101":["\u5416"],"ma m\xE1 m\u01CE":["\u5417"],l\u00ECn:["\u541D","\u6061","\u608B","\u6A49","\u711B","\u7510","\u81A6","\u853A","\u85FA","\u8CC3","\u8D41","\u8E78","\u8E8F","\u8E99","\u8EAA","\u8F65","\u95B5"],t\u016Bn:["\u541E","\u66BE","\u671C","\u711E"],"b\u01D0 p\u01D0":["\u5421"],q\u00ECn:["\u5422","\u5423","\u551A","\u628B","\u63FF","\u6407","\u64B3","\u6C81","\u7019","\u83E3","\u85FD"],"ji\xE8 g\xE8":["\u5424"],"f\u01D2u p\u01D0":["\u5426"],"ba b\u0101":["\u5427"],d\u016Bn:["\u5428","\u5678","\u58A9","\u58AA","\u60C7","\u6489","\u64B4","\u729C","\u7364","\u7905","\u8733","\u8E7E","\u9A50"],f\u0113n:["\u5429","\u5E09","\u6610","\u6706","\u68A4","\u68FB","\u6C1B","\u7AD5","\u7D1B","\u7EB7","\u7FC2","\u82AC","\u886F","\u8A1C","\u8EAE","\u915A","\u9216","\u96F0","\u9934","\u9959","\u999A"],"\xE9 hu\u0101":["\u542A"],"k\u0113ng h\xE1ng":["\u542D","\u5994"],sh\u01D4n:["\u542E"],"zh\u012B z\u012B":["\u5431"],"y\u01D0n sh\u011Bn":["\u5432"],w\u00FA:["\u5433","\u5434","\u5449","\u58B2","\u5CFF","\u68A7","\u6A46","\u6BCB","\u6D16","\u6D6F","\u7121","\u73F8","\u7491","\u7966","\u829C","\u8323","\u8381","\u856A","\u8708","\u87F1","\u8B55","\u90DA","\u92D9","\u94FB","\u9BC3","\u9D50","\u9DE1","\u9E40","\u9F2F"],"ch\u01CEo ch\u0101o":["\u5435"],"n\xE0 n\xE8":["\u5436"],"xu\xE8 chu\xF2 ju\xE9":["\u5437"],chu\u012B:["\u5439","\u708A","\u9FA1"],"d\u014Du r\xFA":["\u543A"],h\u01D2u:["\u543C","\u72BC"],"h\u014Dng h\u01D2u \u014Du":["\u543D"],"w\xFA y\xF9":["\u543E"],"ya y\u0101":["\u5440"],"\xE8 e":["\u5443"],d\u0101i:["\u5446","\u61DB","\u7343"],"m\xE8n q\u01D0":["\u5447"],h\u014Dng:["\u544D","\u569D","\u63C8","\u7074","\u70D8","\u7122","\u7861","\u85A8","\u8A07","\u8C3E","\u8EE3","\u8F37","\u8F5F","\u8F70","\u9367"],n\u00E0:["\u5450","\u637A","\u7B1D","\u7D0D","\u7EB3","\u80AD","\u84B3","\u8872","\u8C7D","\u8C80","\u8EDC","\u90CD","\u9209","\u94A0","\u9779","\u9B76"],"t\u016Bn ti\u0101n":["\u5451"],"f\u01D4 \u1E3F":["\u5452","\u5638"],"d\u0101i t\u01CEi":["\u5454"],"\u01D2u \u014Du \xF2u":["\u5455"],"b\xE0i bei":["\u5457"],"yu\xE1n y\xFAn y\xF9n":["\u5458","\u54E1"],gu\u014D:["\u5459","\u556F","\u5613","\u57DA","\u581D","\u588E","\u5D1E","\u5F49","\u5F4D","\u61D6","\u7313","\u7611","\u8052","\u8748","\u87C8","\u90ED","\u921B","\u934B","\u9505"],"hu\xE1 q\xEC":["\u545A"],"qi\xE0ng qi\u0101ng":["\u545B","\u8DC4"],sh\u012B:["\u545E","\u5931","\u5C38","\u5C4D","\u5E08","\u5E2B","\u65BD","\u6D49","\u6E64","\u6E7F","\u6EAE","\u6EBC","\u6FD5","\u72EE","\u7345","\u7461","\u7D41","\u8479","\u8492","\u84CD","\u8671","\u8768","\u8937","\u8979","\u8A69","\u8BD7","\u90BF","\u91C3","\u9247","\u9366","\u9BF4","\u9C24","\u9CBA","\u9CF2","\u9CFE","\u9DB3","\u9E24","\u4D13","\u{2B695}"],ju\u01CEn:["\u545F","\u57CD","\u81C7","\u83E4","\u9308","\u9529"],p\u011Bn:["\u5460","\u7FF8"],"w\u011Bn m\u01D0n":["\u5461"],"ne n\xED":["\u5462"],"\u1E3F m\u0300 m\xF3u":["\u5463"],r\u00E1n:["\u5465","\u562B","\u7136","\u71C3","\u7E4E","\u80B0","\u86A6","\u86BA","\u887B","\u8887","\u88A1","\u9AE5","\u9AEF"],"ti\xE8 ch\xE8":["\u546B"],"q\xEC zh\u012B":["\u546E"],"z\u01D0 c\u012B":["\u5470"],"gu\u0101 g\u016B gu\u01CE":["\u5471"],"c\u012B z\u012B":["\u5472"],"h\u01D2u x\u01D4 g\xF2u":["\u5474"],"h\u0113 \u0101 \xE1 \u01CE \xE0 a":["\u5475"],n\u00E1o:["\u5476","\u5912","\u5CF1","\u5DA9","\u5DCE","\u6320","\u6493","\u7331","\u7847","\u86F2","\u87EF","\u8A49","\u8B4A","\u9403","\u94D9"],"xi\u0101 g\u0101":["\u5477"],p\u0113i:["\u5478","\u600C","\u80A7","\u80DA","\u8843","\u9185"],"h\xE1o xi\u0101o":["\u547A"],m\u00ECng:["\u547D","\u63B5"],"d\xE1 d\xE0n":["\u547E"],"zu\u01D0 j\u01D4":["\u5480"],"xi\xE1n g\u0101n":["\u5481"],p\u01D2u:["\u5485","\u54E3","\u7283"],"y\u01CEng y\u0101ng":["\u5489"],"z\u01CE z\xE9 zh\u0101":["\u548B"],"h\xE9 h\xE8 hu\xF3 hu\xF2 h\xFA":["\u548C"],h\u0101i:["\u548D"],d\u0101:["\u5491","\u54D2","\u5660","\u58B6","\u642D","\u6498","\u8037","\u8921","\u939D","\u{28C4F}"],"k\u01CE k\u0101":["\u5494"],g\u016B:["\u5495","\u5502","\u5503","\u59D1","\u5AF4","\u5B64","\u5DEC","\u5DED","\u67E7","\u6A6D","\u6CBD","\u6CD2","\u7A12","\u7B1F","\u7B8D","\u7B9B","\u7BD0","\u7F5B","\u82FD","\u83C7","\u83F0","\u84C7","\u89DA","\u8EF1","\u8EF2","\u8F71","\u8F9C","\u9164","\u9232","\u9B95","\u9D23","\u9E2A"],"k\u0101 g\u0101":["\u5496"],zuo:["\u5497"],l\u00F3ng:["\u5499","\u56A8","\u5D90","\u5DC3","\u5DC4","\u663D","\u66E8","\u6727","\u680A","\u69DE","\u6AF3","\u6E70","\u6EDD","\u6F0B","\u7216","\u73D1","\u74CF","\u7643","\u772C","\u77D3","\u783B","\u7931","\u7932","\u7ABF","\u7ADC","\u804B","\u807E","\u80E7","\u830F","\u8622","\u882A","\u882C","\u8971","\u8C45","\u93E7","\u9468","\u9733","\u9747","\u9A61","\u9E17","\u9F8D","\u9F92","\u9F99"],"xi\xE0n xi\xE1n":["\u549E"],q\u00EC:["\u54A0","\u552D","\u5650","\u5668","\u5921","\u5F03","\u6187","\u61A9","\u66A3","\u68C4","\u6B2B","\u6C14","\u6C17","\u6C23","\u6C54","\u6C7D","\u6CE3","\u6E46","\u6E47","\u7081","\u7508","\u76F5","\u77F5","\u789B","\u78B6","\u78DC","\u78E7","\u7F4A","\u829E","\u847A","\u85D2","\u87FF","\u8A16","\u8BAB","\u8FC4","\u9411"],"x\xEC di\xE9":["\u54A5"],"li\u0113 li\u011B li\xE9 lie":["\u54A7"],z\u012B:["\u54A8","\u55DE","\u59D5","\u59FF","\u5B5C","\u5B73","\u5B76","\u5D30","\u5D6B","\u6825","\u6914","\u6DC4","\u6E7D","\u6ECB","\u6FAC","\u7386","\u798C","\u79F6","\u7CA2","\u7D0E","\u7DC7","\u7DD5","\u7E83","\u7F01","\u830A","\u8332","\u8458","\u8AEE","\u8C18","\u8CB2","\u8CC7","\u8D40","\u8D44","\u8D7C","\u8D91","\u8DA6","\u8F1C","\u8F3A","\u8F8E","\u9111","\u922D","\u9319","\u937F","\u93A1","\u9531","\u9543","\u983E","\u983F","\u9AED","\u9BD4","\u9C26","\u9CBB","\u9D85","\u9F12","\u9F4D","\u9F5C","\u9F87"],m\u012B:["\u54AA"],"j\u012B x\u012B qi\xE0":["\u54AD"],"g\u0113 lu\xF2 k\u01CE lo":["\u54AF"],"sh\xF9 x\xFAn":["\u54B0"],"z\xE1n z\xE1 z\u01CE zan":["\u54B1"],"h\u0101i k\xE9":["\u54B3"],hu\u012B:["\u54B4","\u5645","\u5655","\u5A4E","\u5A88","\u5E51","\u5FBD","\u6062","\u62FB","\u6325","\u63EE","\u6656","\u6689","\u694E","\u6D03","\u7008","\u7070","\u7073","\u70E3","\u7773","\u7988","\u7FDA","\u7FEC","\u8633","\u8886","\u8918","\u8A7C","\u8BD9","\u8C57","\u8F1D","\u8F89","\u9C34","\u9EBE","\u39D1"],"hu\xE0i sh\xEC":["\u54B6"],t\u00E1o:["\u54B7","\u5555","\u6843","\u6AAE","\u6D2E","\u6DD8","\u7979","\u7DAF","\u7EF9","\u8404","\u872A","\u88EA","\u8FEF","\u9003","\u9184","\u92FE","\u9780","\u9789","\u9940","\u99E3","\u9A0A","\u9F17","\u{2B626}"],xi\u00E1n:["\u54B8","\u5563","\u5A34","\u5A39","\u5A71","\u5ACC","\u5AFA","\u5AFB","\u5F26","\u6326","\u648F","\u6D8E","\u6E7A","\u6F96","\u7509","\u75EB","\u7647","\u764E","\u7D43","\u80D8","\u8237","\u85D6","\u86BF","\u86DD","\u8854","\u8858","\u8AB8","\u8AF4","\u8CE2","\u8D12","\u8D24","\u8F31","\u918E","\u929C","\u9466","\u9591","\u95F2","\u9DF3","\u9DF4","\u9DFC","\u9E47","\u9E79","\u9E99","\u{2B36F}"],"\xE8 \xE0n":["\u54B9"],"xu\u0101n xu\u01CEn":["\u54BA","\u70DC"],"w\u0101i h\xE9 w\u01D2 gu\u01CE gu\u014D":["\u54BC"],"y\xE0n y\xE8 y\u0101n":["\u54BD"],\u0101i:["\u54C0","\u54CE","\u57C3","\u6EBE","\u92B0","\u9384","\u953F"],p\u01D0n:["\u54C1","\u6980"],sh\u011Bn:["\u54C2","\u5A76","\u5B38","\u5BA1","\u5BB7","\u5BE9","\u5F1E","\u66CB","\u6E16","\u700B","\u77AB","\u77E4","\u77E7","\u89BE","\u8A20","\u8AD7","\u8B85","\u8C02","\u8C09","\u90A5","\u9823","\u9B6B"],"h\u01D2ng h\u014Dng h\xF2ng":["\u54C4"],"w\u0101 wa":["\u54C7"],"h\u0101 h\u01CE h\xE0":["\u54C8"],z\u0101i:["\u54C9","\u683D","\u6E3D","\u6EA8","\u707D","\u707E","\u70D6","\u7775","\u8CF3"],"d\xEC di\xE8":["\u54CB"],p\u00E0i:["\u54CC","\u6CA0","\u6D3E","\u6E12","\u6E43","\u848E","\u9383"],"g\xE9n h\u011Bn":["\u54CF"],"y\u01CE y\u0101":["\u54D1","\u96C5"],"yu\u011B hu\xEC":["\u54D5","\u5666"],ni\u00E1n:["\u54D6","\u5E74","\u79CA","\u79E5","\u9B8E","\u9BF0","\u9C87","\u9CB6","\u9D47","\u9ECF"],"hu\xE1 hu\u0101":["\u54D7","\u5629"],"j\xEC ji\u0113 zh\u0101i":["\u54DC","\u568C"],m\u014Du:["\u54DE"],"y\u014D yo":["\u54DF","\u55B2"],l\u00F2ng:["\u54E2","\u6887","\u8D1A"],"\xF2 \xF3 \xE9":["\u54E6"],"l\u012B l\u01D0 li":["\u54E9"],"n\u01CE na n\u01CEi n\xE9 n\u011Bi":["\u54EA"],h\u00E8:["\u54EC","\u578E","\u58D1","\u5BC9","\u60D2","\u7103","\u7142","\u71FA","\u7200","\u764B","\u788B","\u7FEF","\u8910","\u8B1E","\u8CC0","\u8D3A","\u8D6B","\u974D","\u974E","\u974F","\u9DB4","\u9E16","\u9E64"],"b\u014D p\xF2 b\u0101":["\u54F1"],zh\u00E9:["\u54F2","\u5560","\u5586","\u569E","\u57D1","\u608A","\u647A","\u6662","\u6663","\u6B7D","\u77FA","\u7813","\u78D4","\u7C77","\u7C8D","\u8674","\u86F0","\u87C4","\u88A9","\u8A5F","\u8B2B","\u8B3A","\u8B81","\u8B8B","\u8C2A","\u8F12","\u8F19","\u8F4D","\u8F84","\u8F99","\u9BBF"],"li\xE0ng l\xE1ng":["\u54F4"],"li\xE8 l\u01DC":["\u54F7"],h\u0101n:["\u54FB","\u61A8","\u86B6","\u8C3D","\u9163","\u9807","\u9878","\u99A0","\u9B7D","\u9F3E"],"h\u0113ng hng":["\u54FC"],g\u011Bng:["\u54FD","\u57C2","\u5CFA","\u632D","\u6897","\u7D86","\u7EE0","\u803F","\u8384","\u90E0","\u9ABE","\u9BC1","\u9CA0","\u{2C494}"],"chu\xF2 yu\xE8":["\u54FE"],"g\u011B ji\u0101":["\u54FF"],"bei b\xE0i":["\u5504"],"h\xE1n h\xE0n":["\u5505"],ch\u00FAn:["\u5507","\u6D71","\u6E7B","\u6EE3","\u6F18","\u7289","\u7D14","\u7EAF","\u8123","\u83BC","\u8493","\u84F4","\u9187","\u9195","\u931E","\u9659","\u9BD9","\u9D89","\u9E51","\u{2CB5A}"],"\xE0i \u0101i":["\u5509"],"ji\xE1 qi\u01CEn":["\u550A"],"y\xE1n d\xE0n xi\xE1n":["\u550C"],ch\u0113:["\u5513","\u7817","\u7868","\u8397","\u86FC"],"w\xFA \u0144g \u0144":["\u5514"],z\u00E0o:["\u5515","\u5523","\u566A","\u6165","\u688D","\u7076","\u7170","\u71E5","\u7681","\u7682","\u7AC3","\u7AC8","\u7C09","\u8241","\u8B5F","\u8DAE","\u8E81","\u9020","\u{255A8}"],d\u00ED:["\u5519","\u5547","\u5600","\u5681","\u5AE1","\u5EF8","\u654C","\u6575","\u6891","\u6DA4","\u6ECC","\u72C4","\u7B1B","\u7C74","\u7CF4","\u82D6","\u837B","\u850B","\u8510","\u85E1","\u89BF","\u89CC","\u8C74","\u8FEA","\u976E","\u9814","\u99B0","\u9AE2","\u9E10","\u{2CC56}"],"g\xF2ng h\u01D2ng g\u01D2ng":["\u551D","\u55CA"],d\u00F3u:["\u551E"],"l\xE0o l\xE1o":["\u5520","\u562E","\u61A6"],hu\u00E0n:["\u5524","\u559A","\u5942","\u5950","\u5BA6","\u5D48","\u5E7B","\u60A3","\u610C","\u6362","\u63DB","\u64D0","\u650C","\u6899","\u69F5","\u6D63","\u6DA3","\u6E19","\u6F36","\u6FA3","\u70C9","\u7115","\u7165","\u744D","\u75EA","\u7613","\u7746","\u8092","\u85E7","\u8C62","\u8F58","\u902D","\u9BC7","\u9BF6","\u9C00","\u9CA9"],l\u00E9ng:["\u5525","\u5844","\u695E","\u7890","\u8590"],"w\u014D w\u011Bi":["\u5529"],f\u011Bng:["\u552A","\u8982","\u8AF7","\u8BBD"],"y\xEDn j\xECn":["\u552B"],"h\u01D4 xi\xE0":["\u552C"],w\u00E9i:["\u552F","\u56F4","\u570D","\u58DD","\u5CD7","\u5CDE","\u5D6C","\u5E0F","\u5E37","\u5E43","\u60DF","\u6845","\u6CA9","\u6D08","\u6DA0","\u6E4B","\u6E88","\u6F4D","\u6F59","\u6F7F","\u6FF0","\u72A9","\u77C0","\u7DAD","\u7EF4","\u84F6","\u89B9","\u8FDD","\u9055","\u912C","\u9180","\u934F","\u95C8","\u95F1","\u97CB","\u97E6","\u9BA0","\u{23C97}","\u{2CD8F}"],shu\u0101:["\u5530"],ch\u00E0ng:["\u5531","\u6005","\u60B5","\u66A2","\u713B","\u7545","\u757C","\u8AAF","\u97D4","\u9B2F"],"\xE9r w\u0101":["\u5532"],qi\u00E0ng:["\u5534","\u709D","\u7197","\u7FBB"],y\u014D:["\u5537"],y\u016B:["\u5539","\u6DE4","\u7600","\u76D3","\u7B8A","\u7D06","\u7EA1","\u8FBC","\u8FC2","\u8FC3","\u9653"],l\u00E0i:["\u553B","\u6FD1","\u7028","\u702C","\u765E","\u7669","\u7750","\u775E","\u7C41","\u7C5F","\u85FE","\u8CDA","\u8CF4","\u8D49","\u8D56","\u983C","\u9842","\u9D63"],tu\u00F2:["\u553E","\u5D9E","\u67DD","\u6BE4","\u6BFB","\u7BA8","\u7C5C","\u841A","\u8600","\u8DC5"],"zh\u014Du zh\u0101o ti\xE0o":["\u5541"],k\u011Bn:["\u5543","\u57A6","\u58BE","\u6073","\u61C7","\u808E","\u80AF","\u80BB","\u8C64","\u9339"],"zhu\xF3 zh\xE0o":["\u5545","\u6FEF"],"h\u0113ng h\xE8ng":["\u5548","\u6099"],"l\xEDn l\xE1n":["\u5549"],"a \u0101 \xE1 \u01CE \xE0":["\u554A"],qi\u0101ng:["\u554C","\u55F4","\u5D88","\u6215","\u6464","\u65A8","\u67AA","\u69CD","\u6EAC","\u7244","\u7310","\u7347","\u7F8C","\u7F97","\u8154","\u8723","\u8B12","\u93D8","\u9516","\u9535"],"t\u016Bn zh\u016Bn xi\u0101ng du\u01D0":["\u554D"],w\u00E8n:["\u554F","\u598F","\u63FE","\u6435","\u74BA","\u95EE","\u9850"],"cu\xEC qi":["\u5550"],"di\xE9 sh\xE0 ji\xE9 t\xEC":["\u5551"],"yu\u0113 w\u0101":["\u5558"],"z\u01D0 c\u01D0":["\u5559"],"b\u01D0 t\xFA":["\u555A"],"chu\xF2 chu\xE0i":["\u555C"],"y\u01CE y\u0101 \xE8":["\u555E"],f\u0113i:["\u5561","\u5A53","\u5A54","\u6249","\u6683","\u6E04","\u7306","\u7DCB","\u7EEF","\u88F6","\u970F","\u975E","\u975F","\u98DB","\u98DD","\u98DE","\u9925","\u99A1","\u9A11","\u9A1B","\u9BE1","\u9CB1","\u{2CD02}"],p\u00ED:["\u5564","\u58C0","\u6787","\u6BD7","\u6BD8","\u7137","\u7435","\u75B2","\u76AE","\u7BFA","\u7F74","\u7F86","\u813E","\u8157","\u818D","\u868D","\u86BD","\u8731","\u87B7","\u882F","\u8C7C","\u8C94","\u90EB","\u9239","\u9630","\u9674","\u96A6","\u9B6E","\u9B8D","\u9C8F","\u9D67","\u9F19"],sh\u00E1:["\u5565"],"l\u0101 la":["\u5566"],"y\u012Bng q\xEDng":["\u5568"],p\u0101:["\u556A","\u5991","\u8225","\u8469","\u8DB4"],"zh\u011B sh\xEC":["\u556B"],s\u00E8:["\u556C","\u55C7","\u61CE","\u64CC","\u681C","\u6B6E","\u6DA9","\u6E0B","\u6F80","\u6F81","\u6FC7","\u6FCF","\u7012","\u745F","\u74B1","\u7637","\u7A51","\u7A61","\u7A6F","\u7E6C","\u8B45","\u8F56","\u92AB","\u93FC","\u94EF","\u98CB"],ni\u00E8:["\u556E","\u55EB","\u565B","\u5699","\u56C1","\u56D3","\u573C","\u5B7C","\u5B7D","\u5D72","\u5DAD","\u5DD5","\u5E07","\u655C","\u67BF","\u69F7","\u6AF1","\u6D85","\u6E7C","\u75C6","\u7BDE","\u7C4B","\u7CF1","\u7CF5","\u8042","\u8076","\u81EC","\u81F2","\u8616","\u8825","\u8B98","\u8E02","\u8E17","\u8E19","\u8E51","\u8EA1","\u931C","\u93B3","\u9448","\u9477","\u9480","\u954A","\u954D","\u95D1","\u9667","\u9689","\u9873","\u989E","\u9F67","\u{2B536}"],"lu\u014D lu\xF3 luo":["\u5570","\u56C9"],"t\u0101n ch\u01CEn tu\u014D":["\u5574"],bo:["\u5575","\u8514"],d\u00ECng:["\u5576","\u5B9A","\u6917","\u77F4","\u7887","\u78A0","\u78F8","\u8062","\u815A","\u8423","\u874A","\u8A02","\u8BA2","\u9320","\u952D","\u9841","\u98E3","\u9964"],l\u0101ng:["\u5577"],"\xE1n \u0101n":["\u557D"],k\u0101:["\u5580","\u64D6"],"y\xF3ng y\xFA":["\u5581"],"l\u0101 l\xE1 l\u01CE":["\u5587"],ji\u0113:["\u5588","\u55BC","\u55DF","\u5826","\u5A98","\u63A5","\u63B2","\u64D1","\u6E5D","\u716F","\u7596","\u75CE","\u7664","\u7686","\u79F8","\u7A2D","\u813B","\u8754","\u8857","\u8B2F","\u9636","\u968E","\u9782","\u9D9B"],h\u00F3u:["\u5589","\u5E3F","\u7334","\u760A","\u777A","\u7BCC","\u7CC7","\u7FED","\u8454","\u9107","\u936D","\u9931","\u9ABA","\u9BF8","\u{2CB64}"],"di\xE9 zh\xE1":["\u558B"],w\u0101i:["\u558E","\u6B6A","\u7AF5"],"nu\xF2 r\u011B":["\u558F"],"x\xF9 hu\xF2 gu\xF3":["\u5590"],z\u00E1n:["\u5592"],"w\u014D \u014D":["\u5594"],h\u00FA:["\u5596","\u561D","\u56EB","\u58F6","\u58F7","\u58FA","\u5AA9","\u5F27","\u6430","\u659B","\u695C","\u69F2","\u6E56","\u702B","\u7100","\u7173","\u72D0","\u7322","\u745A","\u74F3","\u7BB6","\u7D57","\u7E20","\u80E1","\u846B","\u851B","\u8774","\u879C","\u885A","\u89F3","\u9190","\u9378","\u9836","\u992C","\u9B0D","\u9B71","\u9C17","\u9D60","\u9D98","\u9DA6","\u9E55"],"hu\xE0n yu\xE1n xu\u01CEn h\xE9":["\u559B"],x\u01D0:["\u559C","\u56CD","\u58D0","\u5C63","\u5F99","\u6199","\u67B2","\u6A72","\u6B56","\u6F07","\u73BA","\u74BD","\u77D6","\u79A7","\u7E30","\u8448","\u8478","\u84F0","\u87E2","\u8B11","\u8E5D","\u8EA7","\u9222","\u9268","\u9269","\u9C5A","\u{2CB73}","\u{2CDAE}"],"h\u0113 h\xE8 y\xE8":["\u559D"],ku\u00EC:["\u559F","\u5633","\u5ABF","\u5B07","\u6126","\u6127","\u6192","\u7BD1","\u7C23","\u7C44","\u8069","\u806D","\u8075","\u81AD","\u8562","\u8B09","\u993D","\u994B","\u9988"],"zh\u01D2ng chu\xE1ng":["\u55A0"],"w\xE9i w\xE8i":["\u55A1","\u70BA","\u7232"],"du\xF3 zh\xE0":["\u55A5"],"s\u0101ng s\xE0ng":["\u55AA"],"qi\xE1o ji\u0101o":["\u55AC"],"p\xE8n b\u0113n":["\u55AF"],"c\u0101n s\u016Bn q\u012B":["\u55B0"],"zh\u0101 ch\u0101":["\u55B3"],mi\u0101o:["\u55B5"],"p\u0113n p\xE8n":["\u55B7"],ku\u00ED:["\u55B9","\u5914","\u594E","\u5DD9","\u6223","\u63C6","\u6646","\u668C","\u694F","\u6951","\u6AC6","\u72AA","\u777D","\u8475","\u85C8","\u8637","\u8641","\u8770","\u8EA8","\u9035","\u9108","\u9368","\u9377","\u982F","\u9997","\u9A24","\u9A99","\u9B41"],"lou l\xF3u":["\u55BD"],"z\xE0o qi\u0101o":["\u55BF"],"h\xE8 xi\u0101o xi\xE0o h\xF9":["\u55C3"],"\xE1 sh\xE0":["\u55C4"],xi\u00F9:["\u55C5","\u5CAB","\u5CC0","\u6EB4","\u73DB","\u7407","\u7493","\u79C0","\u7D89","\u7E4D","\u7E61","\u7EE3","\u8791","\u8896","\u890E","\u890F","\u92B9","\u93E5","\u93FD","\u9508","\u9F45"],"qi\u0101ng qi\xE0ng":["\u55C6","\u6217","\u6227","\u8E4C","\u8E61"],"\xE0i y\xEC":["\u55CC","\u827E"],"m\xE1 m\u01CE ma":["\u55CE"],"k\xE8 k\u0113":["\u55D1"],"d\u0101 t\xE0":["\u55D2","\u9389"],s\u01CEng:["\u55D3","\u6421","\u78C9","\u892C","\u939F","\u9859","\u98A1"],ch\u0113n:["\u55D4","\u62BB","\u741B","\u778B","\u8AC3","\u8B13","\u8CDD","\u90F4","\u{2C62D}"],"w\u0101 g\u01D4":["\u55D7"],"p\u01CEng b\u0113ng":["\u55D9"],"xi\xE1n qi\u01CEn qi\u0101n":["\u55DB"],l\u00E0o:["\u55E0","\u5AEA","\u6A6F","\u6D9D","\u6F87","\u8022","\u802E","\u8EBC","\u8EC2","\u916A"],w\u0113ng:["\u55E1","\u7FC1","\u806C","\u8789","\u9393","\u9DB2","\u9E5F","\u{2CB69}"],w\u00E0:["\u55E2","\u817D","\u8183","\u889C","\u896A","\u97E4"],"h\u0113i h\u0101i":["\u55E8"],h\u0113:["\u55EC","\u6B31","\u881A","\u8A36","\u8BC3"],zi:["\u55ED"],s\u01CEi:["\u55EE"],"\u01F9g \u0144g \u0148g":["\u55EF"],g\u011B:["\u55F0","\u8238"],n\u00E1:["\u55F1","\u62CF","\u62FF","\u93BF","\u954E"],di\u01CE:["\u55F2"],"\xE0i \u01CEi \u0101i":["\u55F3"],t\u014Dng:["\u55F5","\u6A0B","\u70B5","\u84EA"],"zu\u012B su\u012B":["\u55FA"],"zh\u0113 zh\xE8 zh\xF9 zhe":["\u55FB"],m\u00F2:["\u55FC","\u573D","\u587B","\u58A8","\u59BA","\u5AFC","\u5BDE","\u5E1E","\u6629","\u672B","\u67BA","\u6B7F","\u6B81","\u6CAB","\u6F20","\u7205","\u734F","\u763C","\u768C","\u773D","\u773F","\u7790","\u7799","\u781E","\u7933","\u79E3","\u7D48","\u7E86","\u8031","\u8309","\u8388","\u84E6","\u86E8","\u87D4","\u8C83","\u8C8A","\u8C98","\u9286","\u93CC","\u9546","\u964C","\u977A","\u9A40","\u9B69","\u9ED8","\u9ED9","\u{2C64A}"],s\u00F2u:["\u55FD","\u7636"],t\u01CEn:["\u55FF","\u5766","\u5FD0","\u61B3","\u61BB","\u66BA","\u6BEF","\u74AE","\u83FC","\u8892","\u8962","\u9193","\u926D","\u94BD"],"ji\xE0o d\u01CEo":["\u5604"],"k\u01CEi g\u011B":["\u5605"],"sh\u0101n c\xE0n":["\u5607"],c\u00E1o:["\u5608","\u5D86","\u66F9","\u66FA","\u69FD","\u6F15","\u825A","\u84F8","\u87AC","\u893F","\u93EA","\u{25562}"],pi\u00E0o:["\u560C","\u5FB1","\u8508","\u9A43"],"l\xF3u lou":["\u560D"],g\u01CE:["\u5C15","\u738D"],"g\u01D4 ji\u01CE":["\u560F"],"ji\u0101o xi\u0101o":["\u5610"],"x\u016B sh\u012B":["\u5618","\u5653"],p\u00F3:["\u5619","\u56A9","\u5A46","\u6AC7","\u76A4","\u9131"],"d\u0113 d\u0113i":["\u561A"],"ma m\xE1":["\u561B"],"l\u0113 lei":["\u561E"],"g\u0101 g\xE1 g\u01CE":["\u5620"],s\u0101i:["\u5625","\u567B","\u6BE2","\u816E","\u984B","\u9C13"],"zu\u014D chu\xE0i":["\u562C"],"ch\xE1o zh\u0101o":["\u5632","\u671D","\u9F02"],zu\u01D0:["\u5634","\u567F","\u5D8A","\u74BB"],"qi\xE1o qi\xE0o":["\u563A","\u7FF9","\u8C2F"],"ch\xF9 x\xF9 sh\xF2u":["\u563C"],"t\u0101n ch\u01CEn":["\u563D"],"d\xE0n t\xE1n":["\u563E","\u5F3E","\u5F48","\u60D4","\u6FB9"],"h\u0113i m\xF2":["\u563F"],\u011B:["\u5641","\u7828","\u980B","\u9A00","\u9D48"],"f\u0101n bo":["\u5643"],chu\u00E1ng:["\u5647","\u5E8A","\u7240"],"c\xF9 z\u0101 h\xE9":["\u5648"],"t\u016Bn ku\xF2":["\u564B"],"c\u0113ng ch\u0113ng":["\u564C"],d\u0113ng:["\u5654","\u5B01","\u706F","\u71C8","\u7492","\u767B","\u7AF3","\u7C26","\u8260","\u8C4B"],p\u016B:["\u5657","\u6251","\u64B2","\u6534","\u6535","\u6F7D","\u7087","\u9660"],ju\u0113:["\u5658","\u5C69","\u5C6B","\u64A7"],l\u016B:["\u565C","\u5695","\u64B8","\u64FC","\u8B22"],zh\u0101n:["\u5661","\u5CBE","\u60C9","\u65C3","\u65DC","\u67AC","\u6834","\u6BE1","\u6C08","\u6C0A","\u6CBE","\u77BB","\u859D","\u86C5","\u8A40","\u8A79","\u8B6B","\u8C35","\u8D88","\u9085","\u959A","\u9711","\u98E6","\u9958","\u9A59","\u9B59","\u9C63","\u9E07","\u9E6F","\u{2B5F4}"],\u014D:["\u5662"],"zh\xF2u zhu\xF3":["\u5663"],"ji\xE0o qi\xE0o ch\u012B":["\u566D"],yu\u00E0n:["\u566E","\u59B4","\u6028","\u613F","\u63BE","\u7457","\u7990","\u82D1","\u884F","\u88EB","\u8911","\u9662","\u9858"],"\u01CEi \xE0i \u0101i":["\u566F"],"y\u014Dng y\u01D2ng":["\u5670","\u6FAD"],"ju\xE9 xu\xE9":["\u5671"],"p\u0113n p\xE8n f\xE8n":["\u5674"],g\u00E1:["\u5676","\u5C1C","\u91D3","\u9337","\u9486"],"x\u012Bn h\u011Bn h\xE8n":["\u5677"],d\u0101ng:["\u5679","\u6FA2","\u73F0","\u74AB","\u7B5C","\u7C39","\u8261","\u87F7","\u88C6","\u8960"],l\u00E0n:["\u5682","\u6EE5","\u6FEB","\u70C2","\u71D7","\u7201","\u721B","\u7224","\u74D3","\u7CF7","\u9484"],t\u00E0:["\u5683","\u56BA","\u5D09","\u631E","\u6428","\u64BB","\u69BB","\u6A7D","\u6BFE","\u6DBE","\u6FBE","\u6FCC","\u79A2","\u7C8F","\u8ABB","\u8B76","\u8E4B","\u8E79","\u8E82","\u8EA2","\u905D","\u9314","\u95D2","\u95E5","\u95FC","\u9618","\u979C","\u97B3"],"hu\u014D hu\xF2 \u01D2":["\u5684"],h\u0101o:["\u5686","\u8320","\u84BF","\u8585"],"h\xE8 xi\xE0":["\u5687"],"xi\xF9 p\xEC":["\u568A"],"zh\u014Du ch\xF3u":["\u568B","\u76E9","\u8BEA"],m\u0113:["\u5692"],"ch\u0101 c\u0101":["\u5693"],"b\xF3 p\xE0o b\xE0o":["\u5697"],"me m\xE8i m\xF2":["\u569C"],"xi\xE9 h\xE1i":["\u56A1"],"\xE1o xi\u0101o":["\u56A3"],m\u014D:["\u56A4","\u6478"],p\u00EDn:["\u56AC","\u5A26","\u5AD4","\u5B2A","\u73AD","\u77C9","\u85B2","\u8819","\u8CA7","\u8D2B","\u9870","\u98A6","\u{2C79F}"],m\u00E8:["\u56B0","\u6FF9"],"r\u01CEng r\u0101ng":["\u56B7"],l\u00E1:["\u56B9","\u65EF"],"ji\xE1o ju\xE9 ji\xE0o":["\u56BC"],chu\u00F2:["\u56BD","\u5A16","\u64C9","\u6B60","\u6DB0","\u78ED","\u8E00","\u8F1F","\u8F8D","\u8FB5","\u8FB6","\u916B","\u9461","\u991F","\u9F6A","\u9F8A"],"hu\u0101n hu\xE0n":["\u56BE"],"z\xE1 c\xE0":["\u56C3"],ch\u00E0i:["\u56C6","\u867F","\u8806","\u8883","\u8A0D"],"n\xE1ng n\u0101ng":["\u56CA"],"z\xE1 z\xE0n c\u0101n":["\u56CB"],s\u016B:["\u56CC","\u6AEF","\u7526","\u7A23","\u7A4C","\u7AA3","\u8607","\u8613","\u9165","\u9BC2"],z\u00E8ng:["\u56CE","\u71B7","\u7511","\u8D08","\u8D60","\u92E5","\u9503"],"z\xE1 ni\xE8 y\xE0n":["\u56D0"],n\u0101ng:["\u56D4"],"lu\xF3 lu\u014D luo":["\u56D6"],"w\xE9i gu\xF3":["\u56D7"],hu\u00ED:["\u56D8","\u56DE","\u56EC","\u5EFB","\u5EFD","\u605B","\u6D04","\u75D0","\u8334","\u8698","\u86D4","\u86D5","\u8716","\u8FF4","\u9025","\u9BB0"],n\u00EDn:["\u56DC","\u60A8","\u810C"],"ji\u01CEn n\u0101n":["\u56DD"],n\u0101n:["\u56E1"],tu\u00E1n:["\u56E2","\u56E3","\u5718","\u6171","\u629F","\u6476","\u6AB2","\u7CF0","\u93C4","\u9DD2","\u9DFB"],"t\xFAn d\xF9n":["\u56E4","\u5749"],gu\u00F3:["\u56EF","\u56F6","\u56FB","\u56FD","\u5700","\u570B","\u5E3C","\u5E57","\u6156","\u6451","\u6F0D","\u805D","\u8158","\u8195","\u852E","\u8662","\u9998","\u{2C1F9}"],k\u00F9n:["\u56F0","\u6D83","\u774F"],"w\xE9i t\u014Dng":["\u56F2"],q\u016Bn:["\u56F7","\u590B","\u9021"],r\u00EC:["\u56F8","\u65E5","\u8875","\u9224","\u99B9","\u9A72"],t\u0101i:["\u56FC","\u5B61","\u80CE"],p\u01D4:["\u5703","\u5711","\u64C8","\u666E","\u669C","\u6A38","\u6A8F","\u6C06","\u6D66","\u6EA5","\u70F3","\u8AE9","\u8B5C","\u8C31","\u8E7C","\u9420","\u9568"],"qu\u0101n ju\xE0n ju\u0101n":["\u5708","\u570F"],"chu\xED chu\xE1n":["\u570C"],tu\u01CEn:["\u5715","\u757D","\u7583"],l\u00FC\u00E8:["\u5719","\u63A0","\u7565","\u7567","\u7A24","\u92DD","\u92E2","\u950A","\u40AE"],"hu\xE1n yu\xE1n":["\u571C"],lu\u00E1n:["\u571D","\u571E","\u5971","\u5A08","\u5B4C","\u5B6A","\u5B7F","\u5CE6","\u5DD2","\u631B","\u6523","\u66EB","\u683E","\u6B12","\u6EE6","\u7064","\u7674","\u7675","\u7F89","\u8114","\u81E0","\u864A","\u92AE","\u947E","\u9D49","\u9E1E","\u9E3E"],t\u01D4:["\u571F","\u5721","\u91F7","\u948D"],"x\u016B w\xE9i":["\u5729"],"d\xEC de":["\u5730","\u5DB3"],"qi\u0101n s\xFA":["\u5731"],zh\u00E8n:["\u5733","\u5866","\u630B","\u632F","\u6715","\u681A","\u753D","\u7739","\u7D16","\u7D7C","\u7EBC","\u8AAB","\u8CD1","\u8D48","\u92F4","\u93AD","\u93AE","\u9547","\u9635","\u9663","\u9707","\u9D06","\u9E29"],"ch\u01CEng ch\xE1ng":["\u573A","\u5834","\u5872"],"q\xED y\xEDn":["\u573B"],ji\u00E1:["\u573F","\u5FE6","\u605D","\u621E","\u6274","\u8125","\u835A","\u83A2","\u86F1","\u86FA","\u88CC","\u8DF2","\u90CF","\u90DF","\u92CF","\u94D7","\u982C","\u9830","\u988A","\u9D36","\u9D4A"],"zh\u01D0 zh\xEC":["\u5741"],b\u01CEn:["\u5742","\u5C85","\u6604","\u677F","\u7248","\u74EA","\u7C84","\u8228","\u8742","\u9211","\u94A3","\u962A","\u9B6C"],q\u01D0n:["\u5745","\u5BD1","\u5BDD","\u5BE2","\u6611","\u68AB","\u7B09","\u87BC","\u8D7E","\u92DF","\u9513"],"m\xE9i f\xE9n":["\u5746"],"r\u01D2ng k\u0113ng":["\u5748"],"f\u0101ng f\xE1ng":["\u574A"],"f\xE8n b\xE8n":["\u574B"],t\u0101n:["\u574D","\u6039","\u644A","\u64F9","\u6524","\u6EE9","\u7058","\u762B","\u7671","\u8211","\u8CAA","\u8D2A"],"hu\xE0i p\u0113i p\u012B p\xE9i":["\u574F"],"d\xEC l\xE0n":["\u5754"],t\u00E1n:["\u575B","\u58B0","\u58B5","\u58C7","\u58DC","\u5A52","\u619B","\u6619","\u66C7","\u6983","\u6A80","\u6F6D","\u71C2","\u75F0","\u78F9","\u7F48","\u7F4E","\u85EB","\u8AC7","\u8B5A","\u8B60","\u8C08","\u8C2D","\u8C9A","\u90EF","\u91B0","\u931F","\u9843"],b\u00E0:["\u575D","\u57BB","\u58E9","\u5F1D","\u6B1B","\u705E","\u7238","\u77F2","\u8987","\u9738","\u9B81","\u9C85"],f\u00E9n:["\u575F","\u58B3","\u59A2","\u5C8E","\u5E69","\u678C","\u68FC","\u6C7E","\u711A","\u71CC","\u71D3","\u7F92","\u7FB5","\u84B6","\u8561","\u86A0","\u86A1","\u8C6E","\u8C76","\u8F52","\u943C","\u96AB","\u99A9","\u9B75","\u9EC2","\u9F16","\u9F22","\u{23E23}"],zhu\u00EC:["\u5760","\u589C","\u60F4","\u7500","\u7577","\u7908","\u7DB4","\u7E0B","\u7F00","\u7F12","\u814F","\u8187","\u8AC8","\u8D05","\u8D58","\u918A","\u9323","\u9446"],p\u014D:["\u5761","\u5CA5","\u6CFC","\u6E8C","\u6F51","\u91D9","\u93FA","\u948B","\u9817","\u9887","\u497D"],"p\u01CEn b\xE0n":["\u5762"],k\u016Bn:["\u5764","\u5803","\u5812","\u5D10","\u5D11","\u6606","\u665C","\u6F49","\u711C","\u71B4","\u7311","\u7428","\u747B","\u83CE","\u872B","\u88C8","\u88E9","\u890C","\u918C","\u9315","\u951F","\u9A09","\u9AE0","\u9AE1","\u9AE8","\u9BE4","\u9CB2","\u9D7E","\u9DA4","\u9E4D"],di\u00E0n:["\u576B","\u57AB","\u588A","\u58C2","\u5960","\u5A5D","\u5E97","\u60E6","\u6242","\u6A42","\u6BBF","\u6DC0","\u6FB1","\u73B7","\u7414","\u7535","\u765C","\u7C1F","\u8714","\u923F","\u96FB","\u975B","\u9A54"],"m\xF9 m\u01D4":["\u5776"],"k\u0113 k\u011B":["\u5777","\u8EFB"],xu\u00E8:["\u5779","\u5CA4","\u6856","\u7025","\u72D8","\u77B2","\u8B14","\u8C11","\u8D90"],"d\u01D0 ch\xED":["\u577B","\u67E2"],l\u0101:["\u5783","\u67C6","\u83C8","\u908B"],l\u01D2ng:["\u5784","\u5785","\u58DF","\u58E0","\u62E2","\u650F","\u7AC9","\u9647","\u96B4","\u{2C542}"],m\u00EDn:["\u578A","\u59C4","\u5CB7","\u5D0F","\u636A","\u65FB","\u65FC","\u6C11","\u73C9","\u7418","\u741D","\u7449","\u75FB","\u76FF","\u7807","\u7DCD","\u7DE1","\u7F17","\u7F60","\u82E0","\u9231","\u9309","\u9372","\u9D16"],"d\xF2ng t\xF3ng":["\u578C","\u5CD2","\u6D1E"],c\u00ED:["\u5790","\u5B28","\u6148","\u67CC","\u6FE8","\u73C1","\u74F7","\u7506","\u78C1","\u7920","\u7960","\u7CCD","\u8328","\u8A5E","\u8BCD","\u8F9D","\u8F9E","\u8FA4","\u8FAD","\u96CC","\u98FA","\u9908","\u9D1C","\u9DBF","\u9DC0","\u9E5A"],du\u012B:["\u5796","\u5806","\u5860","\u75FD","\u78D3","\u9413","\u941C","\u9D2D"],"du\xF2 du\u01D2":["\u579B"],"du\u01D2 du\xF2":["\u579C","\u6306"],ch\u00E1:["\u579E","\u5BDF","\u5D56","\u643D","\u69CE","\u6AAB","\u7339","\u832C","\u8336","\u8A67","\u976B","\u{25ED7}"],sh\u01CEng:["\u57A7","\u664C","\u6A09","\u8CDE","\u8D18","\u8D4F","\u92FF","\u93DB","\u945C"],sh\u01D2u:["\u57A8","\u5B88","\u624B","\u624C","\u824F","\u9996"],da:["\u57AF","\u7E68","\u8DF6"],h\u00E1ng:["\u57B3","\u65BB","\u676D","\u7B55","\u7D4E","\u7ED7","\u822A","\u82C0","\u86A2","\u88C4","\u8CA5","\u8FD2","\u980F","\u9883","\u9B67"],"\u0101n \u01CEn":["\u57B5"],x\u012Bng:["\u57B6","\u60FA","\u661F","\u66D0","\u714B","\u7329","\u7446","\u76A8","\u7BC2","\u8165","\u8208","\u89EA","\u89F2","\u8B03","\u9A02","\u9A8D","\u9B8F","\u9BF9"],"yu\xE0n hu\xE1n":["\u57B8"],b\u0101ng:["\u57B9","\u5E2E","\u5E47","\u5E5A","\u5E6B","\u6360","\u6886","\u6D5C","\u90A6","\u90AB","\u97A4","\u{20CD0}"],"p\xF3u f\xFA":["\u57BA"],c\u00E9n:["\u57C1","\u5C91","\u6D94"],"b\u011Bng f\u0113ng":["\u57C4"],"d\xEC f\xE1ng":["\u57C5"],"xi\xE1 ji\u0101":["\u57C9"],"m\xE1i m\xE1n":["\u57CB"],l\u00E0ng:["\u57CC","\u5D00","\u6D6A","\u8497","\u95AC","\u3AF0"],"sh\u0101n y\xE1n":["\u57CF"],"q\xEDn j\u012Bn":["\u57D0"],"p\u01D4 b\xF9":["\u57D4"],hu\u0101:["\u57D6","\u5A72","\u691B","\u7874","\u7CC0","\u82B1","\u848A","\u8624","\u8AAE","\u9335"],"su\xEC s\xF9":["\u57E3"],"p\xED p\xEC":["\u57E4"],"q\u012Bng zh\u0113ng":["\u57E5","\u9CAD"],"w\u01CEn w\u0101n":["\u57E6"],l\u01D4n:["\u57E8","\u7A10","\u{2BB62}"],"zh\u0113ng ch\xE9ng":["\u57E9"],k\u014Dng:["\u57EA","\u5D06","\u7B9C","\u8EBB","\u9313","\u9D7C"],"c\u01CEi c\xE0i":["\u57F0","\u5BC0","\u91C7"],"ch\xF9 t\xF2u":["\u57F1"],b\u011Bng:["\u57F2","\u742B","\u83F6","\u979B"],"k\u01CEn xi\xE0n":["\u57F3"],"y\xEC sh\xEC":["\u57F6","\u91B3"],p\u00E9i:["\u57F9","\u6BF0","\u88F4","\u88F5","\u8CE0","\u8D54","\u9307","\u952B","\u962B","\u966A"],"s\xE0o s\u01CEo":["\u57FD"],"j\u01D0n q\u012Bn j\xECn":["\u5807"],"p\xE9ng b\xE8ng":["\u580B"],"qi\xE0n z\xE0n ji\xE0n":["\u5811"],\u00E0n:["\u5813","\u5C75","\u5CB8","\u6309","\u6697","\u6848","\u80FA","\u834C","\u8C7B","\u8C8B","\u930C","\u95C7","\u968C","\u9EEF"],"du\xF2 hu\u012B":["\u5815","\u58AE"],hu\u00E1n:["\u581A","\u5BCF","\u5BF0","\u5CD8","\u6853","\u6D39","\u6FB4","\u7342","\u73AF","\u74B0","\u7CEB","\u7E6F","\u7F33","\u7FA6","\u8341","\u8408","\u8411","\u8C72","\u9370","\u9436","\u953E","\u956E","\u95E4","\u961B","\u96C8","\u9B1F","\u9E6E","\u{2C62B}","\u{24A7D}"],"b\u01CEo b\u01D4 p\xF9":["\u5821"],"m\xE1o m\xF3u w\u01D4":["\u5825"],ru\u00E1n:["\u5827","\u58D6","\u648B"],"\xE0i \xE8 y\xE8":["\u5828"],g\u00E8ng:["\u5829","\u6685"],m\u00E9i:["\u5833","\u587A","\u5A92","\u5D4B","\u5FBE","\u6517","\u679A","\u6802","\u6885","\u6963","\u6973","\u69D1","\u6E44","\u6E48","\u7164","\u7338","\u73AB","\u73FB","\u7442","\u7709","\u7742","\u7996","\u8104","\u8122","\u815C","\u82FA","\u8393","\u847F","\u90FF","\u9176","\u9387","\u9545","\u9709","\u9DA5","\u9E5B","\u9EF4"],d\u01D4:["\u5835","\u743D","\u7779","\u7B03","\u7BE4","\u89A9","\u8CED","\u8D4C"],f\u00E9ng:["\u5838","\u7D98","\u8242","\u9022"],h\u00E8ng:["\u583C"],ch\u016Bn:["\u583E","\u5A8B","\u65FE","\u6625","\u6699","\u6776","\u693F","\u69C6","\u6A41","\u6AC4","\u7443","\u7BBA","\u8405","\u877D","\u8F34","\u9C06","\u9D9E","\u4CA0"],ji\u01CEng:["\u5842","\u5956","\u5968","\u596C","\u6868","\u69F3","\u734E","\u8029","\u8199","\u848B","\u8523","\u8B1B","\u8BB2","\u985C"],hu\u0101ng:["\u5843","\u5DDF","\u614C","\u8093","\u8352","\u8841"],du\u00E0n:["\u5845","\u65AD","\u65B7","\u6934","\u6BB5","\u6BC8","\u7145","\u7456","\u78AB","\u7C16","\u7C6A","\u7DDE","\u7F0E","\u8176","\u846E","\u8E96","\u935B","\u953B"],t\u01CE:["\u5854","\u5896","\u736D","\u737A","\u9B99","\u9C28","\u9CCE"],w\u011Bng:["\u5855","\u5963","\u5D61","\u651A","\u66A1","\u7788","\u84CA"],"s\u0101i s\xE0i s\xE8":["\u585E"],z\u00E0ng:["\u585F","\u5F09","\u81D3","\u81DF","\u846C","\u8535","\u92BA"],ti\u00E1n:["\u5861","\u5C47","\u606C","\u6CBA","\u6E49","\u74B3","\u751B","\u751C","\u7530","\u754B","\u7551","\u78B5","\u78CC","\u80CB","\u95D0","\u9617","\u9D2B","\u9DC6","\u9DCF"],zh\u00E8ng:["\u5863","\u5E41","\u653F","\u8A3C","\u8ACD","\u8B49","\u8BC1","\u8BE4","\u90D1","\u912D","\u9755","\u9D0A"],"ti\xE1n zh\xE8n":["\u586B"],w\u0113n:["\u586D","\u6637","\u69B2","\u6B9F","\u6E29","\u6EAB","\u7465","\u761F","\u8570","\u8C71","\u8F3C","\u8F40","\u8F92","\u93BE","\u9942","\u9C1B","\u9C2E","\u9CC1"],li\u00F9:["\u586F","\u5EC7","\u78DF","\u7FCF","\u96E1","\u9724","\u993E","\u9B38","\u9DDA","\u9E68"],h\u01CEi:["\u5870","\u6D77","\u70F8","\u917C","\u91A2"],l\u01CEng:["\u5871","\u6716","\u6717","\u6724","\u70FA","\u84E2","\u3BBE"],b\u00E8ng:["\u5874","\u63FC","\u6CF5","\u750F","\u7DB3","\u8E66","\u8FF8","\u902C","\u93F0","\u955A"],ch\u00E9n:["\u5875","\u5BB8","\u5C18","\u5FF1","\u6550","\u6576","\u6668","\u66DF","\u6815","\u6A04","\u6C89","\u7141","\u760E","\u81E3","\u831E","\u8380","\u8390","\u852F","\u85BC","\u87B4","\u8A26","\u8AF6","\u8ED9","\u8FB0","\u8FE7","\u9202","\u9648","\u9673","\u9703","\u9DD0","\u9E8E"],"\u014Du qi\u016B":["\u5878"],"qi\xE0n ji\xE0n":["\u5879"],"zhu\u0101n tu\xE1n":["\u587C"],shu\u01CEng:["\u587D","\u6161","\u6F3A","\u723D","\u7E14","\u93EF"],sh\u00FA:["\u587E","\u5A4C","\u5B70","\u74B9","\u79EB","\u8D16","\u8D4E"],l\u01D2u:["\u587F","\u5D5D","\u5D81","\u750A","\u7BD3","\u7C0D"],ch\u00ED:["\u5880","\u5F1B","\u6301","\u6C60","\u6F26","\u7AFE","\u7B42","\u7B8E","\u7BEA","\u830C","\u834E","\u86B3","\u8B18","\u8CBE","\u8D7F","\u8E1F","\u8FDF","\u8FE1","\u9045","\u905F","\u9072","\u9349","\u99B3","\u9A70"],sh\u00F9:["\u5885","\u5EB6","\u5EBB","\u6037","\u6055","\u620D","\u675F","\u6811","\u6A39","\u6CAD","\u6F31","\u6F44","\u6FD6","\u7AD6","\u7AEA","\u7D49","\u8167","\u8357","\u8481","\u866A","\u8853","\u88CB","\u8C4E","\u8FF0","\u9265","\u9330","\u93E3","\u9714","\u9D90","\u{2CB38}"],"d\xEC zh\xEC":["\u5886","\u7590"],k\u00E0n:["\u5888","\u5D01","\u77B0","\u77D9","\u78E1","\u884E","\u9B2B"],ch\u011Bn:["\u588B","\u5926","\u7876","\u789C","\u78E3","\u8D02","\u8DBB","\u8E38","\u9356"],"zh\u01D0 zhu\xF3":["\u588C"],qi\u01CEng:["\u588F","\u7E48","\u7E66","\u7FA5","\u8941"],z\u0113ng:["\u5897","\u589E","\u618E","\u7494","\u77F0","\u78F3","\u7F7E","\u8B44","\u912B","\u9C5B","\u4396"],qi\u00E1ng:["\u5899","\u58BB","\u5AF1","\u5B19","\u6A2F","\u6AA3","\u6F12","\u7246","\u8262","\u8503","\u8537","\u8620"],"ku\xE0i tu\xED":["\u58A4"],"tu\u01CEn d\u01D2ng":["\u58A5"],"qi\xE1o qu\xE8":["\u58A7"],"z\u016Bn d\u016Bn":["\u58AB"],"qi\u0101o \xE1o":["\u58BD"],"y\xEC t\xFA":["\u58BF"],"xu\xE9 b\xF3 ju\xE9":["\u58C6"],l\u01CEn:["\u58C8","\u5B3E","\u5B44","\u5B4F","\u61D2","\u61F6","\u63FD","\u64E5","\u652C","\u6984","\u6B16","\u6D68","\u6F24","\u7060","\u7E9C","\u7F06","\u7F71","\u89A7","\u89BD","\u89C8","\u9182","\u9872"],hu\u00E0i:["\u58CA","\u58DE","\u863E"],r\u01CEng:["\u58CC","\u58E4","\u6518","\u7219"],"l\xE0n xi\xE0n":["\u58CF"],d\u01CEo:["\u58D4","\u5BFC","\u5C0E","\u5C9B","\u5CF6","\u5D8B","\u5D8C","\u5DB9","\u6363","\u6417","\u64E3","\u69DD","\u7977","\u7982","\u79B1","\u8E48","\u9666","\u969D","\u96AF"],ru\u01D0:["\u58E1","\u6875","\u6A64","\u7E60","\u854A","\u854B","\u8602","\u8603"],san:["\u58ED"],zhu\u00E0ng:["\u58EE","\u58EF","\u58F5","\u649E","\u710B","\u72B6","\u72C0"],"k\xE9 qi\xE0o":["\u58F3","\u6BBC"],k\u01D4n:["\u58F8","\u58FC","\u6083","\u6346","\u68B1","\u7871","\u7975","\u7A07","\u7A1B","\u7D91","\u88CD","\u95AB","\u95B8","\u9603"],m\u01CEng:["\u58FE","\u6F2D","\u833B","\u83BD","\u83BE","\u880E"],c\u00FAn:["\u58FF","\u5B58"],"zh\u01D0 zh\u014Dng":["\u5902"],"g\u01D4 y\xEDng":["\u5903"],"ji\xE0ng xi\xE1ng":["\u5905","\u964D"],"p\xE1ng f\xE9ng f\u0113ng":["\u5906"],zh\u0101i:["\u5908","\u635A","\u6458","\u658B","\u658E","\u69B8","\u7C82","\u9F4B"],"xu\xE0n xi\xF2ng":["\u5910"],w\u00E0i:["\u5916","\u9861"],"w\u01CEn yu\xE0n w\u0101n yu\u0101n":["\u5917"],"m\u01CEo w\u01CEn":["\u5918"],m\u00E8ng:["\u5922","\u5923","\u5B5F","\u68A6","\u7666","\u9725"],"d\xE0 d\xE0i":["\u5927"],"f\u016B f\xFA":["\u592B","\u59C7","\u678E","\u7CB0"],gu\u00E0i:["\u592C","\u602A","\u6060"],y\u0101ng:["\u592E","\u59CE","\u62B0","\u6B83","\u6CF1","\u79E7","\u80E6","\u9260","\u9348","\u96F5","\u9D26","\u9E2F"],"h\u0101ng b\xE8n":["\u592F"],g\u01CEo:["\u5930","\u641E","\u6772","\u69C0","\u69C1","\u6ABA","\u7A01","\u7A3E","\u7A3F","\u7E1E","\u7F1F","\u83D2","\u85C1","\u85F3"],"t\u0101o b\u011Bn":["\u5932"],"t\xF3u tou":["\u5934"],"y\u01CEn t\u0101o":["\u5935"],"ku\u0101 ku\xE0":["\u5938","\u8A87"],"ji\xE1 ji\u0101 g\u0101 xi\xE1":["\u5939"],hu\u00E0:["\u593B","\u5A73","\u5AFF","\u5B05","\u5D0B","\u6466","\u6779","\u67A0","\u6866","\u69EC","\u6A3A","\u6F85","\u753B","\u756B","\u7575","\u7E63","\u8219","\u8A71","\u8AD9","\u8B6E","\u8BDD","\u9ECA"],"ji\u0101 ji\xE1 g\u0101 xi\xE1":["\u593E"],\u0113n:["\u5940","\u6069","\u84BD"],"d\u012B t\xEC":["\u5943"],"y\u01CEn y\u0101n":["\u5944","\u6E30"],p\u00E0o:["\u5945","\u75B1","\u76B0","\u7832","\u791F","\u792E","\u9764","\u9EAD"],n\u00E0i:["\u5948","\u67F0","\u6E3F","\u8010","\u8418","\u8926","\u933C","\u9F10"],"qu\u0101n ju\xE0n":["\u594D","\u5F2E","\u68EC"],z\u00F2u:["\u594F","\u63CD"],"q\xEC qi\xE8 xi\xE8":["\u5951"],k\u0101i:["\u5952","\u5F00","\u63E9","\u9426","\u950E","\u958B"],"b\u0113n b\xE8n":["\u5954","\u6CCD"],t\u00E0o:["\u5957"],"z\xE0ng zhu\u01CEng":["\u5958"],b\u011Bn:["\u5959","\u672C","\u694D","\u755A","\u7FC9","\u82EF"],"x\xF9n zhu\xEC":["\u595E"],sh\u0113:["\u5962","\u6AA8","\u731E","\u756D","\u7572","\u8CD2","\u8CD6","\u8D4A","\u8F0B","\u{2AA36}"],"h\u01CE p\xF2 t\u01CEi":["\u5964"],"\xE0o y\xF9":["\u5965","\u5967","\u6F9A"],y\u016Bn:["\u596B","\u6C32","\u6C33","\u8480","\u8495","\u8779","\u8D07","\u8D5F","\u{2B5B3}"],"du\u01D2 ch\u011B":["\u5972"],"n\u01DA r\u01D4":["\u5973"],n\u00FA:["\u5974","\u5B65","\u7B2F","\u99D1","\u9A7D"],"d\u012Bng d\u01D0ng ti\u01CEn":["\u5975"],"t\u0101 ji\u011B":["\u5979"],nu\u00E1n:["\u597B"],"h\u01CEo h\xE0o":["\u597D"],f\u00E0n:["\u597F","\u5B0E","\u68B5","\u6C4E","\u6CDB","\u6EFC","\u702A","\u72AF","\u7548","\u76D5","\u7B35","\u7BC4","\u8303","\u8A09","\u8CA9","\u8D29","\u8EEC","\u8F3D","\u98EF","\u98F0","\u996D"],shu\u00F2:["\u5981","\u6420","\u6714","\u69CA","\u70C1","\u720D","\u77DF","\u84B4","\u9399","\u9460","\u94C4"],"f\u0113i p\xE8i":["\u5983"],w\u00E0ng:["\u5984","\u5FD8","\u65FA","\u671B","\u6722"],zhu\u0101ng:["\u5986","\u599D","\u5A24","\u5E84","\u5E92","\u6869","\u6889","\u6A01","\u7CA7","\u7CDA","\u8358","\u838A","\u88C5","\u88DD"],m\u0101:["\u5988","\u5ABD"],"f\u016B y\u014Du":["\u598B"],"h\xE0i ji\xE8":["\u598E"],d\u00F9:["\u5992","\u59AC","\u675C","\u6BAC","\u6E21","\u79FA","\u828F","\u8370","\u8799","\u8827","\u8839","\u934D","\u9540","\u976F","\u{2CB4A}"],mi\u00E0o:["\u5999","\u5E99","\u5EBF","\u5EDF","\u7385","\u7AD7"],"f\u01D2u p\u0113i p\u012B":["\u599A"],"yu\xE8 ju\xE9":["\u599C"],ni\u016B:["\u599E"],"n\xE0 n\xE0n":["\u59A0"],tu\u01D2:["\u59A5","\u5AF7","\u5EB9","\u692D","\u6955","\u6A62","\u9B0C","\u9C16","\u9D4E"],"w\xE0n yu\xE1n":["\u59A7"],f\u00E1ng:["\u59A8","\u623F","\u80AA","\u9632","\u9B74","\u9C82"],n\u012B:["\u59AE"],zh\u00F3u:["\u59AF","\u78A1"],zh\u0101o:["\u59B1","\u5DF6","\u62DB","\u662D","\u91D7","\u924A","\u9363","\u948A","\u99CB","\u{2CB3F}"],"n\u01CEi n\u01D0":["\u59B3"],t\u01D2u:["\u59B5","\u6568","\u7D0F","\u8623","\u9EC8"],"xi\xE1n xu\xE1n x\xF9":["\u59B6"],"zh\xED y\xEC":["\u59B7","\u79C7"],\u0113:["\u59B8","\u59BF","\u5A40","\u5C59"],m\u00E8i:["\u59B9","\u5A9A","\u5BD0","\u62BA","\u65C0","\u6627","\u6CAC","\u715D","\u75D7","\u771B","\u7778","\u7959","\u7BC3","\u875E","\u8882","\u8DCA","\u9B3D","\u9B45"],"q\u012B q\xEC":["\u59BB"],"x\u016B x\u01D4":["\u59C1","\u7A30"],"sh\u0101n sh\xE0n":["\u59CD","\u59D7","\u82EB","\u91E4","\u9490"],m\u00E1n:["\u59CF","\u6172","\u6A20","\u86EE","\u883B","\u8B3E","\u9945","\u9992","\u9B17","\u9B18","\u9C3B","\u9CD7"],ji\u011B:["\u59D0","\u5A8E","\u6A9E","\u6BD1","\u98F7"],"w\u011Bi w\u0113i":["\u59D4"],p\u012Bn:["\u59D8","\u62FC","\u7917","\u7A66","\u99AA","\u9A5E"],"hu\xE1 hu\xF3":["\u59E1"],"ji\u0101o xi\xE1o":["\u59E3"],"g\xF2u d\xF9":["\u59E4"],"l\u01CEo m\u01D4":["\u59E5"],"ni\xE1n ni\xE0n":["\u59E9"],zh\u011Bn:["\u59EB","\u5C52","\u5F2B","\u62AE","\u6623","\u6795","\u755B","\u75B9","\u7715","\u7A39","\u7E1D","\u7E25","\u7F1C","\u8044","\u8419","\u8897","\u88D6","\u8999","\u8A3A","\u8BCA","\u8EEB","\u8F78","\u8FB4","\u99D7","\u9B12"],h\u00E9ng:["\u59EE","\u6046","\u6052","\u70C6","\u73E9","\u80FB","\u8605","\u8861","\u9445","\u9D34","\u9D46","\u9E3B"],"j\u016Bn x\xFAn":["\u59F0"],"ku\u0101 h\xF9":["\u59F1"],"\xE8 y\xE0":["\u59F6"],"xi\u0101n sh\u0113n":["\u59FA"],w\u00E1:["\u5A03"],"r\xE1o r\u01CEo":["\u5A06","\u5B08"],"sh\xE0o sh\u0101o":["\u5A0B"],xi\u0113:["\u5A0E","\u63F3","\u6954","\u6B47","\u874E","\u880D"],"w\u01D4 m\xE9i m\u01D4":["\u5A12"],"chu\xF2 l\xE0i":["\u5A15"],ni\u00E1ng:["\u5A18","\u5B22","\u5B43"],"n\xE0 nu\xF3":["\u5A1C","\u{26C21}"],"p\u014Du b\u01D0":["\u5A1D"],"n\u011Bi su\u012B":["\u5A1E"],tu\u00EC:["\u5A27","\u717A","\u86FB","\u8715","\u9000","\u99FE"],m\u01CEn:["\u5A28","\u5C58","\u6E80","\u6EE1","\u6EFF","\u87A8","\u87CE","\u8954","\u93CB"],"w\xFA w\xF9 y\xFA":["\u5A2A"],"x\u012B \u0101i":["\u5A2D"],"zhu\xEC shu\xEC":["\u5A37"],"d\u014Dng d\xF2ng":["\u5A3B"],"\u01CEi \xE1i \xE8":["\u5A3E"],"\u0113 \u011B":["\u5A3F"],mi\u00E1n:["\u5A42","\u5B35","\u5B80","\u6763","\u68C9","\u6AB0","\u6ACB","\u7720","\u77C8","\u77CA","\u77CF","\u7DBF","\u7DDC","\u7EF5","\u8287","\u8752"],"p\u01D2u p\xE9i b\xF9":["\u5A44"],bi\u01CEo:["\u5A4A","\u813F","\u8868","\u88F1","\u893E","\u8AD8","\u9336"],"f\xF9 f\xE0n":["\u5A4F"],w\u01D2:["\u5A50","\u5A51","\u6211"],"n\xED n\u01D0":["\u5A57","\u68FF"],"qu\xE1n ju\xE0n":["\u5A58","\u60D3"],h\u016Bn:["\u5A5A","\u660F","\u662C","\u68D4","\u6DBD","\u7767","\u776F","\u7888","\u8364","\u8477","\u8512","\u8F4B","\u95BD","\u960D"],"qi\u0101n j\u01D0n":["\u5A5C"],"w\u0101n w\xE0":["\u5A60"],"l\xE1i l\xE0i":["\u5A61","\u5F95","\u5FA0"],"zh\u014Du ch\u014Du":["\u5A64"],"chu\xF2 n\xE0o":["\u5A65"],"n\xFC\xE8 \xE0n":["\u5A69"],"h\xF9n k\u016Bn":["\u5A6B"],"d\xE0ng y\xE1ng":["\u5A78"],n\u00E0n:["\u5A7B"],"ru\xF2 chu\xF2":["\u5A7C"],ji\u01CE:["\u5A7D","\u5CAC","\u659A","\u659D","\u698E","\u69DA","\u6A9F","\u73BE","\u7532","\u80DB","\u9240","\u94BE"],"t\u014Du y\xFA":["\u5A7E","\u5AAE"],"y\xF9 y\xFA":["\u5A80"],"w\xE9i w\u011Bi":["\u5A81"],"d\xEC t\xED":["\u5A82","\u73F6","\u82D0"],r\u00F3u:["\u5A83","\u63C9","\u67D4","\u6E18","\u7163","\u7448","\u74C7","\u79B8","\u7C88","\u7CC5","\u811C","\u816C","\u8447","\u875A","\u8E42","\u8F2E","\u9352","\u97A3","\u9A25","\u9C07","\u9D94","\u{2B413}"],"ru\u01CEn n\xE8n":["\u5A86"],mi\u00E1o:["\u5A8C","\u5AF9","\u63CF","\u7784","\u82D7","\u9D93","\u9E4B"],"y\xED p\xE8i":["\u5A90"],"mi\xE1n mi\u01CEn":["\u5A94"],"t\xED sh\xEC":["\u5A9E","\u60FF"],"du\xF2 tu\xF3":["\u5AA0","\u6CB2"],\u01CEo:["\u5AAA","\u5ABC","\u8279","\u82BA","\u8884","\u8956","\u957A"],"ch\xFA z\xF2u":["\u5AB0"],y\u00ECng:["\u5AB5","\u6620","\u668E","\u786C","\u81A1","\u9C66"],"q\xEDn sh\u0113n":["\u5AC0"],ji\u00E0:["\u5AC1","\u5E4F","\u67B6","\u69A2","\u7A3C","\u99D5","\u9A7E"],s\u01CEo:["\u5AC2"],"zh\u0113n zh\u011Bn":["\u5AC3"],"ji\u0113 su\u01D2":["\u5AC5"],"m\xEDng m\u01D0ng":["\u5AC7"],ni\u01CEo:["\u5ACB","\u5B1D","\u5B32","\u8311","\u8526","\u8885","\u88CA","\u892D","\u9E1F"],t\u0101o:["\u5ACD","\u5E4D","\u5F22","\u6146","\u638F","\u642F","\u69C4","\u6D9B","\u6ED4","\u6FE4","\u746B","\u7D5B","\u7E1A","\u7E27","\u7EE6","\u8A5C","\u8B1F","\u8F41","\u97B1","\u97DC","\u97EC","\u98F8","\u9955"],bi\u00E1o:["\u5AD1"],"pi\xE1o pi\u0101o":["\u5AD6","\u85B8"],xu\u00E1n:["\u5AD9","\u60AC","\u61F8","\u66B6","\u6A88","\u6F29","\u7384","\u7487","\u74BF","\u75C3","\u8701","\u{2B80A}"],"m\xE0n m\u0101n":["\u5ADA"],k\u0101ng:["\u5ADD","\u5D7B","\u5EB7","\u6177","\u69FA","\u6F2E","\u780A","\u7A45","\u7CE0","\u8EBF","\u93EE","\u9C47","\u{21413}","\u{29F8C}"],"h\u0101n n\u01CEn":["\u5AE8"],n\u00E8n:["\u5AE9","\u5AF0"],zh\u0113:["\u5AEC","\u906E"],"m\u0101 m\xE1":["\u5AF2"],pi\u00E8:["\u5AF3"],zh\u01CEn:["\u5AF8","\u5C55","\u640C","\u65A9","\u65AC","\u7416","\u76CF","\u76DE","\u8F3E","\u9186","\u98AD","\u98D0"],"xi\u0101n y\u01CEn j\xECn":["\u5B10"],li\u01CEn:["\u5B1A","\u655B","\u6582","\u740F","\u7489","\u7FB7","\u8138","\u81C9","\u8539","\u861D","\u861E","\u88E3","\u895D","\u913B"],"qi\xF3ng hu\xE1n xu\u0101n":["\u5B1B"],d\u01D2ng:["\u5B1E","\u61C2","\u7BBD","\u8463","\u856B","\u8ACC"],c\u0101n:["\u5B20","\u6E4C","\u7218","\u98E1","\u9910","\u9A42","\u9A96"],ti\u01CEo:["\u5B25","\u5BA8","\u6640","\u6713","\u7AB1","\u8101"],b\u00ED:["\u5B36","\u8378","\u9F3B"],li\u01D4:["\u5B3C","\u67F3","\u6801","\u685E","\u687A","\u6A6E","\u71AE","\u73CB","\u7DB9","\u7EFA","\u7F76","\u7F80","\u92F6","\u950D"],"qi\u0101n xi\u0101n":["\u5B45","\u6B26"],"xi\xE9 hu\u012B":["\u5B48"],"hu\u0101n qu\xE1n":["\u5B49"],"l\xED l\xEC":["\u5B4B","\u9E97"],"zh\xFA chu\xF2":["\u5B4E"],k\u01D2ng:["\u5B54","\u6050"],"m\u0101 z\u012B":["\u5B56"],"s\u016Bn x\xF9n":["\u5B59","\u5B6B"],"b\xE8i b\xF3":["\u5B5B","\u8A96"],"y\xF2u ni\u016B":["\u5B67"],zhu\u01CEn:["\u5B68","\u7AF1","\u8F49"],h\u00E1i:["\u5B69","\u9AB8"],n\u0101o:["\u5B6C"],"ch\xE1n c\xE0n":["\u5B71"],b\u00F2:["\u5B79","\u6A97","\u8617","\u8B52"],n\u00E1i:["\u5B7B","\u8149"],"n\xEDng n\xECng":["\u5B81","\u5BCD","\u5BD7","\u5BDC","\u5BE7","\u752F"],zh\u00E1i:["\u5B85"],"t\u016B ji\u0101":["\u5B8A"],s\u00F2ng:["\u5B8B","\u8A1F","\u8AA6","\u8BBC","\u8BF5","\u9001","\u93B9","\u980C","\u9882","\u9938"],r\u00F2u:["\u5B8D","\u8089","\u8B73"],zh\u016Bn:["\u5B92","\u7A80","\u8860","\u8AC4","\u8C06","\u8FCD"],"m\xEC f\xFA":["\u5B93"],"d\xE0ng t\xE0n":["\u5B95"],"w\u01CEn yu\u0101n":["\u5B9B"],ch\u01D2ng:["\u5BA0","\u5BF5"],q\u00FAn:["\u5BAD","\u5CEE","\u5E2C","\u7FA3","\u7FA4","\u88D9","\u88E0"],z\u01CEi:["\u5BB0","\u5D3D"],"b\u01CEo sh\xED":["\u5BB2"],"ji\u0101 jia jie":["\u5BB6"],"hu\u0101ng hu\u01CEng":["\u5BBA"],ku\u0101n:["\u5BBD","\u5BDB","\u5BEC","\u81D7","\u9467","\u9ACB","\u9AD6"],"s\xF9 xi\u01D4 xi\xF9":["\u5BBF"],"ji\xE9 z\u01CEn":["\u5BC1"],"b\xECng b\u01D0ng":["\u5BCE"],"j\xECn q\u01D0n":["\u5BD6"],"l\xF3u j\xF9":["\u5BE0"],"xi\u011B xi\xE8":["\u5BEB"],"q\u012Bn q\xECn":["\u5BF4"],c\u00F9n:["\u5BF8","\u7C7F"],du\u00EC:["\u5BF9","\u5BFE","\u5C0D","\u603C","\u619D","\u61DF","\u6FE7","\u7029","\u7893","\u794B","\u7D90","\u85B1","\u8B48","\u8B75","\u8F5B","\u961F","\u966E"],"l\xFC\xE8 lu\xF3":["\u5BFD"],"sh\xE8 y\xE8 y\xEC":["\u5C04"],"ji\u0101ng ji\xE0ng qi\u0101ng":["\u5C06"],"ji\u0101ng ji\xE0ng":["\u5C07","\u6D46","\u6F3F","\u757A"],z\u016Bn:["\u5C0A","\u5D9F","\u6A3D","\u7F47","\u9075","\u940F","\u9C52","\u9CDF","\u9D8E","\u9DF7","\u{28C54}"],"sh\xF9 zh\xF9":["\u5C0C","\u6F8D"],xi\u01CEo:["\u5C0F","\u6653","\u6681","\u66C9","\u769B","\u76A2","\u7B71","\u7B7F","\u7BE0","\u8B0F","\u{2B372}"],"ji\xE9 j\xED":["\u5C10","\u8BD8","\u978A"],"sh\u01CEo sh\xE0o":["\u5C11"],\u011Br:["\u5C12","\u5C13","\u5C14","\u682E","\u6BE6","\u6D31","\u723E","\u73E5","\u8033","\u85BE","\u8848","\u8DB0","\u8FE9","\u9087","\u927A","\u94D2","\u990C","\u9975","\u99EC"],"w\u0101ng y\xF3u":["\u5C22"],w\u0101ng:["\u5C23","\u5C29","\u5C2A","\u5C2B","\u6C6A"],li\u00E0o:["\u5C25","\u5C26","\u5ED6","\u6482","\u6599","\u7093","\u7AB7","\u9410","\u9563","\u{2A917}"],"m\xE9ng m\xE1ng l\xF3ng p\xE1ng":["\u5C28"],g\u00E0:["\u5C2C","\u9B40"],"ku\xEC ku\u01D0":["\u5C2F"],tu\u00ED:["\u5C35","\u5F1A","\u7A68","\u8608","\u8E6A","\u96A4","\u9839","\u983A","\u983D","\u9893","\u9B4B","\u{2CBCE}"],y\u01D0n:["\u5C39","\u5DBE","\u5F15","\u6704","\u6A83","\u6ABC","\u6AFD","\u6DFE","\u6FE5","\u763E","\u766E","\u7C8C","\u861F","\u8693","\u87BE","\u8B94","\u8D7A","\u8D9B","\u8F11","\u920F","\u9777"],"ch\u01D0 ch\u011B":["\u5C3A"],k\u0101o:["\u5C3B","\u9ADB"],"j\xECn j\u01D0n":["\u5C3D"],"w\u011Bi y\u01D0":["\u5C3E"],"ni\xE0o su\u012B":["\u5C3F"],c\u00E9ng:["\u5C42","\u5C64","\u5D92","\u9A53"],di\u01CEo:["\u5C4C"],"p\xEDng b\u01D0ng b\u012Bng":["\u5C4F"],l\u00F2u:["\u5C5A","\u6F0F","\u7618","\u763A","\u763B","\u93E4","\u9542","\u964B"],"sh\u01D4 zh\u01D4":["\u5C5E","\u5C6C"],"xi\xE8 t\xEC":["\u5C5F"],"ch\xE8 c\u01CEo":["\u5C6E"],"t\xFAn zh\u016Bn":["\u5C6F"],"n\xEC j\u01D0":["\u5C70"],"h\xF3ng l\xF3ng":["\u5C78"],"q\u01D0 k\u01CEi":["\u5C82","\u8C48"],\u00E1ng:["\u5C87","\u6602","\u663B"],"g\u01CEng g\u0101ng":["\u5C97","\u5D17"],k\u011B:["\u5CA2","\u6564","\u6E07","\u6E34","\u70A3"],g\u01D2u:["\u5CA3","\u72D7","\u73BD","\u7B31","\u8007","\u8008","\u8009","\u82DF","\u8C7F"],ti\u00E1o:["\u5CA7","\u5CB9","\u6A24","\u7952","\u7B24","\u8280","\u8414","\u84DA","\u84E8","\u8729","\u8FE2","\u92DA","\u93A5","\u9797","\u9AEB","\u9BC8","\u9C37","\u9CA6","\u9F60","\u9F86"],"q\u016B j\u016B":["\u5CA8"],l\u01D0ng:["\u5CAD","\u5DBA","\u9818","\u9886"],p\u00F2:["\u5CB6","\u6540","\u6D26","\u6E50","\u70DE","\u73C0","\u7834","\u7836","\u7C95","\u84AA","\u9B44"],"b\u0101 k\xE8":["\u5CC7"],lu\u00F2:["\u5CC8","\u645E","\u6D1B","\u6D1C","\u7296","\u73DE","\u7B3F","\u7E99","\u8366","\u8A7B","\u96D2","\u99F1","\u9A86","\u9D45"],"f\xF9 ni\xE8":["\u5CCA"],\u011Bn:["\u5CCE"],"zh\xEC sh\xEC":["\u5CD9","\u5D3B"],qi\u01CE:["\u5CE0","\u8DD2","\u9160","\u9790"],"qi\xE1o ji\xE0o":["\u5CE4","\u7644"],"xi\xE9 y\xE9":["\u5CEB"],b\u016B:["\u5CEC","\u5EAF","\u6661","\u8AA7","\u900B","\u923D","\u933B","\u94B8","\u9914","\u9D4F"],ch\u00F3ng:["\u5D07","\u5D08","\u721E","\u866B","\u8769","\u87F2","\u8908","\u9680"],"z\xFA cu\xEC":["\u5D12","\u690A"],"l\xEDng l\xE9ng":["\u5D1A"],"d\xF2ng d\u014Dng":["\u5D20"],xi\u00E1o:["\u5D24","\u6D28","\u6DC6","\u8A24","\u8AB5"],"p\xED b\u01D0":["\u5D25","\u8298"],"zh\u01CEn ch\xE1n":["\u5D2D","\u5D83","\u5D84"],"w\u01CEi w\u0113i":["\u5D34"],"y\xE1ng d\xE0ng":["\u5D35"],"sh\xEC di\xE9":["\u5D3C"],y\u00E0o:["\u5D3E","\u66DC","\u718E","\u71FF","\u77C5","\u7A7E","\u7A94","\u7B44","\u8000","\u825E","\u836F","\u846F","\u85AC","\u85E5","\u888E","\u899E","\u8A4F","\u8B91","\u977F","\u9DC2","\u9E5E","\u9F3C"],"k\u0101n zh\xE0n":["\u5D41"],"h\xE1n d\u01CEng":["\u5D45"],"qi\xE0n k\xE0n":["\u5D4C"],"w\xF9 m\xE1o":["\u5D4D"],"k\u011B ji\xE9":["\u5D51","\u5DB1"],"w\u0113i w\u011Bi":["\u5D54"],k\u0113:["\u5D59","\u67EF","\u68F5","\u69BC","\u6A16","\u7241","\u7271","\u7290","\u73C2","\u75B4","\u778C","\u78D5","\u791A","\u79D1","\u7A1E","\u7AA0","\u842A","\u8596","\u86B5","\u874C","\u8DB7","\u8F72","\u9198","\u9233","\u94B6","\u9826","\u9846","\u9897","\u9AC1"],"d\xE0ng t\xE1ng":["\u5D63"],"r\xF3ng y\xEDng":["\u5D64","\u7203"],"\xE1i k\u01CEi":["\u5D66"],"k\u0101o qi\u0101o":["\u5D6A"],cu\u00F3:["\u5D6F","\u5D73","\u75E4","\u77EC","\u84AB","\u8516","\u8658","\u9E7A","\u9E7E"],"qi\u01CEn q\u012Bn":["\u5D70"],"d\xEC di\xE9":["\u5D7D"],c\u0113n:["\u5D7E"],d\u01D0ng:["\u5D7F","\u827C","\u85A1","\u9424","\u9802","\u9876","\u9F0E","\u9F11"],"\xE1o \xE0o":["\u5D85"],"p\u01D0 p\xE8i":["\u5D8F"],"ji\xE0o qi\xE1o":["\u5DA0","\u6F50"],"ju\xE9 gu\xEC":["\u5DA1","\u9CDC"],"zh\u0101n sh\xE0n":["\u5DA6","\u9CE3"],"xi\xE8 ji\xE8":["\u5DB0"],"gu\u012B x\u012B ju\xE0n":["\u5DB2"],r\u016B:["\u5DBF"],"l\xEC li\xE8":["\u5DC1","\u68D9","\u7204","\u7D9F"],"x\u012B gu\u012B ju\xE0n":["\u5DC2"],"y\xEDng h\u014Dng":["\u5DC6"],y\u01D0ng:["\u5DCA","\u5EEE","\u5F71","\u646C","\u68AC","\u6F41","\u763F","\u766D","\u77E8","\u7A4E","\u90E2","\u941B","\u9834","\u988D","\u9895","\u9896"],ch\u01CEo:["\u5DD0","\u7092","\u717C","\u7727","\u9EA8"],cu\u00E1n:["\u5DD1","\u6AD5","\u6B11"],chu\u0101n:["\u5DDB","\u5DDD","\u6C1A","\u744F","\u7A7F"],"j\u012Bng x\xEDng":["\u5DE0"],ch\u00E1o:["\u5DE2","\u5DE3","\u6641","\u6F05","\u6F6E","\u724A","\u7AB2","\u7F7A","\u8B3F","\u8F48","\u911B","\u9F0C"],qi\u01CEo:["\u5DE7","\u6100","\u9ADC"],g\u01D2ng:["\u5DE9","\u5EFE","\u62F1","\u62F2","\u6831","\u6C5E","\u73D9","\u8F01","\u978F"],"ch\xE0 ch\u0101 ch\u0101i c\u012B":["\u5DEE"],"xi\xE0ng h\xE0ng":["\u5DF7"],shu\u00E0i:["\u5E05","\u5E25","\u87C0"],p\u00E0:["\u5E0A","\u5E15","\u6015","\u8899"],"t\u01CEng n\xFA":["\u5E11"],"m\xF2 w\xE0":["\u5E13"],"ti\u0113 ti\u011B ti\xE8":["\u5E16"],zh\u01D2u:["\u5E1A","\u666D","\u759B","\u776D","\u7B92","\u8098","\u83F7","\u9BDE"],"ju\u01CEn ju\xE0n":["\u5E23"],shu\u00EC:["\u5E28","\u6D97","\u6D9A","\u7761","\u7A05","\u7A0E","\u88DE"],"ch\xF3u d\xE0o":["\u5E31","\u5E6C"],"ji\u01CEn ji\u0101n s\xE0n":["\u5E34"],"sh\xE0 qi\xE8":["\u5E39"],"q\xED j\xEC":["\u5E3A","\u8360"],"sh\u0101n qi\u0101o sh\u0113n":["\u5E53"],"zhu\xE0ng chu\xE1ng":["\u5E62"],"ch\u0101n ch\xE0n":["\u5E68"],mi\u00E8:["\u5E6D","\u61F1","\u6423","\u6EC5","\u706D","\u70D5","\u7923","\u7BFE","\u8511","\u858E","\u881B","\u884A","\u9456","\u9C74","\u9D13"],"g\u0101n g\xE0n":["\u5E72"],"b\xECng b\u012Bng":["\u5E76","\u5E77"],"j\u012B j\u01D0":["\u5E7E"],"gu\u01CEng \u0101n":["\u5E7F"],gu\u01CEng:["\u5E83","\u5EE3","\u72B7","\u7377"],me:["\u5E85"],"d\xF9n t\xFAn":["\u5E89"],"b\xE0i t\u012Bng":["\u5E8D"],"y\xECng y\u012Bng":["\u5E94"],"d\u01D0 de":["\u5E95"],"d\xF9 du\xF3":["\u5EA6"],"m\xE1ng m\xE9ng p\xE1ng":["\u5EAC"],"b\xECng p\xEDng":["\u5EB0"],ch\u011Bng:["\u5EB1","\u609C","\u7748","\u901E","\u9A01","\u9A8B"],"j\u012B cu\xF2":["\u5EB4"],q\u01D0ng:["\u5EBC","\u5ECE","\u6ABE","\u6F00","\u82D8","\u8ACB","\u8B26","\u8BF7","\u9803","\u9877"],"gu\u012B w\u011Bi hu\xEC":["\u5EC6"],"j\u01D0n q\xEDn":["\u5ED1"],ku\u00F2:["\u5ED3","\u6269","\u62E1","\u64F4","\u6FF6","\u7B48","\u843F","\u8440","\u86DE","\u95CA","\u9614","\u9729","\u979F","\u97B9","\u97D5","\u9822","\u9B20"],"qi\xE1ng s\xE8":["\u5EE7","\u8594"],"y\u01D0n y\xECn":["\u5EF4","\u9690","\u96A0","\u96B1","\u98EE","\u98F2","\u996E"],"p\xF2 p\u01CEi":["\u5EF9","\u8FEB"],"n\xF2ng l\xF2ng":["\u5F04"],"d\xEC t\xEC tu\xED":["\u5F1F"],"ju\xE9 zh\u0101ng":["\u5F21"],"m\xED m\u01D0":["\u5F25","\u5F4C","\u9761"],ch\u0101o:["\u5F28","\u600A","\u6284","\u6B29","\u8A2C","\u8D85","\u9214","\u949E"],yi:["\u5F2C"],sh\u0101o:["\u5F30","\u65D3","\u70E7","\u713C","\u71D2","\u7B72","\u8244","\u8437","\u8571","\u8F0E","\u9AFE","\u9BB9"],"xu\u0101n yu\u0101n":["\u5F32"],"qi\xE1ng qi\u01CEng ji\xE0ng":["\u5F37","\u5F3A"],"t\xE1n d\xE0n":["\u5F39","\u9188"],bi\u00E8:["\u5F46"],"qi\xE1ng ji\xE0ng qi\u01CEng":["\u5F4A"],"j\xEC xu\u011B":["\u5F50"],tu\u00E0n:["\u5F56","\u8916"],yu\u0113:["\u5F5F","\u66F0","\u66F1","\u77F1"],"sh\u0101n xi\u01CEn":["\u5F61"],w\u00E9n:["\u5F63","\u6587","\u7086","\u73F3","\u7612","\u7E67","\u805E","\u82A0","\u8689","\u868A","\u87A1","\u87C1","\u95BA","\u95BF","\u95C5","\u95E6","\u95FB","\u960C","\u96EF","\u99BC","\u99C7","\u9B70","\u9CFC","\u9D0D","\u9F24","\u{2B61C}"],"p\xE9ng b\u0101ng":["\u5F6D"],"pi\u0101o pi\xE0o":["\u5F6F"],"zhu\xF3 b\xF3":["\u5F74"],"tu\u01D2 y\xED":["\u5F75"],"p\xE1ng f\u01CEng":["\u5F77"],w\u01CEng:["\u5F7A","\u5F80","\u5F83","\u60D8","\u6789","\u68E2","\u7DB2","\u7F51","\u7F52","\u7F53","\u7F54","\u7F56","\u83F5","\u86E7","\u8744","\u8AB7","\u8F1E","\u8F8B","\u9B4D"],c\u00FA:["\u5F82","\u6B82"],"d\xE0i d\u0101i":["\u5F85"],hu\u00E1i:["\u5F8A","\u6000","\u61D0","\u61F7","\u69D0","\u6DEE","\u8032","\u8639","\u8922","\u8931","\u8E1D"],"w\u0101 w\xE0ng ji\u0101":["\u5F8D"],"ch\u011Bng zh\xE8ng":["\u5F8E"],"d\xE9 d\u011Bi de":["\u5F97"],"c\xF3ng z\xF2ng":["\u5F9E"],"sh\xEC t\u01D0":["\u5FA5"],"t\xED ch\xED":["\u5FB2","\u9D97","\u9D99"],d\u00E9:["\u5FB3","\u5FB7","\u6074","\u60B3","\u60EA","\u6DC2","\u9340","\u951D"],"zh\u01D0 zh\u0113ng":["\u5FB4","\u5FB5"],bi\u00E9:["\u5FB6","\u767F","\u8382","\u86C2","\u8952","\u8E69"],"ch\u014Dng zh\u01D2ng":["\u5FB8"],"ji\u01CEo ji\xE0o":["\u5FBC","\u7B05","\u7B4A"],"l\xF2ng l\u01D2ng":["\u5FBF"],"q\xFA j\xF9":["\u5FC2","\u6E20","\u77BF","\u87B6"],"d\xECng t\xECng":["\u5FCA"],g\u01CEi:["\u5FCB","\u6539"],r\u011Bn:["\u5FCD","\u6820","\u6823","\u79F9","\u7A14","\u7D9B","\u834F","\u8375","\u8EB5"],ch\u00E0n:["\u5FCF","\u61F4","\u61FA","\u785F","\u7FBC","\u97C2","\u986B"],t\u00E8:["\u5FD1","\u615D","\u7279","\u87D8","\u92F1","\u94FD"],"t\xE8 t\u0113i tu\u012B":["\u5FD2"],"g\u0101n h\xE0n":["\u5FD3","\u653C"],"y\xEC q\xEC":["\u5FD4"],"t\xE0i sh\xEC":["\u5FD5"],"x\u012B li\u011B":["\u5FDA"],"y\u012Bng y\xECng":["\u5FDC","\u61C9","\u8B4D"],"m\u01D0n w\u011Bn m\xEDn":["\u5FDE","\u5FDF"],"s\u014Dng zh\u014Dng":["\u5FEA"],"y\xF9 sh\u016B":["\u5FEC","\u6086"],"q\xED sh\xEC":["\u5FEF","\u8006"],"t\xFAn zh\u016Bn d\xF9n":["\u5FF3"],"qi\xE1n q\xEDn":["\u5FF4","\u6272"],h\u00FAn:["\u5FF6","\u6D51","\u6E3E","\u991B","\u9984","\u9B42","\u9F32"],ni\u01D4:["\u5FF8","\u626D","\u7084","\u72C3","\u7D10","\u7EBD","\u83A5","\u9215","\u94AE","\u9775"],"ku\xE1ng w\u01CEng":["\u5FF9"],"k\u0101ng h\xE0ng":["\u5FFC"],"k\xE0i x\xEC":["\u5FFE","\u613E"],\u00F2u:["\u6004","\u616A"],"b\u01CEo b\xE0o":["\u6009"],"m\xEDn m\xE9n":["\u600B"],"zu\xF2 zh\xE0":["\u600D"],z\u011Bn:["\u600E"],y\u00E0ng:["\u600F","\u6059","\u6837","\u69D8","\u6A23","\u6F3E","\u7F95","\u8A47"],"k\xF2u j\xF9":["\u6010"],"n\xE1o ni\xFA":["\u6013"],"zh\u0113ng zh\xE8ng":["\u6014","\u6399","\u94B2","\u94EE"],"ti\u0113 zh\u0101n":["\u6017"],"h\xF9 g\xF9":["\u6018"],"c\u016B j\xF9 z\u016B":["\u601A"],"s\u012B s\u0101i":["\u601D"],"y\xF3u ch\xF3u":["\u601E"],"t\u016B di\xE9":["\u6022"],"y\u014Du y\xE0o":["\u602E"],xu\u00E0n:["\u6030","\u6621","\u6966","\u6CEB","\u6E32","\u70AB","\u7404","\u7729","\u78B9","\u7D62","\u7E3C","\u7E4F","\u7EDA","\u8519","\u8852","\u88A8","\u8D19","\u9249","\u93C7","\u94C9","\u955F","\u98B4"],"x\xF9 xu\xE8":["\u6034"],"b\xEC p\u012B":["\u6036"],"x\u012B sh\xF9":["\u6038"],"n\xE8n n\xEDn":["\u6041"],"ti\u0101o y\xE1o":["\u604C"],"x\u012B q\u012B x\xF9":["\u6053"],"xi\xE0o ji\u01CEo":["\u6054"],"h\u016B ku\u0101":["\u6057"],n\u01DC:["\u6067","\u6712","\u8842","\u8844"],h\u00E8n:["\u6068"],"d\xF2ng t\u014Dng":["\u606B"],"qu\xE1n zhu\u0101n":["\u606E"],"\xE8 w\xF9 \u011B w\u016B":["\u6076","\u60E1"],t\u00F2ng:["\u6078","\u615F","\u6185","\u75DB","\u8855"],"yu\u0101n ju\xE0n":["\u6081"],"qi\u0101o qi\u01CEo":["\u6084"],"ji\xE8 k\xE8":["\u6088"],"h\xE0o ji\xE0o":["\u608E"],hu\u01D0:["\u6094","\u6A93","\u6BC0","\u6BC1","\u6BC7","\u71EC","\u8B6D"],"m\xE1n m\xE8n":["\u6097","\u9794"],"y\u012B y\xEC":["\u6098","\u8863"],qu\u0101n:["\u609B","\u7B9E","\u9409","\u{287E0}"],"ku\u012B l\u01D0":["\u609D"],"y\xEC ni\xE0n":["\u60A5"],"m\xE8n m\u0113n":["\u60B6"],gu\u00E0n:["\u60B9","\u60BA","\u60EF","\u6163","\u63BC","\u645C","\u6A0C","\u6B1F","\u6CF4","\u6DAB","\u6F45","\u704C","\u721F","\u74D8","\u76E5","\u7936","\u797C","\u7F46","\u7F50","\u8CAB","\u8D2F","\u8E80","\u9066","\u93C6","\u9475","\u9C79","\u9E1B","\u9E73"],"k\u014Dng k\u01D2ng":["\u60BE"],"l\u01D4n l\xF9n":["\u60C0"],gu\u01D2:["\u60C8","\u679C","\u6901","\u69E8","\u7CBF","\u7DB6","\u83D3","\u873E","\u88F9","\u8901","\u8F20","\u991C","\u9983"],"yu\u0101n w\u01CEn":["\u60CC","\u7BA2"],"l\xE1n l\xEDn":["\u60CF"],"y\xF9 x\xF9":["\u60D0","\u6DE2"],"chu\xF2 chu\xEC":["\u60D9"],"h\u016Bn m\xE8n":["\u60DB"],"ch\u01CEng t\u01CEng":["\u60DD"],"su\u01D2 ru\u01D0":["\u60E2"],c\u01CEn:["\u60E8","\u6158","\u61AF","\u9EEA","\u9EF2","\u415F"],c\u00E1n:["\u60ED","\u6159","\u615A","\u6B8B","\u6B98","\u8695","\u8745","\u8836","\u883A"],"d\xE0n d\xE1":["\u60EE","\u619A"],r\u011B:["\u60F9"],"y\xFA t\u014Du":["\u6109"],"k\xE0i q\xEC":["\u6112"],"d\xE0ng t\xE1ng sh\u0101ng y\xE1ng":["\u6113"],"ch\xE9n x\xECn d\u0101n":["\u6116"],"k\xE8 qi\xE0":["\u6118"],nu\u00F2:["\u611E","\u61E6","\u61E7","\u63BF","\u6426","\u6992","\u7A2C","\u7A64","\u7CD1","\u7CE5","\u7CEF","\u8AFE","\u8BFA","\u8E43","\u903D","\u9369","\u9518"],g\u01CEn:["\u611F","\u64C0","\u6562","\u687F","\u6A44","\u6F89","\u6FB8","\u76AF","\u79C6","\u7A08","\u7B34","\u8289","\u8866","\u8D76","\u8D95","\u9C64","\u9CE1"],"c\xF2ng s\u014Dng":["\u6121"],"s\u0101i s\u012B s\u01D0":["\u6122"],"g\u014Dng g\xF2ng h\u01D2ng":["\u6129","\u6150"],"shu\xF2 s\xF9":["\u612C","\u6D2C"],"y\xE1o y\xE0o":["\u612E"],hu\u00E0ng:["\u6130","\u66C2","\u69A5","\u6EC9","\u769D","\u76A9","\u93A4","\u3FE0"],zh\u011Bng:["\u6138","\u628D","\u62EF","\u6574","\u6678"],c\u01CEo:["\u613A","\u8278","\u8349","\u9A32"],"x\xEC xi\xE9":["\u6140"],"c\u01CEo s\u0101o":["\u6145"],"x\xF9 ch\xF9":["\u6149"],"qi\xE8 qi\xE0n":["\u614A"],"c\xE1o c\xF3ng":["\u6152"],"\xE0o \xE1o":["\u6160"],"li\xE1n li\u01CEn":["\u6169","\u68BF","\u69E4","\u6AE3"],"j\xECn q\xEDn j\u01D0n":["\u616C"],"d\xEC ch\xEC":["\u6178"],"zh\xED zh\xE9":["\u6179"],"l\xF3u l\u01DA":["\u617A","\u9DDC"],c\u00F2ng:["\u6181","\u8B25"],"zh\u012B zh\xEC":["\u6184","\u77E5","\u7E54","\u7EC7"],ch\u0113ng:["\u6186","\u645A","\u6490","\u6491","\u667F","\u67FD","\u68E6","\u6A55","\u6A89","\u6CDF","\u6D7E","\u7424","\u77A0","\u7880","\u7DFD","\u7F49","\u86CF","\u87F6","\u8D6A","\u8D6C","\u93FF","\u9423","\u9637","\u9757","\u9833","\u9953"],bi\u0113:["\u618B","\u864C","\u9C49","\u9CD6","\u9F08","\u9F9E"],"ch\xE9ng d\xE8ng zh\xE8ng":["\u6195"],"x\u01D0 x\u012B":["\u6198"],"du\xEC d\xF9n t\u016Bn":["\u619E"],"xi\u0101o ji\u0101o":["\u61A2"],"xi\xE1n xi\xE0n":["\u61AA"],"li\xE1o li\u01CEo":["\u61AD","\u71CE","\u720E","\u7212"],sh\u00E9ng:["\u61B4","\u7E04","\u7E49","\u7E69","\u7EF3","\u8B5D"],"n\xE1o n\u01CEo n\xE1ng":["\u61B9"],"j\u01D0ng j\xECng":["\u61BC"],"j\u01D0 ji\u01CEo":["\u61BF"],"xu\u0101n hu\u0101n":["\u61C1"],"c\u01CEo s\u0101o s\xE0o":["\u61C6"],m\u00E8n:["\u61D1","\u61E3","\u66AA","\u7116","\u71DC"],"m\xE8ng m\xE9ng m\u011Bng":["\u61DC"],"\xE0i y\xEC n\u01D0":["\u61DD"],"m\xE9ng m\u011Bng":["\u61DE","\u77A2","\u77D2"],"q\xED j\u012B j\xEC":["\u61E0"],m\u01D2:["\u61E1"],"l\xE1n xi\xE0n":["\u61E2"],"y\u014Du y\u01D2u":["\u61EE"],"li\xFA li\u01D4":["\u61F0","\u85F0"],r\u00E0ng:["\u61F9","\u8B72","\u8B93","\u8BA9"],hu\u0101n:["\u61FD","\u6B22","\u6B53","\u6B61","\u737E","\u8B99","\u8C9B","\u9144","\u9A69","\u9D05","\u9D4D"],n\u01CEn:["\u6201","\u63C7","\u6E73","\u7175","\u8169","\u877B","\u8D67"],"m\xED m\xF3":["\u6202"],"g\xE0ng zhu\xE0ng":["\u6205","\u6206"],"zhu\xE0ng g\xE0ng":["\u6207"],"x\u016B qu":["\u620C"],"x\xEC h\u016B":["\u620F","\u622F","\u6232"],"ji\xE1 g\u0101":["\u621B"],z\u00E9i:["\u621D","\u8808","\u8CCA","\u8D3C","\u9C02","\u9C61","\u9C97"],d\u011Bng:["\u6225","\u7B49"],"h\u016B x\xEC":["\u6231"],chu\u014D:["\u6233","\u8E14","\u9034"],"bi\u01CEn pi\u0101n":["\u6241"],"sh\u01CEng ji\u014Dng":["\u6244"],"sh\xE0n sh\u0101n":["\u6247"],c\u00E1i:["\u624D","\u6750","\u7E94","\u88C1","\u8CA1","\u8D22"],"zh\u0101 z\u0101 zh\xE1":["\u624E"],"l\xE8 l\xEC c\xE1i":["\u6250"],"b\u0101 p\xE1":["\u6252"],"d\u01CE d\xE1":["\u6253"],r\u0113ng:["\u6254"],"f\u01CEn f\xFA":["\u6255"],"di\u01CEo d\xED yu\u0113 l\xEC":["\u625A"],"k\xE1ng g\u0101ng":["\u625B"],"y\u016B w\u016B":["\u625C"],"y\u016B w\u016B k\u016B":["\u625D"],"tu\u014D ch\u01D0 y\u01D0":["\u6261"],"g\u01D4 ji\xE9 x\xEC g\u0113":["\u6262"],d\u00E8n:["\u6265","\u627D"],"s\u01CEo s\xE0o":["\u626B","\u6383"],r\u01CEo:["\u6270","\u64FE","\u96A2"],"x\u012B ch\u0101 q\xEC":["\u6271"],"b\u0101n p\u0101n":["\u6273"],"b\u0101 \xE0o":["\u6277"],"x\u012B zh\xE9":["\u6278"],"zh\xEC s\u01D4n k\u01CEn":["\u627B"],zh\u01CEo:["\u627E","\u6CBC","\u7475"],"ku\xE1ng w\u01CEng z\xE0i":["\u6282"],"h\xFA g\u01D4":["\u6287","\u9E44","\u9E58"],"b\u01CE b\xE0":["\u628A"],"d\u01CEn sh\u011Bn":["\u628C"],"n\xE8 n\xEC ru\xEC n\xE0":["\u6290"],zhu\u0101:["\u6293","\u6A9B","\u7C3B","\u81BC","\u9AFD"],p\u00F3u:["\u6294","\u88D2"],"zh\xE9 sh\xE9 zh\u0113":["\u6298"],"p\xF3u p\u014Du f\u016B":["\u6299","\u634A"],p\u0101o:["\u629B","\u62CB","\u812C","\u8422"],"\u01CEo \xE0o ni\xF9":["\u629D"],"l\u016Bn l\xFAn":["\u62A1","\u6384"],"qi\u01CEng qi\u0101ng ch\u0113ng":["\u62A2"],"zh\u01D0 zh\u01CEi":["\u62A7"],"b\xF9 p\u016B":["\u62AA","\u67E8"],"y\u01CEo t\u0101o":["\u62AD"],"h\u0113 h\xE8 qi\u0101":["\u62B2"],"n\u01D0 n\xED":["\u62B3"],"p\u012B p\u0113i":["\u62B7"],"m\u01D2 m\xF2 m\u0101":["\u62B9"],ch\u014Du:["\u62BD","\u72A8","\u72AB","\u7633","\u7BD8"],"ji\u0101 y\xE1":["\u62C1"],"f\xFA b\xEC":["\u62C2","\u7550","\u9D9D"],zh\u01CE:["\u62C3","\u7728","\u781F","\u9BBA","\u9C9D"],"d\u0101n d\xE0n d\u01CEn":["\u62C5"],"ch\u0101i c\u0101":["\u62C6"],ni\u0101n:["\u62C8","\u852B"],"l\u0101 l\xE1 l\u01CE l\xE0":["\u62C9"],"b\xE0n p\xE0n":["\u62CC"],p\u0101i:["\u62CD"],l\u012Bn:["\u62CE"],gu\u01CEi:["\u62D0","\u67B4","\u67FA"],"tu\xF2 t\xE0 zh\xED":["\u62D3"],"\xE0o \u01CEo ni\xF9":["\u62D7"],"j\u016B g\u014Du":["\u62D8"],"p\u012Bn p\xE0n f\u0101n":["\u62DA"],"b\xE0i b\xE1i":["\u62DC"],b\u00E0i:["\u62DD","\u6557","\u7A17","\u7CBA","\u85AD","\u8D01","\u8D25","\u97DB"],qi\u00E1:["\u62E4"],"n\u01D0ng n\xEDng n\xECng":["\u62E7"],"z\xE9 zh\xE1i":["\u62E9","\u64C7"],h\u00E9n:["\u62EB","\u75D5","\u978E"],"ku\xF2 gu\u0101":["\u62EC"],"ji\xE9 ji\xE1":["\u62EE"],n\u01D0n:["\u62F0"],shu\u0101n:["\u62F4","\u6813","\u9582","\u95E9"],"c\xFAn z\xF9n":["\u62F5"],"z\u0101 z\u01CEn":["\u62F6","\u685A"],k\u01CEo:["\u62F7","\u6537","\u6832","\u70E4","\u8003"],"y\xED ch\u01D0 h\xE0i":["\u62F8"],"c\xE8 s\xE8 chu\xF2":["\u62FA"],"zhu\xE0i zhu\u0101i y\xE8":["\u62FD"],"sh\xED sh\xE8":["\u62FE"],b\u0101i:["\u6300","\u63B0"],"ku\xF2 gu\u0101ng":["\u6304"],n\u00F2ng:["\u630A","\u6335","\u9F48"],"ji\xE0o ji\u0101o":["\u630D","\u654E","\u6559"],"ku\xE0 k\u016B":["\u630E"],"n\xE1 r\xFA":["\u6310"],"ti\u0101o ti\u01CEo":["\u6311"],"di\xE9 sh\xE8":["\u6315"],li\u011B:["\u6318","\u6BDF"],"y\xE0 y\u01CE":["\u631C","\u6397"],"w\u014D zhu\u0101":["\u631D"],"xi\xE9 ji\u0101":["\u631F","\u633E"],"d\u01CEng d\xE0ng":["\u6321","\u64CB"],"zh\xE8ng zh\u0113ng":["\u6323","\u6B63","\u75C7"],"\u0101i \xE1i":["\u6328"],"tu\u014D shu\xEC":["\u6329","\u635D"],"t\u01D0 t\xEC":["\u632E"],"su\u014D sh\u0101":["\u6331"],"s\u0101 sh\u0101 su\u014D":["\u6332"],"k\u0113ng qi\u0101n":["\u6333","\u647C"],"b\xE0ng p\xE9ng":["\u6337"],"ru\xF3 ru\xE1":["\u633C"],"ji\u01CEo k\xF9":["\u6341"],"w\u01D4 w\xFA":["\u6342"],t\u01D2ng:["\u6345","\u6876","\u7B52","\u7B69","\u7D71","\u7D82","\u7EDF","\u36DA"],"hu\xF2 ch\xEC":["\u6347"],"t\xFA sh\u016B ch\xE1":["\u6348"],"l\u01DA lu\u014D":["\u634B"],"sh\u0101o sh\xE0o":["\u634E","\u7A0D"],ni\u0113:["\u634F","\u63D1"],"sh\xF9 s\u01D2ng s\u014Du":["\u6352"],"y\xE9 y\xFA":["\u6353"],"ju\xE9 zhu\xF3":["\u6354"],"b\xF9 p\xFA zh\xEC":["\u6357"],z\u00F9n:["\u6358","\u928C"],l\u0101o:["\u635E","\u6488","\u7CA9"],s\u01D4n:["\u635F","\u640D","\u69AB","\u7B0B","\u7B4D","\u7BB0","\u93A8","\u96BC"],"w\xE0n w\u01CEn w\u0101n y\xF9":["\u6365"],p\u011Bng:["\u6367","\u6DCE","\u768F"],sh\u011B:["\u6368"],"f\u01D4 f\xF9 b\u01D4":["\u636C"],d\u00E1o:["\u636F"],"lu\xF2 lu\u01D2 w\u01D2":["\u6370"],"ju\u01CEn qu\xE1n":["\u6372"],"ch\u0113n ti\u01CEn":["\u6375"],"ni\u01CEn ni\u0113":["\u637B"],"ru\xF3 w\u011Bi r\xE9":["\u637C"],zu\u00F3:["\u637D","\u6628","\u79E8","\u7A13","\u7B70","\u838B","\u923C"],"w\xF2 xi\xE1":["\u637E"],"q\xECng qi\xE0n":["\u6385"],"p\xF3u p\u01D2u":["\u638A"],qi\u0101:["\u6390","\u845C"],"p\xE1i p\u01CEi":["\u6392"],"qi\u0101n w\xE0n":["\u6394"],"y\xE8 y\u0113":["\u6396"],"ni\xE8 n\u01D0 y\xEC":["\u639C"],"hu\xF2 x\xF9":["\u639D"],"y\xE0n sh\xE0n y\u01CEn":["\u639E"],"zh\u011Bng d\xECng":["\u639F"],k\u00F2ng:["\u63A7","\u979A"],tu\u012B:["\u63A8","\u84F7","\u85EC"],"z\u014Du zh\u014Du ch\u014Du":["\u63AB"],ti\u00E0n:["\u63AD","\u821A"],k\u00E8n:["\u63AF","\u88C9","\u8903"],p\u00E1:["\u63B1","\u6777","\u6F56","\u722C","\u7436","\u7B62"],"gu\xF3 gu\u0101i":["\u63B4"],"d\u01CEn sh\xE0n":["\u63B8","\u64A3"],"ch\u0101n xi\u0101n c\xE0n sh\u01CEn":["\u63BA"],s\u0101o:["\u63BB","\u6414","\u6E9E","\u7E45","\u7F2B","\u87A6","\u9A12","\u9A37","\u9C20","\u9C62","\u9CCB"],p\u00E8ng:["\u63BD","\u692A","\u69F0","\u78B0","\u8E2B"],"zh\u0113ng k\u0113ng":["\u63C1"],"ji\u016B y\xF3u":["\u63C2"],"ji\u0101n ji\u01CEn":["\u63C3","\u7C5B"],"p\xEC ch\xE8":["\u63CA"],"s\u0101i z\u01D2ng c\u0101i":["\u63CC"],"t\xED d\u012B d\u01D0":["\u63D0"],"z\u01D2ng s\u014Dng":["\u63D4"],"hu\xE1ng y\xF3ng":["\u63D8"],"z\u01CEn zu\xE0n":["\u63DD"],"x\u016B j\u016B":["\u63DF"],"k\xE9 qi\u0101":["\u63E2"],"chu\u0101i chu\u01CEi chu\xE0i tu\xE1n zhu\u012B":["\u63E3"],"d\xEC t\xEC":["\u63E5"],"l\xE1 l\xE0":["\u63E6"],l\u00E0:["\u63E7","\u694B","\u6E82","\u74CE","\u760C","\u7FCB","\u81D8","\u874B","\u8772","\u881F","\u8FA2","\u8FA3","\u945E","\u9574","\u9B0E","\u9BFB","\u{2CD9F}"],"ji\u0113 q\xEC":["\u63ED"],"ch\xF2ng d\u01D2ng":["\u63F0"],"di\xE9 sh\xE9 y\xE8":["\u63F2"],"ji\xE0n qi\xE1n ji\u01CEn":["\u63F5"],y\u00E9:["\u63F6","\u7237","\u723A","\u7458","\u92E3","\u9381","\u94D8"],ch\u0101n:["\u6400","\u647B","\u6519","\u88E7","\u895C","\u8998","\u89C7","\u8FBF","\u92D3"],"g\u0113 g\xE9":["\u6401","\u64F1"],"l\u01D2u l\u014Du":["\u6402","\u645F"],"ch\u014Du z\u01D2u":["\u640A"],chu\u0101i:["\u640B"],s\u016Bn:["\u640E","\u69C2","\u72F2","\u733B","\u836A","\u84C0","\u8575","\u859E","\u98E7","\u98F1"],"r\xF3ng n\xE1ng n\u01CEng":["\u6411"],"p\xE9ng b\xE0ng":["\u6412"],cu\u014D:["\u6413","\u7473","\u78CB","\u8E49","\u9073","\u919D"],"k\u0113 \xE8":["\u6415"],"n\xF9 nu\xF2 n\xF2u":["\u6419"],"l\u0101 xi\xE9 xi\xE0n":["\u641A"],qi\u01D4:["\u641D","\u7CD7"],"xi\u01CEn xi\u0101n":["\u641F"],"ji\xE9 zh\xE9":["\u6429"],"p\xE1n b\u0101n p\xF3":["\u642B"],b\u0101n:["\u642C","\u653D","\u6591","\u6592","\u73ED","\u7622","\u764D","\u80A6","\u8781","\u878C","\u8929","\u8FAC","\u9812","\u9881","\u{28B49}"],"zh\xEC n\xE1i":["\u6431"],"w\u0101 w\u01CE w\xE0":["\u6432"],hu\u00E1:["\u6433","\u64B6","\u6ED1","\u733E","\u8550","\u8796","\u8B41","\u93F5","\u94E7","\u9A4A","\u9A85","\u9DE8"],"qi\u0101ng qi\u01CEng ch\u0113ng":["\u6436"],"ti\xE1n sh\u0113n":["\u6437"],"n\xE1 nu\xF2":["\u643B"],\u00E8n:["\u6441"],"sh\xE8 ni\xE8":["\u6444","\u651D"],b\u00ECn:["\u6448","\u64EF","\u6BA1","\u6BAF","\u8191","\u81CF","\u9ACC","\u9AD5","\u9AE9","\u9B02","\u9B13","\u9B22"],"sh\u0101 s\xE0 sh\u01CEi":["\u644B"],"ch\u01CEn s\xF9n":["\u644C"],"ji\u016B li\xFA li\xE1o ji\u01CEo n\xE1o":["\u644E"],"f\xE9ng p\u011Bng":["\u6453"],shu\u0101i:["\u6454"],"d\xEC t\xFA zh\xED":["\u6455"],"q\xEC j\xEC ch\xE1":["\u6456"],"s\u014Du s\u01D2ng":["\u6457"],"li\u01CEn li\xE0n":["\u6459"],"g\xE0i x\xEC":["\u6461"],"h\xF9 ch\u016B":["\u6462"],t\u00E0ng:["\u6465","\u70EB","\u71D9","\u940B"],"n\xE1i zh\xEC":["\u6468"],"m\xF3 m\u0101":["\u6469"],"ji\u0101ng qi\xE0ng":["\u646A"],"\xE1o qi\xE1o":["\u646E"],"ni\xE8 ch\xE8":["\u6470"],"m\xE1n m\xE0n":["\u6471"],"ch\xE0n c\xE1n":["\u6472"],"s\xE8 m\xED s\xF9":["\u6475"],"bi\u0101o bi\xE0o":["\u647D"],"ju\u0113 ju\xE9":["\u6485"],pi\u0113:["\u6486","\u66BC","\u6C15","\u77A5"],"pi\u011B pi\u0113":["\u6487"],"z\u01CEn z\u0101n z\u0113n qi\xE1n":["\u648D"],"s\u0101 s\u01CE":["\u6492"],h\u00F2ng:["\u6494","\u8A0C","\u8BA7","\u95C0","\u9B28"],"h\xE9ng gu\xE0ng":["\u6497"],ni\u01CEn:["\u649A","\u64B5","\u6506","\u6D8A","\u713E","\u78BE","\u7C10","\u8E4D","\u8E68","\u8E8E","\u8F26","\u8F87"],"ch\xE9ng zh\u011Bng":["\u649C"],"hu\u012B w\xE9i":["\u649D"],c\u0101o:["\u64A1","\u64CD","\u7CD9"],"xi\u0101o s\u014Du":["\u64A8"],"li\xE1o li\u0101o":["\u64A9"],"cu\u014D zu\u01D2":["\u64AE"],"w\u011Bi tu\u01D2":["\u64B1"],cu\u0101n:["\u64BA","\u651B","\u6C46","\u8E7F","\u8EA5","\u9479","\u9569"],"qi\xE0o y\u0101o j\u012B":["\u64BD"],"zhu\u0101 w\u014D":["\u64BE"],"l\xE8i l\xE9i":["\u64C2"],n\u01CEng:["\u64C3","\u652E","\u66E9","\u7062"],"q\xEDng j\u01D0ng":["\u64CF"],ku\u01CEi:["\u64D3","\u84AF","\u39DF"],"p\u01D0 b\xF2":["\u64D7"],"b\xF2 b\u0101i":["\u64D8"],"j\xF9 j\u01D0":["\u64DA"],m\u0113ng:["\u64DD"],"s\u01D2u s\xF2u":["\u64DE"],x\u01D0ng:["\u64E4","\u7BB5","\u9192"],c\u0101:["\u64E6"],"n\xEDng n\u01D0ng n\xECng":["\u64F0"],"zh\xEC ji\xE9":["\u64F3"],"l\xE0 li\xE8":["\u64F8","\u7209"],"s\xF2u s\u01D2u":["\u64FB"],"l\xEC lu\xF2 yu\xE8":["\u64FD"],"t\u012B zh\u0101i zh\xEC":["\u64FF"],p\u0101n:["\u6500","\u6F58","\u7705","\u8420"],l\u00E8i:["\u6502","\u6CEA","\u6D99","\u6DDA","\u79B7","\u7C7B","\u7E87","\u8631","\u9179","\u9287","\u9311","\u981B","\u982A","\u985E","\u98A3"],"c\u0101 s\u01CE":["\u6503"],"j\xF9n p\xE8i":["\u6508"],"l\xEC lu\xF2":["\u650A","\u8E92"],"l\xE0 l\xE0i":["\u650B","\u6AF4"],"l\xFA lu\xF3":["\u650E"],"z\u01CEn cu\xE1n":["\u6512"],"xi\u0101n ji\u0101n":["\u6515"],"m\xED m\u01D0 m\xF3":["\u6520"],"z\u01CEn cu\xE1n z\xE0n zu\u0101n":["\u6522"],zu\u00E0n:["\u6525"],"l\xEC sh\xE0i":["\u6526"],"l\xEC lu\u01D2":["\u652D"],"gu\u01D0 gu\xEC":["\u6531"],"j\u012B q\u012B y\u01D0":["\u6532"],f\u00E0ng:["\u653E"],"w\xF9 m\xF3u":["\u6544"],"ch\xF9 sh\u014Du":["\u654A"],"g\xE9 gu\xF3 \xE8":["\u654B"],"du\xF3 du\xEC":["\u6553","\u655A"],"du\u014D qu\xE8":["\u6560","\u656A"],"s\xE0n s\u01CEn":["\u6563"],"d\u016Bn du\xEC":["\u6566","\u9566"],"q\u012B y\u01D0 j\u012B":["\u6567"],"xi\xE0o xu\xE9":["\u6569"],"sh\xF9 sh\u01D4 shu\xF2":["\u6570","\u6578"],"\xE1i zh\xFA":["\u6571","\u6573"],"xi\xF2ng xu\xE0n":["\u657B"],"zhu\xF3 zh\xFA":["\u6580"],"y\xEC d\xF9":["\u6581"],"l\xED t\xE1i":["\u6584"],"f\u011Bi f\u0113i":["\u6590"],"y\u01D4 zh\u014Dng":["\u6594"],"d\xF2u d\u01D2u":["\u6597"],"w\xF2 gu\u01CEn":["\u65A1"],"t\u01D2u ti\u01CEo":["\u65A2"],d\u00F2u:["\u65A3","\u68AA","\u6D62","\u75D8","\u7AA6","\u7AC7","\u8130","\u8373","\u8C46","\u9017","\u90D6","\u9158","\u9597","\u95D8","\u9916","\u997E","\u9B25","\u9B26","\u9B2A","\u9B2C","\u9B2D"],"y\xEDn zh\xEC":["\u65A6"],"ch\u01CEn ji\xE8":["\u65BA"],"w\u016B y\u016B y\xFA":["\u65BC"],"y\xF3u li\xFA":["\u65BF"],"p\xE1ng b\xE0ng":["\u65C1"],"m\xE1o m\xE0o":["\u65C4"],"p\u012B b\xEC":["\u65C7"],"xu\xE1n xu\xE0n":["\u65CB"],"w\xFA m\xF3":["\u65E0"],z\u01CEo:["\u65E9","\u67A3","\u6806","\u68D7","\u6FA1","\u74AA","\u85BB","\u85FB","\u86A4"],g\u0101:["\u65EE"],"g\xE0n h\xE0n":["\u65F0"],"t\xE1i y\u012Bng":["\u65F2"],"x\u016B x\xF9":["\u65F4"],"t\u016Bn zh\xF9n":["\u65FD"],"w\xF9 w\u01D4":["\u65FF"],"p\xF2 p\xE8i":["\u6622"],z\u00F2ng:["\u662E","\u7314","\u75AD","\u7632","\u7CBD","\u7CC9","\u7CED","\u7E26"],\u01CEi:["\u6639","\u6BD0","\u77EE","\u853C","\u85F9","\u8B6A","\u8EB7","\u972D","\u9744"],"hu\xE0ng hu\u01CEng":["\u6643"],xu\u01CEn:["\u6645","\u7663","\u766C","\u9009","\u9078"],"x\xF9 ku\u0101":["\u6647"],h\u01D2ng:["\u664E"],sh\u00E0i:["\u6652","\u66EC"],"y\u016Bn y\xF9n":["\u6655","\u7174"],"sh\xE8ng ch\xE9ng":["\u665F","\u6909","\u76DB"],"j\u01D0ng y\u01D0ng":["\u666F"],sh\u01CEn:["\u6671","\u718C","\u7752","\u89A2","\u9583","\u95EA","\u9655","\u965D"],"q\u01D0 d\xF9":["\u6675"],"\u01CEn \xE0n y\u01CEn":["\u667B"],"w\u01CEng w\xE0ng":["\u6680"],z\u00E0n:["\u6682","\u66AB","\u74C9","\u74D2","\u74DA","\u79B6","\u8978","\u8B83","\u8B9A","\u8CDB","\u8D0A","\u8D5E","\u8E54","\u913C","\u933E","\u93E8","\u9961"],"y\xF9n y\u016Bn":["\u6688"],"m\xEDn m\u01D0n":["\u668B"],"d\u01D4 sh\u01D4":["\u668F"],sh\u01D4:["\u6691","\u66D9","\u6F7B","\u7659","\u7CEC","\u7F72","\u85A5","\u85AF","\u85F7","\u8700","\u8834","\u8961","\u8969","\u9C6A","\u9C70","\u9ECD","\u9F20","\u9F21"],"ji\u01CEn l\xE1n":["\u6695"],nu\u01CEn:["\u6696","\u7157","\u992A"],"b\xE0o p\xF9":["\u66B4"],"x\u012B x\u01D0":["\u66BF"],"p\xF9 b\xE0o":["\u66DD","\u7011"],"q\u016B q\u01D4":["\u7D36"],"q\u01D4 q\u016B":["\u66F2"],"g\xE8ng g\u0113ng":["\u66F4"],"h\u016B h\xF9":["\u66F6","\u96FD"],"z\u0113ng c\xE9ng":["\u66FD","\u6A67"],"c\xE9ng z\u0113ng":["\u66FE","\u7AF2"],"c\u01CEn qi\xE1n ji\xE0n":["\u6701"],"qi\xE8 h\xE9":["\u6705"],"b\xEC p\xED":["\u6707","\u7986","\u7B13","\u88E8"],"y\u01D2u y\xF2u":["\u6709"],"b\u0101n f\xE9n":["\u670C","\u9CFB"],"f\xFA f\xF9":["\u670D","\u6D11"],"f\u011Bi k\u016B":["\u670F","\u80D0"],"q\xFA x\xF9 ch\u01D4n":["\u6710"],"ju\u0101n zu\u012B":["\u6718"],"hu\u0101ng m\xE1ng w\xE1ng":["\u671A"],"q\u012B j\u012B":["\u671F"],"t\xF3ng chu\xE1ng":["\u6723","\u6A66"],zh\u00E1:["\u672D","\u7250","\u7B9A","\u86BB","\u8B57","\u9358","\u94E1","\u9598","\u95F8"],"zh\xFA sh\xF9 sh\xFA":["\u672E"],"sh\xF9 sh\xFA zh\xFA":["\u672F"],"zh\u016B sh\xFA":["\u6731"],"p\u01D4 p\xF2 p\u014D pi\xE1o":["\u6734"],"d\u0101o ti\xE1o m\xF9":["\u6737"],"gu\u01D0 qi\xFA":["\u6739"],xi\u01D4:["\u673D","\u6EEB","\u6F43","\u7CD4"],"ch\xE9ng ch\u0113ng":["\u673E"],z\u00E1:["\u6742","\u6CAF","\u7838","\u894D","\u96D1","\u96DC","\u96E5","\u97F4"],"y\xFA w\u016B":["\u6745"],"g\u0101n g\u01CEn":["\u6746"],"ch\u0101 ch\xE0":["\u6748"],"sh\u0101n sh\u0101":["\u6749"],c\u016Bn:["\u6751","\u76B4","\u7AF4","\u81A5","\u8E06","\u90A8"],"r\xE8n \xE9r":["\u6752","\u6895"],"sh\xE1o bi\u0101o":["\u6753"],"d\xEC du\xF2":["\u6755","\u67A4"],"g\u016B g\xE0i":["\u675A"],"y\xED zh\xEC l\xED du\xF2":["\u675D"],"g\xE0ng g\u0101ng":["\u6760"],"ti\xE1o ti\u0101o":["\u6761","\u689D"],"m\xE0 m\u01CE":["\u6769"],"s\xEC zh\u01D0 x\u01D0":["\u676B"],"yu\xE1n w\xE1n":["\u676C","\u8696"],"b\xE8i f\xE8i":["\u676E"],"sh\u016B du\xEC":["\u6778"],"ni\u01D4 ch\u01D2u":["\u677B"],"w\xF2 yu\xE8":["\u6782","\u81D2"],m\u00E1o:["\u6786","\u6BDB","\u6C02","\u6E35","\u7266","\u77DB","\u7F5E","\u8305","\u8306","\u8765","\u87CA","\u8EDE","\u9155","\u927E","\u9328","\u951A","\u9AE6","\u9D9C"],"p\u012B m\xEC":["\u6788"],\u00E0ng:["\u678A","\u76CE","\u91A0"],"f\u0101ng b\xECng":["\u678B"],"h\xF9 d\u01D0":["\u6791"],x\u00EDn:["\u6794","\u8951","\u9414","\u9B35"],"y\u0101o y\u01CEo":["\u6796"],"\u011B \xE8":["\u6799"],"zh\u012B q\xED":["\u679D"],"c\u014Dng z\u014Dng":["\u679E","\u6A05"],"xi\u0101n zh\u0113n":["\u67AE"],"t\xE1i s\xEC":["\u67B1"],"g\u01D2u j\u01D4 g\u014Du":["\u67B8"],"b\u0101o f\xFA":["\u67B9"],"y\xEC xi\xE8":["\u67BB","\u6827"],"tu\xF3 du\xF2":["\u67C1","\u99B1","\u99C4","\u9A6E"],"y\xED du\xF2 l\xED":["\u67C2"],"n\u01D0 ch\xEC":["\u67C5"],"p\xE1n b\xE0n":["\u67C8","\u8DD8"],"y\u01CEng y\xE0ng y\u0101ng y\u012Bng":["\u67CD"],"f\xF9 f\u016B f\u01D4":["\u67CE"],"b\u01CEi b\xF3 b\xF2":["\u67CF"],m\u01D2u:["\u67D0"],"sh\xE1o sh\xE0o":["\u67D6"],zh\u00E8:["\u67D8","\u6A1C","\u6D59","\u6DDB","\u8517","\u87C5","\u9019","\u9DD3","\u9E67","\u45EA"],"y\xF2u y\xF3u":["\u67DA","\u6AFE"],"gu\xEC j\u01D4":["\u67DC"],"zh\xE0 zu\xF2":["\u67DE"],"di\xE9 zh\xEC":["\u67E3","\u7730"],"zh\u0101 z\u01D4 z\u016B":["\u67E4"],"ch\xE1 zh\u0101":["\u67E5","\u67FB"],"\u0101o \xE0o":["\u67EA","\u8EEA"],"b\u0101 f\xFA p\xE8i b\xF3 bi\u0113":["\u67ED"],"du\xF2 zu\xF3 w\xF9":["\u67EE"],"b\xEC bi\xE9":["\u67F2"],"zh\xF9 ch\xF9":["\u67F7"],"b\u0113i p\u0113i":["\u67F8"],"sh\xEC f\xE8i":["\u67F9"],"sh\u0101n zh\xE0 shi c\xE8":["\u6805"],"l\xEC yu\xE8":["\u680E","\u6ADF"],"q\xEC qi\xE8":["\u6814","\u780C"],"q\u012B x\u012B":["\u6816","\u8E4A"],"gu\u0101 ku\xF2":["\u681D"],"b\u012Bng b\u0113n":["\u681F"],"xi\xE0o ji\xE0o":["\u6821"],"ji\xE0n z\xF9n":["\u682B","\u88B8"],"y\u01D2u y\xF9":["\u682F"],"h\xE9 h\xFA":["\u6838"],g\u0113n:["\u6839","\u8DDF"],"zh\u012B y\xEC":["\u683A"],"g\xE9 g\u0113":["\u683C"],"h\xE9ng h\xE1ng":["\u6841"],"gu\xE0ng gu\u0101ng":["\u6844"],"y\xED t\xED":["\u684B","\u8351"],s\u0101ng:["\u6851","\u6852","\u69E1"],"j\xFA ji\xE9":["\u6854"],"y\xFA m\xF3u":["\u6859"],"r\xE1o n\xE1o":["\u6861","\u6A48"],"gu\xEC hu\xEC":["\u6867","\u6A9C"],"ch\xE9n zh\xE8n":["\u686D"],"t\u012Bng y\xEDng":["\u686F"],"b\xF3 po":["\u6872"],"b\xE8n f\xE0n":["\u6873"],"f\u0113ng f\xE8ng":["\u687B","\u8451"],"s\xF9 y\xECn":["\u6880"],"t\u01D0ng t\xECng":["\u6883"],"xu\u0101n ju\u0101n xi\xE9":["\u688B"],"t\xFA ch\xE1":["\u688C"],"\u0101o y\xF2u":["\u688E"],ku\u01CEn:["\u68A1","\u6B35","\u6B3E","\u6B40"],"sh\u0101o s\xE0o":["\u68A2"],"q\xEDn ch\xE9n c\xE9n":["\u68A3"],"l\xED s\xEC q\u01D0":["\u68A9"],"ch\u0101n y\xE1n":["\u68B4"],"b\u012Bn b\u012Bng":["\u68B9","\u69DF","\u6AB3"],"t\xE1o ch\xF3u d\xE0o":["\u68BC"],"c\u014Dng s\u014Dng":["\u68C7"],"g\xF9n h\xF9n":["\u68CD"],"d\xE9 zh\xE9":["\u68CF"],"p\xE1i b\xE8i p\xE8i":["\u68D1"],"b\xE0ng p\u01D2u b\xE8i b\u0113i":["\u68D3"],"d\xEC d\xE0i t\xEC":["\u68E3"],s\u0113n:["\u68EE","\u692E","\u69EE","\u8942"],"r\u011Bn sh\u011Bn":["\u68EF"],"l\xE9ng l\u0113ng l\xEDng":["\u68F1"],"f\xFA s\xF9":["\u68F4"],"z\u014Du s\u01D2u":["\u68F7"],z\u014Du:["\u68F8","\u7B83","\u7DC5","\u8ACF","\u8BF9","\u90B9","\u90F0","\u9112","\u9139","\u966C","\u9A36","\u9A7A","\u9BEB","\u9CB0","\u9EC0","\u9F71","\u9F7A"],"zh\xE0o zhu\u014D":["\u68F9"],"ch\u0113n sh\u0113n":["\u68FD"],"ji\u0113 qi\xE8":["\u6904"],"y\u01D0 y\u012B":["\u6905"],"ch\xF3u zh\xF2u di\u0101o":["\u6906"],"qi\u0101ng k\u014Dng":["\u690C"],"zhu\u012B chu\xED":["\u690E"],"b\u0113i p\xED":["\u6911"],m\u0113n:["\u691A"],"qu\u0101n ju\xE0n qu\xE1n":["\u6926"],"du\u01D2 chu\xE1n":["\u692F"],"w\u011Bi hu\u012B":["\u6932"],"ji\u01CE ji\u0101":["\u6935"],"h\xE1n ji\u0101n":["\u6937"],"sh\xE8n zh\u0113n":["\u6939"],"y\xE0n y\xE0":["\u693B"],"zh\u0101 ch\xE1":["\u6942"],"gu\u014D ku\u01CE":["\u6947"],"j\xED zh\xEC":["\u6956"],"k\u01D4 h\xF9":["\u695B"],"y\xF3u y\u01D2u":["\u6962"],"s\u01D2ng c\u014Dng":["\u6964"],"yu\xE1n xu\xE0n":["\u6965"],"y\u01CEng y\xE0ng y\u012Bng":["\u6967"],pi\u00E1n:["\u6969","\u80FC","\u8141","\u8CC6","\u8E41","\u99E2","\u9A08","\u9A88","\u9ABF","\u36F9"],"di\xE9 y\xE8":["\u696A"],"d\xF9n sh\u01D4n":["\u696F"],"c\xF2u z\xF2u":["\u6971"],"d\xEC d\u01D0 sh\xEC":["\u6974"],"k\u01CEi ji\u0113":["\u6977"],"r\xF3u r\xF2u":["\u697A"],"l\xE8 yu\xE8":["\u697D"],"w\u0113n y\xF9n":["\u6985","\u97B0"],l\u01D8:["\u6988","\u6ADA","\u6C00","\u81A2","\u85D8","\u95AD","\u95FE","\u9A62","\u9A74"],sh\u00E9n:["\u698A","\u795E","\u926E","\u9C30","\u{2CB39}"],"b\u012B pi":["\u698C"],"zh\u01CEn ni\u01CEn zh\xE8n":["\u6990"],"f\xFA f\xF9 b\xF3":["\u6991"],"ji\xE0n j\xECn":["\u6997"],"b\u01CEng b\xE0ng":["\u699C"],"sh\u0101 xi\xE8":["\u699D","\u6A27"],n\u00F2u:["\u69C8","\u8028","\u9392","\u941E"],"qi\u01CEn li\xE1n xi\xE0n":["\u69CF"],g\u00E0ng:["\u69D3","\u7135","\u7139","\u7B7B","\u9FCD"],g\u0101o:["\u69D4","\u69F9","\u6A70","\u6ADC","\u777E","\u7BD9","\u7CD5","\u7F94","\u81EF","\u97DF","\u993B","\u9AD8","\u9AD9","\u9DCE","\u9DF1","\u9F1B"],"di\u0101n zh\u011Bn zh\u0113n":["\u69D9"],"k\u01CEn ji\xE0n":["\u69DB"],"x\xED di\xE9":["\u69E2"],"j\u012B gu\u012B":["\u69E3"],"r\xF3ng y\u014Dng":["\u69E6"],"tu\xE1n shu\xE0n qu\xE1n":["\u69EB"],"q\xEC s\xE8":["\u69ED"],"cu\u012B zh\u01D0":["\u69EF"],"y\u01D2u ch\u01CEo":["\u69F1"],"m\xE0n w\xE0n":["\u69FE"],"l\xED ch\u012B":["\u6A06"],"l\xE9i l\u011Bi":["\u6A0F","\u6AD1","\u790C"],"ch\xE1o ji\u01CEo ch\u0101o":["\u6A14"],"ch\u0113ng t\xE1ng":["\u6A18"],"ji\u016B li\xE1o":["\u6A1B"],"m\xF3 m\xFA":["\u6A21"],"ni\u01CEo m\xF9":["\u6A22"],"h\xE9ng h\xE8ng":["\u6A2A","\u6A6B"],xu\u011B:["\u6A30","\u81A4","\u825D","\u8F4C","\u96EA","\u9C48","\u9CD5"],"f\xE1 f\xE8i":["\u6A43"],r\u00F9n:["\u6A4D","\u6DA6","\u6F64","\u81B6","\u958F","\u95A0","\u95F0"],"zh\u01CEn ji\u01CEn":["\u6A4F"],sh\u00F9n:["\u6A53","\u779A","\u77AC","\u821C","\u8563","\u9806","\u987A","\u9B0A"],"tu\xED d\u016Bn":["\u6A54"],"t\xE1ng ch\u0113ng":["\u6A56"],"s\xF9 qi\u016B":["\u6A5A"],"t\xE1n di\xE0n":["\u6A5D"],"f\xE9n f\xE8n f\xE8i":["\u6A68"],"r\u01CEn y\u0101n":["\u6A6A"],"c\u016B chu":["\u6A7B"],"sh\u016B qi\u0101o":["\u6A7E"],"p\xEDng b\xF2":["\u6A98"],"zh\xE1i sh\xEC t\xFA":["\u6AA1"],"bi\u01CEo bi\u0101o":["\u6AA6"],"qi\u0101n li\xE1n":["\u6AB6"],"n\u01D0 m\xED":["\u6AB7"],"ji\xE0n k\u01CEn":["\u6ABB"],"n\xF2u ru\u01CEn r\xFA":["\u6ABD"],"j\u012B j\xEC":["\u6AC5","\u79A8"],"hu\u01CEng gu\u01D2 g\u01D4":["\u6ACE"],"l\u01DC ch\u016B":["\u6AD6"],"mi\xE8 m\xE8i":["\u6AD7"],\u014Du:["\u6AD9","\u6B27","\u6B50","\u6BB4","\u6BC6","\u74EF","\u750C","\u8192","\u85F2","\u8B33","\u8BB4","\u93C2","\u9D0E","\u9DD7","\u9E25"],"zh\xF9 zhu\xF3":["\u6AE1"],"ju\xE9 j\xEC":["\u6AED"],"hu\xE1i gu\u012B":["\u6AF0"],"ch\xE1n zh\xE0n":["\u6B03"],"w\xE9i zu\xEC":["\u6B08"],c\u00E1ng:["\u6B0C","\u9476"],"y\xF9 y\xEC":["\u6B25"],"ch\xF9 q\xF9 x\xEC":["\u6B2A"],"k\xE0i \xE0i":["\u6B2C"],"y\xEC y\u012Bn":["\u6B2D"],"x\xEC k\xE0i":["\u6B2F"],"shu\xF2 s\xF2u":["\u6B36"],"\u01CEi \u0113i \xE9i \u011Bi \xE8i \xEA\u0304 \u1EBF \xEA\u030C \u1EC1":["\u6B38"],"q\u012B y\u012B":["\u6B39"],"chu\u0101 x\u016B":["\u6B3B"],"ch\u01D0 chu\xE0i":["\u6B3C"],"k\u01CEn qi\xE0n":["\u6B3F"],"k\u01CEn k\xE8":["\u6B41"],"chu\u01CEn chu\xE1n":["\u6B42"],"y\u012Bn y\u0101n":["\u6B45"],"j\xECn q\u016Bn":["\u6B4F"],p\u0113n:["\u6B55"],"x\u016B chu\u0101":["\u6B58"],"x\u012B sh\xE8":["\u6B59"],"li\u01CEn h\u0101n":["\u6B5B"],"zh\xEC ch\xED":["\u6B6D"],"s\xE8 sh\xE0":["\u6B70"],s\u01D0:["\u6B7B"],"w\u011Bn m\xF2":["\u6B7E"],pi\u01CEo:["\u6B8D","\u76AB","\u779F","\u91A5","\u9860"],"q\xEDng j\xECng":["\u6B91"],"f\u01D2u b\xF3":["\u6B95"],"zh\xED shi":["\u6B96"],"y\xE8 y\u0101n y\xE0n":["\u6B97"],"h\u016Bn m\xE8i":["\u6B99"],ch\u00F2u:["\u6BA0","\u81F0","\u905A"],"ku\xEC hu\xEC":["\u6BA8","\u6E83","\u6F70"],cu\u00E0n:["\u6BA9","\u71B6","\u7228","\u7A9C","\u7AC4","\u7BE1","\u7C12"],"y\u012Bn y\u0101n y\u01D0n":["\u6BB7"],"q\xECng k\u0113ng sh\u0113ng":["\u6BB8"],"y\xE1o xi\xE1o xi\xE0o":["\u6BBD"],"g\u016B g\u01D4":["\u6BC2","\u86C4"],"gu\xE0n w\u0101n":["\u6BCC"],"d\xFA d\xE0i":["\u6BD2"],"x\xFAn x\xF9n":["\u6BE5"],m\u00FA:["\u6BEA","\u6C01"],"d\xF2u nu\xF2":["\u6BED"],"s\u0101i su\u012B":["\u6BF8"],lu:["\u6C07"],s\u00E0o:["\u6C09","\u7619","\u77C2","\u9ADE"],"sh\xEC zh\u012B":["\u6C0F"],"d\u012B d\u01D0":["\u6C10"],"m\xE1ng m\xE9ng":["\u6C13"],"y\xE1ng r\xEC":["\u6C1C"],shu\u01D0:["\u6C34","\u6C35","\u6C3A","\u9596"],"zh\u011Bng ch\xE9ng zh\xE8ng":["\u6C36"],t\u01D4n:["\u6C3D"],"f\xE1n f\xE0n":["\u6C3E"],"gu\u01D0 ji\u01D4":["\u6C3F"],"b\u012Bn p\xE0 p\u0101":["\u6C43"],"zhu\xF3 qu\xE8":["\u6C4B"],"d\xE0 t\xE0i":["\u6C4F"],p\u00ECn:["\u6C56","\u725D","\u8058"],"h\xE0n h\xE1n":["\u6C57","\u99AF"],tu:["\u6C62"],"t\u0101ng sh\u0101ng":["\u6C64","\u6E6F"],"zh\u012B j\xEC":["\u6C65"],"g\xE0n h\xE1n c\xE9n":["\u6C75"],"w\xE8n m\xE9n":["\u6C76"],"f\u0101ng p\u0101ng":["\u6C78"],"h\u01D4 hu\u01CEng":["\u6C7B"],"ni\xFA y\xF3u":["\u6C7C"],h\u00E0ng:["\u6C86"],"sh\u011Bn ch\xE9n":["\u6C88"],"d\xF9n zhu\xE0n":["\u6C8C"],"n\u01DC ni\u01D4":["\u6C91"],"m\xE9i m\xF2":["\u6C92","\u6CA1"],"t\xE0 d\xE1":["\u6C93"],"m\xEC w\xF9":["\u6C95"],"h\xF3ng p\u0101ng":["\u6C97"],"sh\u0101 sh\xE0":["\u6C99"],"zhu\u01D0 z\u01D0":["\u6C9D"],"\u014Du \xF2u":["\u6CA4","\u6F1A"],"j\u01D4 j\xF9":["\u6CAE"],"tu\u014D du\xF3":["\u6CB0"],"m\u01D0 l\xEC":["\u6CB5"],"y\xED ch\xED":["\u6CB6"],"xi\xE8 y\xEC":["\u6CC4"],"b\xF3 p\u014D":["\u6CCA"],"m\xEC b\xEC":["\u6CCC","\u79D8"],"ch\xF9 sh\xE8":["\u6CCF"],"y\u014Du y\xF2u \u0101o":["\u6CD1"],"p\u0113ng p\xEDng":["\u6CD9","\u7851"],"p\xE0o p\u0101o":["\u6CE1"],"n\xED n\xEC":["\u6CE5","\u79DC"],"yu\xE8 s\xE0":["\u6CE7"],"ju\xE9 xu\xE8":["\u6CEC","\u75A6"],"l\xF3ng shu\u0101ng":["\u6CF7","\u7027"],"lu\xF2 p\u014D":["\u6CFA","\u6FFC"],"z\xE9 sh\xEC":["\u6CFD","\u6FA4"],"s\u01CE x\u01D0":["\u6D12"],"s\xE8 q\xEC z\xEC":["\u6D13"],"x\u01D0 xi\u01CEn":["\u6D17"],"k\u01CEo k\xE0o":["\u6D18"],"\xE0n y\xE0n \xE8":["\u6D1D"],"l\u011Bi l\xE8i":["\u6D21"],"qi\xE8 ji\xE9":["\u6D2F"],"qi\u01CEn ji\u0101n":["\u6D45"],"j\xEC j\u01D0":["\u6D4E","\u6E08","\u6FDF","\u7EAA"],"h\u01D4 x\u01D4":["\u6D52","\u6EF8"],"j\xF9n x\xF9n":["\u6D5A","\u6FEC"],"y\u01D0ng ch\xE9ng y\xEDng":["\u6D67"],"li\xE0n l\xEC":["\u6D70"],"f\xE9ng h\xF3ng":["\u6D72","\u6E84"],"ji\u01D2ng ji\u014Dng":["\u6D7B"],"su\u012B n\u011Bi":["\u6D7D"],"y\u01D2ng ch\u014Dng":["\u6D8C"],"t\u016Bn y\u016Bn":["\u6D92"],"w\u014D gu\u014D":["\u6DA1","\u6E26"],h\u0113ng:["\u6DA5","\u811D"],"zh\u01CEng zh\xE0ng":["\u6DA8","\u6F32"],"sh\xF2u t\u0101o":["\u6DAD"],shu\u00E0n:["\u6DAE","\u8168"],"k\u014Dng n\xE1ng":["\u6DB3"],"w\xF2 w\u01CEn yu\u0101n":["\u6DB4"],"tu\u014D tu\xF2":["\u6DB6"],w\u014D:["\u6DB9","\u7327","\u7A9D","\u7AA9","\u83B4","\u8435","\u8717","\u8778","\u8E12"],"qi\xE8 j\xED":["\u6DC1"],"gu\u01D2 gu\xE0n":["\u6DC9"],"l\xEDn l\xECn":["\u6DCB","\u735C","\u7584"],"t\u01CEng ch\u01CEng":["\u6DCC"],"n\xE0o chu\xF2 zhu\u014D":["\u6DD6"],"p\xE9ng p\xEDng":["\u6DDC"],f\u00E9i:["\u6DDD","\u80A5","\u8153","\u8730"],"p\xEC p\xE8i":["\u6DE0"],"ni\u01CEn sh\u011Bn":["\u6DF0"],"bi\u0101o h\u01D4":["\u6DF2"],"ch\xFAn zh\u016Bn":["\u6DF3"],"h\xF9n h\xFAn":["\u6DF7"],qi\u01CEn:["\u6DFA","\u7E7E","\u7F31","\u80B7","\u8181","\u8738","\u8B74","\u8C34","\u9063","\u9453"],"w\xE8n m\xEDn":["\u6E02"],"r\xE8 ru\xF2 lu\xF2":["\u6E03"],"d\xFA d\xF2u":["\u6E0E","\u7006","\u8BFB"],"ji\xE0n ji\u0101n":["\u6E10","\u6E85","\u6F38","\u6FFA"],"mi\u01CEn sh\xE9ng":["\u6E11","\u6FA0"],"nu\u01CEn nu\xE1n":["\u6E1C"],"qi\xFA w\xF9":["\u6E1E"],"t\xEDng t\u012Bng":["\u6E1F"],"d\xEC t\xED d\u012B":["\u6E27"],"g\u01CEng ji\u01CEng":["\u6E2F"],"h\u014Dng q\xECng":["\u6E39"],tu\u0101n:["\u6E4D","\u7153"],"hu\xEC m\u01D0n x\u016B":["\u6E4F"],"x\u01D4 x\xF9":["\u6E51"],p\u00E9n:["\u6E53","\u74EB","\u76C6","\u8450"],"m\u01D0n h\u016Bn":["\u6E63"],"tu\xE0n nu\u01CEn":["\u6E6A"],"qi\u016B ji\u01CEo":["\u6E6B","\u6E6C"],"y\u0101n y\u012Bn":["\u6E6E"],"b\xE0n p\xE1n":["\u6E74"],"zhu\u0101ng h\xFAn":["\u6E77"],"y\xE0n gu\xEC":["\u6E8E"],"li\xE1n li\u01CEn ni\xE1n xi\xE1n xi\xE0n":["\u6E93"],"d\xE1 t\u01CE":["\u6E9A","\u9FCE"],"li\u016B li\xF9":["\u6E9C","\u6F91","\u8E53"],l\u00F9n:["\u6EA3"],m\u01CE:["\u6EA4","\u72B8","\u7341","\u739B","\u746A","\u7801","\u78BC","\u9064","\u93B7","\u99AC","\u9A6C","\u9C22","\u9DCC"],"zh\u0113n q\xEDn":["\u6EB1"],"n\xEC ni\xE0o":["\u6EBA"],"ch\xF9 x\xF9":["\u6EC0","\u755C"],"w\u011Bng w\u0113ng":["\u6EC3"],"h\xE0o xu\xE8":["\u6EC8"],"q\xEC x\xEC xi\u0113":["\u6ECA"],"x\xEDng y\xEDng":["\u6ECE"],"z\xE9 h\xE0o":["\u6EDC"],"pi\u0101o pi\xE0o pi\u01CEo":["\u6F02"],"c\xF3ng s\u01D2ng":["\u6F0E"],"f\xE9ng p\xE9ng":["\u6F28"],"lu\xF2 t\xE0":["\u6F2F"],"p\u0113ng b\u0113n":["\u6F30"],"ch\xF3ng shu\u0101ng":["\u6F34"],"hu\u01D2 ku\xF2 hu\xF2":["\u6F37"],"li\xE1o li\xFA":["\u6F3B"],"cu\u01D0 cu\u012B":["\u6F3C"],"c\xF3ng z\u01D2ng":["\u6F40"],"c\xF3ng z\u014Dng":["\u6F48"],"p\xEC pi\u0113":["\u6F4E"],"d\xE0ng xi\xE0ng":["\u6F52"],"hu\xE1ng gu\u0101ng":["\u6F62"],"li\xE1o l\xE0o l\u01CEo":["\u6F66"],"c\u014Dng z\xF2ng":["\u6F68"],"zh\xED zh\xEC":["\u6F6A"],"t\u0101n sh\xE0n":["\u6F6C"],"t\xFA zh\u0101":["\u6F73"],"s\xE0n s\u01CE":["\u6F75"],h\u0113i:["\u6F76","\u9ED1","\u9ED2","\u{2CB76}"],"ch\xE9ng d\xE8ng":["\u6F84","\u7013"],"c\u016Bn c\xFAn":["\u6F8A"],"p\xE9ng p\u0113ng":["\u6F8E"],"h\xF2ng g\u01D2ng":["\u6F92","\u92BE"],"w\xE0n m\xE0n":["\u6FAB"],"ku\xE0i hu\xEC":["\u6FAE"],"gu\u014D w\u014D":["\u6FC4"],"p\u0113n f\xE9n":["\u6FC6"],"j\xED sh\xE0":["\u6FC8"],"hu\xEC hu\xF2":["\u6FCA"],"d\u01D0ng t\xECng":["\u6FCE"],"m\u01D0 n\u01D0":["\u6FD4"],"b\xEC p\xEC":["\u6FDE"],"cu\xEC zu\u01D0":["\u6FE2"],"h\xF9 hu\xF2":["\u6FE9"],"\u01CEi k\xE0i k\xE8":["\u6FED"],"w\u011Bi du\xEC":["\u6FFB","\u7022"],"z\xE0n cu\xE1n":["\u6FFD","\u7052"],"y\u01CEng y\xE0ng":["\u7001"],"w\u01CEng w\u0101ng":["\u7007"],"m\xF2 mi\xE8":["\u700E","\u771C"],su\u01D0:["\u7021","\u81B8","\u9AD3"],"hu\xE1i w\u0101i":["\u7024"],"z\xF9n ji\xE0n":["\u7033"],"y\u012Bng y\u01D0ng y\xECng":["\u7034"],"r\xE1ng r\xE0ng":["\u703C"],shu\u00E0ng:["\u7040"],"zhu\xF3 ji\xE0o z\xE9":["\u7042"],s\u01CE:["\u7051","\u8A2F","\u9778"],"lu\xE1n lu\xE0n":["\u7053"],"d\u01CEng t\u01CEng":["\u7059"],"x\xFAn qu\xE1n qu\xE0n":["\u7065"],"hu\u01D2 bi\u0101o":["\u706C"],"zh\xE0 y\xF9":["\u7079"],"f\xE9n b\xE8n":["\u7083"],"ji\u01D2ng gu\xEC":["\u7085"],"p\xE0ng f\u0113ng":["\u7090"],qu\u0113:["\u7094","\u7F3A","\u7F3C","\u849B"],bi\u0101n:["\u709E","\u7178","\u7502","\u782D","\u7B3E","\u7BAF","\u7C69","\u7DE8","\u7F16","\u8759","\u9089","\u908A","\u937D","\u97AD","\u9BFE","\u9BFF","\u9CCA"],"zh\u0101o zh\xE0o":["\u70A4"],"zhu\u014D ch\xF9":["\u70AA"],"p\xE0o p\xE1o b\u0101o":["\u70AE"],"p\xE1o f\u01D2u":["\u70B0"],"sh\u01CEn qi\xE1n sh\u0101n":["\u70B6"],"zh\xE0 zh\xE1":["\u70B8"],"ji\u01CEo y\xE0o":["\u70C4"],qu\u01CEn:["\u70C7","\u72AC","\u72AD","\u754E","\u7DA3","\u7EFB","\u8647"],"y\xE0ng y\xE1ng":["\u70CA"],"l\xE0o lu\xF2":["\u70D9"],"hu\xED hu\u01D0":["\u70E0"],r\u00E8:["\u70ED","\u71B1"],"f\xFA p\xE1o":["\u70F0"],"xi\xE8 ch\xE8":["\u70F2","\u710E"],"y\xE0n sh\u0101n":["\u70FB"],"h\u016Bn x\u016Bn":["\u7104"],k\u00E0o:["\u7105","\u7292","\u92AC","\u94D0","\u9760","\u9BB3","\u9BCC","\u9C93","\u3E06"],"ju\u0101n y\xE8":["\u7106"],"j\xF9n q\u016B":["\u710C"],"t\u0101o d\xE0o":["\u7118"],"ch\u01CEo j\xF9":["\u7123"],"w\xF2 \xE0i":["\u7125"],"z\u01D2ng c\u014Dng":["\u7127"],"x\u012B y\xEC":["\u712C"],"x\xECn x\u012Bn":["\u712E"],"ch\u0101o zhu\u014D":["\u712F"],"xi\u01D2ng y\u012Bng":["\u7138","\u713D"],ku\u01D0:["\u7143","\u8DEC","\u8E5E","\u980D","\u{2B806}"],"hu\u012B y\xF9n x\u016Bn":["\u7147"],"ji\u01CEo qi\u0101o":["\u714D"],"qi\xE1n sh\u01CEn sh\u0101n":["\u7154"],"x\u012B y\xED":["\u7155"],"sh\xE0 sh\u0101":["\u715E"],"y\xE8 zh\xE1":["\u7160"],"y\xE1ng y\xE0ng":["\u716C"],"\u0113n y\u016Bn":["\u717E"],"y\u016Bn y\u01D4n":["\u7185"],"h\xE8 xi\u0101o":["\u7187"],xi\u00F3ng:["\u718A","\u718B","\u96C4"],"x\u016Bn x\xF9n":["\u718F","\u720B"],g\u00F2ng:["\u7195","\u8CA2","\u8D21"],li\u016B:["\u7198"],"c\u014Dng z\u01D2ng":["\u719C"],"l\xF9 \u0101o":["\u719D"],"sh\xFA sh\xF3u":["\u719F"],"f\u0113ng p\xE9ng":["\u71A2"],"cu\u01D0 su\u012B":["\u71A3"],t\u0113ng:["\u71A5","\u81AF","\u9F1F"],"y\xF9n y\xF9":["\u71A8"],"\xE1o \u0101o":["\u71AC"],"h\xE0n r\u01CEn":["\u71AF"],"\u014Du \u01D2u":["\u71B0"],"hu\xE1ng hu\u01CEng":["\u71BF"],"ch\u01CEn d\u01CEn ch\xE0n":["\u71C0"],"ji\u0101o zhu\xF3 qi\xE1o ju\xE9":["\u71CB"],"y\xE0n y\u0101n":["\u71D5"],"t\xE0i li\xE8":["\u71E4"],\u0101o:["\u720A"],"y\xE0n x\xFAn":["\u7213"],"ju\xE9 ji\xE0o":["\u721D","\u8990","\u899A","\u89BA","\u89C9"],"l\u01CEn l\xE0n":["\u7226"],"zhu\u01CE zh\u01CEo":["\u722A"],"zh\u01CEo zhu\u01CE":["\u722B"],"f\xF9 f\u01D4":["\u7236"],di\u0113:["\u7239","\u893A","\u8DCC"],z\u0101ng:["\u7242","\u7F98","\u81E7","\u8CCD","\u8CD8","\u8D13","\u8D1C","\u8D43","\u9AD2"],"pi\xE0n pi\u0101n":["\u7247"],"bi\u0101n mi\xE0n":["\u7251"],b\u01CEng:["\u7253","\u7D81","\u7ED1"],"y\u01D2u y\u014Dng":["\u7257"],"ch\u0113ng ch\xE8ng":["\u725A","\u7AC0"],ni\u00FA:["\u725B","\u725C"],"ji\u016B l\xE8":["\u725E"],"m\xF9 m\xF3u":["\u725F"],m\u0101ng:["\u7264"],"g\u0113 qi\xFA":["\u726B"],"y\xF2u ch\u014Du":["\u7270"],"t\xE8 zh\xED":["\u7286"],b\u0113n:["\u7287","\u931B","\u951B"],"ji\u0101n qi\xE1n":["\u728D","\u73AA"],m\u00E1:["\u7298","\u75F2","\u8534","\u87C7","\u9EBB"],"m\xE1o l\xED":["\u729B"],"b\xE1 qu\u01CEn":["\u72AE"],"zhu\xF3 b\xE0o":["\u72B3"],"\xE0n h\u0101n":["\u72B4"],"k\xE0ng g\u01CEng":["\u72BA"],"p\xE8i f\xE8i":["\u72BB"],"f\u0101n hu\u0101n":["\u72BF"],ku\u00E1ng:["\u72C2","\u72C5","\u8A91","\u8BF3","\u8ED6","\u8EE0","\u9D5F","\u{2B6ED}"],"y\xED qu\xE1n ch\xED":["\u72CB"],"x\u012Bng sh\u0113ng":["\u72CC"],"tu\xF3 y\xED":["\u72CF"],k\u01D4:["\u72DC","\u82E6"],"hu\xE1n hu\u0101n":["\u72DF"],"h\xE9 m\xF2":["\u72E2"],"t\xE0 sh\xEC":["\u72E7"],"m\xE1ng d\xF2u":["\u72F5"],"x\u012B sh\u01D0":["\u72F6"],su\u0101n:["\u72FB","\u75E0","\u9178"],"b\xE0i p\xED":["\u7308"],"ji\u0101n y\xE0n":["\u730F","\u8C63"],"y\u012B y\u01D0":["\u7317"],"y\xE1 w\xE8i":["\u731A"],c\u0101i:["\u731C"],"m\u0101o m\xE1o":["\u732B","\u8C93"],"chu\xE0n chu\u0101n":["\u732D"],"tu\u0101n tu\xE0n":["\u732F","\u8C92"],"y\xE0 ji\xE1 qi\xE8":["\u7330"],"h\xE8 xi\u0113 g\xE9 h\xE0i":["\u7332"],"bi\u0101n pi\xE0n":["\u7335","\u7371"],"b\xF3 p\xF2":["\u733C"],"h\xE1o g\u0101o":["\u734B"],"f\xE9n f\xE8n":["\u7356"],"y\xE0o xi\u0101o":["\u735F"],"shu\xF2 x\u012B":["\u7361"],"g\xE9 li\xE8 xi\u0113":["\u7366"],"n\xF2u r\xFA":["\u7373"],"n\xE1o n\u01CEo y\u014Du":["\u7376"],r\u00E1ng:["\u737D","\u74E4","\u79B3","\u7A63","\u7A70","\u8618","\u8E9F","\u9B24"],"n\xE1o y\u014Du":["\u737F"],"l\u01DC shu\xE0i":["\u7387"],"w\xE1ng w\xE0ng":["\u738B"],"y\xE1ng ch\xE0ng":["\u739A"],"m\xEDn w\xE9n":["\u739F"],"b\u012Bn f\u0113n":["\u73A2"],"m\xE9n y\u01D4n":["\u73A7"],"qi\u0101ng c\u0101ng":["\u73B1","\u7472","\u7BEC"],"\xE1n g\u0101n":["\u73B5"],"xu\xE1n xi\xE1n":["\u73B9"],"c\u012B c\u01D0":["\u73BC","\u8DD0"],"y\xED t\u0101i":["\u73C6"],"z\u01D4 j\xF9":["\u73C7"],f\u00E0:["\u73D0","\u743A","\u855F","\u9AEA","\u9AEE"],"y\xEDn k\xE8n":["\u73E2"],"hu\u012B h\xFAn":["\u73F2"],"xu\xE1n qi\xF3ng":["\u7401"],"f\xFA f\u016B":["\u7408"],"b\u01D0ng p\xEDn":["\u7415"],"cu\xEC s\xE8":["\u7417"],"y\xF9 w\xE9i":["\u741F"],"ti\u01CEn ti\xE0n":["\u7420"],"zhu\xF3 zu\xF3":["\u7422"],"b\u011Bng p\u011Bi":["\u7423"],gu\u01CEn:["\u742F","\u74AD","\u75EF","\u7B66","\u7BA1","\u8218","\u8F28","\u9327","\u9928","\u9986","\u9CE4"],"h\xFAn hu\u012B":["\u743F"],"xi\xE9 ji\u0113":["\u744E"],"ch\xE0ng d\xE0ng y\xE1ng":["\u7452"],"ti\xE0n zh\xE8n":["\u7471"],"b\u012Bn pi\xE1n":["\u7478","\u74B8"],"t\xFA sh\u016B":["\u7479"],cu\u01D0:["\u7480","\u76A0","\u8DA1"],"z\u01CEo su\u01D2":["\u7485"],"ju\xE9 qi\xF3ng":["\u749A"],"l\xFA f\u016B":["\u74B7"],"j\xEC z\u012B":["\u74BE"],su\u00ED:["\u74CD","\u7D8F","\u7EE5","\u9040","\u968F","\u96A8","\u9AC4"],"m\xED x\u01D0":["\u74D5"],"qi\xF3ng w\u011Bi w\xE8i":["\u74D7"],"hu\xE1n y\xE8 y\xE0":["\u74DB"],"b\xF3 p\xE1o":["\u74DF"],"zh\xED h\xFA":["\u74E1"],pi\u00E1o:["\u74E2","\u95DD"],"w\u01CE w\xE0":["\u74E6"],"xi\xE1ng h\xF3ng":["\u74E8"],w\u00E8ng:["\u74EE","\u7515","\u7F4B","\u8579","\u9F46"],"sh\xE8n sh\xE9n":["\u751A"],ru\u00ED:["\u7524","\u7DCC","\u8564"],y\u00F2ng:["\u7528","\u783D","\u82DA","\u848F","\u919F","\u3DB2"],shu\u01CEi:["\u7529"],b\u00E9ng:["\u752D","\u752E"],"y\xF3u zh\xE1":["\u7534"],"di\xE0n ti\xE1n sh\xE8ng":["\u7538"],"t\u01D0ng d\u012Bng":["\u753A","\u753C"],"z\u0101i z\u012B":["\u753E"],"b\xEC q\xED":["\u7541"],"d\xE1 f\xFA":["\u7557"],"c\xE8 j\xEC":["\u755F"],"z\u0101i z\u012B ti\xE1n":["\u7560"],"zh\xEC ch\xF3u sh\xEC":["\u7564"],"f\u0101n p\u0101n":["\u7568","\u756A"],"sh\u0113 y\xFA":["\u756C"],"d\u0101ng d\xE0ng d\u01CEng":["\u7576"],"ji\u0101ng qi\xE1ng":["\u7586"],"p\u01D0 y\u01CE sh\u016B":["\u758B"],"ji\xE9 qi\xE8":["\u758C"],"y\xED n\u01D0":["\u7591"],n\u00E8:["\u7592","\u7732","\u8A25","\u8BB7"],"g\u0113 y\xEC":["\u7599"],"n\xFC\xE8 y\xE0o":["\u759F","\u7627"],"l\xEC l\xE0i":["\u75A0","\u7658"],"y\u01CE xi\u0101":["\u75A8"],xu\u0113:["\u75B6","\u8486","\u859B","\u8FA5","\u8FAA","\u9774","\u97BE"],"d\u01CEn da":["\u75B8"],"f\xE1 bi\u01CEn":["\u75BA"],"f\xE8i f\xE9i":["\u75BF","\u75F1"],"sh\u0101n di\xE0n":["\u75C1"],"t\xE9ng ch\xF3ng":["\u75CB"],"t\u014Dng t\xF3ng":["\u75CC"],"w\u011Bi y\xF2u y\xF9":["\u75CF"],"t\u0101n sh\u01D0":["\u75D1"],"p\u016B p\xF9":["\u75E1","\u92EA"],"b\u0113ng p\xE9ng":["\u75ED"],"m\xE1 l\xECn":["\u75F3"],"ti\u01CEn di\xE0n":["\u75F6"],"\u0101n y\xE8 \xE8":["\u75F7"],"k\u0113 \u0113":["\u75FE"],"zh\xEC ch\xEC":["\u7608"],"ji\u01CE xi\xE1 xi\u0101":["\u7615"],"l\u011Bi hu\xEC":["\u7623"],"ch\xE0i cu\xF3":["\u7625"],"di\u0101n ch\u0113n":["\u7628"],"da d\xE1":["\u7629"],"bi\u011B bi\u0113":["\u762A"],qu\u00E9:["\u7638"],"d\xE0n d\u0101n":["\u7649"],"gu\xEC w\u0113i":["\u7650"],"n\xF2ng n\xF3ng":["\u7651"],"bi\u0113 bi\u011B":["\u765F"],"b\u014D b\u01D2":["\u7677"],b\u00E1i:["\u767D"],"j\xED b\u012B":["\u7680"],"de d\xEC d\xED d\u012B":["\u7684"],"p\u0101 b\xE0":["\u7685"],"g\u0101o h\xE1o":["\u768B"],"g\u0101o y\xE1o":["\u7690"],"l\xEC lu\xF2 b\u014D":["\u76AA"],"zh\u0101 c\u01D4":["\u76BB"],"zh\u0101o zh\u01CEn d\u01CEn":["\u76BD"],"ji\u0101n ji\xE0n":["\u76D1","\u76E3","\u92FB","\u95F4","\u97AC"],"g\xE0i g\u011B h\xE9":["\u76D6"],"m\xE1ng w\xE0ng":["\u76F3"],yu\u01CEn:["\u76F6","\u903A","\u9060"],"ti\xE1n xi\xE1n":["\u76F7"],"xi\u0101ng xi\xE0ng":["\u76F8"],d\u01D4n:["\u76F9","\u8DB8","\u8E89"],"x\xEC p\u01CEn":["\u76FB"],"sh\u011Bng x\u01D0ng":["\u7701"],"y\xFAn h\xF9n":["\u7703"],"mi\u01CEn mi\xE0n":["\u7704"],"k\xE0n k\u0101n":["\u770B"],"y\xECng y\u0101ng y\u01CEng":["\u770F"],"y\u01CEo \u0101o \u01CEo":["\u7711"],"j\u016B x\u016B k\u014Du":["\u7717"],"y\xED ch\xEC":["\u7719"],"di\xE9 t\xEC":["\u7723"],"b\u01D0ng f\u01CEng":["\u772A"],"p\xE0ng p\xE1n":["\u772B"],"m\u012B m\xED":["\u772F","\u7787"],"xu\xE0n sh\xF9n x\xFAn":["\u7734"],ti\u00E0o:["\u773A","\u7C9C","\u7CF6","\u899C","\u8D92"],"zhe zhu\xF3 zh\xE1o zh\u0101o":["\u7740"],"qi\xE1o sh\xE0o xi\u0101o":["\u7744"],"cu\xF3 zhu\xE0i":["\u7749"],g\u00F9n:["\u7754","\u8B34"],"su\xEC zu\xEC":["\u775F"],"p\xEC b\xEC":["\u7765","\u7A2B","\u8F9F"],"y\xEC z\xE9 g\u0101o":["\u776A"],"x\u01D0ng x\xECng":["\u7772"],"gu\xEC w\xE8i ku\xEC":["\u7786"],"k\xF2u j\xEC":["\u7789"],"qi\xF3ng hu\xE1n":["\u778F"],"m\xE1n m\xE9n":["\u7792","\u779E"],"di\u0101o d\u014Du":["\u7797"],"lou l\xF3u l\u01D8":["\u779C"],"sh\xF9n r\xFAn":["\u77A4"],"li\xE0o li\u01CEo":["\u77AD","\u948C"],"ji\xE0n xi\xE1n":["\u77AF"],"w\u01D4 m\xED":["\u77B4"],"gu\xEC ku\xEC":["\u77B6"],"n\u01D0ng ch\u0113ng":["\u77C3"],"hu\xF2 yu\xE8":["\u77C6"],"m\u0113ng m\xE9ng":["\u77C7"],"ku\xE0ng gu\u014D":["\u77CC"],"gu\xE0n qu\xE1n":["\u77D4"],"m\u01CEn m\xE1n":["\u77D5"],"j\u012Bn gu\u0101n q\xEDn":["\u77DC"],"j\u012Bn q\xEDn gu\u0101n":["\u77DD"],"y\xF9 x\xF9 ju\xE9":["\u77DE"],"ji\u01CEo ji\xE1o":["\u77EB","\u77EF"],du\u01CEn:["\u77ED"],"sh\xED d\xE0n":["\u77F3"],"g\u0101ng qi\u0101ng k\xF2ng":["\u77FC"],"hu\u0101 x\u016B":["\u7809"],"p\u012Bn b\u012Bn f\u0113n":["\u780F"],"y\xE1n y\xE0n":["\u7814","\u784F"],"lu\u01D2 k\u0113":["\u7822"],"f\xFA f\xE8i":["\u7829","\u7B30"],"zh\u01D4 zh\xF9":["\u782B"],"l\xE1 l\xEC l\u0101":["\u782C"],"ku\u0101ng gu\u0101ng":["\u7844"],"g\xE8 lu\xF2":["\u784C"],"shu\xF2 sh\xED":["\u7855","\u78A9"],"w\xE8i w\xE9i \xE1i":["\u7859"],"qu\xE8 k\xE8 k\xF9":["\u785E"],"m\u01CEng b\xE0ng":["\u7865"],"lu\xF2 l\xF2ng":["\u7866"],"y\u01D2ng t\xF3ng":["\u7867"],n\u00FC\u00E8:["\u7878","\u8650"],"k\u0113ng k\u011Bng":["\u787B"],"y\u0101n y\u01CEn":["\u787D"],"zhu\xEC chu\xED du\u01D2":["\u787E"],"k\u014Dng k\xF2ng":["\u787F"],"z\xF2ng c\xF3ng":["\u7882"],"ji\u0101n zh\xE0n":["\u788A"],"l\xF9 li\xF9":["\u788C","\u9646"],"qu\xE8 x\u012B":["\u788F"],"l\xFAn l\u01D4n l\xF9n":["\u7896"],"n\xE1o g\u0101ng":["\u7899"],"ji\xE9 y\xE0":["\u78A3"],"w\xE8i w\u011Bi":["\u78A8"],"t\xED d\u012B":["\u78AE"],"ch\xE1 ch\u0101":["\u78B4"],"qi\u0101o qu\xE8":["\u78BB"],"s\xF9 xi\xE8":["\u78BF"],"li\xFA li\xF9":["\u78C2","\u905B","\u93A6","\u998F"],"s\u012B t\xED":["\u78C3"],"b\xE0ng p\xE1ng":["\u78C5"],"hu\xE1 k\u011B g\u016B":["\u78C6"],"w\u011Bi ku\u01D0":["\u78C8"],"xi\xE1 qi\xE0 y\xE0":["\u78CD"],"li\xE1n qi\u0101n":["\u78CF"],"w\xE8i \xE1i g\xE0i":["\u78D1"],"l\xE1 l\u0101":["\u78D6"],"\xE1o qi\u0101o":["\u78DD"],"p\u0113ng p\xE8ng":["\u78DE","\u959B"],"y\u012Bn y\u01D0n":["\u78E4"],"l\u011Bi l\xE9i":["\u78E5"],"m\xF3 m\xF2":["\u78E8"],"q\xEC zh\xFA":["\u78E9"],"l\xE1o lu\xF2":["\u78F1"],"p\xE1n b\u014D":["\u78FB"],"j\xED sh\xE9":["\u78FC"],"h\xE9 qi\u0101o qi\xE0o":["\u7909"],"k\xE8 hu\xF2":["\u790A"],"qu\xE8 h\xFA":["\u7910"],"\xE8 q\xEC":["\u7918"],c\u01CE:["\u7924","\u7938"],"xi\xE1n x\xEDn":["\u7925"],"l\xE9i l\u011Bi l\xE8i":["\u7927"],"y\xE1n y\u01CEn":["\u7939"],"q\xED zh\u01D0":["\u7947","\u8694"],"b\u0113ng f\u0101ng":["\u794A"],"b\xEC m\xEC":["\u7955"],su\u00E0n:["\u7958","\u7B07","\u7B6D","\u7B97","\u849C"],"pi\xE0o pi\u0101o":["\u7968"],"j\xEC zh\xE0i":["\u796D"],"shu\xEC l\xE8i":["\u7971"],"j\xECn j\u012Bn":["\u7981"],"ch\xE1n sh\xE0n":["\u7985"],"y\xE1ng sh\u0101ng":["\u7993"],"zh\u012B zh\u01D0 t\xED":["\u7994"],"sh\xE0n ch\xE1n":["\u79AA"],"y\xFA y\xF9 \u01D2u":["\u79BA"],"z\u01D0 z\xEC":["\u79C4"],"ch\xE1 n\xE1":["\u79C5"],"zh\u01D2ng zh\xF2ng ch\xF3ng":["\u79CD"],"h\xE0o m\xE0o":["\u79CF"],"k\xF9 k\u016B":["\u79D9"],z\u016B:["\u79DF","\u8445"],ch\u00E8ng:["\u79E4","\u7A6A"],"hu\xF3 ku\xF2":["\u79EE","\u79F3"],"ch\u0113ng ch\xE8n ch\xE8ng":["\u79F0","\u7A31"],"sh\xEC zh\xEC":["\u79F2","\u92B4"],"f\xF9 p\u016B":["\u79FF"],"x\xF9n z\xE8":["\u7A04"],"t\xFA sh\u01D4":["\u7A0C"],"zh\xF9n zh\u01D4n":["\u7A15"],"j\u012B q\xED":["\u7A18","\u7DA8","\u89ED"],"l\xE9ng l\xEDng":["\u7A1C"],"zu\xEC z\xFA s\u016B":["\u7A21"],"x\xEC qi\xE8":["\u7A27","\u90C4"],"zh\u01D2ng zh\xF2ng":["\u7A2E"],"z\u014Dng z\u01D2ng":["\u7A2F"],"xi\xE1n ji\u0101n li\xE0n":["\u7A34"],"z\u012B ji\u016B":["\u7A35"],"j\u012B q\u01D0":["\u7A3D"],r\u00F2ng:["\u7A43"],"sh\u0101n c\u01CEn c\u0113n":["\u7A47"],"m\xE9n m\xE9i":["\u7A48"],"j\u01D0 j\xEC":["\u7A56"],"xi\u0101o r\xE0o":["\u7A58"],"zhu\u014D b\xF3":["\u7A5B"],"t\xF3ng zh\u01D2ng zh\xF2ng":["\u7A5C"],zu\u014D:["\u7A5D"],"bi\u0101o p\u0101o":["\u7A6E","\u85E8"],"zhu\u014D ju\xE9":["\u7A71"],"cu\xE1n z\xE0n":["\u7A73"],"k\u014Dng k\xF2ng k\u01D2ng":["\u7A7A"],"y\u016B y\u01D4":["\u7A7B"],zh\u01CEi:["\u7A84","\u9259"],b\u00E1o:["\u7A87","\u96F9"],"k\u016B zh\xFA":["\u7A8B"],"ji\xE0o li\xE1o li\xF9":["\u7A8C"],"w\u0101 gu\u012B":["\u7A90"],"ti\u01CEo y\xE1o":["\u7A95"],"x\u016Bn y\xECn":["\u7AA8"],"y\xE0 y\u0113":["\u7AAB"],"ti\xE1n di\u0101n y\u01CEn":["\u7AB4"],"ch\u0101o k\u0113":["\u7ABC"],"ku\u01CEn cu\xE0n":["\u7ABD","\u7ABE"],"ch\xF9 q\xEC":["\u7AD0"],"q\u01D4 k\u01D2u":["\u7AD8"],"j\xECng zh\u011Bn":["\u7AE7"],"k\u01CEn k\xE0n":["\u7AF7"],"zh\xFA d\u01D4":["\u7AFA"],"l\xE8 j\u012Bn":["\u7AFB"],"zhu\xEC ru\xEC":["\u7B0D"],"h\xE1ng h\xE0ng":["\u7B10"],"c\xE9n j\xECn h\xE1n":["\u7B12"],"d\u0101 xi\xE1 n\xE0":["\u7B1A"],"z\xE9 zu\xF3":["\u7B2E"],"l\xF3ng l\u01D2ng":["\u7B3C","\u7BED","\u7C60","\u8E98","\u9F93"],"zh\xF9 zh\xFA":["\u7B51","\u7BC9"],"d\xE1 d\u0101":["\u7B54","\u8345"],sh\u0101i:["\u7B5B","\u7BE9","\u7C01","\u7C6D"],"y\xFAn j\u016Bn":["\u7B60"],"l\xE1ng l\xE0ng":["\u7B64","\u90CE","\u9606"],"zh\xEC zh\u01D0":["\u7B6B"],o:["\u7B7D"],"p\xF3u b\xF9 f\xFA p\xFA":["\u7B81"],"p\xE1i b\u0113i":["\u7B84"],g\u00E8:["\u7B87","\u867C","\u927B","\u94EC"],"t\xE1i ch\xED":["\u7B88"],"gu\u01CEi d\xE0i":["\u7B89"],"zh\xE0o d\xE0o":["\u7B8C"],"j\u012Bng q\xECng":["\u7B90"],"l\xEDn l\u01D0n":["\u7B96"],"j\xF9n q\u016Bn":["\u7B98"],"sh\u012B y\xED":["\u7BB7","\u91F6"],"yu\u0113 y\xE0o chu\xF2":["\u7BB9"],"xi\u0101o shu\xF2 qi\xE0o":["\u7BBE"],"g\u014Dng g\u01CEn l\u01D2ng":["\u7BE2"],"p\xE1ng p\xE9ng":["\u7BE3"],"zhu\xF3 hu\xF2":["\u7BE7"],"ji\u01CEn ji\u0101n":["\u7BEF"],"d\xED zh\xFA":["\u7BF4"],"z\u0101n c\u0113n c\u01CEn":["\u7BF8"],"zhu\xE0n su\u01CEn zu\xE0n":["\u7BF9"],"pi\u01CEo bi\u0101o":["\u7BFB"],"gu\xF3 gu\xEC":["\u7C02"],"c\xE8 j\xED":["\u7C0E"],"m\xEC mi\xE8":["\u7C1A"],"sh\u0101i s\u012B":["\u7C1B"],"s\u01D4n zhu\xE0n":["\u7C28"],"g\xE0n g\u01CEn":["\u7C33"],"b\xF2 b\u01D2":["\u7C38"],"b\xF3 b\xF9":["\u7C3F"],shi:["\u7C42"],"zh\u0113n ji\u0101n":["\u7C48"],"zhu\xE0n zu\u01CEn":["\u7C51"],"f\u0101n p\u0101n bi\u0101n":["\u7C53"],"s\u01D2u sh\u01D4":["\u7C54"],zu\u01CEn:["\u7C6B","\u7E64","\u7E82","\u7E89","\u7E98","\u7F35"],n\u01DA:["\u7C79","\u91F9","\u9495"],"sh\u0101 ch\u01CEo":["\u7C86"],"k\u0101ng j\u012Bng":["\u7C87"],f\u011Bn:["\u7C89","\u9EFA"],c\u016B:["\u7C97","\u89D5","\u9E81","\u9E84","\u9EA4"],"ni\xE1n zh\u0101n":["\u7C98"],"c\xE8 s\xE8":["\u7CA3"],"zh\u014Du y\xF9":["\u7CA5"],"sh\u0113n s\u01CEn":["\u7CC1"],"bi\u0101n bi\u01CEn":["\u7CC4","\u8439"],mi\u00E0n:["\u7CC6","\u9762","\u9763","\u9EAA","\u9EAB","\u9EB5","\u9EBA"],"h\xFA h\u016B h\xF9":["\u7CCA"],"g\u01D4 g\xF2u":["\u7CD3"],"m\xED m\xE9i":["\u7CDC"],"s\u01CEn sh\u0113n":["\u7CDD","\u7CE3"],z\u0101o:["\u7CDF","\u8E67","\u906D","\u91A9"],"m\xEC s\u012B":["\u7CF8"],"ji\u016B ji\u01D4":["\u7CFA"],"x\xEC j\xEC":["\u7CFB","\u7E6B"],"zh\u0113ng zh\u011Bng":["\u7CFD"],"ch\xE0 ch\u01CE":["\u7D01","\u8869"],"yu\u0113 y\u0101o":["\u7D04","\u7EA6"],"h\xF3ng g\u014Dng":["\u7D05","\u7EA2"],"h\xE9 g\u0113":["\u7D07","\u7EA5"],"w\xE9n w\xE8n":["\u7D0B","\u7EB9"],f\u00F3u:["\u7D11"],"j\xEC ji\xE9 ji\xE8":["\u7D12"],"p\u012B p\xED b\u01D0":["\u7D15","\u7EB0"],"j\u012Bn j\xECn":["\u7D1F"],"zh\u0101 z\u0101":["\u7D25","\u7D2E"],h\u0101:["\u7D26"],"f\u016B f\xF9":["\u7D28"],"ch\u014Du ch\xF3u":["\u7D2C"],"l\xE8i l\xE9i l\u011Bi":["\u7D2F"],"b\u014D b\xEC":["\u7D34"],"ti\u01CEn zh\u011Bn":["\u7D3E"],"ji\u014Dng ji\u01D2ng":["\u7D45"],"ji\xE9 ji\u0113":["\u7D50","\u7ED3","\u8282"],"gu\xE0 ku\u0101":["\u7D53"],"b\u01CEi m\xF2":["\u7D54"],"g\u0113ng hu\xE1n":["\u7D59"],"ji\xE9 xi\xE9":["\u7D5C"],"qu\xE1n shu\u0101n":["\u7D5F"],"g\u01CEi \u01CEi":["\u7D60"],"lu\xF2 l\xE0o":["\u7D61","\u7EDC"],"b\u012Bng b\u0113ng p\u0113ng":["\u7D63"],"g\u011Bi j\u01D0":["\u7D66","\u7ED9"],"t\xF3ng t\u014Dng d\xF2ng":["\u7D67"],"ti\xE0o di\xE0o d\xE0o":["\u7D69"],"l\u011Bi l\xE8i l\xE9i":["\u7D6B"],"g\u0101i h\xE0i":["\u7D6F"],"ch\u012B zh\u01D0":["\u7D7A"],"w\xE8n mi\u01CEn m\xE1n w\xE0n":["\u7D7B"],"hu\xE1n hu\xE0n w\xE0n":["\u7D84"],"q\u012Bn xi\u0101n":["\u7D85"],"t\xEC t\xED":["\u7D88"],"y\xE1n xi\xE0n":["\u7D96"],"z\u014Dng z\xE8ng z\xF2ng":["\u7D9C"],"ch\u0113n l\xEDn":["\u7D9D"],"zh\u01D4n zh\xF9n":["\u7DA7"],"qi\xE0n q\u012Bng zh\u0113ng":["\u7DAA"],"q\xECng q\u01D0":["\u7DAE"],"l\xFAn gu\u0101n":["\u7DB8","\u7EB6"],"chu\xF2 ch\u0101o":["\u7DBD","\u7EF0"],"ti\xE1n t\u01CEn ch\u0101n":["\u7DC2"],"l\u01DC l\xF9":["\u7DD1","\u7EFF"],"ru\u01CEn ru\xE0n":["\u7DDB"],"j\xED q\u012B":["\u7DDD"],"zh\xF2ng ch\xF3ng":["\u7DDF","\u91CD"],"mi\xE1o m\xE1o":["\u7DE2"],"xi\xE8 y\xE8":["\u7DE4"],hu\u01CEn:["\u7DE9","\u7F13","\u3B0A"],"g\u0113ng g\xE8ng":["\u7DEA","\u7E06"],"t\u014Du x\u016B sh\u016B":["\u7DF0"],"z\u014Dng z\xF2ng":["\u7DF5","\u7E4C"],"y\xF9n g\u01D4n":["\u7DF7"],"gu\u0101 w\u014D":["\u7DFA"],"y\xF9n y\u016Bn w\u0113n":["\u7DFC","\u7E15"],"b\u0101ng b\xE0ng":["\u7E0D"],"g\u01D4 h\xFA":["\u7E0E","\u9DBB"],"c\u012B cu\xF2 su\u01D2":["\u7E12"],"cu\u012B shu\u0101i":["\u7E17"],"r\xF3ng r\u01D2ng r\xF2ng":["\u7E19"],"z\xE0i z\u0113ng":["\u7E21"],c\u00E0i:["\u7E29","\u83DC","\u8521"],"f\xE9ng f\xE8ng":["\u7E2B"],"su\u014D s\xF9":["\u7E2E","\u7F29"],"y\u01CEn y\u01D0n":["\u7E2F","\u9153"],"z\xF2ng z\u01D2ng":["\u7E31","\u7EB5"],"zhu\xE0n ju\xE0n":["\u7E33"],"m\xF2 m\xF9":["\u7E38","\u83AB"],"pi\u01CEo pi\u0101o":["\u7E39","\u7F25"],"f\xE1n p\xF3":["\u7E41"],"b\u0113ng b\xE8ng":["\u7E43"],"m\xF3u mi\xF9 mi\xE0o li\u01CEo":["\u7E46"],"y\xE1o y\xF3u zh\xF2u":["\u7E47"],"z\u0113ng z\xE8ng":["\u7E52","\u7F2F"],"j\xFA ju\xE9":["\u7E58"],"chu\u014D chu\xF2":["\u7E5B"],"z\u016Bn z\u01D4n":["\u7E5C"],r\u00E0o:["\u7E5E","\u7ED5","\u9076"],"ch\u01CEn ch\xE1n":["\u7E5F"],"hu\xEC hu\xED":["\u7E62","\u7F0B","\u85F1"],"qi\u0101o s\u0101o z\u01CEo":["\u7E70"],"ji\u01CEo zhu\xF3":["\u7E73","\u7F34"],"d\xE0n t\xE1n ch\xE1n":["\u7E75"],n\u01D2ng:["\u7E77"],"p\xFA f\xFA":["\u7E80"],"y\xE0o l\xEC":["\u7E85"],"r\u01CEng xi\u0101ng":["\u7E95"],"l\xED s\u01CE x\u01D0 l\u01D0":["\u7E9A"],"xi\u0101n qi\xE0n":["\u7EA4"],"j\u012Bng j\xECng":["\u7ECF"],"t\xED t\xEC":["\u7EE8"],"b\u0113ng b\u011Bng b\xE8ng":["\u7EF7"],"z\u014Dng z\xE8ng":["\u7EFC"],"j\u012B q\u012B":["\u7F09"],"w\u0113n y\xF9n y\u016Bn":["\u7F0A"],"f\xE8ng f\xE9ng":["\u7F1D"],"shu\u0101i cu\u012B su\u012B":["\u7F1E"],"mi\xF9 m\xF3u li\xE1o mi\xE0o m\xF9":["\u7F2A"],"qi\u0101o s\u0101o":["\u7F32"],f\u01D2u:["\u7F36","\u7F39","\u7F3B","\u96EC","\u9D00"],"b\xE0 ba p\xED":["\u7F62","\u7F77"],"gu\xE0 gu\u01CEi":["\u7F6B"],"y\xE1ng xi\xE1ng":["\u7F8A","\u7F8F"],"m\u011Bi g\u0101o":["\u7F99"],"y\xEC x\u012B":["\u7F9B"],"qi\u01CEng qi\u0101n":["\u7F9F"],"qi\u0101ng k\xF2ng":["\u7FAB"],"qi\xE1n xi\xE1n y\xE1n":["\u7FAC"],n\u00F3u:["\u7FBA"],"h\xF3ng g\xF2ng":["\u7FBE"],"p\u012B b\xEC p\u014D":["\u7FCD"],"q\xFA y\xF9":["\u7FD1"],k\u00E9:["\u7FD7"],"qi\xE0o qi\xE1o":["\u7FD8"],"zh\xE1i d\xED":["\u7FDF"],"d\xE0o zh\u014Du":["\u7FE2"],"h\xF3u q\xFA":["\u7FF5"],shu\u01CE:["\u800D"],"ru\u01CEn nu\xF2":["\u800E"],"\xE9r n\xE0i":["\u800F"],"zhu\u0101n du\u0101n":["\u8011"],"p\xE1 b\xE0":["\u8019"],"ch\xED s\xEC":["\u801B"],"q\xF9 ch\xFA":["\u801D"],"l\xFAn l\u01D4n":["\u8023"],"j\xED ji\xE8":["\u8024"],"t\u0101ng t\u01CEng":["\u8025"],p\u01CEng:["\u802A","\u89AB"],"zh\xE1 z\xE9":["\u802B"],"y\u0113 y\xE9":["\u8036"],"y\xFAn y\xEDng":["\u803A"],"w\xE0 tu\u01D0 zhu\xF3":["\u8049"],"\xE9r n\u01DC":["\u804F"],"ti\u0113 zh\xE9":["\u8051"],"d\u01D0 zh\xEC":["\u805C"],qi\u00E9:["\u807A"],"n\u01D0 ji\xE0n":["\u807B"],"l\xE8i l\u0113":["\u808B"],c\u00E0o:["\u808F","\u8959","\u9135","\u9F1C"],"b\xF3 d\xED":["\u8091"],"xi\xE0o xi\u0101o":["\u8096"],"d\xF9 d\u01D4":["\u809A"],ch\u0101i:["\u809E","\u91F5","\u9497"],"h\xE1n q\xEDn h\xE0n":["\u80A3"],"p\xE0ng p\xE1n p\xE0n":["\u80A8","\u80D6"],"zh\u016Bn ch\xFAn":["\u80AB"],\u0101ng:["\u80AE","\u9AAF"],"y\xF9 y\u014D":["\u80B2"],"p\xED b\u01D0 b\xEC":["\u80B6"],"f\xE8i b\xEC":["\u80C7"],"b\xE8i b\u0113i":["\u80CC"],"f\xE8i z\u01D0":["\u80CF"],"p\xEDng p\u0113ng":["\u80D3","\u82F9"],"f\u016B f\xFA zh\u01D2u":["\u80D5"],"sh\xE8ng sh\u0113ng":["\u80DC"],ku\u00E0:["\u80EF","\u8DE8","\u9ABB"],"g\u01CEi h\u01CEi":["\u80F2"],"g\u0113 g\xE9 g\u0101":["\u80F3"],"n\xE9ng n\xE0i":["\u80FD"],"gu\u012B ku\xEC":["\u80FF"],"m\xE0i m\xF2":["\u8109"],"z\u0101ng z\xE0ng":["\u810F"],"ji\u01CEo ju\xE9":["\u811A","\u89D2"],cu\u01D2:["\u811E"],"de te":["\u8126"],"zu\u012B ju\u0101n":["\u8127"],n\u011Bi:["\u812E","\u8147","\u9912","\u9981","\u9BBE","\u9BD8"],"p\xFA f\u01D4":["\u812F"],ni\u00E0o:["\u8132"],shu\u00ED:["\u813D"],gu\u00F2:["\u8142","\u904E","\u9439"],"l\xE0 x\u012B":["\u814A"],"y\u0101n \u0101":["\u814C"],"g\u0101o g\xE0o":["\u818F"],"l\xF9 bi\u0101o":["\u8194"],chu\u00E1i:["\u8197"],"zhu\u0101n chu\xE1n ch\xFAn zhu\u01CEn":["\u819E"],chu\u00E0i:["\u81AA","\u8E39"],"f\xE1n p\xE1n":["\u81B0"],"w\u01D4 h\u016B":["\u81B4"],"sh\u0101n d\xE0n":["\u81BB"],t\u00FAn:["\u81C0","\u81CB","\u86CC","\u8C58","\u8C5A","\u8ED8","\u9715","\u98E9","\u9968","\u9B68","\u9C80","\u9ED7"],"b\xEC bei":["\u81C2"],"l\xE0 g\xE9":["\u81C8"],"s\xE0o s\u0101o":["\u81CA"],n\u00E0o:["\u81D1","\u9599","\u95F9","\u9B27"],"n\xED lu\xE1n":["\u81E1"],"qi\u0101n xi\xE1n":["\u81E4"],"gu\xE0ng ji\u01D2ng":["\u81E6"],"gu\u01CEng ji\u01D2ng":["\u81E9"],"ch\xF2u xi\xF9":["\u81ED"],"mi\xE1n bi\u0101n":["\u81F1"],"di\xE9 zh\xED":["\u81F7"],"zh\u012B j\xECn":["\u81F8"],"sh\xE8 sh\u011B":["\u820D"],p\u00F9:["\u8216","\u8217"],"b\u0101n b\u014D p\xE1n":["\u822C"],ku\u0101:["\u823F"],"g\xE8n g\u011Bn":["\u826E"],"s\xE8 sh\u01CEi":["\u8272"],"f\xFA b\xF3":["\u8274"],"ji\u0101o qi\xFA":["\u827D"],"ch\u0101i ch\u0101":["\u8286"],"sh\xE1o qu\xE8":["\u828D"],"h\xF9 xi\xE0":["\u8290"],"z\xEC z\u01D0":["\u8293"],"hu\xEC h\u016B":["\u8294"],"t\xFAn ch\u016Bn":["\u829A"],"ji\xE8 g\xE0i":["\u82A5"],"x\xF9 zh\xF9":["\u82A7"],"yu\xE1n y\xE1n":["\u82AB"],"x\u012Bn x\xECn":["\u82AF"],"l\xFAn hu\u0101":["\u82B2"],"w\xF9 h\u016B":["\u82B4"],"g\u014Du g\u01D2u":["\u82B6"],"m\xE0o m\xE1o":["\u82BC"],"f\xE8i f\xFA":["\u82BE"],"ch\xE1n y\xEDn":["\u82C2"],qi\u0113:["\u82C6"],"s\u016B s\xF9":["\u82CF"],"ti\xE1o sh\xE1o":["\u82D5"],"l\xEC j\u012B":["\u82D9"],"k\u0113 h\u0113":["\u82DB"],"j\xF9 q\u01D4":["\u82E3"],"ru\xF2 r\u011B":["\u82E5"],"zh\xF9 n\xEDng":["\u82E7"],"p\u0101 b\xF3":["\u82E9"],xi\u00FA:["\u82EC"],"zh\u01CE zu\xF3":["\u82F2"],"j\u016B ch\xE1":["\u82F4"],ni\u00E9:["\u82F6"],"sh\u0113ng ru\xED":["\u82FC"],"qi\xE9 ji\u0101":["\u8304"],"z\u01D0 c\xED":["\u8308"],"qi\xE0n x\u012B":["\u831C"],ch\u01CEi:["\u831D"],"f\xE1 p\xE8i":["\u8337"],r\u00E1o:["\u835B","\u8558","\u8953","\u9952","\u9976"],"y\xEDng x\xEDng":["\u8365"],"qi\xE1n x\xFAn":["\u8368","\u8541"],"y\xECn y\u012Bn":["\u836B"],"h\xE9 h\xE8":["\u8377"],"sh\u0101 su\u014D":["\u838E"],"p\xE9ng f\u0113ng":["\u8391"],"sh\u0113n x\u012Bn":["\u8398"],"w\u01CEn gu\u0101n gu\u01CEn":["\u839E"],"y\xF3u s\xF9":["\u83A4"],"sh\u0101o xi\u0101o":["\u83A6","\u86F8"],"l\xE0ng li\xE1ng":["\u83A8"],"pi\u01CEo f\xFA":["\u83A9"],"w\xE8n w\u01CEn mi\u01CEn":["\u83AC"],"sh\xEC sh\xED":["\u83B3","\u8494"],"t\xF9 t\xFA":["\u83B5"],"xi\u0101n li\u01CEn":["\u83B6","\u859F"],"w\u01CEn y\xF9":["\u83C0"],"z\u014Du ch\xF9":["\u83C6"],"l\xF9 l\u01DC":["\u83C9"],"j\u016Bn j\xF9n":["\u83CC"],"ni\xE8 r\u011Bn":["\u83CD"],"z\u012B z\xEC z\u0101i":["\u83D1"],"t\xFA t\xF9":["\u83DF"],"ji\u0113 sh\xE0":["\u83E8"],"qi\xE1o zh\u01CEo":["\u83EC"],"t\xE1i zh\u012B ch\xED":["\u83ED"],"f\u0113i f\u011Bi":["\u83F2","\u871A"],"q\xEDn q\u012Bn j\u012Bn":["\u83F3"],"z\u016B j\xF9":["\u83F9","\u84A9"],"l\u01D0n m\xE1":["\u83FB"],"ti\xE1n ti\xE0n":["\u83FE"],ti\u0113:["\u841C","\u8CBC","\u8D34"],"lu\xF2 l\xE0 l\xE0o lu\u014D":["\u843D"],"zh\xF9 zhu\xF3 zhe":["\u8457"],"sh\xE8n r\xE8n":["\u845A"],"g\u011B g\xE9":["\u845B"],"j\xF9n su\u01D2":["\u8470"],"ku\xEC ku\xE0i":["\u8489"],"r\xFA n\xE1":["\u8498"],"m\xE9ng m\u0113ng m\u011Bng":["\u8499"],"yu\xE1n hu\xE1n":["\u849D"],"x\xFA sh\xFA":["\u84A3"],"x\xED x\xEC":["\u84B5"],"m\xEC m\xEDng":["\u84C2"],"s\u014Du s\u01D2u":["\u84C3"],"g\xE0i g\u011B h\xE9 h\xE0i":["\u84CB"],"y\u01CEo zhu\xF3":["\u84D4"],"di\xE0o ti\xE1o d\xED":["\u84E7"],"x\u016B qi\u016B f\u016B":["\u84F2"],"z\xED j\xFA":["\u84FB"],"li\u01CEo l\xF9":["\u84FC"],xu:["\u84FF"],"h\xE0n h\u01CEn":["\u850A"],"m\xE0n w\xE0n m\xE1n":["\u8513"],"p\xF3 b\xF2":["\u8522"],"f\u0101n f\xE1n b\u014D":["\u8543"],"h\xF3ng h\xF2ng":["\u857B"],"y\xF9 \xE0o":["\u8581","\u96A9"],"x\xED xi\xE0o":["\u8582"],"b\xE1o b\xF3 b\xF2":["\u8584"],"c\xED z\u012B":["\u858B"],"w\xE0n lu\xE0n":["\u858D"],"k\u01CEo h\u0101o":["\u85A7"],"yu\u01CEn w\u011Bi":["\u85B3"],"zh\xF2u ch\xF3u":["\u85B5"],"w\u014D m\xE1i":["\u85B6"],"xi\u0101o h\xE0o":["\u85C3"],"y\xF9 x\xF9 x\u016B":["\u85C7"],"ji\xE8 j\xED":["\u85C9"],"di\xE0o zhu\xF3":["\u85CB"],"c\xE1ng z\xE0ng":["\u85CF"],l\u01CE:["\u85DE"],"ch\xFA zh\u016B":["\u85F8"],"p\xEDn p\xEDng":["\u860B"],"g\u0101n h\xE1n":["\u8677"],"h\xF3ng ji\xE0ng":["\u8679"],"hu\u012B hu\u01D0":["\u867A"],"xi\u0101 h\xE1":["\u867E"],"m\u01CE m\xE0 m\u0101":["\u8682"],"f\u0101ng b\xE0ng":["\u8684"],"b\xE0ng b\xE8ng":["\u868C"],"ju\xE9 qu\u0113":["\u8697"],"q\xEDn qi\xE1n":["\u8699"],"g\u014Dng zh\u014Dng":["\u86A3"],"f\u01D4 f\xF9":["\u86A5"],"d\xE0i d\xE9":["\u86AE"],"g\u01D2u q\xFA x\xF9":["\u86BC"],"b\u01D2 p\xED":["\u86BE"],"sh\xE9 y\xED":["\u86C7"],ti\u011B:["\u86C8","\u9244","\u9295","\u9421","\u9435","\u94C1","\u9A56"],"g\xE9 lu\xF2":["\u86D2"],"m\xE1ng b\xE0ng":["\u86D6"],"y\xEC x\u01D4":["\u86E1"],"h\xE1 g\xE9":["\u86E4"],"qi\xE8 n\xED":["\u86EA"],"\xE9 y\u01D0":["\u86FE"],"zh\u0113 zh\xE9":["\u8707"],"l\xE0 zh\xE0":["\u8721"],su\u00F2:["\u8736","\u9024"],"y\xF3u qi\xFA":["\u8764"],"xi\u0101 h\u0101":["\u8766"],"x\u012B q\u012B":["\u8787"],"b\u012B p\xED":["\u8795"],"n\xE0i n\u011Bng":["\u879A"],"h\xE9 xi\xE1":["\u879B"],"gu\xEC hu\u01D0":["\u879D"],"m\u01CE m\u0101 m\xE0":["\u879E"],"sh\xEC zh\u0113":["\u87AB"],"zh\xEC di\xE9":["\u87B2"],"ji\xE0n ch\xE1n":["\u87B9"],"ma m\xE1 m\xF2":["\u87C6"],"m\u01CEng m\u011Bng":["\u87D2"],"bi\u0113 bi\xE9":["\u87DE"],"b\u0113n f\xE8i":["\u87E6"],"l\xE1o li\xE1o":["\u87E7"],"y\xEDn x\xFAn":["\u87EB"],"l\xED l\u01D0":["\u8821"],"xu\xE8 xi\u011B":["\u8840"],"x\xEDng h\xE1ng h\xE0ng h\xE9ng":["\u884C"],"shu\u0101i cu\u012B":["\u8870"],"tu\xF3 tu\u014D":["\u8889"],"l\u01D0ng l\xEDng":["\u888A"],"b\xE0o p\xE1o p\xE0o":["\u888C"],"j\xF9 ji\u0113":["\u8893"],"h\xE8 k\xE8":["\u8894"],"y\xED y\xEC":["\u8898","\u8CA4"],"n\xE0 ju\xE9":["\u88A6"],"b\xE8i p\u012B":["\u88AB"],"ch\u01D0 nu\u01D2":["\u88B2"],"ch\u01D0 q\u01D0 du\u01D2 nu\u01D2":["\u88B3"],"ji\xE1 qi\u0101 ji\xE9":["\u88B7"],"b\xF3 m\xF2":["\u88B9"],"gu\u012B gu\xE0":["\u88BF"],"li\xE8 li\u011B":["\u88C2"],"ch\xE9ng ch\u011Bng":["\u88CE"],"ji\u0113 g\xE9":["\u88D3"],"d\u0101o ch\xF3u":["\u88EF"],"shang ch\xE1ng":["\u88F3"],"yu\u0101n g\u01D4n":["\u88F7"],"y\u01CEn \u0101n":["\u88FA"],"t\xEC x\u012B":["\u88FC"],"f\xF9 f\xFA":["\u8914"],"ch\u01D4 zh\u01D4":["\u891A"],"tu\xEC t\xF9n":["\u892A"],l\u01CEi:["\u8970"],"y\xE0o y\u0101o":["\u8981"],"q\xEDn t\xE1n":["\u8983"],"ji\xE0n xi\xE0n":["\u898B","\u89C1"],pi\u01CEn:["\u8991","\u8ADE","\u8C1D","\u8CB5","\u{2139A}"],"pi\u0113 mi\xE8":["\u8995"],"y\xEDng y\u01D0ng":["\u89AE"],"q\xF9 q\u016B":["\u89B0","\u89B7","\u89D1"],"ji\xE0n bi\u01CEn":["\u89B5"],"lu\xF3 lu\u01CEn":["\u89B6"],"z\u012B zu\u01D0":["\u89DC"],"hu\xE0 xi\xE8":["\u89DF"],"ji\u011B ji\xE8 xi\xE8":["\u89E3","\u89E7"],"xu\xE9 h\xF9":["\u89F7"],"l\xEC l\xF9":["\u89FB"],t\u01CEo:["\u8A0E","\u8BA8"],zh\u00F9n:["\u8A30"],"z\u012B z\u01D0":["\u8A3E"],"y\xED d\xE0i":["\u8A52","\u8BD2"],xi\u00F2ng:["\u8A57","\u8BC7"],"di\xE0o ti\u01CEo":["\u8A82"],"y\xED ch\u01D0 ch\xEC":["\u8A83"],"l\u01CEng l\xE0ng":["\u8A8F"],"\u0113i \xE9i \u011Bi \xE8i x\u012B":["\u8A92","\u8BF6"],shu\u00E0:["\u8A9C"],"y\u01D4 y\xF9":["\u8A9E","\u8BED","\u96E8"],"shu\u014D shu\xEC yu\xE8":["\u8AAA","\u8BF4"],"shu\xED sh\xE9i":["\u8AB0","\u8C01"],"q\u016B ju\xE8":["\u8AB3"],"ch\u012B l\xE0i":["\u8ABA"],"n\xEC n\xE1":["\u8ABD"],"di\xE0o ti\xE1o":["\u8ABF"],"p\u01D0 b\u0113i":["\u8AC0"],"j\xEC j\u012B":["\u8AC5"],"z\xE9 zu\xF2 zh\u01CE cu\xF2":["\u8ACE"],"ch\xF9 j\xED":["\u8AD4"],"h\xE1o xi\xE0":["\u8AD5"],"l\xF9n l\xFAn":["\u8AD6","\u8BBA"],"sh\xEC d\xEC":["\u8ADF"],"hu\xE0 gu\u0101":["\u8AE3"],"x\u01D0 sh\u0101i \u0101i":["\u8AF0"],"n\xE1n n\xE0n":["\u8AF5","\u96E3"],mi\u00F9:["\u8B2C","\u8C2C"],z\u00E8n:["\u8B56","\u8C2E"],"sh\xED zh\xEC":["\u8B58","\u8BC6"],"ju\xE0n xu\u0101n":["\u8B82"],"y\xED tu\u012B":["\u8B89"],zh\u00E1n:["\u8B9D"],"x\u01D4 h\u01D4":["\u8BB8"],"xi\xE1ng y\xE1ng":["\u8BE6"],"ti\xE1o di\xE0o zh\u014Du":["\u8C03"],"ch\xE9n sh\xE8n":["\u8C0C"],"m\xED m\xE8i":["\u8C1C"],"m\xE0n m\xE1n":["\u8C29"],"g\u01D4 y\xF9":["\u8C37"],"hu\u014D hu\xF2 hu\xE1":["\u8C41"],"zh\xEC zh\xE0i":["\u8C78"],"hu\u0101n hu\xE1n":["\u8C86"],"k\u011Bn k\u016Bn":["\u8C87"],"m\xF2 h\xE9":["\u8C88"],"m\xF2 h\xE9 h\xE1o":["\u8C89"],"j\xF9 l\xF3u":["\u8C97"],"z\xE9 zh\xE0i":["\u8CAC","\u8D23"],"d\xE0i t\xE8":["\u8CB8"],"b\xEC b\u0113n":["\u8CC1"],"ji\u01CE g\u01D4 ji\xE0":["\u8CC8"],"xi\u014Dng m\xEDn":["\u8CEF"],c\u00E0ng:["\u8CF6"],"zhu\xE0n zu\xE0n":["\u8CFA","\u8D5A"],"w\xE0n zhu\xE0n":["\u8D03"],"g\xE0n g\xF2ng zhu\xE0ng":["\u8D1B"],"yu\xE1n y\xF9n":["\u8D20"],"b\u0113n b\xEC":["\u8D32"],"ji\u01CE g\u01D4":["\u8D3E"],z\u01D2u:["\u8D70","\u8D71","\u9BD0"],"di\xE9 t\xFA":["\u8D83"],"j\u016B qi\xE8":["\u8D84"],"q\u016B c\xF9":["\u8D8B","\u8DA8"],"j\xED ji\xE9":["\u8D8C"],"gu\u0101 hu\xF3":["\u8D8F"],"qu\xE8 q\xEC j\xED":["\u8D9E"],"t\xE0ng t\u0101ng":["\u8D9F"],"chu\u014D zhu\xF3":["\u8DA0"],"q\xF9 c\xF9":["\u8DA3"],"yu\xE8 t\xEC":["\u8DAF"],"b\u014D b\xE0o":["\u8DB5"],"ku\xE0 w\xF9":["\u8DB6"],"gu\xEC ju\xE9":["\u8DB9"],"f\u0101ng f\xE0ng p\xE1ng":["\u8DBD"],"p\xE1o b\xE0":["\u8DC1"],"q\xED q\u01D0":["\u8DC2"],"ji\xE0n ch\xE9n":["\u8DC8"],"p\u01CEo p\xE1o":["\u8DD1"],"di\u01CEn di\u0113 ti\u0113":["\u8DD5"],"j\u016B j\xF9 qi\xE8":["\u8DD9"],b\u01D2:["\u8DDB"],"lu\xF2 l\xEC":["\u8DDE"],"d\xE0i du\xF2 du\u014D ch\xED":["\u8DE2"],zhu\u01CEi:["\u8DE9"],"b\xE8ng pi\xE1n":["\u8DF0"],"ti\xE0o t\xE1o":["\u8DF3"],"sh\u016B ch\u014Du":["\u8DFE"],"li\xE0ng li\xE1ng":["\u8E09"],"t\xE0 t\u0101":["\u8E0F"],ch\u01CE:["\u8E45","\u9454","\u9572"],"d\xED zh\xED":["\u8E62"],"d\u0113ng d\xE8ng":["\u8E6C","\u9419","\u956B"],c\u00E8ng:["\u8E6D"],"d\u016Bn c\xFAn":["\u8E72"],"ju\u011B ju\xE9":["\u8E76"],li\u0101o:["\u8E7D"],"xi\xE8 s\u01CE":["\u8EA0"],t\u01D0:["\u8EB0","\u8EC6","\u9AB5"],"y\xE0 zh\xE1 g\xE1":["\u8F67","\u8ECB"],"x\xECn xi\xE0n":["\u8ED0"],"f\xE0n gu\u01D0":["\u8ED3"],"zhu\xE0n zhu\u01CEn":["\u8EE2"],"zh\xF3u zh\xF2u":["\u8EF8","\u8F74"],b\u00FA:["\u8F50","\u91AD","\u9CEA"],"zhu\u01CEn zhu\xE0n zhu\u01CEi":["\u8F6C"],"z\u01CEi z\xE0i":["\u8F7D"],"ni\u01CEn zh\u01CEn":["\u8F97"],"bi\u0101n bian":["\u8FB9"],"d\xE0o bi\u0101n":["\u8FBA"],"y\u01D0 y\xED":["\u8FC6","\u8FE4","\u8FF1"],"gu\xF2 guo gu\u014D":["\u8FC7"],"w\xE0ng ku\u0101ng":["\u8FCB"],"h\xE1i hu\xE1n":["\u8FD8"],"zh\xE8 zh\xE8i":["\u8FD9"],"yu\u01CEn yu\xE0n":["\u8FDC"],"zh\xEC l\xEC":["\u8FE3"],"zh\xF9 w\u01CEng":["\u8FEC"],"zhu\u012B du\u012B":["\u8FFD"],"sh\xEC ku\xF2":["\u9002"],t\u00F2u:["\u900F"],"t\u014Dng t\xF2ng":["\u901A"],gu\u00E0ng:["\u901B"],"d\u01CEi d\xE0i":["\u902E"],"su\xEC su\xED":["\u9042"],"t\xED d\xEC":["\u9046"],"y\xED w\xE8i":["\u9057"],"sh\xEC d\xED zh\xE9":["\u9069"],c\u00E0:["\u906A"],"hu\xE1n h\xE1i":["\u9084"],"l\xED ch\xED":["\u908C"],"k\xE0ng h\xE1ng":["\u909F"],"n\xE0 n\xE8i n\u0101":["\u90A3"],"xi\xE9 y\xE1 y\xE9 y\xFA x\xFA":["\u90AA"],"g\u0101i h\xE1i":["\u90C2"],"hu\xE1n x\xFAn":["\u90C7"],"ch\u012B x\u012B":["\u90D7"],h\u01CEo:["\u90DD"],"l\xEC zh\xED":["\u90E6"],"xi\xE1o \u01CEo":["\u90E9"],"d\u014Du d\u016B":["\u90FD"],li\u01CEo:["\u66E2","\u911D","\u957D"],"z\xE0n cu\xE1n cu\xF3":["\u9142","\u9147"],"d\u012Bng d\u01D0ng":["\u914A"],"c\xF9 zu\xF2":["\u9162"],"f\u0101 p\u014D":["\u9166"],"sh\u0101i sh\u012B":["\u917E"],ni\u00E0ng:["\u917F","\u91B8"],"qi\xFA ch\u014Du":["\u9194"],"p\u014D f\u0101":["\u9197","\u91B1"],"ch\u01CEn ch\u011Bn":["\u91A6"],"y\xE0n li\u01CEn xi\u0101n":["\u91B6"],"ni\xE0ng ni\xE1ng":["\u91C0"],"l\u01D0 li":["\u91CC"],"l\xED x\u01D0 x\u012B":["\u91D0"],"li\u01CEo li\xE0o":["\u91D5"],"d\u012Bng d\xECng":["\u91D8","\u9489"],"qi\u01CEo ji\u01CEo":["\u91E5"],"y\xFA hu\xE1":["\u91EA"],"hu\xE1 w\u016B":["\u91EB"],"r\xEC r\xE8n ji\xE0n":["\u91F0","\u91FC"],"d\xEC d\xE0i":["\u91F1"],"p\u012B zh\u0101o":["\u91FD"],"y\xE1 y\xE9":["\u91FE"],"b\u01CE p\xE1":["\u9200","\u94AF"],"t\u0101 tu\xF3":["\u9248","\u94CA"],b\u011Bi:["\u9273"],"b\u01D0ng p\xEDng":["\u927C"],"h\u0101 k\u0113":["\u927F","\u94EA"],ch\u00F2ng:["\u9283","\u94F3"],"xi\u01CEng ji\u014Dng":["\u9284"],"y\xF9 s\xEC":["\u9289"],"x\xF9 hu\xEC":["\u928A"],"r\xE9n r\u011Bn":["\u928B"],"sh\xE0n shu\xF2":["\u928F"],"ch\xEC l\xEC":["\u9290"],"xi\u01CEn x\u01D0":["\u9291","\u94E3"],"h\xF3u xi\xE0ng":["\u9297"],"di\xE0o ti\xE1o y\xE1o":["\u929A"],"xi\u0101n ku\xF2 ti\u01CEn gu\u0101":["\u929B","\u92BD","\u94E6"],"zh\xE9 ni\xE8":["\u92B8"],"zh\u014Dng y\u014Dng":["\u92BF"],"t\u014Du t\xF9 d\xF2u":["\u92C0"],"m\xE9i m\xE9ng":["\u92C2"],"w\xE0n ji\u01CEn":["\u92C4","\u93AB"],"t\u01D0ng d\xECng":["\u92CC","\u94E4"],"ju\u0101n ji\u0101n cu\u0101n":["\u92D1"],"s\u012B tu\xF3":["\u92D6"],"ju\u0101n xu\u0101n ju\xE0n":["\u92D7"],"w\xFA hu\xE1 w\u016B":["\u92D8"],"zhu\xF3 chu\xF2":["\u92DC"],"x\xEDng x\xECng j\u012Bng":["\u92DE"],"j\u016B j\xFA":["\u92E6","\u9514"],"zu\xEC ni\xE8":["\u92F7"],"yu\u0101n yu\u01CEn w\u01CEn w\u0101n":["\u92FA"],"g\u0101ng g\xE0ng":["\u92FC","\u94A2"],zhu\u012B:["\u9310","\u9525","\u9A05","\u9A93","\u9D7B"],\u0101:["\u9312","\u9515"],"cu\u014D ch\u0101":["\u9388"],"su\u01D2 s\xE8":["\u938D"],"y\xE1o z\xFA":["\u9390"],"y\xE8 t\xE0 g\xE9":["\u9391"],"qi\u0101ng ch\u0113ng":["\u9397"],"g\xE9 l\xEC":["\u9398","\u9549","\u9B32"],"b\u012B p\u012B b\xEC":["\u939E"],"g\u01CEo h\xE0o":["\u93AC"],"z\xFA chu\xF2":["\u93C3"],"xi\u016B xi\xF9":["\u93C5"],"sh\xF2u s\u014Du":["\u93C9"],"d\xED d\u012B":["\u93D1","\u955D"],"qi\u0101o s\u01CEn c\xE0n":["\u93D2"],"l\xF9 \xE1o":["\u93D5"],"t\u0101ng t\xE1ng":["\u93DC"],"ji\xE0n z\xE0n":["\u93E9"],"hu\xEC su\xEC ru\xEC":["\u93F8"],"qi\u01CEng qi\u0101ng":["\u93F9","\u956A"],"s\u01CEn xi\xE0n s\xE0":["\u93FE"],"ji\u01CEn ji\xE0n":["\u9427","\u950F"],"d\u0101ng ch\u0113ng":["\u943A","\u94DB"],"zu\u0101n zu\xE0n":["\u947D"],"s\xE0 x\xEC":["\u9491"],"y\xE0o yu\xE8":["\u94A5"],"t\u01D2u d\u01D2u":["\u94AD"],"zu\xE0n zu\u0101n":["\u94BB"],"qi\u0101n y\xE1n":["\u94C5"],"p\xED p\u012B":["\u94CD"],"y\xE1o di\xE0o ti\xE1o":["\u94EB"],"t\u0101ng t\xE0ng":["\u94F4"],"p\xF9 p\u016B":["\u94FA"],"t\xE1n xi\u0101n":["\u952C"],"li\xF9 li\xFA":["\u954F"],"h\xE0o g\u01CEo":["\u9550"],"t\xE1ng t\u0101ng":["\u9557"],"t\xE1n ch\xE1n x\xEDn":["\u9561"],"hu\xF2 sh\u01CEn":["\u9584"],"h\xE0n b\xEC":["\u9588","\u95EC"],"k\u0101ng k\xE0ng":["\u958C","\u95F6"],"xi\xE1n ji\xE0n ji\u0101n ji\u01CEn":["\u9592"],"xi\u0101 xi\u01CE":["\u9595"],"xi\u01CE k\u011B":["\u959C"],"bi\xE0n gu\u0101n":["\u959E"],"h\xE9 g\xE9":["\u95A4","\u988C"],"h\xF2ng xi\xE0ng":["\u95A7"],"s\u0113 x\u012B":["\u95AA"],"t\xEDng t\u01D0ng":["\u95AE"],"\xE8 y\u0101n":["\u95BC","\u960F"],"h\xF2ng ju\u01CEn xi\xE0ng":["\u95C2"],"b\u01CEn p\xE0n":["\u95C6"],"d\u016B sh\xE9":["\u95CD","\u9607"],"qu\xE8 qu\u0113":["\u95D5"],"t\u0101ng t\xE1ng ch\u0101ng":["\u95DB"],"k\xE0n h\u01CEn":["\u95DE","\u961A"],"x\xEC s\xE8 t\xE0":["\u95DF"],"m\u0113n m\xE8n":["\u95F7"],"qu\u0113 qu\xE8":["\u9619"],"y\xE1n di\xE0n":["\u963D"],"\u0101 \u0113":["\u963F"],"b\u0113i p\u014D p\xED":["\u9642"],"y\xE0n y\u01CEn":["\u9681"],"y\xFA y\xE1o sh\xF9":["\u9683"],"l\xF3ng l\u014Dng":["\u9686"],"du\xEC zhu\xEC":["\u968A"],"su\xED du\xF2":["\u968B"],"g\u0101i q\xED \xE1i":["\u9691"],"hu\u012B du\xF2":["\u9693","\u96B3"],"w\u011Bi ku\xED":["\u9697"],"l\xEC d\xE0i":["\u96B8"],"zhu\u012B cu\u012B w\xE9i":["\u96B9"],"h\xE8 h\xFA":["\u96BA","\u9DAE"],"j\xF9n ju\xE0n":["\u96BD","\u96CB"],"n\xE1n n\xE0n nu\xF3":["\u96BE"],"qu\xE8 qi\u0101o qi\u01CEo":["\u96C0"],"gu\xE0n hu\xE1n":["\u96DA"],"gu\u012B x\u012B":["\u96DF"],"s\xE8 x\xED":["\u96ED"],\u00E1n:["\u96F8"],"w\xF9 m\xE9ng":["\u96FA"],t\u00E8ng:["\u972F"],"l\xF9 l\xF2u":["\u9732"],m\u00E1i:["\u973E"],"j\xECng li\xE0ng":["\u975A"],"g\xE9 j\xED":["\u9769"],b\u01CE:["\u9776"],"y\u0101ng y\xE0ng":["\u9785"],"g\xE9 t\xE0 s\u01CE":["\u9788"],"bi\u0101n y\xECng":["\u9795"],"qi\xE0o sh\u0101o":["\u9798"],"ju\u0101n xu\u0101n":["\u9799"],"sh\xE0ng zh\u01CEng":["\u979D"],"p\xED b\u01D0ng b\xEC b\u0113i":["\u979E"],la:["\u97A1"],"xi\xE8 di\xE9":["\u97A2"],\u0113ng:["\u97A5"],"m\xF3u m\xF9":["\u97AA"],"b\xEC b\u01D0ng":["\u97B8"],"m\xE8i w\xE0":["\u97CE"],r\u01D2u:["\u97D6"],"sh\xE8 xi\xE8":["\u97D8"],"y\xF9n w\u0113n":["\u97EB"],"d\xF9n d\xFA":["\u9813","\u987F"],du\u01D0:["\u9827"],lu\u014D:["\u9831"],"b\u012Bn p\xEDn":["\u983B"],y\u00F3ng:["\u9852","\u9899","\u9C2B"],m\u0101n:["\u9862","\u989F"],"j\u01D0ng g\u011Bng":["\u9888"],"ji\xE9 xi\xE9 ji\xE1":["\u9889"],"k\u0113 k\xE9":["\u988F"],"p\xEDn b\u012Bn":["\u9891"],"ch\xE0n zh\xE0n":["\u98A4"],"f\u0113ng f\u011Bng":["\u98A8","\u98CE"],"bi\u0101o di\u016B":["\u98A9"],"b\xE1 f\xFA":["\u98B0"],"s\u0101o s\u014Du":["\u98BE"],"li\xF9 li\xE1o":["\u98C2"],"sh\xED s\xEC y\xEC":["\u98DF"],"y\u01CEng ju\xE0n":["\u98EC"],"zh\xF9 t\u01D2u":["\u98F3"],"y\xED s\xEC":["\u98F4"],"zu\xF2 z\xE9 zh\u0101":["\u98F5"],ti\u00E8:["\u98FB","\u992E"],"xi\u01CEng n\xE1ng":["\u995F"],"t\xE1ng x\xEDng":["\u9967"],"g\u0113 le":["\u9979"],"ch\u0101 zha":["\u9987"],"n\xE1ng n\u01CEng":["\u9995"],"y\u016Bn w\xF2":["\u99A7"],"zh\u012B sh\xEC":["\u99B6"],"x\xECn j\xECn":["\u99B8"],"ku\xE0i ju\xE9":["\u99C3"],z\u01CEng:["\u99D4","\u9A75"],"t\xE1i d\xE0i":["\u99D8"],"x\xFAn xu\u0101n":["\u99E8"],"li\xE1ng l\xE1ng":["\u99FA"],pi\u00E0n:["\u9A17","\u9A19","\u9A97","\u9B78"],"d\xE0i t\xE1i":["\u9A80"],"s\u0101o s\u01CEo":["\u9A9A"],"g\u01D4 g\u016B":["\u9AA8"],"b\xE8i m\xF3":["\u9AB3"],"xi\u0101o qi\u0101o":["\u9AB9"],"b\u01CEng p\u01CEng":["\u9AC8"],"b\xF3 ju\xE9":["\u9AC9"],"b\xEC p\u01D2":["\u9AF2"],"m\xE1o m\xE9ng":["\u9AF3"],"ku\xF2 yu\xE8":["\u9AFA"],"b\u0101 b\xE0":["\u9B5E","\u9C83"],"j\xEC c\u01D0":["\u9B86"],"b\xF3 b\xE0":["\u9B8A"],"zh\u01CE zh\xE0":["\u9B93","\u9C8A"],"ch\xF3u d\xE0i":["\u9B98"],"lu\xF2 g\xE9":["\u9BA5"],"gu\u012B xi\xE9 w\u0101 ku\xED":["\u9BAD"],"xi\u0101n xi\u01CEn":["\u9BAE","\u9C9C"],"p\u016B b\u016B":["\u9BC6"],"y\xEC s\u012B":["\u9BE3"],"b\xE0 b\xF3":["\u9C8C"],"gu\u012B xi\xE9":["\u9C91"],"s\u0101i x\u01D0":["\u9CC3"],"ni\u01CEo di\u01CEo":["\u9CE5"],"di\u0101o zh\u0101o":["\u9CED"],"g\u0101n h\xE0n y\xE0n":["\u9CF1"],"f\u016B gu\u012B":["\u9CFA"],"ji\u0101n qi\u0101n zh\u0101n":["\u9CFD"],"h\xE9 ji\xE8":["\u9DA1"],"pi\u0101n bi\u01CEn":["\u9DA3"],"chu\xE0n zh\xEC":["\u9DA8"],"c\u0101ng qi\u0101ng":["\u9DAC"],"s\u01D4n x\xF9n":["\u9DBD"],"bi\u0101o p\xE1o":["\u9E83"],"zh\xF9 c\u016B":["\u9E86"],"j\u016Bn q\xFAn":["\u9E87","\u9E95"],chi:["\u9EB6"],"m\xF3 me":["\u9EBC"],"m\xF3 me ma":["\u9EBD"],"m\xED m\u01D2":["\u9EBF"],"d\xE0n sh\xE8n":["\u9EEE"],"zh\u011Bn y\u0101n":["\u9EF0"],"d\u01CEn zh\u01CEn":["\u9EF5"],"mi\u01CEn m\u01D0n m\u011Bng":["\u9EFE"],h\u014Du:["\u9F41"],n\u00E0ng:["\u9F49"],"q\xED j\xEC z\u012B zh\u0101i":["\u9F50"],"y\xEDn k\u011Bn y\u01CEn":["\u9F82"],"y\xEDn k\u011Bn":["\u9F88"],"g\u014Dng w\xF2":["\u9F8F"],"gu\u012B j\u016Bn qi\u016B":["\u9F9C","\u9F9F"],"ku\xED w\u0101":["\u45AF"],l\u014Du:["\u4056"],"\u014Du q\u016B":["\u{2BB5F}"],"l\xF3u l\u01D8":["\u{2677C}"],"g\u01CE g\u0101 g\xE1":["\u560E"],"w\u0101 gu\xE0":["\u576C"],"zh\u01D0 d\u01D0":["\u830B"],"g\u01D2ng h\xF3ng":["\u7854"],"y\xE1o xi\xE0o":["\u6EE7"]},z=new l;Object.keys(O).forEach(n=>{let g=O[n];for(let i of g)z.set(i,n)});var nn=new l,E=new l;var d=n=>n.replace(/(ā|á|ǎ|à)/g,"a").replace(/(ō|ó|ǒ|ò)/g,"o").replace(/(ē|é|ě|è)/g,"e").replace(/(ī|í|ǐ|ì)/g,"i").replace(/(ū|ú|ǔ|ù)/g,"u").replace(/(ǖ|ǘ|ǚ|ǜ)/g,"\xFC").replace(/(n̄|ń|ň|ǹ)/g,"n").replace(/(m̄|ḿ|m̌|m̀)/g,"m").replace(/(ê̄|ế|ê̌|ề)/g,"\xEA");var e=(n,g)=>{let i=n.split(" "),h=[],u=[];for(let o of i)for(let t of v)if(o.startsWith(t)){let s=o.slice(t.length);I.indexOf(t)!==-1&&N.indexOf(s)!==-1&&(s=_[s]),h.push(t),u.push(s);break}return g==="standard"&&h.forEach((o,t)=>{(o==="y"||o==="w")&&(h[t]="")}),{final:u.join(" "),initial:h.join(" ")}};function p(n){let g="",i="",h="";return C.indexOf(d(n))!==-1?(g=n[0],i=n[1],h=n.slice(2)):(i=n[0]||"",h=n.slice(1)||""),{head:g,body:i,tail:h}}var j=n=>{let{final:g}=e(n);return p(g)},r=n=>{let g=/(ā|ō|ē|ī|ū|ǖ|n̄|m̄|ê̄)/,i=/(á|ó|é|í|ú|ǘ|ń|ḿ|ế)/,h=/(ǎ|ǒ|ě|ǐ|ǔ|ǚ|ň|m̌|ê̌)/,u=/(à|ò|è|ì|ù|ǜ|ǹ|m̀|ề)/,o=/(a|o|e|i|u|ü|ê)/,t=/(n|m)$/,s=[];return n.split(" ").forEach(c=>{g.test(c)?s.push("1"):i.test(c)?s.push("2"):h.test(c)?s.push("3"):u.test(c)?s.push("4"):o.test(c)||t.test(c)?s.push("0"):s.push("")}),s.join(" ")},A=(n,g)=>{let i=d(n).split(" "),h=r(g).split(" "),u=[];return i.forEach((o,t)=>{u.push(`${o}${h[t]}`)}),u.join(" ")},x=(n,g)=>{let i=[];return n.split(" ").forEach(u=>{i.push(g?u[0]:u)}),i.join(" ")};var M=n=>typeof n!="string"?(console.error("The first param of pinyin is error: "+n+' is not assignable to type "string".'),!1):!0;function f(n,g){return g instanceof RegExp?((g.global||g.sticky)&&(g.lastIndex=0),g.test(n)):!0}var R=(n,g)=>{let i=g.nonZh;if(i==="removed")return n.filter(h=>h.isZh||!f(h.origin,g.nonZhScope));if(i==="consecutive"){for(let h=n.length-2;h>=0;h--){let u=n[h],o=n[h+1];!u.isZh&&!o.isZh&&f(u.origin,g.nonZhScope)&&f(o.origin,g.nonZhScope)&&(u.origin+=o.origin,u.result+=o.result,o.delete=!0)}return n.filter(h=>!h.delete)}else return n};var W=(n,g)=>{switch(g.pattern){case"pinyin":break;case"num":n.forEach(i=>{i.result=i.isZh?r(i.result):""});break;case"initial":n.forEach(i=>{i.result=i.isZh?e(i.result,g.initialPattern).initial:""});break;case"final":n.forEach(i=>{i.result=i.isZh?e(i.result,g.initialPattern).final:""});break;case"first":n.forEach(i=>{i.result=x(i.result,i.isZh)});break;case"finalHead":n.forEach(i=>{i.result=i.isZh?j(i.result).head:""});break;case"finalBody":n.forEach(i=>{i.result=i.isZh?j(i.result).body:""});break;case"finalTail":n.forEach(i=>{i.result=i.isZh?j(i.result).tail:""});break}},$=(n,g)=>{switch(g.toneType){case"symbol":break;case"none":n.forEach(i=>{i.isZh&&(i.result=d(i.result))});break;case"num":{n.forEach(i=>{i.isZh&&(i.result=A(i.result,i.originPinyin))});break}}},B=(n,g)=>{g.v&&n.forEach(i=>{i.isZh&&(i.result=i.result.replace(/ü/g,typeof g.v=="string"?g.v:"v"))})};var U=()=>E;var gn={pattern:"pinyin",toneType:"symbol",type:"string",v:!1,nonZh:"spaced"};function b(n,g=gn){if(!M(n))return[];if(n==="")return[];g.type==="all"&&(g.pattern="pinyin"),g.pattern==="num"&&(g.toneType="none"),g.removeNonZh&&(g.nonZh="removed");let h=hn(n);h=R(h,g);let u=un(h),o=[];for(let t of u)W(t,g),$(t,g),B(t,g),o.push(on(t,g));return o}var hn=n=>{let g=U();return P(n).map(i=>{let h=g.get(i)||z.get(i)||i;return{origin:i,result:h,isZh:h!==i,originPinyin:h}})},un=n=>n.map(g=>g.isZh?g.result.includes(" ")?g.result.split(" ").map(i=>({origin:g.origin,result:i,isZh:!0,originPinyin:i})):[{origin:g.origin,result:g.result,isZh:!0,originPinyin:g.result}]:[g]),on=(n,g)=>{if(g.type!=="all"){let h=new Set;for(let o of n)h.add(o.result);let u=Array.from(h);return g.type==="array"?u:u.join(" ")}let i=[];for(let h of n){let u=h.isZh?h.result:"",{initial:o,final:t}=e(u,g.initialPattern),{head:s,body:q,tail:c}=p(t);i.push({origin:h.origin,pinyin:u,initial:o,final:t,first:x(h.result,h.isZh),finalHead:s,finalBody:q,finalTail:c,num:Number(r(h.originPinyin)),isZh:h.isZh,inZhRange:!!z.get(h.origin)})}return i};return Q(tn);})();

  const REMOTE_KEY = 'exhloj.local.remote.cache';
  const CF_KEY = 'exhloj.local.cf.ratings';
  const LUOGU_DIFFICULTY_SCALE = 2;
  const LUOGU_DIFFICULTIES = [
    ['暂无评定', '#777'], ['入门', '#fe4c61'], ['普及−', '#d47f00'], ['普及', '#987400'],
    ['普及+/提高−', '#299522'], ['提高', '#147d85'], ['提高+/省选−', '#2385c8'], ['省选/NOI−', '#9d3dcf'], ['NOI/NOI+/CTS', '#0e1d69'],
  ];
  // 旧版的手动选择按颜色保留；原站响应已经使用新版编号。
  const LEGACY_LUOGU_DIFFICULTIES = [0, 1, 2, 3, 4, 6, 7, 8];
  function luoguDifficulty(value) {
    const n = typeof value === 'number' ? value : typeof value === 'string' && /^\d+$/.test(value.trim()) ? Number(value) : NaN;
    return Number.isInteger(n) && n >= 0 && n < LUOGU_DIFFICULTIES.length ? n : undefined;
  }
  function cacheObject() { try { return validateCache(stored(CACHE_KEY, {})); } catch { return {}; } }
  function safeLink(value) {
    try { const url = new URL(value); return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : ''; }
    catch { return ''; }
  }
  function luoguId(value) {
    const text = String(value || '').trim().replace(/^https:\/\/(?:www\.)?luogu\.com\.cn\/problem\//i, '').split(/[?#]/)[0].replace(/\/$/, '');
    if (/^AT_[\w]+$/i.test(text)) return 'AT_' + text.slice(3).toLowerCase();
    return /^(?:P|B|U|T|CF|SP|UVA)\d+[A-Z]?\d?$/i.test(text) ? text.toUpperCase() : '';
  }
  function cfId(value) {
    let text = String(value || '').trim();
    const url = text.match(/^https:\/\/codeforces\.com\/(?:problemset\/problem\/(\d+)\/([A-Z]\d?)|(?:contest|gym)\/(\d+)\/problem\/([A-Z]\d?))/i);
    if (url) text = (url[1] || url[3]) + (url[2] || url[4]);
    const match = text.match(/^(?:CF|P)?(\d+)\/?([A-Z]\d?)$/i);
    return match ? `CF${match[1]}${match[2].toUpperCase()}` : '';
  }
  function atcoderId(value) {
    let text = String(value || '').trim().replace(/^AT_/i, '').replace(/^atcoder\//i, '');
    const url = text.match(/^https:\/\/atcoder\.jp\/contests\/[\w-]+\/tasks\/([\w-]+)/i);
    if (url) text = url[1];
    if (/^[a-z]+\d+[a-z]\d?$/i.test(text)) text = text.replace(/^([a-z]+\d+)([a-z]\d?)$/i, '$1_$2');
    return /^[a-z][\w-]*_[a-z\d]+$/i.test(text) ? text.toLowerCase() : '';
  }
  function normalizeOrigin(value) {
    if (typeof value === 'string') { try { value = value.trim().startsWith('{') ? JSON.parse(value) : { type: 'luogu', luoguId: value }; } catch { return null; } }
    if (!isObject(value)) return null;
    const type = String(value.type || 'luogu').toLowerCase();
    if (type === 'none') return { type: 'none', target: '', extra_links: [] };
    let target = String(value.target || value.luoguId || '').trim(), lid = luoguId(value.luoguId || '');
    if (type === 'luogu') { target = luoguId(target); lid = target; }
    else if (type === 'codeforces') { target = cfId(target); lid ||= target; }
    else if (type === 'atcoder') { target = atcoderId(target); lid ||= target ? `AT_${target}` : ''; }
    else if (type === 'qoj') { target = target.replace(/^https:\/\/qoj\.ac\/problem\//i, '').replace(/^[PQ]/i, '').replace(/\/$/, ''); if (!/^\d+$/.test(target)) target = ''; }
    else if (type !== 'other') return null;
    if (!target && type !== 'other') return null;
    const extra_links = (Array.isArray(value.extra_links) ? value.extra_links : []).slice(0, 20).filter(x => x && safeLink(x.link)).map(x => ({ name: String(x.name || x.link).slice(0, 150), link: safeLink(x.link) }));
    const result = { type, target, luoguId: lid, extra_links };
    const id = luoguDifficulty(value.difficulty), difficulty = value.difficultyScale === undefined ? LEGACY_LUOGU_DIFFICULTIES[id] : value.difficultyScale === LUOGU_DIFFICULTY_SCALE ? id : undefined;
    if (difficulty !== undefined) Object.assign(result, { difficulty, difficultyScale: LUOGU_DIFFICULTY_SCALE });
    return result;
  }
  function problemKey() { const pdoc = current('pdoc'); return `${pdoc?.domainId || domainId()}/${pdoc?.docId ?? pdoc?._id ?? location.pathname}`; }
  function qojTitleOrigin(title) {
    if (typeof title !== 'string') return null;
    const ids = new Set();
    for (const match of title.normalize('NFKC').matchAll(/(?:^|[^a-z0-9_])QOJ\s*#?\s*(\d+)(?![a-z0-9_])/gi)) {
      const id = Number(match[1]);
      if (Number.isSafeInteger(id) && id > 0) ids.add(String(id));
    }
    return ids.size === 1 ? normalizeOrigin({ type: 'qoj', target: [...ids][0] }) : null;
  }
  function inferOrigin() {
    const cache = cacheObject(), key = problemKey();
    const local = cache['exhloj.remoteOrigins'];
    if (isObject(local) && Object.hasOwn(local, key)) return normalizeOrigin(local[key]);
    const old = cache['exhloj.problemOriginCache'];
    if (isObject(old) && Object.hasOwn(old, key)) { const result = normalizeOrigin(old[key]); if (result) return result; }
    const pdoc = current('pdoc') || {}, config = pdoc.config || {};
    const subtype = String(config.subType || '').toLowerCase();
    if (['luogu', 'codeforces', 'qoj', 'atcoder'].includes(subtype) && config.target) return normalizeOrigin({ type: subtype, target: config.target });
    if (/^CF\d+[A-Z]\d?$/i.test(pdoc.pid || '')) return normalizeOrigin({ type: 'codeforces', target: pdoc.pid });
    if ((pdoc.domainId || domainId()) === 'luogu' && luoguId(pdoc.pid)) return normalizeOrigin({ type: 'luogu', target: pdoc.pid });
    for (const link of $$('.remote__tags a[href]')) {
      const href = link.href;
      if (/^https:\/\/(?:www\.)?luogu\.com\.cn\/problem\//i.test(href)) return normalizeOrigin({ type: 'luogu', target: href });
      if (cfId(href)) return normalizeOrigin({ type: 'codeforces', target: href });
      if (/^https:\/\/qoj\.ac\/problem\/\d+/i.test(href)) return normalizeOrigin({ type: 'qoj', target: href });
      if (/^https:\/\/atcoder\.jp\/contests\//i.test(href)) return normalizeOrigin({ type: 'atcoder', target: href });
    }
    return qojTitleOrigin(pdoc.title);
  }
  function originLinks(origin) {
    if (!origin || origin.type === 'none') return [];
    const links = [], cf = cfId(origin.luoguId) || (origin.type === 'codeforces' ? origin.target : '');
    if (cf) { const [, contest, index] = cf.match(/^CF(\d+)(.+)$/); links.push({ name: `Codeforces ${contest}${index}`, link: `https://codeforces.com/${+contest >= 100000 ? 'gym' : 'contest'}/${contest}/problem/${index}` }); }
    if (origin.type === 'qoj') links.push({ name: `QOJ ${origin.target}`, link: `https://qoj.ac/problem/${origin.target}` });
    if (origin.type === 'atcoder') { const contest = origin.target.split('_').slice(0, -1).join('_'); links.push({ name: `AtCoder ${origin.target}`, link: `https://atcoder.jp/contests/${contest}/tasks/${origin.target}` }); }
    if (origin.luoguId) links.push({ name: `洛谷 ${origin.luoguId}`, link: `https://www.luogu.com.cn/problem/${origin.luoguId}` });
    for (const link of origin.extra_links || []) if (!links.some(x => x.link === link.link)) links.push(link);
    return links;
  }
  const externalRequests = new Map();
  function externalText(address) {
    const url = new URL(address);
    if (url.protocol !== 'https:' || !['www.luogu.com.cn', 'codeforces.com', 'qoj.ac'].includes(url.hostname) || url.username || url.password) return Promise.reject(new Error('不允许读取此站点'));
    if (externalRequests.has(url.href)) return externalRequests.get(url.href);
    const promise = new Promise((resolve, reject) => {
      let settled = false;
      const finish = (fn, value) => { if (!settled) { settled = true; clearTimeout(timer); fn(value); } };
      const timer = setTimeout(() => finish(reject, new Error('原站请求超时')), 15000);
      try {
        GM_xmlhttpRequest({ method: 'GET', url: url.href, timeout: 14000,
          anonymous: url.hostname !== 'www.luogu.com.cn', headers: { Accept: 'text/html,application/json' },
          onload(response) {
            if (response.finalUrl) {
              try { if (new URL(response.finalUrl).origin !== url.origin) return finish(reject, new Error('原站跳转到了其他站点，请直接打开原链接查看')); } catch { return finish(reject, new Error('原站跳转地址无效')); }
            }
            if ([401, 403].includes(response.status)) return finish(reject, new Error('原站拒绝读取，请在原站登录并确认访问权限'));
            if (response.status < 200 || response.status >= 300) return finish(reject, new Error(`原站返回 HTTP ${response.status}`));
            const text = response.responseText ?? response.response;
            if (typeof text !== 'string' || text.length > 12 * 1024 * 1024) return finish(reject, new Error('原站返回的数据过大或无效'));
            finish(resolve, text);
          }, onerror: () => finish(reject, new Error('无法连接原站，请检查网络与油猴的跨站权限')),
          ontimeout: () => finish(reject, new Error('原站请求超时')), onabort: () => finish(reject, new Error('原站请求被取消')) });
      } catch (error) { finish(reject, error); }
    });
    externalRequests.set(url.href, promise);
    promise.finally(() => externalRequests.delete(url.href)).catch(() => {});
    return promise;
  }
  function parseLuogu(text) {
    try { const data = JSON.parse(text); if (isObject(data)) return data; } catch {}
    const doc = new DOMParser().parseFromString(text, 'text/html');
    const json = doc.querySelector('script#lentille-context, script#__NEXT_DATA__')?.textContent;
    if (json) { try { return JSON.parse(json); } catch {} }
    const old = text.match(/JSON\.parse\(decodeURIComponent\(("(?:[^"\\]|\\.)*")\)\)/);
    if (old) { try { return JSON.parse(decodeURIComponent(JSON.parse(old[1]))); } catch {} }
    throw new Error('洛谷页面结构变化或需要验证，请直接打开原站');
  }
  function statementMarkdown(problem, content, id) {
    content = isObject(content) ? content : problem;
    let text = `# ${id} ${content.name || problem.title || problem.name || ''}\n\n`;
    for (const [title, keys] of [['题目背景', ['background']], ['题目描述', ['description']], ['输入格式', ['formatI', 'inputFormat']], ['输出格式', ['formatO', 'outputFormat']]]) {
      const value = keys.map(key => content[key]).find(x => typeof x === 'string' && x.trim());
      if (value) text += `## ${title}\n\n${value.trim()}\n\n`;
    }
    for (const [i, sample] of (Array.isArray(problem.samples) ? problem.samples : []).entries()) {
      if (Array.isArray(sample)) text += `## 样例 ${i + 1}\n\n\`\`\`input\n${sample[0]}\n\`\`\`\n\n\`\`\`output\n${sample[1]}\n\`\`\`\n\n`;
    }
    if (typeof content.hint === 'string' && content.hint.trim()) text += `## 说明/提示\n\n${content.hint.trim()}\n`;
    if (typeof problem.translation === 'string' && problem.translation.trim()) text += `\n## 题目翻译\n\n${problem.translation.trim()}\n`;
    return text;
  }
  async function luoguProblem(id, force = false) {
    const cache = stored(REMOTE_KEY, {}), cached = isObject(cache) ? cache[id] : null;
    if (!force && cached?.difficultyScale === LUOGU_DIFFICULTY_SCALE && cached.time > Date.now() - 86400000 && isObject(cached.value)) return cached.value;
    const payload = parseLuogu(await externalText(`https://www.luogu.com.cn/problem/${encodeURIComponent(id)}`));
    const data = payload.data || payload.currentData || payload, problem = data.problem;
    if (!isObject(problem)) throw new Error('洛谷未返回题目资料，题号或访问权限可能不正确');
    const content = data.translations?.['zh-CN'] || data.translations?.zh || problem.content || problem.contenu || problem;
    const value = { id, title: problem.title || problem.name || content.name || id,
      difficulty: luoguDifficulty(problem.difficulty),
      statement: statementMarkdown(problem, content, id) };
    const next = Object.entries(isObject(cache) ? cache : {}).filter(([key, item]) => key !== id && item?.difficultyScale === LUOGU_DIFFICULTY_SCALE && item.time > Date.now() - 86400000).sort((a, b) => a[1].time - b[1].time).slice(-14);
    save(REMOTE_KEY, { ...Object.fromEntries(next), [id]: { time: Date.now(), difficultyScale: LUOGU_DIFFICULTY_SCALE, value } });
    return value;
  }
  let cfPromise;
  async function cfRating(id, force = false) {
    let cache = stored(CF_KEY, {});
    if (force || !isObject(cache.ratings) || cache.time < Date.now() - 3 * 86400000) {
      if (!cfPromise) {
        cfPromise = externalText('https://codeforces.com/api/problemset.problems').then(text => {
          const data = JSON.parse(text);
          if (data.status !== 'OK' || !Array.isArray(data.result?.problems)) throw new Error('Codeforces API 未返回题目列表');
          const ratings = {};
          for (const p of data.result.problems) if (Number.isInteger(p.contestId) && /^[A-Z]\d?$/.test(p.index) && Number.isFinite(p.rating)) ratings[`CF${p.contestId}${p.index}`] = p.rating;
          const value = { time: Date.now(), ratings }; save(CF_KEY, value); return value;
        }).finally(() => { cfPromise = undefined; });
      }
      cache = await cfPromise;
    }
    return cache.ratings[id];
  }
  const SEARCH_ENGINES = Object.freeze({
    yuantiji: { name: '原题机', home: 'https://yuantiji.ac/', endpoint: 'https://yuantiji.ac/api/search' },
    cpret: { name: 'CPRet', home: 'https://cpret.online/', endpoint: 'https://cpret.online/api/search' },
  });
  const semanticCache = new Map();
  let semanticPanel;
  function searchCandidate(value) {
    if (!isObject(value)) return null;
    const link = safeLink(value.url);
    if (!link) return null;
    const url = new URL(link), host = url.hostname.toLowerCase().replace(/^www\./, ''), path = url.pathname;
    let origin;
    if (host === 'luogu.com.cn' && /^\/problem\/[^/]+\/?$/.test(path)) origin = normalizeOrigin({ type: 'luogu', target: path.split('/')[2] });
    else if (host === 'codeforces.com' && /^\/(?:problemset\/problem\/\d+\/[a-z]\d?|(?:contest|gym)\/\d+\/problem\/[a-z]\d?)\/?$/i.test(path)) origin = normalizeOrigin({ type: 'codeforces', target: `https://codeforces.com${path}` });
    else if (host === 'qoj.ac' && /^\/problem\/\d+(?:\/|$)/.test(path)) origin = normalizeOrigin({ type: 'qoj', target: path.split('/')[2] });
    else if (host === 'atcoder.jp' && /^\/contests\/[\w-]+\/tasks\/[\w-]+\/?$/.test(path)) origin = normalizeOrigin({ type: 'atcoder', target: `https://atcoder.jp${path}` });
    const title = String(value.title || url.hostname).slice(0, 300), source = String(value.source || url.hostname).slice(0, 80);
    origin ||= normalizeOrigin({ type: 'other', extra_links: [{ name: title, link }] });
    const canonical = originLinks(origin).find(row => new URL(row.link).hostname.replace(/^www\./, '') === host)?.link || link;
    return { title, source, url: canonical, origin, score: Number.isFinite(value.score) ? value.score : null,
      snippet: typeof value.snippet === 'string' ? value.snippet.slice(0, 5000) : '', alternatives: [] };
  }
  function parseSearchResults(engine, data) {
    if (!isObject(data)) throw new Error('返回格式已变化，请打开网站检索');
    let rows;
    if (engine === 'yuantiji') {
      if (!Array.isArray(data.results)) throw new Error('未返回候选列表，请打开原题机检索');
      rows = data.results.slice(0, 20).map(row => isObject(row) ? {
        title: row.title, source: row.src, url: row.url, score: row.cos, snippet: row.t0 || row.original,
        alternatives: (Array.isArray(row.also) ? row.also : []).slice(0, 8).filter(isObject).map(other => ({ title: other.uid, url: other.url })),
      } : null);
    } else {
      if (typeof data.html !== 'string' || !Number.isSafeInteger(data.total) || data.total < 0) throw new Error('返回格式已变化，请打开 CPRet 检索');
      // 模板内容仅在惰性 DOM 内解析，绝不将外站 HTML、图片或脚本插入当前页面。
      const template = document.createElement('template'); template.innerHTML = data.html;
      const cards = [...template.content.querySelectorAll('.result-list > .result-card')].slice(0, 20);
      if (data.total && !cards.length) throw new Error('未识别到候选列表，请打开 CPRet 检索');
      const read = (node, selector) => node.querySelector(selector)?.textContent?.trim() || '';
      rows = cards.map(card => ({ title: read(card, '.result-title'), source: read(card, '.result-meta > .oj-tag'),
        url: card.querySelector('.result-title')?.getAttribute('href'), score: parseFloat(read(card, '.score-col > .score-num')),
        alternatives: [...card.querySelectorAll('.dups li')].slice(0, 8).map(other => ({ title: read(other, 'a.t'), source: read(other, '.oj-tag'),
          url: other.querySelector('a.t')?.getAttribute('href'), score: parseFloat(read(other, '.num')) })),
      }));
    }
    const results = [], seen = new Set();
    for (const row of rows) {
      const candidate = searchCandidate(row);
      if (!candidate || seen.has(candidate.url)) continue;
      seen.add(candidate.url);
      const alternatives = new Set([candidate.url]);
      for (const other of row.alternatives || []) {
        const value = searchCandidate(other);
        if (value && !alternatives.has(value.url)) { alternatives.add(value.url); candidate.alternatives.push(value); }
      }
      results.push(candidate);
    }
    if (rows.length && !results.length) throw new Error('候选中没有有效原题链接，请打开网站检索');
    return results;
  }
  function semanticRequest(engine, query, signal) {
    const service = SEARCH_ENGINES[engine];
    if (!service) return Promise.reject(new Error('未知的检索网站'));
    const address = new URL(service.endpoint), post = engine === 'yuantiji';
    if (!post) {
      address.search = new URLSearchParams({ q: query, lang: 'zh', page: '1', dedup: '1', mmr: '0' }).toString();
      if (address.href.length > 7500) return Promise.reject(new Error('题意过长，请精简后重试 CPRet，或使用原题机；本次没有向 CPRet 发送请求'));
    }
    return new Promise((resolve, reject) => {
      let settled = false, request;
      const finish = (fn, value) => { if (settled) return; settled = true; clearTimeout(timer); signal.removeEventListener('abort', abort); fn(value); };
      const abort = () => { finish(reject, new Error('已停止搜索')); request?.abort?.(); };
      const timer = setTimeout(() => { finish(reject, new Error('检索超时，可重试或打开网站搜索')); request?.abort?.(); }, 46000);
      if (signal.aborted) { abort(); return; }
      signal.addEventListener('abort', abort, { once: true });
      try {
        request = GM_xmlhttpRequest({ method: post ? 'POST' : 'GET', url: address.href, anonymous: true, timeout: 45000,
          headers: { Accept: 'application/json', ...(post ? { 'Content-Type': 'application/json' } : {}) },
          ...(post ? { data: JSON.stringify({ query, k: 20, rewrite: false, rerank: false, skip_short: false }) } : {}),
          onload(response) {
            try {
              if (response.finalUrl && new URL(response.finalUrl).origin !== address.origin) throw new Error('检索跳转到了其他网站，请打开原站查看');
              if (response.status === 429) throw new Error('网站请求较多，请稍后再试');
              if (response.status === 414) throw new Error('题意过长，请缩短后重试');
              if (response.status < 200 || response.status >= 300) throw new Error(`网站返回 HTTP ${response.status}，可打开原站查看`);
              const text = response.responseText ?? response.response;
              if (typeof text !== 'string' || text.length > 2 * 1024 * 1024) throw new Error('返回内容过大或无效');
              let data; try { data = JSON.parse(text); } catch { throw new Error('网站未返回检索数据，可能需要验证；请打开原站查看'); }
              finish(resolve, parseSearchResults(engine, data));
            } catch (error) { finish(reject, error); }
          }, onerror: () => finish(reject, new Error('无法连接检索网站，请检查网络与油猴的跨站权限')),
          ontimeout: () => finish(reject, new Error('检索超时，可重试或打开网站搜索')),
          onabort: () => finish(reject, new Error('已停止搜索')),
        });
      } catch (error) { finish(reject, error); }
    });
  }
  function assertSearchPanel(state) {
    if (!settings.remote || !state || state !== semanticPanel || !state.body.isConnected || !state.dialog.open || !sameOriginContext(state.context)) throw new Error('题目、账号或面板已变化，请重新打开原题搜索');
  }
  function renderSearchResults(state) {
    if (!state.body.isConnected || !state.dialog.open) return;
    const root = $('#exhloj-search-results', state.body); root.replaceChildren(); state.candidates.clear();
    let valid = true; try { assertSearchPanel(state); } catch { valid = false; }
    if (state.query !== undefined && $('#exhloj-search-query', state.body).value.trim() !== state.query) {
      valid = false; root.append(el('p', { role: 'status' }, '题意已修改，以下为上次搜索的候选；请重新搜索后关联。'));
    }
    const appendCandidate = (parent, row, id, rank) => {
      state.candidates.set(id, row);
      const card = el('article', { class: 'exhloj-search-candidate', 'data-search-candidate': id });
      card.append(el('strong', {}, rank + ' '), el('a', { href: row.url, target: '_blank', rel: 'noopener noreferrer', referrerpolicy: 'no-referrer' }, row.title));
      card.append(el('p', { class: 'exhloj-search-note' }, `${row.source}${row.score === null ? '' : ` · 相似度 ${row.score.toFixed(4)}`}`));
      if (row.snippet) { const details = el('details'); details.append(el('summary', {}, '查看候选题意'), el('pre', {}, row.snippet)); card.append(details); }
      if (state.context.key) card.append(button('核对并关联', 'remote-search-select', { 'data-search-id': id, ...(!valid ? { disabled: '' } : {}) }));
      if (row.alternatives.length) {
        const details = el('details'); details.append(el('summary', {}, `同组候选（${row.alternatives.length}，仍需逐题核对）`));
        row.alternatives.forEach((other, index) => appendCandidate(details, other, `${id}-${index}`, '↳')); card.append(details);
      }
      parent.append(card);
    };
    for (const [engine, group] of Object.entries(state.groups)) {
      const section = el('section', { 'data-search-engine-results': engine });
      section.append(el('h3', {}, SEARCH_ENGINES[engine].name), el('p', { class: 'exhloj-search-status', role: 'status' }, group.message));
      group.rows.forEach((row, index) => appendCandidate(section, row, `${engine}-${index}`, `${index + 1}.`)); root.append(section);
    }
  }
  function openSemanticSearch() {
    if (!settings.remote) throw new Error('请先在设置中开启题源与题解');
    const body = modal('按题意搜索原题', 'remote'), context = originContext();
    const state = { body, dialog: body.closest('dialog'), context, groups: {}, candidates: new Map(), controller: null };
    semanticPanel = state;
    body.append(el('p', {}, context.key ? `当前题目：${current('pdoc').title || current('pdoc').pid || context.key}` : '可搜索相似题。在题目页打开此工具，才能将候选关联到当前题目。'));
    const label = el('label', { for: 'exhloj-search-query' }, '题面或题意简述'), input = el('textarea', { id: 'exhloj-search-query', placeholder: '保留要求计算的内容、操作与限制；也可直接粘贴题面。' });
    input.value = markdownContent(current('pdoc')?.content || '').trim();
    input.addEventListener('input', () => renderSearchResults(state));
    body.append(label, input, el('p', { class: 'exhloj-search-note' }, '点击搜索才会把此框内容发送到勾选的网站。建议精简长题面；CPRet 最多处理 2048 token。'));
    const options = el('div', { class: 'exhloj-search-options' });
    for (const [engine, service] of Object.entries(SEARCH_ENGINES)) {
      const label = el('label'), checkbox = el('input', { type: 'checkbox', 'data-search-engine': engine }); checkbox.checked = true; label.append(checkbox, service.name); options.append(label);
    }
    body.append(options, button('开始搜索', 'remote-search-run'), button('停止搜索', 'remote-search-cancel', { disabled: '' }), button('复制题意', 'remote-search-copy'));
    if (context.key) body.append(button('重新载入当前题面', 'remote-search-fill'));
    const links = el('p', { class: 'exhloj-panel-footer' });
    for (const service of Object.values(SEARCH_ENGINES)) links.append(el('a', { href: service.home, target: '_blank', rel: 'noopener noreferrer', referrerpolicy: 'no-referrer' }, `打开 ${service.name}`));
    body.append(links, el('p', { class: 'exhloj-search-note' }, '结果按网站分别排序，分数不能跨网站比较。相似度不代表同题，请核对题意、数据范围和样例后再保存。'), el('div', { id: 'exhloj-search-results', 'aria-live': 'polite' }));
    state.dialog.addEventListener('close', () => state.controller?.abort(), { once: true });
  }
  async function fillSearchStatement() {
    const state = semanticPanel; assertSearchPanel(state);
    const input = $('#exhloj-search-query', state.body), before = input.value, pdoc = await problemDocument();
    assertSearchPanel(state);
    if (input.value !== before) throw new Error('你已编辑题意，保留当前输入');
    input.value = markdownContent(pdoc.content || '').trim();
    renderSearchResults(state);
  }
  async function runSemanticSearch() {
    const state = semanticPanel; assertSearchPanel(state);
    if (state.controller) return;
    const query = $('#exhloj-search-query', state.body).value.trim(), engines = $$('[data-search-engine]:checked', state.body).map(node => node.dataset.searchEngine);
    if (!query) throw new Error('请先输入题面或题意');
    if (query.length > 16000) throw new Error('题意超过 16000 字符，请精简后再搜索；未发送请求');
    if (!engines.length) throw new Error('请至少选择一个检索网站');
    const controller = new AbortController(); state.controller = controller; state.query = query;
    state.groups = Object.fromEntries(engines.map(engine => [engine, { rows: [], message: '正在搜索…' }]));
    const controls = [$('#exhloj-search-query', state.body), ...$$('[data-search-engine], [data-exh-action="remote-search-run"], [data-exh-action="remote-search-fill"]', state.body)];
    controls.forEach(node => { node.disabled = true; }); $('[data-exh-action="remote-search-cancel"]', state.body).disabled = false; renderSearchResults(state);
    try {
      await Promise.allSettled(engines.map(async engine => {
        const group = state.groups[engine], key = JSON.stringify([engine, query]);
        try {
          const cached = semanticCache.get(key), rows = cached || await semanticRequest(engine, query, controller.signal);
          assertSearchPanel(state); if (controller.signal.aborted) throw new Error('已停止搜索');
          group.rows = rows; group.message = rows.length ? `前 ${rows.length} 条候选${cached ? ' · 复用本次页面的搜索结果' : ''}` : '未找到可用候选，可调整题意或打开网站查看';
          if (!cached) { semanticCache.set(key, rows); if (semanticCache.size > 8) semanticCache.delete(semanticCache.keys().next().value); }
        } catch (error) { group.message = error.message || '检索失败，可重试或打开网站查看'; }
        renderSearchResults(state);
      }));
    } finally {
      state.controller = null; controls.forEach(node => { node.disabled = false; }); $('[data-exh-action="remote-search-cancel"]', state.body).disabled = true;
    }
  }
  function selectSearchCandidate(control) {
    const state = semanticPanel; assertSearchPanel(state);
    if (!state.context.key) throw new Error('请在需要关联的题目页搜索');
    if ($('#exhloj-search-query', state.body).value.trim() !== state.query) throw new Error('题意已修改，请重新搜索后关联');
    const candidate = state.candidates.get(control.dataset.searchId);
    if (!candidate) throw new Error('候选列表已变化，请重新选择');
    state.controller?.abort(); configureOrigin(candidate.origin, candidate.title);
  }

  const remoteViews = new Map();
  let remoteState, remoteCounter = 0, remotePending = false, contestRevealed = false;
  function makeRemoteState(origin, local = false) {
    const state = { id: String(++remoteCounter), origin, local, solutions: [], solutionPage: 0, total: 0, exhausted: false, messages: [] };
    remoteViews.set(state.id, state);
    if (remoteViews.size > 12) remoteViews.delete(remoteViews.keys().next().value);
    return state;
  }
  function stateFor(control) {
    const id = control.closest('[data-remote-view]')?.dataset.remoteView;
    const state = remoteState?.id === id ? remoteState : remoteViews.get(id);
    if (!state || (state.local && state !== remoteState)) throw new Error('工具面板已过期，请重新打开');
    return state;
  }
  function renderedMarkdown(text) {
    const node = el('div', { class: 'typo richmedia' }); node.innerHTML = ExhlojMarkdown.render(text);
    for (const a of $$('a[href]', node)) {
      const href = a.getAttribute('href');
      if (href && !href.startsWith('#')) { try { a.href = new URL(href, 'https://www.luogu.com.cn/').href; } catch { a.removeAttribute('href'); } }
      a.target = '_blank'; a.rel = 'noopener noreferrer';
    }
    for (const img of $$('img', node)) {
      const src = img.getAttribute('src');
      if (src && !src.startsWith('data:')) { try { img.src = new URL(src, 'https://www.luogu.com.cn/').href; } catch { img.removeAttribute('src'); } }
      img.loading = 'lazy'; img.referrerPolicy = 'no-referrer';
    }
    return node;
  }
  function renderRemote(state) {
    let root = state.root;
    if (!root?.isConnected || (state.local && (state !== remoteState || hiddenContestSource()))) return;
    root.dataset.remoteView = state.id;
    const tools = state.local ? document.createDocumentFragment() : el('div', { class: 'exhloj-remote-tools' });
    for (const link of originLinks(state.origin)) tools.append(el('a', { href: link.link, target: '_blank', rel: 'noopener noreferrer' }, link.name));
    const difficulty = luoguDifficulty(state.origin?.difficulty ?? state.problem?.difficulty);
    if (difficulty !== undefined) {
      const [label, color] = LUOGU_DIFFICULTIES[difficulty], chip = el('span', { class: 'exhloj-remote-chip', 'data-exh-difficulty': difficulty }, label);
      if (settings.remoteColor === 'text') chip.style.color = color;
      if (settings.remoteColor === 'background') { chip.style.backgroundColor = color; chip.style.color = '#fff'; }
      tools.append(chip);
    }
    if (state.rating !== undefined) tools.append(el('span', { class: 'exhloj-remote-chip', 'data-exh-cf-rating': '' }, `CF *${state.rating}`));
    if (state.local) {
      if (!state.origin) tools.append(button('查找原题', 'remote-search', { class: 'exhloj-find-source', title: '未识别题源，按题意查找原题' }));
      root.replaceChildren(tools); state.color = settings.remoteColor;
      syncTitleTools();
      let content = $('#exhloj-local-remote-content');
      if (!state.showStatement && !state.showSolutions) { content?.remove(); return; }
      if (!content) content = el('div', { id: 'exhloj-local-remote-content' });
      const anchor = root.closest('.problem__tags') || root;
      if (content.previousElementSibling !== anchor) anchor.after(content);
      root = content; root.dataset.remoteView = state.id; root.replaceChildren();
    } else {
      for (const [name, action] of remoteActions(state)) tools.append(button(name, action));
      if (state.messages.length) tools.append(el('div', { class: 'exhloj-remote-status', role: 'status' }, state.messages.join('；')));
      root.replaceChildren(tools);
    }
    if (state.showStatement && state.problem) {
      const article = el('section', { class: 'exhloj-remote-article' });
      article.append(button('复制题面 Markdown', 'remote-copy-statement'), renderedMarkdown(state.problem.statement)); root.append(article);
    }
    if (state.showSolutions) {
      const content = el('div', { class: 'exhloj-remote-solutions' });
      content.append(el('p', {}, `已加载 ${state.solutions.length} 篇题解${state.total ? ` / 原站共 ${state.total} 篇` : ''}；仅导出已加载内容。`));
      state.solutions.forEach((solution, index) => {
        const article = el('section', { class: 'exhloj-remote-article' });
        const header = el('p', {}, `作者：${solution.author} `);
        if (/^[\w-]+$/.test(solution.id)) header.append(el('a', { href: `https://www.luogu.com.cn/article/${solution.id}`, target: '_blank', rel: 'noopener noreferrer' }, '原文'));
        header.append(button('复制 Markdown', 'remote-copy-solution', { 'data-index': index }));
        article.append(header, renderedMarkdown(solution.content)); content.append(article);
      });
      if (!state.exhausted) content.append(button('加载下一页题解', 'remote-more'));
      root.append(content);
    }
    try { (page.jQuery || page.$)?.(root).trigger('vjContentNew'); } catch {}
  }
  async function loadRemoteMeta(state, force = false) {
    if (state.metaPromise) return state.metaPromise;
    state.messages = ['正在读取原站资料…']; renderRemote(state);
    state.metaPromise = (async () => {
      const jobs = [], names = [];
      if (state.origin?.luoguId) { jobs.push(luoguProblem(state.origin.luoguId, force).then(p => { state.problem = p; })); names.push('洛谷'); }
      const cf = cfId(state.origin?.luoguId) || (state.origin?.type === 'codeforces' ? state.origin.target : '');
      if (cf) { jobs.push(cfRating(cf, force).then(rating => { state.rating = rating; })); names.push('Codeforces'); }
      const results = await Promise.allSettled(jobs);
      state.metaError = results.some(result => result.status === 'rejected');
      state.messages = results.flatMap((result, i) => result.status === 'rejected' ? [`${names[i]}：${result.reason.message}`] : []);
      if (!state.messages.length) state.messages = ['原站资料已读取；未评级的题目不显示 rating'];
      renderRemote(state);
    })().finally(() => { state.metaPromise = undefined; });
    return state.metaPromise;
  }
  async function loadRemoteSolutions(state) {
    if (!state.origin?.luoguId) throw new Error('请先配置洛谷题号');
    const number = state.solutionPage + 1;
    const payload = parseLuogu(await externalText(`https://www.luogu.com.cn/problem/solution/${encodeURIComponent(state.origin.luoguId)}?page=${number}`));
    const data = payload.data || payload.currentData || payload, list = data.solutions;
    const rows = Array.isArray(list) ? list : list?.result || list?.list;
    if (!Array.isArray(rows)) throw new Error('未获得题解列表；请在洛谷登录并确认有查看权限');
    const known = new Set(state.solutions.map(x => x.id));
    let added = 0;
    for (const row of rows) {
      if (typeof row.content !== 'string') continue;
      const id = String(row.lid || row.id || row._id || `page${number}-${added}`);
      if (known.has(id)) continue;
      known.add(id); state.solutions.push({ id, author: String(row.author?.name || row.author?.uname || '未知'), content: row.content }); added++;
    }
    state.solutionPage = number; state.total = Number(list?.count ?? list?.total ?? state.total) || 0;
    state.showSolutions = true;
    state.exhausted = rows.length === 0 || added === 0 || (state.total > 0 && state.solutions.length >= state.total) || state.solutions.length >= 500;
    state.messages = rows.length ? [] : ['原站没有更多题解']; renderRemote(state);
  }
  function clearLocalRemote() {
    remoteState = undefined; $('#exhloj-local-remote')?.remove(); $('#exhloj-local-remote-content')?.remove();
  }
  function remoteProblem() {
    const { column, tags, header, heading } = titleLocation();
    if (!settings.remote || hiddenContestSource() || !column) { clearLocalRemote(); return; }
    if (!current('pdoc')) {
      if (!remotePending) { remotePending = true; const epoch = routeEpoch; loadPage().then(() => { if (epoch === routeEpoch) schedule(); }).catch(() => {}); }
      return;
    }
    let root = $('#exhloj-local-remote');
    const tag = tags && /^(UL|OL)$/.test(tags.tagName) ? 'LI' : 'SPAN';
    if (root?.tagName !== tag) { root?.remove(); root = el(tag, { id: 'exhloj-local-remote' }); }
    if (tags) { if (root.parentNode !== tags) tags.append(root); }
    else if (header || heading) { const anchor = header || heading; if (root.previousElementSibling !== anchor) anchor.after(root); }
    else if (root.parentNode !== column) column.prepend(root);
    const origin = inferOrigin(), signature = problemKey() + JSON.stringify(origin);
    if (remoteState?.signature === signature) {
      const content = $('#exhloj-local-remote-content');
      if (remoteState.root !== root || remoteState.color !== settings.remoteColor ||
          ((remoteState.showStatement || remoteState.showSolutions) && content?.previousElementSibling !== (tags || root))) {
        remoteState.root = root; renderRemote(remoteState);
      }
      return;
    }
    const state = makeRemoteState(origin, true); state.signature = signature; state.root = root; remoteState = state; renderRemote(state);
    if (settings.remoteAuto && origin?.type !== 'none' && (origin?.luoguId || origin?.type === 'codeforces')) loadRemoteMeta(state);
  }
  let originEditor;
  function originContext() { return { key: current('pdoc') ? problemKey() : null, epoch: routeEpoch, address: location.href, owner: String(user()._id || 0) }; }
  function sameOriginContext(context) {
    return context && context.epoch === routeEpoch && context.address === location.href && context.owner === String(user()._id || 0) && context.key === (current('pdoc') ? problemKey() : null);
  }
  function configureOrigin(suggested, candidateTitle = '') {
    if (!settings.remote || !current('pdoc')) throw new Error('请在需要关联的题目页配置题源');
    const origin = suggested || remoteState?.origin || inferOrigin() || { type: 'luogu', target: '', extra_links: [] };
    const body = modal('本地题源配置', 'remote');
    originEditor = { body, context: originContext(), baseline: JSON.stringify(cacheObject()['exhloj.remoteOrigins']?.[problemKey()] ?? null) };
    if (suggested) body.append(el('p', {}, `候选：${candidateTitle}`), el('p', {}, '请核对题意、数据范围和样例。确认并保存后，将使用下面的配置替换此题的本地题源。'));
    body.append(el('p', {}, `只保存到本机。题目键：${problemKey()}。普通本地 P 题号不会被自动当成洛谷题号。`));
    const type = el('select', { id: 'exhloj-origin-type' });
    for (const [id, label] of [['luogu', '洛谷'], ['codeforces', 'Codeforces'], ['qoj', 'QOJ'], ['atcoder', 'AtCoder'], ['other', '其他链接'], ['none', '停用此题识别']]) type.append(el('option', { value: id }, label));
    type.value = origin.type; body.append(type);
    for (const [key, title, value] of [['target', '原站编号或原题链接', origin.target], ['luoguId', '对应洛谷题号（可留空）', origin.luoguId]]) {
      const label = el('label', {}, title); label.append(el('input', { id: `exhloj-origin-${key}`, type: 'text', class: 'exhloj-source-input', value: value || '' })); body.append(label);
    }
    const label = el('label', {}, '难度 '), difficulty = el('select', { id: 'exhloj-origin-difficulty' });
    difficulty.append(el('option', { value: '' }, '跟随原站'));
    LUOGU_DIFFICULTIES.forEach(([name], id) => difficulty.append(el('option', { value: id }, name)));
    difficulty.value = String(origin.difficulty ?? ''); label.append(difficulty); body.append(label);
    body.append(el('p', {}, '附加链接：每行“显示名,https://...”'));
    const extra = el('textarea', { id: 'exhloj-origin-extra' }); extra.value = (origin.extra_links || []).map(x => `${x.name},${x.link}`).join('\n'); body.append(extra);
    body.append(button(suggested ? '确认并保存题源' : '保存本地题源', 'remote-save-origin'), button('清除手动配置', 'remote-reset-origin'));
  }
  function saveOrigin(reset = false) {
    if (!settings.remote || !originEditor?.body.isConnected || !originEditor.body.closest('dialog')?.open || !sameOriginContext(originEditor.context)) throw new Error('题目或账号已变化，请在当前题目重新打开题源配置');
    const cache = cacheObject(), map = isObject(cache['exhloj.remoteOrigins']) ? { ...cache['exhloj.remoteOrigins'] } : {};
    if (JSON.stringify(map[problemKey()] ?? null) !== originEditor.baseline) throw new Error('此题的本地题源已修改，请重新打开配置');
    if (reset) delete map[problemKey()];
    else {
      const value = { type: $('#exhloj-origin-type').value, target: $('#exhloj-origin-target').value,
        luoguId: $('#exhloj-origin-luoguId').value, extra_links: [] };
      if (value.luoguId && !luoguId(value.luoguId)) throw new Error('对应洛谷题号的格式不正确');
      const diff = $('#exhloj-origin-difficulty').value;
      if (diff !== '') {
        const difficulty = luoguDifficulty(diff); if (difficulty === undefined) throw new Error('请选择有效难度');
        Object.assign(value, { difficulty, difficultyScale: LUOGU_DIFFICULTY_SCALE });
      }
      for (const line of $('#exhloj-origin-extra').value.split('\n').filter(x => x.trim())) {
        const split = line.indexOf(',');
        if (split < 0 || !safeLink(line.slice(split + 1).trim())) throw new Error('附加链接格式错误');
        value.extra_links.push({ name: line.slice(0, split).trim(), link: line.slice(split + 1).trim() });
      }
      const origin = normalizeOrigin(value); if (!origin) throw new Error('原站编号格式不正确'); map[problemKey()] = origin;
    }
    cache['exhloj.remoteOrigins'] = map; save(CACHE_KEY, cache); remoteState = undefined;
    $('#exhloj-local-dialog')?.close(); remoteProblem(); notify(reset ? '已清除手动配置' : '本地题源已保存');
  }
  function openLuoguTool(value) {
    const id = luoguId(value); if (!id) throw new Error('请输入正确的洛谷题号，例如 P1001 或 CF1234A');
    const body = modal(`洛谷工具 · ${id}`, 'remote'), root = el('div'); body.append(root);
    const state = makeRemoteState(normalizeOrigin({ type: 'luogu', target: id })); state.root = root; renderRemote(state);
    loadRemoteMeta(state);
  }
  const crcTable = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  function zipContent(files) {
    const encoder = new TextEncoder(), chunks = [], central = []; let offset = 0, directorySize = 0;
    for (const file of files) {
      const name = encoder.encode(file.name), data = file.bytes instanceof Uint8Array ? file.bytes :
        file.bytes instanceof ArrayBuffer ? new Uint8Array(file.bytes) : encoder.encode(file.content); let crc = 0xffffffff;
      for (const byte of data) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8); crc = (crc ^ 0xffffffff) >>> 0;
      const header = new Uint8Array(30 + name.length), view = new DataView(header.buffer);
      view.setUint32(0, 0x04034b50, true); view.setUint16(4, 20, true); view.setUint16(6, 0x800, true);
      view.setUint16(12, 33, true); // DOS date: 1980-01-01
      view.setUint32(14, crc, true); view.setUint32(18, data.length, true); view.setUint32(22, data.length, true); view.setUint16(26, name.length, true); header.set(name, 30);
      const record = new Uint8Array(46 + name.length), r = new DataView(record.buffer);
      r.setUint32(0, 0x02014b50, true); r.setUint16(4, 20, true); r.setUint16(6, 20, true); r.setUint16(8, 0x800, true);
      r.setUint16(14, 33, true);
      r.setUint32(16, crc, true); r.setUint32(20, data.length, true); r.setUint32(24, data.length, true); r.setUint16(28, name.length, true); r.setUint32(42, offset, true); record.set(name, 46);
      chunks.push(header, data); central.push(record); offset += header.length + data.length; directorySize += record.length;
    }
    const end = new Uint8Array(22), e = new DataView(end.buffer);
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, directorySize, true); e.setUint32(16, offset, true);
    return new Blob([...chunks, ...central, end], { type: 'application/zip' });
  }
  async function exportRemote(state) {
    if (!state.problem) { state.problem = await luoguProblem(state.origin.luoguId); renderRemote(state); }
    const files = [{ name: 'statement.md', content: state.problem.statement }, { name: 'source.json', content: JSON.stringify({ source: state.origin, solutionsLoaded: state.solutions.length, pagesLoaded: state.solutionPage, exportedAt: new Date().toISOString() }, null, 2) }];
    state.solutions.forEach((solution, i) => files.push({ name: `solutions/${String(i + 1).padStart(3, '0')}-${solution.id.replace(/[^\w-]/g, '_').slice(0, 80)}.md`, content: `Author: ${solution.author}\n\n${solution.content}` }));
    download(`Luogu_${state.origin.luoguId}.zip`, zipContent(files), 'application/zip');
  }
  function remoteSubmissionTools() {
    if ($('#exhloj-local-origin-code')) return;
    const record = current('rdoc'); if (!record || record.code?.trim()) return;
    const id = (Array.isArray(record.judgeTexts) ? record.judgeTexts.join(' ') : '').match(/^ID\s*=\s*(\d+)/)?.[1];
    const platform = String(record.lang || '').split('.')[0]; if (!id || !['qoj', 'codeforces'].includes(platform)) return;
    let link = `https://qoj.ac/submission/${id}`;
    if (platform === 'codeforces') {
      const origin = inferOrigin(), cf = cfId(origin?.luoguId) || cfId(origin?.target);
      if (!cf) return;
      const contest = cf.match(/^CF(\d+)/)[1]; link = `https://codeforces.com/${+contest >= 100000 ? 'gym' : 'contest'}/${contest}/submission/${id}`;
    }
    const root = el('div', { class: 'section__body', id: 'exhloj-local-origin-code' });
    root.append(el('a', { href: link, target: '_blank', rel: 'noopener noreferrer' }, '原站提交'), button('读取原站公开代码', 'remote-code', { 'data-url': link }));
    (mainColumn() || document.body).append(root);
  }
  async function loadSubmissionCode(control) {
    const root = $('#exhloj-local-origin-code'), html = await externalText(control.dataset.url);
    if (!root?.isConnected) return;
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const source = doc.querySelector('#program-source, #submission-source-code, .submission-source-code, .card-body pre > code');
    if (!source || !source.textContent.trim()) throw new Error('原站没有公开可读取的代码；请打开原站提交查看');
    $('pre', root)?.remove(); const pre = el('pre'), code = el('code', { class: 'language-cpp' }, source.textContent); pre.append(code); root.append(pre);
  }


  // contest-helper / juan-monitor 共用串行请求、进度与取消控制。
  const workStates = { contest: {}, juan: {}, auto: {}, user: {}, oier: {}, planner: {} }, workJobs = new Map();
  const SNAPSHOT_KEY = 'exhloj.local.juan.snapshots.v1', ATTEND_KEY = 'exhloj.local.attended.v1';
  const VERDICTS = { 0: 'Waiting', 1: 'Accepted', 2: 'Wrong Answer', 3: 'Time Limit Exceeded', 4: 'Memory Limit Exceeded',
    5: 'Output Limit Exceeded', 6: 'Runtime Error', 7: 'Compile Error', 8: 'System Error', 9: 'Cancelled', 20: 'Running', 21: 'Compiling', 30: 'Ignored' };
  let netQueue = Promise.resolve(), lastWorkRequest = 0;
  function workError(message, budget = false) { const error = new Error(message); error.budget = budget; return error; }
  function checkJob(job, requesting = false) {
    if (job.controller.signal.aborted) throw workError('任务已取消');
    if (job.owner !== +user()._id) throw workError('登录账号已变化，任务停止');
    if (job.kind === 'planner' && (!settings.homeworkPlanner || job.epoch !== routeEpoch || job.address !== location.href ||
        job.domain !== domainId() || pageName() !== 'homework_main')) throw workError('作业页面或账号已变化，请重新查找');
    if (job.kind === 'user' && (job.epoch !== routeEpoch || job.address !== location.href || job.pageName !== pageName())) throw workError('页面已变化，请重新开始结算');
    if (requesting && job.count >= job.limit) throw workError(`达到 ${job.limit} 次请求上限；本次结果不完整`, true);
  }
  function pauseWork(ms, signal) {
    if (signal.aborted) return Promise.reject(workError('任务已取消'));
    return new Promise((resolve, reject) => {
      const cancel = () => { clearTimeout(timer); signal.removeEventListener('abort', cancel); reject(workError('任务已取消')); };
      const timer = setTimeout(() => { signal.removeEventListener('abort', cancel); resolve(); }, ms);
      signal.addEventListener('abort', cancel, { once: true });
    });
  }
  function updateWorkProgress(kind) {
    const state = workStates[kind], root = state.root;
    if (!root?.isConnected) return;
    const progress = $(`[data-work-progress="${kind}"]`, root);
    if (progress) progress.textContent = `${state.running ? '运行中' : state.status || '就绪'} · ${state.job?.count || 0} 次请求\n${state.message || ''}`;
  }
  async function workRequest(job, label, fn) {
    const operation = netQueue.then(async () => {
      checkJob(job, true);
      await pauseWork(Math.max(0, job.delay - (Date.now() - lastWorkRequest)), job.controller.signal);
      checkJob(job, true); job.count++; lastWorkRequest = Date.now();
      workStates[job.kind].message = label; updateWorkProgress(job.kind);
      return fn(job.controller.signal);
    });
    netQueue = operation.catch(() => {}); return operation;
  }
  function jobJSON(job, path, options = {}) {
    const url = new URL(path, location.origin);
    return workRequest(job, url.pathname + url.search, signal => requestJSON(url.href, { ...options, signal }));
  }
  function postOptions(data) {
    const body = { ...data }, csrf = $('input[name="_csrf"]')?.value || $('meta[name="csrf-token"]')?.content;
    if (csrf) body._csrf = csrf;
    return { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
  }
  async function jobBytes(job, address, label) {
    const url = new URL(address, location.origin);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw workError('附件链接无效');
    return workRequest(job, `下载附件：${label}`, async signal => {
      const abort = new AbortController(), cancel = () => abort.abort(), timer = setTimeout(cancel, 30000);
      signal.addEventListener('abort', cancel, { once: true });
      try {
        const response = await fetch(url.href, { credentials: url.origin === location.origin ? 'same-origin' : 'omit', signal: abort.signal });
        if (!response.ok) throw workError(`附件返回 HTTP ${response.status}`);
        if (+response.headers.get('content-length') > 64 * 1024 * 1024) throw workError('附件超过 64 MiB，请在原站单独下载');
        const bytes = new Uint8Array(await response.arrayBuffer());
        if (bytes.length > 64 * 1024 * 1024) throw workError('附件超过 64 MiB，请在原站单独下载');
        return bytes;
      } finally { clearTimeout(timer); signal.removeEventListener('abort', cancel); }
    });
  }
  async function runWork(kind, fn, local = false) {
    if (kind === 'user' || kind === 'planner') syncPageContext();
    if (workJobs.has(kind)) throw workError('此模块已有任务运行，请等待或取消');
    if (!local && !(+user()._id > 0)) throw workError('请先登录 OJ');
    const state = workStates[kind], job = { kind, count: 0, limit: settings.helperRequestLimit,
      delay: settings.helperDelay, owner: +user()._id, domain: domainId(), epoch: routeEpoch, address: location.href, pageName: pageName(), controller: new AbortController() };
    workJobs.set(kind, job); Object.assign(state, { kind, job, running: true, status: '', message: '', errors: [] }); updateWorkProgress(kind);
    try { return await fn(job, state); }
    catch (error) {
      state.status = job.controller.signal.aborted ? '已取消' : '未完成'; state.errors.push(error.message);
      if (!job.controller.signal.aborted) notify(error.message, true);
    } finally {
      state.running = false; state.status ||= state.errors.length ? '完成，存在缺失' : '已完成'; workJobs.delete(kind);
      updateWorkProgress(kind); showWorkErrors(state);
    }
  }
  function showWorkErrors(state) {
    const root = state.root; if (!root?.isConnected) return;
    let area = $(`[data-work-errors="${state.kind}"]`, root);
    if (!area) { area = el('div', { class: 'exhloj-work-errors', role: 'status', 'data-work-errors': state.kind }); root.append(area); }
    area.textContent = (state.errors || []).join('\n');
  }
  function workProgress(root, kind) {
    const row = el('div'); row.append(el('pre', { class: 'exhloj-work-progress', 'data-work-progress': kind, 'aria-live': 'polite' }), button('取消任务', 'work-cancel', { 'data-kind': kind })); root.append(row);
    workStates[kind].root = root; workStates[kind].kind = kind; updateWorkProgress(kind);
  }
  async function listPages(job, path, key, onPage = () => {}) {
    const result = [], signatures = new Set();
    try { for (let number = 1; number <= settings.helperPageLimit; number++) {
      const url = new URL(path, location.origin); url.searchParams.set('page', number);
      const body = await jobJSON(job, url.href), rows = body[key] ?? body.data?.[key];
      if (!Array.isArray(rows)) throw workError(`接口未返回 ${key} 列表`);
      onPage(body);
      if (!rows.length) return result;
      const signature = JSON.stringify(rows.map(row => String(row._id ?? row.docId ?? `${row.uid}/${row.pid}`)));
      if (signatures.has(signature)) throw workError('分页重复，已停止扫描；结果不完整');
      signatures.add(signature); result.push(...rows);
      const pages = Number(body.pageCount ?? body.totalPages ?? body.rpages ?? body.tpages ?? body.upcount ?? body.data?.upcount);
      if (pages > 0 && number >= pages) return result;
      if (number === settings.helperPageLimit) throw Object.assign(workError(`达到 ${number} 页上限；结果不完整`), { rows: result });
    } } catch (error) { error.rows ||= result; throw error; }
    return result;
  }
  function domainList(value) {
    const ids = [...new Set(String(value).split(/[\s,]+/).filter(Boolean))];
    if (!ids.length || ids.some(id => !/^[\p{L}\p{N}_-]{1,80}$/u.test(id))) throw workError('域 ID 格式不正确');
    return ids;
  }
  const seg = value => encodeURIComponent(String(value));
  function contestURL(domain, kind, id, suffix = '') { return `/d/${seg(domain)}/${kind}/${seg(id)}${suffix}`; }
  function alphabet(index) { let text = ''; do { text = String.fromCharCode(65 + index % 26) + text; index = Math.floor(index / 26) - 1; } while (index >= 0); return text; }
  function objectId(value) {
    if (typeof value === 'string') { const id = value.replace(/^ObjectId::/, ''); return /^[\da-f]{24}$/i.test(id) ? id : ''; }
    if (isObject(value)) return objectId(value.$oid || value.rid || value._id || value.raw || '');
    return '';
  }
  function recordTime(record) {
    for (const value of [record.submitAt, record.createdAt, record.timeAt]) {
      if (!value) continue;
      const time = typeof value === 'number' ? (value < 1e11 ? value * 1000 : value) : new Date(value).getTime();
      if (Number.isFinite(time)) return time;
    }
    return core.getTimeByObjectId(objectId(record._id || record.rid))?.getTime() || 0;
  }
  function textOnly(value) { return new DOMParser().parseFromString(String(value ?? ''), 'text/html').body.textContent || ''; }
  function csvField(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
    let text = String(value ?? ''); if (/^[=+@\t\r]|^-\D/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
  }
  function csvContent(headers, rows) { return '\ufeff' + [headers, ...rows].map(row => row.map(csvField).join(',')).join('\r\n'); }
  function safeArchivePath(value) {
    const path = String(value).replace(/\\/g, '/'), parts = path.split('/');
    if (!path || path.startsWith('/') || parts.some(part => !part || part === '.' || part === '..' || /[\x00-\x1f:*?"<>|]/.test(part))) throw workError('附件文件名不合法');
    return path;
  }
  function fileReferences(markdown, pdoc) {
    const names = new Set();
    for (const match of markdown.matchAll(/file:\/\/([^\s)<>"']+)/g)) { try { names.add(decodeURIComponent(match[1])); } catch { names.add(match[1]); } }
    for (const file of Array.isArray(pdoc.additional_file) ? pdoc.additional_file : []) if (typeof file.name === 'string') names.add(file.name);
    return [...names];
  }
  function contestContext() {
    const match = location.pathname.match(/\/((?:contest|homework))\/([^/]+)/), tdoc = current('tdoc');
    return { domain: domainId(), kind: match?.[1] || (pageName().startsWith('homework') ? 'homework' : 'contest'), id: String(match?.[2] || tdoc?.docId || tdoc?._id || '') };
  }
  function contestInput() {
    const form = $('#exhloj-contest-form');
    const domain = domainList(form.elements.domain.value)[0], kind = form.elements.kind.value, id = form.elements.tid.value.trim();
    if (!['contest', 'homework'].includes(kind) || !/^(?:[\da-f]{24}|\d+)$/i.test(id)) throw workError('请输入正确的比赛 / 作业 ID');
    return { domain, kind, id, files: form.elements.files.checked, details: form.elements.details.checked };
  }
  const fileDetailPage = () => /^(contest|homework)_detail$/.test(pageName());
  const validFileName = name => typeof name === 'string' && !!name && !/[\\\x00-\x1f]/.test(name) && name.split('/').every(part => part && part !== '.' && part !== '..');
  function nativeFileSections(target) {
    if (!fileDetailPage()) return [];
    const base = contestURL(target.domain, target.kind, target.id, '/file/'), groups = [];
    for (const fragment of $$('.section > .files:is([data-fragment-id="files"],[data-fragment-id="files-public"],[data-fragment-id="files-private"])')) {
      const section = fragment.parentElement, items = [], rows = $$('tbody tr', fragment);
      if (!section.closest('main,.main')) continue;
      for (const row of rows) {
        const link = $('.col--name a[href]', row), name = row.dataset.filename || link?.textContent.trim();
        if (!link || !validFileName(name)) continue;
        let url; try { url = new URL(link.href); } catch { continue; }
        if (url.origin !== location.origin || !url.pathname.startsWith(base)) continue;
        const suffix = url.pathname.slice(base.length);
        const type = suffix.startsWith('private/') ? 'private' : 'public';
        const tail = suffix.replace(/^(public|private)\//, '');
        try { if (decodeURIComponent(tail) !== name) continue; } catch { continue; }
        items.push({ name, type, href: url.href, size: row.dataset.size, sizeText: $('.col--size', row)?.textContent.trim() });
      }
      // Only fold a standalone download list. Keep forms, extra links and file-management actions on the site.
      const downloads = new Set(items.map(item => item.href));
      const canFold = items.length && items.length === rows.length &&
        [...section.children].every(child => child === fragment || child.matches('.section__header')) &&
        !section.closest('form') && !section.querySelector('form,button,select,textarea,input:not([type="checkbox"]),.section__header a,.section__tools') &&
        $$('a[href]', fragment).every(link => downloads.has(link.href));
      if (items.length) groups.push({ section, items, canFold });
    }
    return groups;
  }
  function syncNativeFileSections() {
    const reachable = settings.contestHelper && ($('#exhloj-title-toggle') || $('.exhloj-local-menu') || typeof GM_registerMenuCommand === 'function');
    const folded = new Set(reachable && fileDetailPage() ? nativeFileSections(contestContext()).filter(group => group.canFold).map(group => group.section) : []);
    for (const section of $$('[data-exh-files-in-helper]')) if (!folded.has(section)) section.removeAttribute('data-exh-files-in-helper');
    for (const section of folded) section.setAttribute('data-exh-files-in-helper', '');
  }
  function mountContestFiles(box, form) {
    const heading = el('h3', { id: 'exhloj-files-heading' }), list = el('ul'), status = el('div', { 'aria-live': 'polite' });
    box.append(heading, list, status);
    let generation = 0, inputKey, controller;
    const epoch = routeEpoch, owner = routeOwner, address = location.href, name = pageName();
    const active = gen => gen === generation && box.closest('dialog')?.open && routeEpoch === epoch &&
      location.href === address && String(user()._id || 0) === owner && pageName() === name;
    function update(onOpen = false) {
      const key = JSON.stringify(['domain', 'kind', 'tid'].map(key => form.elements[key].value));
      if (key === inputKey) return;
      inputKey = key; const gen = ++generation; controller?.abort();
      const label = form.elements.kind.value === 'homework' ? '作业' : '比赛';
      heading.textContent = label + '附件'; list.replaceChildren(); status.replaceChildren();
      let target;
      try { target = contestInput(); } catch { status.textContent = '填写域和有效的比赛 / 作业 ID 后可查看附件。'; return; }
      const context = contestContext(), here = /^(contest|homework)_(detail|scoreboard)$/.test(pageName()) &&
        context.domain === target.domain && context.kind === target.kind && context.id === target.id;
      const groups = here ? nativeFileSections(target) : [];
      const matches = doc => doc && (!doc.docId && !doc._id || String(doc.docId || doc._id) === target.id);
      const local = here && current('tdoc');
      function draw(doc, availablePrivate) {
        const files = new Map();
        const add = item => files.set(item.type + '/' + item.name, item);
        for (const [type, records] of [['public', doc?.files], ['private', target.kind === 'contest' && availablePrivate]]) {
          for (const file of Array.isArray(records) ? records : []) if (validFileName(file?.name))
            add({ name: file.name, size: file.size, type, href: contestURL(target.domain, target.kind, target.id, '/file/' + type + '/' + seg(file.name)) });
        }
        // The site's link wins (including its query string). Never read the unfiltered tdoc.privateFiles.
        for (const group of groups) for (const item of group.items) add(item);
        list.replaceChildren();
        for (const file of files.values()) {
          const li = el('li');
          li.append(el('a', { href: file.href, download: file.name }, file.name), el('small', {}, file.sizeText || niceSize(file.size)));
          list.append(li);
        }
        heading.textContent = label + '附件' + (files.size ? '（' + files.size + '）' : '');
        status.textContent = files.size ? '' : '暂无可下载的附件。';
      }
      function offer(text, action) {
        const btn = el('button', { type: 'button', class: 'exhloj-local-button' }, action);
        btn.addEventListener('click', read); status.replaceChildren(text, btn);
      }
      async function read() {
        if (!active(gen)) return;
        status.textContent = '正在读取附件…';
        try {
          controller = new AbortController();
          const data = here && fileDetailPage() ? await loadPage() : await requestJSON(contestURL(target.domain, target.kind, target.id), { signal: controller.signal });
          if (!active(gen)) return;
          if (!matches(data.tdoc)) throw new Error('未读到这场比赛或作业的信息');
          draw(data.tdoc, data.files);
        } catch (error) { if (active(gen)) offer(error.message + ' ', '重试'); }
      }
      const known = matches(local) && Array.isArray(local.files);
      if (known || groups.length) draw(known ? local : null, matches(local) && fileDetailPage() && current('files'));
      if (known) return;
      if (here && onOpen) read(); else offer('', '查看附件');
    }
    for (const field of ['domain', 'kind', 'tid']) for (const event of ['input', 'change'])
      form.elements[field].addEventListener(event, () => update());
    list.addEventListener('click', event => { if (!active(generation)) event.preventDefault(); });
    box.closest('dialog').addEventListener('close', () => { generation++; controller?.abort(); }, { once: true });
    update(true);
  }
  function openContestHelper() {
    if (!settings.contestHelper) throw workError('请先启用 contest-helper');
    const context = contestContext(), body = modal(context.kind === 'homework' ? '作业助手' : '比赛助手', 'contest'), form = el('form', { id: 'exhloj-contest-form' });
    if (pageName() === 'homework_main' && settings.homeworkPlanner) body.append(button('补题计划', 'homework-plan-open'));
    for (const [name, title, value] of [['domain', '域 ID', context.domain], ['tid', '比赛 / 作业 ID', context.id]]) {
      const label = el('label', {}, title + ' '); label.append(el('input', { type: 'text', name, value, required: true })); form.append(label);
    }
    const kind = el('select', { name: 'kind' }); kind.append(el('option', { value: 'contest' }, '比赛'), el('option', { value: 'homework' }, '作业')); kind.value = context.kind; form.append(kind);
    const files = el('section', { id: 'exhloj-contest-files', 'aria-labelledby': 'exhloj-files-heading' }); form.append(files);
    for (const [name, title, checked] of [['files', '打包题面引用的附件及公开比赛附件', settings.contestFiles], ['details', '提交导出包含时间 / 内存详情（逐条读取）', settings.contestDetails]]) {
      const label = el('label'), input = el('input', { type: 'checkbox', name }); input.checked = checked; label.append(input, title); form.append(label);
    }
    form.append(button('导出题面 ZIP', 'contest-statements'), button('导出提交 CSV', 'contest-records-csv'), button('导出提交 JSON', 'contest-records-json'), button('导出 Ghost', 'contest-ghost'));
    body.append(form); mountContestFiles(files, form); workProgress(body, 'contest');
    body.append(el('h3', {}, '报名工具'), button('自动报名设置', 'panel-attend'), el('p', {}, '检查配置范围内尚未结束、未报名的比赛与作业。'));
    body.append(button('检查待报名', 'attend-preview'), el('div', { id: 'exhloj-attend-results' }));
    workProgress(body, 'auto'); showWorkErrors(workStates.contest); showWorkErrors(workStates.auto);
  }
  async function contestDocument(job, target) {
    const context = contestContext();
    let body = context.domain === target.domain && context.kind === target.kind && context.id === target.id && current('tdoc') ?
      { tdoc: current('tdoc'), pdict: current('pdict') || {}, tsdoc: current('tsdoc') } : await jobJSON(job, contestURL(target.domain, target.kind, target.id));
    if (!body.tdoc || !Array.isArray(body.tdoc.pids)) throw workError('未读取到比赛题目列表，请检查权限');
    return body;
  }
  async function exportContestStatements(target) {
    return runWork('contest', async (job, state) => {
      const body = await contestDocument(job, target), tdoc = body.tdoc;
      if (tdoc.duration && !body.tsdoc?.startAt && +tdoc.owner !== +user()._id) throw workError('请先在原站开始灵活计时比赛，再导出题面');
      const files = [], report = { version: VERSION, title: tdoc.title, target, problems: [], errors: [] };
      for (const [index, pid] of tdoc.pids.entries()) {
        const letter = alphabet(index), record = { id: letter, pid, attachments: [] }; report.problems.push(record);
        try {
          const url = `/d/${seg(target.domain)}/p/${seg(pid)}?tid=${seg(target.id)}`;
          const data = await jobJSON(job, url), pdoc = data.pdoc;
          if (!pdoc || typeof pdoc.content !== 'string' && !isObject(pdoc.content)) throw workError('题面未开放或接口没有返回正文');
          let markdown = markdownContent(pdoc.content);
          if (target.files) {
            const names = fileReferences(markdown, pdoc), safe = [];
            for (const name of names) { try { safe.push({ name, path: safeArchivePath(name) }); } catch (error) { report.errors.push(`${letter}/${name}: ${error.message}`); } }
            if (safe.length) {
              let links = {};
              try {
                const response = await jobJSON(job, `/d/${seg(target.domain)}/p/${seg(pid)}/files?tid=${seg(target.id)}`, postOptions({ operation: 'get_links', type: 'additional_file', files: safe.map(x => x.name) }));
                links = response.links || {};
              } catch (error) { if (job.controller.signal.aborted || error.budget) throw error; report.errors.push(`${letter} 附件链接: ${error.message}`); }
              for (const file of safe) {
                try {
                  const link = links[file.name]; if (!link) throw workError('未返回附件链接');
                  files.push({ name: `${letter}/files/${file.path}`, bytes: await jobBytes(job, link, file.name) }); record.attachments.push(file.name);
                  for (const token of [file.name, encodeURI(file.name), encodeURIComponent(file.name)]) markdown = markdown.split('file://' + token).join('files/' + file.path.split('/').map(seg).join('/'));
                } catch (error) { if (job.controller.signal.aborted || error.budget) throw error; report.errors.push(`${letter}/${file.name}: ${error.message}`); }
              }
            }
          }
          const config = isObject(pdoc.config) ? pdoc.config : {};
          files.push({ name: `${letter}/statement.md`, content: `# ${pdoc.title || letter}\n\nTime: ${config.timeMax ?? '?'} ms\nMemory: ${config.memoryMax ?? '?'} MiB\n\n${markdown}` }); record.title = pdoc.title;
        } catch (error) {
          if (job.controller.signal.aborted || error.budget) throw error;
          report.errors.push(`${letter}: ${error.message}`); files.push({ name: `${letter}/ERROR.txt`, content: error.message });
        }
      }
      if (target.files && target.kind === 'contest') for (const file of Array.isArray(tdoc.files) ? tdoc.files : []) {
        try {
          const name = safeArchivePath(file.name);
          files.push({ name: `attachments/${name}`, bytes: await jobBytes(job, contestURL(target.domain, target.kind, target.id, `/file/public/${seg(file.name)}`), file.name) });
        } catch (error) { if (job.controller.signal.aborted || error.budget) throw error; report.errors.push(`比赛附件 ${file.name}: ${error.message}`); }
      }
      report.complete = !report.errors.length; state.errors.push(...report.errors); report.exportedAt = new Date().toISOString();
      files.push({ name: 'REPORT.json', content: JSON.stringify(report, null, 2) });
      download(`contest-${target.id}.zip`, zipContent(files), 'application/zip'); state.message = `已打包 ${tdoc.pids.length} 道题；缺失项目 ${report.errors.length}，详见 REPORT.json`;
    });
  }
  async function collectContestRecords(job, target) {
    const body = await contestDocument(job, target), tdoc = body.tdoc, users = {}, problems = tdoc.pids.map((pid, i) => ({ id: alphabet(i), pid, title: body.pdict?.[pid]?.title || '', fullScore: tdoc.score?.[pid] || 100 }));
    const rows = await listPages(job, `/d/${seg(target.domain)}/record?tid=${seg(target.id)}`, 'rdocs', page => Object.assign(users, page.udict || {}));
    const unique = new Map();
    for (let record of rows) {
      const rid = objectId(record._id); if (!rid || unique.has(rid)) continue;
      let detail = {};
      if (target.details) { const response = await jobJSON(job, `/d/${seg(target.domain)}/record/${seg(rid)}`); detail = response; record = { ...record, ...response.rdoc }; }
      const problem = problems.find(p => String(p.pid) === String(record.pid ?? detail.pdoc?.docId)); if (!problem) continue;
      if (detail.udoc) users[record.uid] = detail.udoc;
      const cases = Array.isArray(record.testCases) ? record.testCases : [];
      const at = recordTime(record), begin = new Date(tdoc.beginAt).getTime();
      unique.set(rid, { rid, uid: record.uid, submitter: String(users[record.uid]?.uname || `User ${record.uid}`), problem: problem.id, pid: problem.pid,
        score: record.score ?? '', status: Number(record.status), verdict: VERDICTS[record.status] || `Status ${record.status}`,
        submitTime: at, elapsed: Number.isFinite(begin) && at ? at - begin : null,
        codeSize: typeof record.code === 'string' ? record.code.length : record.length ?? null,
        maxTime: cases.length ? Math.max(0, ...cases.map(x => +x.time || 0)) : record.time ?? null,
        maxMemory: cases.length ? Math.max(0, ...cases.map(x => +x.memory || 0)) : record.memory ?? null,
        judgedCases: cases.length ? cases.filter(x => ![0, 9, 20, 21].includes(+x.status)).length : null });
    }
    return { version: VERSION, target, title: tdoc.title || target.id, beginAt: tdoc.beginAt, endAt: tdoc.endAt, problems, records: [...unique.values()].sort((a, b) => a.submitTime - b.submitTime || a.rid.localeCompare(b.rid)) };
  }
  function ghostText(data) {
    const clean = value => String(value ?? '').replace(/[\r\n,"\t]/g, ' '), teams = [...new Set(data.records.map(x => String(x.uid)))];
    const minutes = Math.max(0, Math.round((new Date(data.endAt) - new Date(data.beginAt)) / 60000)) || 0;
    return [`@contest "${clean(data.title)}"`, `@contlen ${minutes}`, `@problems ${data.problems.length}`, `@teams ${teams.length}`, `@submissions ${data.records.length}`,
      ...data.problems.map(p => `@p ${p.id},${clean(p.title)},20,0`), ...teams.map((uid, i) => `@t ${i + 1},0,1,${clean(data.records.find(r => String(r.uid) === uid).submitter)}`),
      ...data.records.map(r => `@s ${teams.indexOf(String(r.uid)) + 1},${r.problem},0,${Math.max(0, Math.ceil((r.elapsed || 0) / 1000))},${r.status === 1 ? 'AC' : 'RJ'},${r.score}`)].join('\n') + '\n';
  }
  async function exportContestRecords(target, format) {
    return runWork('contest', async (job, state) => {
      const data = await collectContestRecords(job, target); state.result = data;
      if (format === 'json') download(`contest-${target.id}-records.json`, JSON.stringify(data, null, 2));
      else if (format === 'ghost') download(`contest-${target.id}.ghost`, ghostText(data), 'text/plain;charset=utf-8');
      else download(`contest-${target.id}-records.csv`, csvContent(['submitter', 'uid', 'problem', 'pid', 'score', 'status', 'submitTime', 'elapsedMs', 'codeSize', 'maxTimeMs', 'maxMemoryKiB', 'judgedCases'],
        data.records.map(r => [r.submitter, r.uid, r.problem, r.pid, r.score, r.verdict, r.submitTime ? new Date(r.submitTime).toISOString() : '', r.elapsed, r.codeSize, r.maxTime, r.maxMemory, r.judgedCases])), 'text/csv;charset=utf-8');
      state.message = `已导出 ${data.records.length} 次提交，${data.problems.length} 道题`;
    });
  }
  function attendTargets() {
    const targets = [];
    for (const line of settings.autoAttendTargets.split(/[\s,]+/).filter(Boolean)) {
      const [domain, kind, extra] = line.split('/');
      domainList(domain);
      if (extra || !['contest', 'homework'].includes(kind)) throw workError('报名目标格式应为 域ID/contest 或 域ID/homework');
      if (!targets.some(t => t.domain === domain && t.kind === kind)) targets.push({ domain, kind });
    }
    if (!targets.length) throw workError('请先在设置中填写报名目标');
    return targets;
  }
  async function findAttendCandidates(job) {
    const results = [], known = stored(ATTEND_KEY, {}), rules = settings.autoAttendRules.split(/[\s,]+/).filter(Boolean);
    for (const target of attendTargets()) {
      const statuses = {}, docs = await listPages(job, `/d/${seg(target.domain)}/${target.kind}`, 'tdocs', page => Object.assign(statuses, page.tsdict || {}));
      for (const tdoc of docs) {
        const id = String(tdoc.docId || tdoc._id || ''), key = `${target.domain}/${target.kind}/${id}`, end = new Date(tdoc.endAt).getTime();
        if (!id || !Number.isFinite(end) || end <= Date.now() || (settings.autoAttendTitle && !String(tdoc.title).includes(settings.autoAttendTitle)) || (rules.length && !rules.includes(tdoc.rule))) continue;
        if (known[key] || statuses[id]?.attend === 1) continue;
        const detail = await jobJSON(job, contestURL(target.domain, target.kind, id));
        if (detail.tsdoc?.attend || +detail.tdoc?.owner === +user()._id) continue;
        results.push({ ...target, id, key, title: String(tdoc.title || id), endAt: end });
      }
    }
    return results;
  }
  async function attendOne(job, candidate) {
    await jobJSON(job, contestURL(candidate.domain, candidate.kind, candidate.id), postOptions({ operation: 'attend' }));
    const known = stored(ATTEND_KEY, {}), next = {};
    if (isObject(known)) for (const [key, end] of Object.entries(known)) if (end > Date.now()) next[key] = end;
    next[candidate.key] = candidate.endAt; save(ATTEND_KEY, next);
  }
  function renderAttendCandidates() {
    const box = $('#exhloj-attend-results'); if (!box) return;
    const list = workStates.auto.candidates || []; box.replaceChildren(el('p', {}, `待报名 ${list.length} 项`));
    list.forEach((item, index) => { const row = el('p'); row.append(el('a', { href: contestURL(item.domain, item.kind, item.id), target: '_blank', rel: 'noopener noreferrer' }, `${item.domain} · ${item.title}`), button('报名', 'attend-one', { 'data-index': index })); box.append(row); });
  }
  async function checkAttendance(automatic = false) {
    return runWork('auto', async (job, state) => {
      state.candidates = []; renderAttendCandidates();
      state.candidates = await findAttendCandidates(job); renderAttendCandidates();
      if (automatic) {
        for (const item of state.candidates) {
          if (!settings.autoAttend || !settings.contestHelper) break;
          await attendOne(job, item);
        }
        state.message = `自动报名处理 ${state.candidates.length} 项`; state.candidates = []; renderAttendCandidates();
      } else state.message = `检查完成，待报名 ${state.candidates.length} 项`;
    });
  }
  let autoTimer, autoSignature = '';
  function configureAutoAttend() {
    const signature = JSON.stringify([settings.contestHelper, settings.autoAttend, settings.autoAttendTargets, settings.autoAttendTitle, settings.autoAttendRules, settings.autoAttendInterval, user()._id]);
    if (signature === autoSignature) return;
    autoSignature = signature; clearTimeout(autoTimer); workJobs.get('auto')?.controller.abort();
    if (!settings.contestHelper || !settings.autoAttend || !(+user()._id > 0) || !settings.autoAttendTargets) return;
    const tick = async () => {
      if (signature !== autoSignature) return;
      const last = stored('exhloj.local.autoAttend.lastRun', 0), gap = settings.autoAttendInterval * 1000;
      if (Date.now() - last >= gap && !workJobs.has('auto')) {
        save('exhloj.local.autoAttend.lastRun', Date.now()); await task(() => checkAttendance(true));
      }
      if (signature === autoSignature) autoTimer = setTimeout(tick, gap);
    };
    autoTimer = setTimeout(tick, 300);
  }

  // 榜单按原始 score（100 分制）判断满分，不能把列中最高的部分分当作 AC。
  function boardAccepts(cell, rule, fullScore) {
    if (!cell) return [];
    if (cell.type === 'records' && Array.isArray(cell.raw)) return cell.raw.flatMap(part => boardAccepts({ ...part, type: 'record' }, rule, fullScore));
    const raw = cell.raw;
    const explicit = isObject(raw) ? raw.status : undefined;
    let accepted;
    if (explicit !== undefined) accepted = +explicit === 1;
    else if (cell.score !== undefined && cell.score !== null) accepted = Number(cell.score) >= 100;
    else if (rule === 'acm') accepted = /icon-check/.test(String(cell.value)) || /^\+\d*(?:\s|$)/.test(textOnly(cell.value).trim());
    else accepted = /^\d+(?:\.\d+)?(?:\s|\(|$)/.test(textOnly(cell.value).trim()) && parseFloat(textOnly(cell.value)) >= fullScore;
    return accepted ? [{ time: recordTime({ _id: objectId(raw) }), rid: objectId(raw) }] : [];
  }
  function acceptedBoard(body, domain, onAccept, onName) {
    const rows = body.rows; if (!Array.isArray(rows)) throw workError('榜单没有返回 rows，可能无权访问');
    const header = rows.find(row => Array.isArray(row) && row.some(cell => cell?.type === 'problem'));
    if (!header) { if (rows.length > 1 && body.tdoc?.pids?.length) throw workError('无法识别榜单题目列'); return; }
    const columns = header.map((cell, index) => ({ cell, index })).filter(x => x.cell?.type === 'problem');
    for (const row of rows) {
      if (row === header || !Array.isArray(row)) continue;
      const u = row.find(cell => cell?.type === 'user'), uid = Number(u?.raw);
      if (!Number.isSafeInteger(uid) || uid <= 0) continue;
      onName(uid, String(body.udict?.[uid]?.uname || textOnly(u.value) || `User ${uid}`));
      for (const { cell, index } of columns) {
        const pid = isObject(cell.raw) ? cell.raw.docId ?? cell.raw.pid : cell.raw;
        if (pid === undefined || pid === null) continue;
        for (const evidence of boardAccepts(row[index], body.tdoc?.rule, Number(body.tdoc?.score?.[pid]) || 100)) onAccept(uid, domain, pid, evidence.time);
      }
    }
  }
  function monitorFormSettings() {
    const form = $('#exhloj-juan-form'), domains = domainList(form.elements.domains.value);
    return { domains, records: form.elements.records.checked, contests: form.elements.contests.checked, homeworks: form.elements.homeworks.checked, period: +form.elements.period.value };
  }
  function openJuanMonitor() {
    if (!settings.juanMonitor) throw workError('请先启用 juan-monitor');
    const body = modal('卷王监视器', 'juan'), form = el('form', { id: 'exhloj-juan-form' });
    body.append(el('p', {}, '同一用户在同一域通过同一道题只计一次。区间 AC 按可见提交时间去重；缺少时间的榜单成绩仅计入累计。'));
    const label = el('label', {}, '训练域 ID（每行一个）'), domains = el('textarea', { name: 'domains' }); domains.value = settings.juanDomains || domainId(); label.append(domains); form.append(label, button('读取可访问域', 'juan-domains'), el('div', { id: 'exhloj-juan-domains' }));
    for (const [name, text, checked] of [['records', '公开 AC 提交', settings.juanRecords], ['contests', '比赛榜单', settings.juanContests], ['homeworks', '作业榜单', settings.juanHomeworks]]) {
      const label = el('label'), input = el('input', { type: 'checkbox', name }); input.checked = checked; label.append(input, text); form.append(label);
    }
    const period = el('select', { name: 'period' });
    for (const [days, text] of [[0.25, '6 小时'], [1, '1 天'], [3, '3 天'], [7, '7 天'], [30, '30 天'], [90, '90 天'], [365, '1 年']]) period.append(el('option', { value: days }, text));
    period.value = String(settings.juanPeriod); form.append(el('span', {}, '近期范围 '), period, button('开始统计', 'juan-start'));
    body.append(form); workProgress(body, 'juan');
    body.append(button('导出 CSV', 'juan-csv'), button('导出 JSON', 'juan-json'), button('复制榜单', 'juan-copy'), el('div', { class: 'exhloj-work-results', id: 'exhloj-juan-results' }));
    renderJuanResults(); showWorkErrors(workStates.juan);
  }
  function renderJuanResults() {
    const box = $('#exhloj-juan-results'), state = workStates.juan; if (!box || !state.result) return;
    const result = state.result;
    box.replaceChildren(el('p', {}, `${result.complete ? '扫描完成' : '部分结果（不保存快照）'} · ${result.rows.length} 名用户 · ${result.period} 天内 AC · 无时间证据 ${result.unknownTime} 项`));
    box.append(el('p', {}, result.baseline ? `新增列与 ${new Date(result.baseline).toLocaleString()} 的相同范围快照比较` : '暂无可比较的完整快照，新增列显示 —'));
    const table = el('table'), head = el('tr'); for (const title of ['排名', '用户', '累计 AC', '区间 AC', '较上次新增']) head.append(el('th', {}, title)); table.append(head);
    result.rows.slice(0, 100).forEach((row, index) => {
      const tr = el('tr'), who = el('td'); who.append(el('a', { href: `/user/${row.uid}`, target: '_blank', rel: 'noopener noreferrer' }, `${row.name} (${row.uid})`));
      tr.append(el('td', {}, index + 1), who, el('td', {}, row.total), el('td', {}, row.recent), el('td', {}, row.added ?? '—')); table.append(tr);
    }); box.append(table);
  }
  async function scanJuan(config) {
    if (!config.records && !config.contests && !config.homeworks) throw workError('请至少选择一种统计来源');
    settings.juanDomains = config.domains.join('\n'); settings.juanRecords = config.records; settings.juanContests = config.contests; settings.juanHomeworks = config.homeworks; settings.juanPeriod = config.period; save(SETTINGS_KEY, settings);
    return runWork('juan', async (job, state) => {
      state.result = undefined; const users = new Map(), now = Date.now(), cutoff = now - config.period * 86400000;
      const get = uid => { if (!users.has(uid)) users.set(uid, { uid, name: `User ${uid}`, solved: new Map() }); return users.get(uid); };
      const name = (uid, value) => { if (+uid > 0 && value) get(+uid).name = String(value); };
      const accept = (uid, domain, pid, time) => {
        uid = +uid; if (!Number.isSafeInteger(uid) || uid <= 0 || pid === undefined || pid === null) return;
        const solved = get(uid).solved, key = `${domain}/${pid}`; solved.set(key, Math.max(solved.get(key) || 0, time > 0 && time <= now + 60000 ? time : 0));
      };
      const ingestRecords = (rows, domain) => { for (const r of rows) if (+r.status === 1) accept(r.uid, domain, r.pid, recordTime(r)); };
      const fail = (label, error) => { if (job.controller.signal.aborted || error.budget) throw error; state.errors.push(`${label}: ${error.message}`); };
      try { for (const domain of config.domains) {
        if (config.records) {
          try { ingestRecords(await listPages(job, `/d/${seg(domain)}/record?status=1`, 'rdocs', page => { for (const [uid, u] of Object.entries(page.udict || {})) name(uid, u.uname); }), domain); }
          catch (error) { if (error.rows) ingestRecords(error.rows, domain); fail(`${domain} 提交`, error); }
        }
        for (const [kind, enabled] of [['contest', config.contests], ['homework', config.homeworks]]) {
          if (!enabled) continue; let docs = [];
          try { docs = await listPages(job, `/d/${seg(domain)}/${kind}`, 'tdocs'); }
          catch (error) { docs = error.rows || []; fail(`${domain}/${kind} 列表`, error); }
          const seen = new Set();
          for (const doc of docs) {
            const id = String(doc.docId || doc._id || ''); if (!id || seen.has(id)) continue; seen.add(id);
            try { acceptedBoard(await jobJSON(job, contestURL(domain, kind, id, '/scoreboard')), domain, accept, name); }
            catch (error) { fail(`${domain}/${kind}/${id}`, error); }
          }
        }
      } } catch (error) { state.errors.push(error.message); state.status = job.controller.signal.aborted ? '已取消' : '未完成'; }
      const complete = !state.errors.length, scope = JSON.stringify([+user()._id, [...config.domains].sort(), config.records, config.contests, config.homeworks]);
      const snapshots = stored(SNAPSHOT_KEY, {}), prior = isObject(snapshots) ? snapshots[scope] : undefined;
      const baseline = complete && isObject(prior?.solved) ? prior : null;
      let unknownTime = 0;
      const rows = [...users.values()].filter(u => u.solved.size).map(u => {
        const before = new Set(baseline?.solved?.[u.uid] || []), keys = [...u.solved.keys()]; unknownTime += [...u.solved.values()].filter(time => !time).length;
        return { uid: u.uid, name: u.name, total: keys.length, recent: [...u.solved.values()].filter(time => time >= cutoff).length, added: baseline ? keys.filter(key => !before.has(key)).length : null };
      }).sort((a, b) => b.recent - a.recent || b.total - a.total || a.uid - b.uid);
      state.result = { version: VERSION, generatedAt: now, config, period: config.period, complete, baseline: baseline?.time || null, unknownTime, rows, errors: state.errors };
      if (complete) {
        const saved = { time: now, solved: Object.fromEntries([...users.values()].filter(u => u.solved.size).map(u => [u.uid, [...u.solved.keys()].sort()])),
          history: [...(Array.isArray(prior?.history) ? prior.history : []).slice(-30), { time: now, counts: Object.fromEntries(rows.map(r => [r.uid, r.total])) }] };
        const entries = Object.entries(isObject(snapshots) ? snapshots : {}).filter(([key]) => key !== scope).sort((a, b) => (a[1]?.time || 0) - (b[1]?.time || 0)).slice(-4);
        const next = { ...Object.fromEntries(entries), [scope]: saved };
        if (JSON.stringify(next).length <= 8 * 1024 * 1024) save(SNAPSHOT_KEY, next);
        else state.errors.push('结果过大，本次快照未保存');
      }
      state.message = `统计 ${rows.length} 名用户；按区间 AC 排序，同题同域去重`; renderJuanResults();
      try { if (page.UiContext?.exhloj) page.UiContext.exhloj['juan-monitor'] = state.result; } catch {}
    });
  }
  function juanResult() { const result = workStates.juan.result; if (!result) throw workError('请先完成一次统计'); return result; }


  // user：所有资料编辑和 Rating 结算均在本机完成，不设置指定 UID 的编辑门槛。
  const USER_INITIAL_RATING = 1800;
  const USER_DISPLAY_MODES = [['no-change', '不更改'], ['display-realname', '显示姓名'], ['display-realname-color', '姓名及颜色'],
    ['display-username', '显示用户名'], ['display-username-color', '用户名及颜色'], ['display-username-realname', '姓名（用户名）'], ['display-username-realname-color', '姓名（用户名）及颜色']];
  let userMemo, userMemoSignature, userMemoRaw, userLoadError = '';
  const userNameNodes = new Map();
  function localUid(value) { const uid = Number(value); if (!Number.isSafeInteger(uid) || uid <= 0) throw workError('用户 ID 必须为正整数'); return uid; }
  function localNumber(value, label, min = 0, max = 1e9) {
    const n = Number(value); if (!Number.isFinite(n) || n < min || n > max) throw workError(`${label} 应在 ${min}–${max} 之间`); return n;
  }
  function localText(value, max = 500) { return typeof value === 'string' ? value.slice(0, max) : ''; }
  function normalizeUserData(value = {}) {
    if (!isObject(value)) throw workError('用户资料必须是对象');
    const result = { oiers: {}, teachers: [], practice: {} };
    if (value.oiers !== undefined && !isObject(value.oiers) && !Array.isArray(value.oiers)) throw workError('oiers 必须为用户 ID 映射');
    for (const [key, item] of Object.entries(value.oiers || {})) {
      if (item === null) continue; const uid = localUid(key);
      if (!isObject(item)) throw workError(`用户 ${uid} 的资料必须是对象`);
      const data = { name: localText(item.name, 120), uname: localText(item.uname, 120), oierId: localNumber(item.oierId || 0, 'OIerDB ID'),
        level: localNumber(item.level || 0, 'CCF 级别', 0, 10), grade: localNumber(item.grade || 0, '高中毕业年份', 0, 3000), records: [] };
      for (const key of ['oierId', 'level', 'grade']) if (!Number.isInteger(data[key])) throw workError(`${key} 必须为整数`);
      for (const key of ['oierRank', 'oierScore']) if (item[key] !== undefined) {
        data[key] = localNumber(item[key], key, key === 'oierRank' ? 1 : 0, 1e12);
        if (key === 'oierRank' && !Number.isInteger(data[key])) throw workError('OIerDb 排名必须为整数');
      }
      if (item.oierSyncedAt !== undefined) data.oierSyncedAt = localNumber(item.oierSyncedAt, 'OIerDb 更新时间', 0, 1e15);
      if (item.oierVersion !== undefined) {
        if (typeof item.oierVersion !== 'string' || !/^[a-f\d]{7}\/[a-f\d]{7}$/.test(item.oierVersion)) throw workError('OIerDb 数据版本格式无效');
        data.oierVersion = item.oierVersion;
      }
      if (item.records !== undefined && !Array.isArray(item.records)) throw workError(`用户 ${uid} 的获奖记录必须是数组`);
      if ((item.records?.length || 0) > 200) throw workError('每人至多 200 条获奖记录');
      data.records = (item.records || []).map(record => {
        if (!isObject(record)) throw workError('获奖记录必须为对象');
        const item = { contest: localText(record.contest, 250), awards: localText(record.awards, 120), score: record.score === '' || record.score === undefined ? '' : localNumber(record.score, '获奖分数', -1e6, 1e9) };
        for (const key of ['fullScore', 'rank', 'participants', 'contestId', 'schoolId']) if (record[key] !== undefined) {
          item[key] = localNumber(record[key], key, ['fullScore', 'contestId', 'schoolId'].includes(key) ? 0 : 1);
          if (key !== 'fullScore' && !Number.isInteger(item[key])) throw workError(`${key} 必须为整数`);
        }
        for (const key of ['province', 'school', 'grade']) if (record[key] !== undefined) item[key] = localText(record[key], 250);
        return item;
      }); result.oiers[uid] = data;
    }
    if (value.teachers !== undefined && !Array.isArray(value.teachers)) throw workError('teachers 必须为用户 ID 数组');
    result.teachers = [...new Set((value.teachers || []).map(localUid))];
    if (value.practice !== undefined && !isObject(value.practice)) throw workError('practice 必须为用户 ID 映射');
    for (const [uid, score] of Object.entries(value.practice || {})) result.practice[localUid(uid)] = localNumber(score, '题目分');
    return result;
  }
  function normalizeUserRatings(value = {}) {
    if (!isObject(value) || value.contests !== undefined && !Array.isArray(value.contests) || value.records !== undefined && !Array.isArray(value.records)) throw workError('Rating 数据应包含 contests 和 records 数组');
    const contests = (value.contests || []).map(row => {
      if (!Array.isArray(row) || row.length < 3 || typeof row[0] !== 'string' || !row[0].trim()) throw workError('比赛信息格式应为 [比赛路径, 标题, 权重]');
      return [row[0].trim().slice(0, 250), localText(row[1], 250), localNumber(row[2], 'Rating 权重', 0, 10)];
    });
    if (new Set(contests.map(row => row[0])).size !== contests.length) throw workError('Rated 比赛路径不能重复');
    const seen = new Set(), records = (value.records || []).map(row => {
      if (!Array.isArray(row) || row.length < 5) throw workError('Rating 记录格式应为 [UID, 比赛下标, 排名, 新 Rating, 表现分]');
      const uid = localUid(row[0]), index = Number(row[1]), rank = Number(row[2]);
      if (!Number.isInteger(index) || index < 0 || index >= contests.length || !Number.isInteger(rank) || rank <= 0) throw workError('Rating 记录的比赛下标或排名无效');
      const key = `${uid}/${index}`; if (seen.has(key)) throw workError('同一比赛中同一用户的 Rating 记录重复'); seen.add(key);
      return [uid, index, rank, localNumber(row[3], 'Rating', -1e6, 1e6), localNumber(row[4], '表现分', -1e6, 1e6)];
    });
    return { contests, records, commands: localText(value.commands, 200000) };
  }
  function userStore() {
    let raw; try { raw = GM_getValue(CACHE_KEY, null); } catch {}
    if (typeof raw === 'string' && raw === userMemoRaw && userMemo) return userMemo;
    userMemoRaw = typeof raw === 'string' ? raw : undefined;
    const cache = cacheObject(), signature = JSON.stringify([cache['exhloj.user'], cache['exhloj.ratedcontests']]);
    if (userMemo && userMemoSignature === signature) return userMemo;
    userMemoSignature = signature; userLoadError = '';
    let users, ratings; const errors = [];
    try { users = normalizeUserData(cache['exhloj.user']); }
    catch (error) { errors.push(`用户资料：${error.message}`); users = normalizeUserData(); }
    try { ratings = normalizeUserRatings(cache['exhloj.ratedcontests']); }
    catch (error) { errors.push(`Rating：${error.message}`); ratings = normalizeUserRatings(); }
    userLoadError = errors.join('；');
    const histories = new Map(), byContest = new Map();
    for (const row of ratings.records) {
      const [uid, index, rank, rating, performance] = row, history = histories.get(uid) || [];
      const record = { uid, index, rank, rating, performance, old: history.at(-1)?.rating ?? USER_INITIAL_RATING };
      history.push(record); histories.set(uid, history); byContest.set(`${index}/${uid}`, record);
    }
    return userMemo = { users, ratings, histories, byContest };
  }
  function writeUserStore(users, ratings, repair = false) {
    const nextUsers = normalizeUserData(users), nextRatings = normalizeUserRatings(ratings), cache = cacheObject();
    if (!repair) {
      try { normalizeUserData(cache['exhloj.user']); normalizeUserRatings(cache['exhloj.ratedcontests']); }
      catch (error) { throw workError(`本地数据格式异常，未保存：${error.message}。请在资料 JSON 工具中明确修复异常部分。`); }
    }
    cache['exhloj.user'] = nextUsers; cache['exhloj.ratedcontests'] = nextRatings; cache['exhloj.userStoreVersion'] = Date.now();
    if (new Blob([JSON.stringify(cache)]).size > LIMIT - 32768) throw workError('本地用户资料过大，请减少获奖记录或比赛数量');
    save(CACHE_KEY, cache); userMemoSignature = userMemoRaw = undefined; refreshUserModule();
  }
  function userRating(uid) { return userStore().histories.get(+uid)?.at(-1)?.rating ?? USER_INITIAL_RATING; }
  function userLevel(rating) { const thresholds = [0, 0, 1200, 1400, 1600, 1900, 2100, 2400, 3000, 4000, 5000]; let level = 1; while (level < 10 && rating >= thresholds[level + 1]) level++; return level; }
  function ratingNode(rating) { return el('span', { class: `exhloj-user-rating exhloj-user-level-${userLevel(rating)}` }, rating); }
  function localUserName(uid) { return userStore().users.oiers[uid]?.uname || current('udict')?.[uid]?.uname || (+current('udoc')?._id === +uid ? current('udoc').uname : '') || `User ${uid}`; }
  function localUserLink(uid) { return el('a', { href: `/user/${uid}`, 'data-exh-user': uid }, localUserName(uid)); }
  function uidFromNode(node) {
    if (node.dataset.exhUser) return +node.dataset.exhUser;
    if (!node.getAttribute('href')) return node.classList.contains('user-profile-name') ? +current('udoc')?._id : 0;
    try { const url = new URL(node.getAttribute('href'), location.origin); return url.origin === location.origin ? +(url.pathname.match(/\/user\/(\d+)\/?$/)?.[1] || 0) : 0; } catch { return 0; }
  }
  function resetUserName(node, state) {
    if (state.applied === node.innerHTML) node.replaceChildren(...state.nodes);
    node.classList.remove('exhloj-user-name', ...Array.from({ length: 10 }, (_, i) => `exhloj-user-level-${i + 1}`), 'exhloj-user-level-teacher');
    node.removeAttribute('data-exh-user-rendered');
  }
  function ccfBadge(level) {
    const badge = el('span', { class: `exhloj-user-ccf exhloj-user-ccf-${level <= 5 ? 'green' : level <= 7 ? 'blue' : 'gold'}`, title: `本地资料：CCF ${level} 级`, 'aria-label': `CCF ${level} 级` });
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 16 16'); svg.setAttribute('width', '16'); svg.setAttribute('height', '16'); svg.setAttribute('aria-hidden', 'true'); svg.setAttribute('focusable', 'false');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', 'M16 8C16 6.84375 15.25 5.84375 14.1875 5.4375C14.6562 4.4375 14.4688 3.1875 13.6562 2.34375C12.8125 1.53125 11.5625 1.34375 10.5625 1.8125C10.1562 0.75 9.15625 0 8 0C6.8125 0 5.8125 0.75 5.40625 1.8125C4.40625 1.34375 3.15625 1.53125 2.34375 2.34375C1.5 3.1875 1.3125 4.4375 1.78125 5.4375C0.71875 5.84375 0 6.84375 0 8C0 9.1875 0.71875 10.1875 1.78125 10.5938C1.3125 11.5938 1.5 12.8438 2.34375 13.6562C3.15625 14.5 4.40625 14.6875 5.40625 14.2188C5.8125 15.2812 6.8125 16 8 16C9.15625 16 10.1562 15.2812 10.5625 14.2188C11.5938 14.6875 12.8125 14.5 13.6562 13.6562C14.4688 12.8438 14.6562 11.5938 14.1875 10.5938C15.25 10.1875 16 9.1875 16 8ZM11.4688 6.625L7.375 10.6875C7.21875 10.8438 7 10.8125 6.875 10.6875L4.5 8.3125C4.375 8.1875 4.375 7.96875 4.5 7.8125L5.3125 7C5.46875 6.875 5.6875 6.875 5.8125 7.03125L7.125 8.34375L10.1562 5.34375C10.3125 5.1875 10.5312 5.1875 10.6562 5.34375L11.4688 6.15625C11.5938 6.28125 11.5938 6.5 11.4688 6.625Z');
    svg.append(path); badge.append(svg); return badge;
  }
  function refreshUserNames() {
    const store = userStore();
    for (const [node, state] of userNameNodes) if (!node.isConnected) userNameNodes.delete(node);
    if (!settings.userModule) { for (const [node, state] of userNameNodes) resetUserName(node, state); userNameNodes.clear(); return; }
    const candidates = $$('.user-profile-name, .col--submit-by>a, .col--user a[href], a.username[href], a[data-exh-user]')
      .filter(node => !node.closest('#exhloj-local-dialog, #exhloj-local-user-card, .user-profile-badge') && !$('.user-profile-name', node)
        && (node.matches('.user-profile-name, a.username, a[data-exh-user]') || node.textContent.trim()));
    const active = new Set(candidates);
    for (const [node, state] of userNameNodes) if (!active.has(node)) { resetUserName(node, state); userNameNodes.delete(node); }
    for (const node of candidates) {
      const uid = uidFromNode(node); if (!(uid > 0)) continue;
      let state = userNameNodes.get(node);
      if (!state || node.innerHTML !== state.applied) {
        for (const badge of $$(':scope > .exhloj-user-ccf', node)) badge.remove();
        if (state) { node.classList.remove('exhloj-user-name', ...Array.from({ length: 10 }, (_, i) => `exhloj-user-level-${i + 1}`), 'exhloj-user-level-teacher'); }
        const text = node.textContent.trim(), known = current('udict')?.[uid]?.uname || (+current('udoc')?._id === uid ? current('udoc').uname : '');
        state = { nodes: [...node.childNodes], text, uname: known || text.match(/\(([^()]*)\)\s*$/)?.[1] || text, applied: node.innerHTML }; userNameNodes.set(node, state);
      }
      const profile = store.users.oiers[uid], mode = settings.userDisplay, uname = profile?.uname || state.uname || `User ${uid}`, name = profile?.name || uname;
      const text = mode === 'no-change' ? state.text : mode.includes('username-realname') ? (profile?.name ? `${name} (${uname})` : uname) : mode.includes('realname') ? name : uname;
      const level = store.users.teachers.includes(uid) ? 'teacher' : userLevel(userRating(uid));
      const signature = JSON.stringify([uid, text, mode, settings.userCCF && profile?.level, level]);
      if (node.dataset.exhUserRendered === signature && node.innerHTML === state.applied) continue;
      if (mode === 'no-change') node.replaceChildren(...state.nodes); else node.textContent = text;
      node.classList.remove('exhloj-user-name', ...Array.from({ length: 10 }, (_, i) => `exhloj-user-level-${i + 1}`), 'exhloj-user-level-teacher');
      if (mode.endsWith('-color')) node.classList.add('exhloj-user-name', `exhloj-user-level-${level}`);
      if (settings.userCCF && profile?.level >= 3) node.append(ccfBadge(profile.level));
      node.dataset.exhUserRendered = signature; state.applied = node.innerHTML;
    }
  }
  function userProfileId() { return +(location.pathname.match(/\/user\/(\d+)/)?.[1] || 0) || +current('udoc')?._id; }
  function profileGrade(grade) {
    if (!grade) return '未填写'; const date = new Date(), year = date.getFullYear(), offset = grade - year + (date.getMonth() < 8 ? 1 : 0);
    return ({ 1: '高三', 2: '高二', 3: '高一', 4: '初三', 5: '初二', 6: '初一', 7: '六年级', 8: '五年级', 9: '四年级', 10: '三年级' })[offset] || (offset <= 0 ? `高中毕业 ${1 - offset} 年` : '未到对应年级');
  }
  function refreshUserProfile() {
    const trigger = $('#exhloj-profile-entry'), view = $('#exhloj-profile-view');
    const uid = pageName() === 'user_detail' && userProfileId();
    const target = uid > 0 && settings.options.profileInfoEntry && (settings.userModule || enabled('permissions')) && profileEntryTarget();
    if (!target) { trigger?.remove(); view?.closest('dialog[open]')?.close(); return; }
    const entry = trigger || button('用户信息', 'profile-info', { id: 'exhloj-profile-entry', 'aria-haspopup': 'dialog' });
    if (entry.dataset.uid !== String(uid)) entry.dataset.uid = uid;
    if (entry.parentElement !== target) {
      if (target.closest('.profile-header')) target.append(entry); else target.prepend(entry);
    }
    if (view?.closest('dialog[open]')) {
      if (+view.dataset.uid !== uid) view.closest('dialog').close();
      else renderProfileInfo(view, uid);
    }
  }
  function openProfileInfo(control) {
    syncPageContext();
    const uid = userProfileId();
    if (!settings.options.profileInfoEntry || pageName() !== 'user_detail' || !(uid > 0) || +control.dataset.uid !== uid ||
        (!settings.userModule && !enabled('permissions'))) { refreshUserProfile(); return; }
    const body = modal('用户信息', 'user'), dialog = body.closest('dialog');
    const view = el('div', { id: 'exhloj-profile-view', 'data-uid': uid });
    body.append(view); renderProfileInfo(view, uid);
    dialog.addEventListener('close', () => dialog.remove(), { once: true });
  }
  function renderProfileInfo(view, uid) {
    const data = current('udoc'), doc = +data?._id === uid ? data : null;
    const store = settings.userModule ? userStore() : null, profile = store?.users.oiers[uid], rating = store ? userRating(uid) : null;
    const permEnabled = enabled('permissions'), bits = permEnabled ? permissionValue(doc) : null;
    const title = doc?.uname || profile?.uname || '';
    const signature = JSON.stringify([uid, title, domainId(), doc?.role, permEnabled, bits?.toString(), !!store, profile,
      store?.users.teachers.includes(uid), store?.users.practice[uid], rating]);
    if (view.exhProfileSignature === signature) return;
    const permsOpen = !!$('#exhloj-profile-permissions', view)?.open, awardsOpen = !!$('#exhloj-profile-awards', view)?.open;
    view.exhProfileSignature = signature;
    view.replaceChildren(el('p', { class: 'exhloj-panel-summary' }, (title ? title + ' · ' : '') + 'UID ' + uid + ' · 当前域：' + domainId()));
    if (permEnabled) renderProfilePermissions(view, doc, bits, permsOpen);
    if (store) {
      const body = el('section', { id: 'exhloj-local-user-card' }); body.append(el('h3', {}, '本地资料'));
      view.append(body); renderLocalProfile(body, uid, store, awardsOpen);
    }
  }
  function renderLocalProfile(body, uid, store, awardsOpen) {
    const profile = store.users.oiers[uid], teacher = store.users.teachers.includes(uid);
    const dl = el('dl', { class: 'exhloj-user-data' });
    for (const [title, value] of [['教练标记', teacher ? '是' : '否'], ['姓名', profile?.name || '未填写'], ['CCF 评级', profile?.level ? `${profile.level} 级` : '未填写'], ['就读年级', profileGrade(profile?.grade)], ['题目分', store.users.practice[uid] ?? '未填写']]) dl.append(el('dt', {}, title), el('dd', {}, value));
    const rating = el('dd'); rating.append(ratingNode(userRating(uid))); dl.append(el('dt', {}, 'Rating'), rating);
    if (profile?.oierId) { const dd = el('dd'); dd.append(el('a', { href: `https://oier.baoshuo.dev/oier/${profile.oierId}`, target: '_blank', rel: 'noopener noreferrer' }, `#${profile.oierId}`)); dl.append(el('dt', {}, 'OIerDB'), dd); }
    if (profile?.oierRank) dl.append(el('dt', {}, 'OIerDb 排名'), el('dd', {}, profile.oierRank));
    if (profile?.oierScore !== undefined) dl.append(el('dt', {}, 'OIerDb 积分'), el('dd', {}, profile.oierScore));
    if (profile?.oierSyncedAt) dl.append(el('dt', {}, 'OIerDb 更新'), el('dd', {}, new Date(profile.oierSyncedAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })));
    body.append(dl, button('编辑本地资料', 'user-edit', { 'data-uid': uid }), button('Rating 历史', 'user-history', { 'data-uid': uid }), button('Rating 排行榜', 'user-ranking'));
    if (profile?.oierId) body.append(button('刷新 OIerDb 资料', 'user-oier-refresh', { 'data-uid': uid }));
    if (profile?.records.length) {
      const awards = el('details', { id: 'exhloj-profile-awards' }); awards.open = awardsOpen;
      awards.append(el('summary', {}, '获奖信息（' + profile.records.length + '）')); body.append(awards);
      for (const record of profile.records) {
        const p = el('p'), medal = ['一等奖', '金牌'].includes(record.awards) ? '🥇 ' : ['二等奖', '银牌'].includes(record.awards) ? '🥈 ' : ['三等奖', '铜牌'].includes(record.awards) ? '🥉 ' : '';
        p.append(el('strong', {}, record.contest), el('br'), el('span', {}, `${medal}${record.awards}${record.score === '' ? '' : `（${record.score}${record.fullScore === undefined ? '' : ` / ${record.fullScore}`} 分）`}`));
        const details = [record.rank ? `排名 ${record.rank}${record.participants ? ` / ${record.participants}` : ''}` : '', record.province, record.school, record.grade].filter(Boolean);
        if (details.length) p.append(el('br'), el('small', {}, details.join(' · '))); awards.append(p);
      }
    }
  }
  function refreshUserScoreboards() {
    const store = userStore(), context = contestContext(), index = store.ratings.contests.findIndex(row => row[0] === `${context.domain}/${context.id}`);
    for (const table of $$('.section__table-container > .data-table, table[data-exh-scoreboard]')) {
      if (!settings.userModule || pageName() !== 'contest_scoreboard' || index < 0) { for (const cell of $$('[data-exh-user-column]', table)) cell.remove(); delete table.dataset.exhUserRating; continue; }
      const signature = JSON.stringify([index, store.ratings.records]);
      if (table.dataset.exhUserRating !== signature) { for (const cell of $$('[data-exh-user-column]', table)) cell.remove(); table.dataset.exhUserRating = signature; }
      const col = $('col.col--total_score', table); if (col && !col.previousElementSibling?.hasAttribute('data-exh-user-column')) for (const name of ['performance', 'rating']) col.before(el('col', { 'data-exh-user-column': name }));
      for (const row of $$('tr', table)) {
        const total = $(':scope > .col--total_score', row); if (!total) continue;
        const uid = +$('button.star[data-uid]', row)?.dataset.uid || uidFromNode($('.col--user a', row) || el('span')), record = store.byContest.get(`${index}/${uid}`);
        const rowSignature = JSON.stringify([index, uid, total.tagName, record]);
        if (row.dataset.exhUserRatingRow === rowSignature && $$('[data-exh-user-column]', row).length === 2) continue;
        for (const cell of $$('[data-exh-user-column]', row)) cell.remove(); row.dataset.exhUserRatingRow = rowSignature;
        if (total.tagName === 'TH') { total.before(el('th', { 'data-exh-user-column': 'performance' }, '表现分'), el('th', { 'data-exh-user-column': 'rating' }, '本地 Rating Δ')); continue; }
        const performance = el('td', { 'data-exh-user-column': 'performance' }, record?.performance ?? ''), rating = el('td', { 'data-exh-user-column': 'rating' });
        if (record) { const diff = record.rating - record.old; rating.append(ratingNode(record.old), el('span', { class: diff > 0 ? 'exhloj-user-gain' : diff < 0 ? 'exhloj-user-loss' : '' }, ` ${diff >= 0 ? '+' : '−'}${Math.abs(diff)} = `), ratingNode(record.rating)); }
        total.before(performance, rating);
      }
    }
  }
  function refreshUserModule() {
    if (!settings.userModule) { workJobs.get('user')?.controller.abort(); workJobs.get('oier')?.controller.abort(); }
    try { if (page.UiContext?.exhloj) { if (settings.userModule) page.UiContext.exhloj.user = localUserAPI; else delete page.UiContext.exhloj.user; } } catch {}
    refreshUserProfile(); refreshUserScoreboards(); refreshUserNames();
  }
  function userToolBody(title) { if (!settings.userModule) throw workError('请先启用用户资料与 Rating'); return modal(title, 'user'); }
  function openUserTools() {
    const body = userToolBody('用户工具 · 本地'), store = userStore();
    body.append(el('p', {}, '资料、教练标记和 Rating 只在本机生效。所有用户均可编辑，没有特定 UID 的管理员限制。'));
    if (userLoadError) body.append(el('p', { class: 'exhloj-work-errors' }, `本地数据格式异常：${userLoadError}；请用 JSON 工具修正或重新导入。`));
    const form = el('form', { id: 'exhloj-user-options' }), label = el('label', {}, '名字显示 '), display = el('select', { name: 'display' });
    for (const [value, title] of USER_DISPLAY_MODES) display.append(el('option', { value }, title)); display.value = settings.userDisplay; label.append(display); form.append(label);
    const ccf = el('input', { name: 'ccf', type: 'checkbox' }); ccf.checked = settings.userCCF; const ccfLabel = el('label'); ccfLabel.append(ccf, '显示本地 CCF 评级标记'); form.append(ccfLabel, button('保存显示设置', 'user-options-save')); body.append(form);
    body.append(el('p', {}, `${Object.keys(store.users.oiers).length} 份资料，${store.ratings.contests.length} 场比赛，${store.ratings.records.length} 条 Rating 记录。`));
    const uidLabel = el('label', {}, '编辑用户 ID '); uidLabel.append(el('input', { type: 'number', min: 1, step: 1, id: 'exhloj-user-id', value: userProfileId() || +user()._id || 1 })); body.append(uidLabel, button('编辑资料', 'user-edit'), button('查看 Rating 历史', 'user-history'));
    body.append(button('Rating 排行榜', 'user-ranking'), button('Rated 比赛与结算', 'user-rated'), button('时间轴结算', 'user-timeline'), button('资料 JSON 导入 / 编辑', 'user-json'), button('导出用户数据', 'user-export'), button('从卷王统计更新题目分', 'user-practice'));
    const bindings = el('details', { open: '' }); bindings.append(el('summary', {}, '已绑定的 OIerDb 资料'), el('div', { id: 'exhloj-user-oier-bindings', class: 'exhloj-work-results' }), button('刷新全部 OIerDb 资料', 'user-oier-refresh-all'));
    body.append(button('OIerDb 快捷导入', 'user-oier-quick-open'), bindings); workProgress(body, 'oier'); renderOIerBindings();
  }
  const OIER_API = 'https://oier.api.baoshuo.dev';
  const OIER_AWARDS = ['金牌', '银牌', '铜牌', '一等奖', '二等奖', '三等奖', '国际金牌', '国际银牌', '国际铜牌', '前5%', '前15%', '前25%'];
  const OIER_PROVINCES = ['安徽', '北京', '福建', '甘肃', '广东', '广西', '贵州', '海南', '河北', '河南', '黑龙江', '湖北', '湖南', '吉林', '江苏', '江西', '辽宁', '内蒙古', '山东', '山西', '陕西', '上海', '四川', '天津', '新疆', '浙江', '重庆', '宁夏', '云南', '澳门', '香港', '青海', '西藏', '台湾'];
  let oierDatabaseCache;
  function oierIdFromURL(value) {
    try {
      const url = new URL(String(value).trim()), match = url.pathname.match(/^\/oier\/([1-9]\d*)\/?$/);
      if (url.protocol === 'https:' && url.hostname === 'oier.baoshuo.dev' && !url.port && !url.username && !url.password && match) {
        const id = Number(match[1]); if (Number.isSafeInteger(id) && id <= 1e9) return id;
      }
    } catch {}
    throw workError('请粘贴完整的 OIerDb 选手链接：https://oier.baoshuo.dev/oier/数字ID；不支持排名页、网页文字或 Markdown');
  }
  function oierRequest(job, path, limit) {
    return workRequest(job, `OIerDb：${path.includes('.info.') ? '检查数据库版本' : path.startsWith('static.') ? '下载基础资料' : '下载获奖记录'}`, signal => new Promise((resolve, reject) => {
      let settled = false, request;
      const finish = (fn, value) => { if (settled) return; settled = true; clearTimeout(timer); signal.removeEventListener('abort', abort); fn(value); };
      const abort = () => { finish(reject, workError('任务已取消')); request?.abort?.(); };
      const timer = setTimeout(() => { finish(reject, workError('OIerDb 读取超时，请重试')); request?.abort?.(); }, 75000);
      signal.addEventListener('abort', abort, { once: true });
      if (signal.aborted) return abort();
      try {
        request = GM_xmlhttpRequest({ method: 'GET', url: OIER_API + '/' + path, anonymous: true, timeout: 70000,
          headers: { Accept: 'application/json,text/plain', 'Cache-Control': 'no-cache' },
          onprogress(event) {
            if (settled) return;
            if (event.loaded > limit) { finish(reject, workError('OIerDb 数据超过大小限制')); request?.abort?.(); return; }
            workStates.oier.message = `正在下载 OIerDb · ${(event.loaded / 1048576).toFixed(1)} MiB`; updateWorkProgress('oier');
          },
          onload(response) {
            if (settled) return;
            try {
              if (response.finalUrl && new URL(response.finalUrl).origin !== OIER_API) throw workError('OIerDb 数据跳转到了其他站点');
              if (response.status < 200 || response.status >= 300) throw workError(`OIerDb 返回 HTTP ${response.status}`);
              const text = response.responseText ?? response.response;
              if (typeof text !== 'string' || new Blob([text]).size > limit) throw workError('OIerDb 返回的数据过大或无效');
              finish(resolve, text);
            } catch (error) { finish(reject, error); }
          },
          onerror: () => finish(reject, workError('无法连接 OIerDb；请检查网络，并在油猴提示中允许访问 oier.api.baoshuo.dev')),
          ontimeout: () => finish(reject, workError('OIerDb 读取超时，请重试')),
          onabort: () => finish(reject, workError('OIerDb 请求已取消')) });
      } catch (error) { finish(reject, error); }
    }));
  }
  async function loadOIerDatabase(job) {
    const info = (text, limit) => {
      const value = JSON.parse(text);
      if (!isObject(value) || !/^[a-f\d]{128}$/.test(value.sha512) || !Number.isSafeInteger(value.size) || value.size <= 0 || value.size > limit) throw workError('OIerDb 数据版本信息无效');
      return value;
    };
    const nonce = Date.now(), staticText = await oierRequest(job, `static.info.json?_=${nonce}`, 65536), resultText = await oierRequest(job, `result.info.json?_=${nonce}`, 65536);
    const staticInfo = info(staticText, 8 * 1048576), resultInfo = info(resultText, 64 * 1048576), version = staticInfo.sha512 + '/' + resultInfo.sha512;
    checkJob(job);
    if (oierDatabaseCache?.version === version) return oierDatabaseCache;
    const read = async (kind, meta) => {
      const text = await oierRequest(job, `${kind}.${meta.sha512.slice(0, 7)}.${kind === 'static' ? 'json' : 'txt'}`, meta.size);
      const bytes = new TextEncoder().encode(text);
      if (bytes.length !== meta.size) throw workError('OIerDb 下载不完整，请重试');
      if (globalThis.crypto?.subtle) {
        const digest = [...new Uint8Array(await crypto.subtle.digest('SHA-512', bytes))].map(x => x.toString(16).padStart(2, '0')).join('');
        if (digest !== meta.sha512) throw workError('OIerDb 数据校验失败，请重试');
      }
      checkJob(job); return text;
    };
    const staticsText = await read('static', staticInfo), results = await read('result', resultInfo), statics = JSON.parse(staticsText);
    if (!isObject(statics) || !Array.isArray(statics.contests) || !statics.contests.length || !Array.isArray(statics.schools)) throw workError('无法识别 OIerDb 数据格式');
    checkJob(job); oierDatabaseCache = { version, shortVersion: staticInfo.sha512.slice(0, 7) + '/' + resultInfo.sha512.slice(0, 7), statics, results };
    return oierDatabaseCache;
  }
  function oierRecordGrade(relative) {
    return relative >= 6 ? `高中毕业 ${relative - 5} 年` : ['一年级', '二年级', '三年级', '四年级', '五年级', '六年级', '初一', '初二', '初三', '高一', '高二', '高三'][relative + 6] || '未知';
  }
  async function readOIerProfiles(database, ids, job) {
    const wanted = new Set(ids), selected = new Map(), counts = new Map(), { contests, schools } = database.statics;
    let position = 0, lastScore, lastRank = 0, offset = 0;
    while (offset < database.results.length) {
      const end = database.results.indexOf('\n', offset), line = database.results.slice(offset, end < 0 ? undefined : end).replace(/\r$/, '');
      offset = end < 0 ? database.results.length : end + 1;
      if (!line) continue;
      const fields = line.split(','), id = Number(fields[0]), score = Number(fields[5]);
      if (fields.length !== 9 || !Number.isSafeInteger(id) || id <= 0 || !fields[2] || !Number.isFinite(score)) throw workError('无法识别 OIerDb 选手数据格式');
      const rank = score === lastScore ? lastRank : position + 1; lastScore = score; lastRank = rank; position++;
      const records = fields[8] ? fields[8].split('/') : [];
      for (const record of records) {
        const contestId = Number(record.split(':', 1)[0]);
        if (!Number.isInteger(contestId) || !contests[contestId]) throw workError('OIerDb 比赛索引无效');
        counts.set(contestId, (counts.get(contestId) || 0) + 1);
      }
      if (wanted.has(id)) {
        if (selected.has(id)) throw workError('OIerDb 选手 ID 重复，未更新资料');
        selected.set(id, { fields, records, rank });
      }
      if (position % 2000 === 0) {
        checkJob(job); workStates.oier.message = `正在读取 OIerDb 资料 · ${Math.floor(offset / database.results.length * 100)}%`; updateWorkProgress('oier');
        await pauseWork(0, job.controller.signal);
      }
    }
    checkJob(job);
    const result = new Map(), syncedAt = Date.now();
    for (const [id, row] of selected) {
      const middle = Number(row.fields[4]), level = Number(row.fields[7]);
      if (!Number.isInteger(middle) || middle < 0 || middle > 2994 || !Number.isInteger(level) || level < 0 || level > 10) throw workError('OIerDb 年级或 CCF 等级无效');
      const records = row.records.map(raw => {
        const fields = raw.split(/[:;]/), [contestId, schoolId, score, rank, province, award, enrollment] = fields;
        const contest = contests[+contestId], school = schools[+schoolId];
        if (![6, 7].includes(fields.length) || !contest || !Array.isArray(school) || !school[0] || OIER_AWARDS[+award] === undefined || OIER_PROVINCES[+province] === undefined) throw workError('OIerDb 获奖记录格式无效');
        const year = Number(contest.year) - (contest.fall_semester ? 0 : 1), recordMiddle = raw.includes(';') && enrollment !== undefined ? Number(enrollment) : middle;
        return { contest: contest.name, awards: OIER_AWARDS[+award], score: score === '' ? '' : Number(score), fullScore: Number(contest.full_score), rank: Number(rank),
          participants: Number(contest.capacity) || counts.get(+contestId), province: OIER_PROVINCES[+province], school: school[0], grade: oierRecordGrade(year - recordMiddle), contestId: +contestId, schoolId: +schoolId };
      }).reverse();
      const profile = { name: row.fields[2], oierId: id, level, grade: middle ? middle + 6 : 0, oierRank: row.rank, oierScore: Number(row.fields[5]), records,
        oierSyncedAt: syncedAt, oierVersion: database.shortVersion };
      normalizeUserData({ oiers: { 1: profile } }); result.set(id, profile);
    }
    return result;
  }
  // 快捷导入：只对已同意关联的成员使用；识别与候选队列只在当前页面内存中保留。
  let oierQuickQueue;
  function normalizeOIerLetters(text) {
    return text.normalize('NFKC').replace(/[üǖǘǚǜ]/gi, 'v').normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
  }
  function oierNamePinyins(name, readings) {
    const chars = [...name.replace(/·/g, '')];
    if (chars.length < 2 || chars.length > 12 || chars.some(char => !/^\p{Script=Han}$/u.test(char))) return [];
    let variants = [''];
    for (const char of chars) {
      if (!readings.has(char)) {
        const choices = ExhlojPinyin.polyphonic(char, { type: 'array', toneType: 'none', v: true })[0] || [];
        readings.set(char, [...new Set(choices.map(normalizeOIerLetters).filter(value => /^[a-z]+$/.test(value)))]);
      }
      const choices = readings.get(char);
      if (!choices.length || variants.length * choices.length > 256) return [];
      variants = [...new Set(variants.flatMap(prefix => choices.map(value => prefix + value)))];
    }
    return variants;
  }
  async function indexOIerSearch(database, job) {
    if (database.searchIndex) return database.searchIndex;
    const names = new Map(), initials = new Map(), fullPinyin = new Map(), lengths = new Set(); let offset = 0, count = 0;
    const add = (map, key, ids) => { const values = map.get(key) || []; values.push(...ids); map.set(key, values); };
    const seen = new Set();
    while (offset < database.results.length) {
      const end = database.results.indexOf('\n', offset), line = database.results.slice(offset, end < 0 ? undefined : end).replace(/\r$/, '');
      offset = end < 0 ? database.results.length : end + 1; if (!line) continue;
      const fields = line.split(','), id = +fields[0];
      if (fields.length !== 9 || !Number.isSafeInteger(id) || id <= 0 || !fields[2] || seen.has(id)) throw workError('OIerDb 搜索索引无效或选手 ID 重复');
      seen.add(id); add(names, fields[2].normalize('NFKC').toLowerCase(), [id]);
      const key = fields[1].toLowerCase(); if (/^[a-z]{2,8}$/.test(key)) add(initials, key, [id]);
      if (++count % 2000 === 0) {
        checkJob(job); workStates.oier.message = `建立本地搜索索引 · ${count} 人`; updateWorkProgress('oier'); await pauseWork(0, job.controller.signal);
      }
    }
    const readings = new Map(); let indexed = 0;
    for (const [name, ids] of names) {
      for (const key of oierNamePinyins(name, readings)) { add(fullPinyin, key, ids); lengths.add(key.length); }
      if (++indexed % 1000 === 0) {
        checkJob(job); workStates.oier.message = `建立本地全拼索引 · ${indexed}/${names.size} 个姓名`; updateWorkProgress('oier'); await pauseWork(0, job.controller.signal);
      }
    }
    checkJob(job); return database.searchIndex = { names, initials, fullPinyin, lengths: [...lengths].sort((a, b) => b - a), count };
  }
  function matchOIerUser(uname, index) {
    const han = [...uname.normalize('NFKC').matchAll(/\p{Script=Han}/gu)].map(match => match[0]).join('');
    if (han && index.names.has(han)) return { ids: new Set(index.names.get(han)), evidence: [`汉字：${han}`] };
    const text = normalizeOIerLetters(uname.normalize('NFKC').replace(/([a-z])([A-Z])/g, '$1_$2'));
    const full = [], initials = [];
    for (const group of text.matchAll(/[a-z]+(?:[\s_.'’-]+[a-z]+)*/g)) {
      const compact = group[0].replace(/[^a-z]/g, ''), groupId = group.index;
      let partOffset = 0;
      for (const part of group[0].matchAll(/[a-z]+/g)) {
        const key = part[0], ids = index.initials.get(key);
        if (ids) initials.push({ groupId, start: partOffset, end: partOffset + key.length, ids, evidence: `首字母：${key}` });
        partOffset += key.length;
      }
      // 数字分隔两侧分别识别；字母前后缀内也可命中完整姓名全拼，不把数字两侧拼成一个姓名。
      for (let start = 0; start < compact.length; start++) for (const length of index.lengths) {
        if (start + length > compact.length) continue;
        const key = compact.slice(start, start + length), ids = index.fullPinyin.get(key);
        if (ids) full.push({ groupId, start, end: start + length, ids, evidence: `全拼：${key}（完整姓名读音）` });
      }
    }
    // 优先完整姓名全拼；同一片段里的短姓名不会覆盖较长姓名，等长/分离片段的多候选交给用户选择。
    const signals = full.length ? full : initials;
    const maximal = signals.filter(a => !signals.some(b => a.groupId === b.groupId && b.start <= a.start && b.end >= a.end && b.end - b.start > a.end - a.start));
    return { ids: new Set(maximal.flatMap(signal => signal.ids)), evidence: [...new Set(maximal.map(signal => signal.evidence))] };
  }
  function quickOIerContext(queue = oierQuickQueue) {
    if (!queue || queue.owner !== +user()._id || queue.epoch !== routeEpoch || queue.routeDomain !== domainId()) throw workError('账号或页面已变化，请重新扫描排名页');
    return queue;
  }
  function openQuickOIerImport() {
    const body = userToolBody('OIerDb 快捷导入'), form = el('form', { id: 'exhloj-oier-quick-form' }), label = el('label', {}, '排名页所在域 ID ');
    label.append(el('input', { name: 'domain', type: 'text', value: domainId(), maxlength: 80 })); form.append(label);
    form.append(el('p', {}, '用于已同意关联的成员。扫描排名页可见用户，汉字按完整姓名搜索；全拼/字母子串核对完整姓名读音，支持数字前后缀。命中 1–3 人进入折叠候选组，选择并确认后才保存。已绑定用户自动跳过。'),
      button('扫描排名页并识别', 'user-oier-quick-scan'));
    body.append(form); workProgress(body, 'oier'); body.append(el('div', { id: 'exhloj-oier-quick-results', class: 'exhloj-work-results' }));
    renderQuickOIerImport(); showWorkErrors(workStates.oier);
  }
  function renderQuickOIerImport() {
    const box = $('#exhloj-oier-quick-results'); if (!box) return; box.replaceChildren();
    const scan = $('[data-exh-action="user-oier-quick-scan"]'); if (scan) scan.disabled = !!workStates.oier.running;
    if (!oierQuickQueue) { box.append(el('p', {}, '尚无候选。OIerDb 基础资料与获奖记录在整轮识别中各下载一次；同版本在当前页面继续复用。')); return; }
    let queue; try { queue = quickOIerContext(); } catch (error) { box.append(el('p', {}, error.message)); return; }
    const pending = queue.rows.filter(row => !row.done), size = 30, pages = Math.max(1, Math.ceil(pending.length / size)); queue.page = Math.min(queue.page, pages - 1);
    box.append(el('p', { id: 'exhloj-oier-quick-summary' }, `域 ${queue.domain} · 排名页 ${queue.scanned} 人 · 待确认 ${pending.length} 人 · 已绑定跳过 ${queue.bound} 人 · 未入队 ${queue.unmatched.length} 人 · 数据版本 ${queue.version}`));
    if (queue.message) box.append(el('p', { role: 'status' }, queue.message));
    if (pending.length) {
      box.append(button('选中本页', 'user-oier-quick-select', { 'data-selected': 'yes' }), button('取消本页选择', 'user-oier-quick-select', { 'data-selected': 'no' }),
        button('确认导入选中项', 'user-oier-quick-apply'), button('移除选中项', 'user-oier-quick-remove'));
      const table = el('table'), head = el('tr'); for (const title of ['选择', 'OJ 用户', '匹配依据', 'OIerDb 候选资料', '操作']) head.append(el('th', {}, title)); table.append(head);
      for (const row of pending.slice(queue.page * size, (queue.page + 1) * size)) {
        const tr = el('tr', { 'data-oier-candidate': row.uid }), choice = el('input', { type: 'checkbox', 'data-oier-choice': row.uid, 'aria-label': `选择 ${row.uname}` }); choice.checked = !!row.selected;
        choice.addEventListener('change', () => { row.selected = choice.checked; });
        const select = el('td'); select.append(choice);
        const oj = el('td'); oj.append(el('a', { href: `/d/${seg(queue.domain)}/user/${row.uid}`, target: '_blank', rel: 'noopener noreferrer' }, `${row.uname} · #${row.uid}`));
        const candidate = el('td'), details = el('details', { 'data-oier-options': row.uid }), summary = el('summary'); details.open = !!row.expanded;
        const updateSummary = () => { const chosen = row.options.find(profile => profile.oierId === row.chosenId); summary.textContent = `${row.options.length} 位候选 · ${chosen ? '当前选择：' + chosen.name + ' #' + chosen.oierId : '展开选择一人'}`; };
        updateSummary(); details.append(summary); details.addEventListener('toggle', () => { row.expanded = details.open; });
        const confirm = button('确认此人', 'user-oier-quick-apply', { 'data-uid': row.uid }); confirm.disabled = !row.chosenId;
        for (const profile of row.options) {
          const card = el('div', { class: 'exhloj-oier-option', 'data-oier-profile': profile.oierId }), label = el('label'), radio = el('input', { type: 'radio', name: `oier-choice-${row.uid}`, value: profile.oierId, 'aria-label': `选择 ${profile.name} #${profile.oierId}` });
          radio.checked = row.chosenId === profile.oierId; label.append(radio, `${profile.name} · #${profile.oierId}`); card.append(label);
          radio.addEventListener('change', () => {
            if (!radio.checked) return; row.chosenId = profile.oierId; row.selected = true; choice.checked = true; confirm.disabled = false; updateSummary();
          });
          const latest = profile.records.at(0);
          card.append(el('a', { href: `https://oier.baoshuo.dev/oier/${profile.oierId}`, target: '_blank', rel: 'noopener noreferrer' }, '查看 OIerDb 选手页'),
            el('p', {}, `CCF ${profile.level} 级 · ${profile.grade ? profile.grade + ' 年高中毕业' : '年级未知'} · ${profile.records.length} 条获奖记录`),
            el('p', {}, latest ? `${latest.school} · ${latest.province} · ${latest.contest} ${latest.awards}` : '无获奖记录'));
          if (queue.rows.some(other => other.uid !== row.uid && other.options.some(option => option.oierId === profile.oierId))) card.append(el('p', {}, '同一 OIerDb ID 也匹配了其他账号，请分别核对。'));
          details.append(card);
        }
        candidate.append(details); const actions = el('td'); actions.append(confirm, button('移除', 'user-oier-quick-remove', { 'data-uid': row.uid }));
        tr.append(select, oj, el('td', {}, row.evidence.join('\n')), candidate, actions); table.append(tr);
      }
      box.append(table, button('上一页', 'user-oier-quick-page', { 'data-step': '-1', ...(queue.page === 0 ? { disabled: '' } : {}) }),
        el('span', {}, ` 第 ${queue.page + 1}/${pages} 页 `), button('下一页', 'user-oier-quick-page', { 'data-step': '1', ...(queue.page + 1 >= pages ? { disabled: '' } : {}) }));
    }
    if (queue.unmatched.length) {
      const details = el('details'); details.append(el('summary', {}, `未入队 ${queue.unmatched.length} 人（超过 3 人或无匹配）`));
      for (const row of queue.unmatched.slice(0, 100)) details.append(el('p', {}, `${row.uname} · #${row.uid}：${row.reason}${row.evidence?.length ? '；' + row.evidence.join('；') : ''}`));
      if (queue.unmatched.length > 100) details.append(el('p', {}, '这里只展示前 100 人。')); box.append(details);
    }
  }
  async function scanQuickOIerImport() {
    const form = $('#exhloj-oier-quick-form'), domains = domainList(form.elements.domain.value); if (domains.length !== 1) throw workError('一次请选择一个排名域');
    if (workJobs.has('oier')) throw workError('OIerDb 已有任务运行，请等待或取消');
    oierQuickQueue = undefined; renderQuickOIerImport();
    await runWork('oier', async (job, state) => {
      const queue = { owner: job.owner, epoch: routeEpoch, routeDomain: domainId(), domain: domains[0], rows: [], unmatched: [], bound: 0, scanned: 0, page: 0 };
      job.quick = true; renderQuickOIerImport();
      const rows = await listPages(job, `/d/${seg(queue.domain)}/ranking`, 'udocs'), members = new Map(), store = userStore();
      quickOIerContext(queue);
      for (const row of rows) {
        const uid = Number(row._id ?? row.uid);
        if (!Number.isSafeInteger(uid) || uid <= 1 || typeof row.uname !== 'string' || !row.uname.trim() || row.uname.length > 120 || row.deleted === true) continue;
        if (members.has(uid) && members.get(uid).uname !== row.uname) throw workError('排名页用户名在扫描中变化，请重新扫描');
        members.set(uid, { uid, uname: row.uname });
      }
      queue.scanned = members.size;
      const unbound = [];
      for (const row of members.values()) {
        if (store.users.oiers[row.uid]?.oierId) { queue.bound++; continue; }
        unbound.push({ ...row, baseline: JSON.stringify(store.users.oiers[row.uid] ?? null) });
      }
      if (!unbound.length) {
        checkJob(job); quickOIerContext(queue); queue.version = '无需下载'; oierQuickQueue = queue; state.message = `已扫描 ${queue.scanned} 人，没有未绑定成员`; return;
      }
      const database = await loadOIerDatabase(job), index = await indexOIerSearch(database, job), matched = [];
      for (const [number, row] of unbound.entries()) {
        let match; try { match = matchOIerUser(row.uname, index); } catch (error) { queue.unmatched.push({ ...row, reason: error.message }); continue; }
        if (match.ids.size >= 1 && match.ids.size <= 3) matched.push({ ...row, ids: [...match.ids], evidence: match.evidence });
        else queue.unmatched.push({ ...row, evidence: match.evidence, reason: match.ids.size ? `搜索命中 ${match.ids.size} 人，超过 3 人，未入队` : '未找到完整姓名、首字母或可匹配的全拼片段' });
        if (number % 25 === 0) {
          checkJob(job); quickOIerContext(queue); state.message = `本地识别 ${number + 1}/${unbound.length} 人`; updateWorkProgress('oier'); await pauseWork(0, job.controller.signal);
        }
      }
      const profiles = matched.length ? await readOIerProfiles(database, matched.flatMap(row => row.ids), job) : new Map();
      for (const row of matched) {
        const options = row.ids.map(id => profiles.get(id)); if (options.some(profile => !profile)) throw workError('候选资料不完整，请重试');
        queue.rows.push({ ...row, options, chosenId: options.length === 1 ? options[0].oierId : 0 });
      }
      checkJob(job); quickOIerContext(queue); queue.version = database.shortVersion; oierQuickQueue = queue;
      state.message = `识别完成，${queue.rows.length} 人进入待确认队列；尚未保存任何资料`;
    });
    renderQuickOIerImport();
  }
  function applyQuickOIerImport(uid) {
    if (workJobs.has('oier')) throw workError('请等待当前 OIerDb 任务结束');
    const queue = quickOIerContext(), selected = queue.rows.filter(row => !row.done && (uid === undefined ? row.selected : row.uid === uid));
    if (!selected.length) throw workError('请先勾选候选，或点击对应的“确认此人”');
    const store = userStore(), next = clone(store.users), errors = []; let saved = 0; const accepted = [];
    for (const row of selected) {
      const profile = row.options.find(option => option.oierId === row.chosenId);
      if (!profile) { errors.push(`#${row.uid} 有多个候选，请先展开并选择一人`); continue; }
      if (JSON.stringify(next.oiers[row.uid] ?? null) !== row.baseline) { errors.push(`#${row.uid} 的本地资料已变化，请重新扫描`); continue; }
      next.oiers[row.uid] = { ...next.oiers[row.uid], ...profile, uname: row.uname }; saved++; accepted.push(row);
    }
    if (saved) { writeUserStore(next, store.ratings); for (const row of accepted) row.done = true; }
    queue.message = `已确认保存 ${saved} 人${errors.length ? '；' + errors.join('；') : ''}`; renderQuickOIerImport(); notify(queue.message, !saved);
  }
  function changeQuickOIerQueue(action, control) {
    const queue = quickOIerContext();
    if (action === 'user-oier-quick-page') queue.page = Math.max(0, queue.page + Number(control.dataset.step));
    else {
      const displayed = new Set($$('[data-oier-choice]').map(input => +input.dataset.oierChoice));
      for (const row of queue.rows) {
        if (row.done) continue;
        if (action === 'user-oier-quick-select' && displayed.has(row.uid)) row.selected = control.dataset.selected === 'yes';
        if (action === 'user-oier-quick-remove' && (control.dataset.uid ? row.uid === +control.dataset.uid : row.selected)) row.done = true;
      }
    }
    renderQuickOIerImport();
  }
  function renderOIerBindings() {
    const box = $('#exhloj-user-oier-bindings'); if (!box) return;
    const rows = Object.entries(userStore().users.oiers).filter(([, profile]) => profile.oierId);
    box.replaceChildren(el('p', {}, `${rows.length} 人已绑定 OIerDb ID。刷新只更新姓名、CCF 评级、年级、排名和获奖记录；OJ 用户名、教练标记、题目分及 Rating 保留。`));
    if (!rows.length) return;
    const table = el('table'), head = el('tr'); for (const title of ['OJ 用户', 'OIerDb ID', '最后更新', '操作']) head.append(el('th', {}, title)); table.append(head);
    for (const [uid, profile] of rows.slice(0, 100)) {
      const tr = el('tr'), idCell = el('td'), actions = el('td');
      idCell.append(el('a', { href: `https://oier.baoshuo.dev/oier/${profile.oierId}`, target: '_blank', rel: 'noopener noreferrer' }, `#${profile.oierId}`));
      actions.append(button('刷新', 'user-oier-refresh', { 'data-uid': uid }), button('编辑', 'user-edit', { 'data-uid': uid }));
      tr.append(el('td', {}, `${profile.name || profile.uname || '用户'} · #${uid}`), idCell, el('td', {}, profile.oierSyncedAt ? new Date(profile.oierSyncedAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }) : '尚未刷新'), actions); table.append(tr);
    }
    box.append(table); if (rows.length > 100) box.append(el('p', {}, '仅展示前 100 人；刷新全部会更新所有已绑定资料。'));
  }
  function oierEditorSnapshot(form) {
    return JSON.stringify(['name', 'level', 'grade', 'oierId', 'awards'].map(name => form.elements[name].value));
  }
  async function fillUserFromOIerLink(form) {
    const address = form.elements.oierURL.value.trim(), status = $('#exhloj-user-oier-status'), baseline = oierEditorSnapshot(form); let id;
    try { id = oierIdFromURL(address); } catch (error) { status.textContent = `读取失败：${error.message}`; throw error; }
    status.textContent = '正在读取 OIerDb…';
    await runWork('oier', async (job, state) => {
      const database = await loadOIerDatabase(job), profiles = await readOIerProfiles(database, [id], job), profile = profiles.get(id);
      checkJob(job);
      if (!form.isConnected || form.elements.oierURL.value.trim() !== address) throw workError('编辑页面或链接已变化，请重新读取');
      if (oierEditorSnapshot(form) !== baseline) throw workError('编辑内容已变化，已保留当前输入；需要导入时请重新读取链接');
      if (!profile) throw workError(`OIerDb 中未找到选手 #${id}；请检查链接，原资料已保留`);
      for (const key of ['name', 'level', 'grade', 'oierId']) form.elements[key].value = profile[key];
      form.elements.awards.value = JSON.stringify(profile.records, null, 2); form.exhlojOIerPreview = profile;
      state.message = `已读取 ${profile.name} · OIerDb #${id} · ${profile.records.length} 条获奖记录。点击“保存本地资料”后生效。`;
      status.textContent = state.message;
    }, true);
    if (workStates.oier.errors.length) status.textContent = `读取失败：${workStates.oier.errors.join('；')}`;
  }
  async function refreshOIerUsers(uid, control) {
    const mappings = Object.entries(userStore().users.oiers).filter(([key, profile]) => profile.oierId && (uid === undefined || +key === +uid)).map(([key, profile]) => [+key, profile.oierId, JSON.stringify(profile)]);
    if (!mappings.length) throw workError('没有已绑定的 OIerDb ID；请先在编辑资料中粘贴选手链接并保存');
    const editor = $('#exhloj-user-editor'), editorBaseline = editor ? oierEditorSnapshot(editor) : undefined;
    const sourceProfile = control.closest('#exhloj-profile-view'), sourceEpoch = routeEpoch;
    if (sourceProfile) {
      const body = sourceProfile.parentElement;
      if (!$('[data-work-progress="oier"]', body)) workProgress(body, 'oier');
    } else if (!control.closest('#exhloj-local-dialog')) { const body = userToolBody('刷新 OIerDb 资料'); workProgress(body, 'oier'); }
    await runWork('oier', async (job, state) => {
      const database = await loadOIerDatabase(job), profiles = await readOIerProfiles(database, mappings.map(([, id]) => id), job);
      checkJob(job);
      if (sourceProfile) syncPageContext();
      if (sourceProfile && (sourceEpoch !== routeEpoch || !sourceProfile.closest('dialog[open]') || userProfileId() !== uid))
        throw workError('已离开此用户资料页，未写入刷新结果');
      const { users, ratings } = userStore(), next = clone(users), updatedKeys = new Set(); let updated = 0;
      for (const [key, id, baseline] of mappings) {
        if (next.oiers[key]?.oierId !== id) { state.errors.push(`OJ #${key} 的绑定已变化，已跳过`); continue; }
        if (JSON.stringify(next.oiers[key]) !== baseline) { state.errors.push(`OJ #${key} 的本地资料已变化，已跳过；重新刷新可更新`); continue; }
        const profile = profiles.get(id);
        if (!profile) { state.errors.push(`OIerDb 未找到 #${id}（OJ #${key}），原资料已保留`); continue; }
        next.oiers[key] = { ...next.oiers[key], ...profile }; updated++; updatedKeys.add(key);
      }
      checkJob(job); if (updated) writeUserStore(next, ratings);
      const form = $('#exhloj-user-editor');
      if (form && form === editor && updatedKeys.has(+form.dataset.uid) && next.oiers[form.dataset.uid]) {
        if (oierEditorSnapshot(form) !== editorBaseline) state.errors.push('编辑内容已变化，已保留编辑框草稿；已保存资料的刷新结果可重新打开查看');
        else {
          const profile = next.oiers[form.dataset.uid]; for (const key of ['name', 'level', 'grade', 'oierId']) form.elements[key].value = profile[key];
          form.elements.awards.value = JSON.stringify(profile.records, null, 2); form.exhlojOIerPreview = profile;
        }
      }
      renderOIerBindings(); state.message = `已刷新并保存 ${updated}/${mappings.length} 份 OIerDb 资料${state.errors.length ? `；${state.errors.length} 项未更新` : ''}`; notify(state.message);
    }, true);
  }
  function userOIerLinkControls(form, profile) {
    const box = el('details', { open: '', class: 'exhloj-oier-import' }); box.append(el('summary', {}, '从 OIerDb 选手链接导入'));
    box.append(el('p', {}, '粘贴选手页面链接后自动读取，也可点击读取按钮。核对后保存；以后可按已记录的 ID 刷新资料。'));
    const label = el('label', {}, 'OIerDb 选手链接 '), input = el('input', { type: 'text', class: 'exhloj-source-input', name: 'oierURL', placeholder: 'https://oier.baoshuo.dev/oier/12345' });
    input.value = profile.oierId ? `https://oier.baoshuo.dev/oier/${profile.oierId}` : ''; label.append(input);
    box.append(label, button('读取链接并填入', 'user-oier-import'));
    if (profile.oierId) box.append(button('刷新已保存资料', 'user-oier-refresh', { 'data-uid': form.dataset.uid }));
    box.append(el('pre', { id: 'exhloj-user-oier-status', role: 'status', 'aria-live': 'polite' })); workProgress(box, 'oier'); form.append(box);
    input.addEventListener('paste', event => { if (!event.clipboardData) return; event.preventDefault(); input.value = event.clipboardData.getData('text/plain').trim(); task(() => fillUserFromOIerLink(form)); });
  }

  function openUserEditor(uid) {
    uid = localUid(uid); const body = userToolBody(`编辑本地用户 #${uid}`), store = userStore(), profile = store.users.oiers[uid] || {}, form = el('form', { id: 'exhloj-user-editor', 'data-uid': uid });
    userOIerLinkControls(form, profile);
    for (const [name, title, type, value] of [['name', '姓名', 'text', profile.name || ''], ['uname', 'OJ 用户名', 'text', profile.uname || localUserName(uid)], ['oierId', 'OIerDb ID（从链接记录）', 'number', profile.oierId || 0], ['level', 'CCF 级别（0–10）', 'number', profile.level || 0], ['grade', '高中毕业年份（0 表示未填写）', 'number', profile.grade || 0], ['practice', '题目分', 'number', store.users.practice[uid] ?? 0]]) {
      const label = el('label', {}, title + ' '); label.append(el('input', { name, type, value, ...(name === 'oierId' ? { readonly: '' } : {}), ...(type === 'number' ? { min: 0, step: 1 } : { maxlength: 120 }) })); form.append(label);
    }
    const teacher = el('input', { type: 'checkbox', name: 'teacher' }); teacher.checked = store.users.teachers.includes(uid); const teacherLabel = el('label'); teacherLabel.append(teacher, '教练标记（本地）'); form.append(teacherLabel);
    const awardsLabel = el('label', {}, '获奖记录 JSON：[{"contest":"NOIP 2026","awards":"一等奖","score":300}]'), awards = el('textarea', { name: 'awards', spellcheck: 'false' }); awards.value = JSON.stringify(profile.records || [], null, 2); awardsLabel.append(awards); form.append(awardsLabel);
    form.append(button('保存本地资料', 'user-save'), button('读取 OJ 用户名', 'user-fetch-name'), button('清除此用户的本地资料', 'user-clear')); body.append(form);
  }
  function saveUserEditor(clear = false) {
    const form = $('#exhloj-user-editor'); if (!form.reportValidity()) return;
    const uid = localUid(form.dataset.uid), { users, ratings } = userStore(), next = clone(users);
    next.teachers = next.teachers.filter(id => id !== uid);
    if (clear) { delete next.oiers[uid]; delete next.practice[uid]; }
    else {
      next.oiers[uid] = { ...next.oiers[uid], ...form.exhlojOIerPreview, name: form.elements.name.value, uname: form.elements.uname.value, oierId: +form.elements.oierId.value, level: +form.elements.level.value, grade: +form.elements.grade.value, records: JSON.parse(form.elements.awards.value) };
      next.practice[uid] = +form.elements.practice.value; if (form.elements.teacher.checked) next.teachers.push(uid);
    }
    writeUserStore(next, ratings); notify(clear ? '本地资料已清除' : '本地资料已保存');
  }
  function userExportData() {
    const { users, ratings } = userStore(), original = userLoadError ? cacheObject() : {};
    return { format: 'exhloj-user', schemaVersion: 1, version: VERSION,
      users: Object.hasOwn(original, 'exhloj.user') ? original['exhloj.user'] : users,
      ratings: Object.hasOwn(original, 'exhloj.ratedcontests') ? original['exhloj.ratedcontests'] : ratings };
  }
  function openUserJSON() {
    const body = userToolBody('用户数据 JSON'), area = el('textarea', { id: 'exhloj-user-json', spellcheck: 'false' }); area.value = JSON.stringify(userExportData(), null, 2);
    body.append(el('p', {}, '保存将替换这里提供的用户资料和 Rating。也可粘贴旧版 exhloj.user / exhloj.ratedcontests 缓存；未提供的部分保留。'), area, button('校验并保存', 'user-json-save'), button('导出用户数据', 'user-export'));
  }
  function importUserJSON(text) {
    if (new Blob([text]).size > LIMIT) throw workError('用户数据超过 2 MiB');
    const data = JSON.parse(text); if (!isObject(data)) throw workError('用户数据必须为对象');
    const cache = cacheObject(); let users = cache['exhloj.user'], ratings = cache['exhloj.ratedcontests'];
    if (data.format === 'exhloj-user') { if (data.schemaVersion !== 1 || !Object.hasOwn(data, 'users') || !Object.hasOwn(data, 'ratings')) throw workError('用户备份格式无效'); users = data.users; ratings = data.ratings; }
    else if (Object.hasOwn(data, 'exhloj.user') || Object.hasOwn(data, 'exhloj.ratedcontests')) { users = data['exhloj.user'] ?? users; ratings = data['exhloj.ratedcontests'] ?? ratings; }
    else if (Object.hasOwn(data, 'oiers') || Object.hasOwn(data, 'teachers') || Object.hasOwn(data, 'practice')) users = data;
    else if (Object.hasOwn(data, 'contests') && Object.hasOwn(data, 'records')) ratings = data;
    else throw workError('没有找到用户资料或 Rating 数据');
    writeUserStore(users, ratings, true); notify('用户数据已保存');
  }
  function openUserHistory(uid) {
    uid = localUid(uid); const body = userToolBody(`Rating 历史 · ${localUserName(uid)} (#${uid})`), store = userStore(), history = store.histories.get(uid) || [];
    const p = el('p'); p.append('本地 Rating：', ratingNode(userRating(uid)), `；最高 ${Math.max(USER_INITIAL_RATING, ...history.map(record => record.rating))}`); body.append(p);
    if (!history.length) body.append(el('p', {}, '暂无结算记录；初始 Rating 为 1800。'));
    const table = el('table'), head = el('tr'); for (const text of ['比赛', '排名', '表现分', 'Rating 变化']) head.append(el('th', {}, text)); table.append(head);
    for (const row of [...history].reverse()) {
      const contest = store.ratings.contests[row.index], tr = el('tr'), title = el('td'), url = ratedContestPath(contest[0], false), diff = row.rating - row.old;
      title.append(url ? el('a', { href: url, target: '_blank', rel: 'noopener noreferrer' }, contest[1] || contest[0]) : el('span', {}, contest[1] || contest[0]));
      const rating = el('td'); rating.append(ratingNode(row.old), ` ${diff >= 0 ? '+' : '−'}${Math.abs(diff)} → `, ratingNode(row.rating)); tr.append(title, el('td', {}, row.rank), el('td', {}, row.performance), rating); table.append(tr);
    } body.append(table, button('Rating 排行榜', 'user-ranking'));
  }
  function userRanking(mode = 'current') {
    const store = userStore(), minIndex = store.ratings.contests.length - 20;
    const rows = [...store.histories].map(([uid, history]) => ({ uid, current: history.at(-1).rating, max: Math.max(USER_INITIAL_RATING, ...history.map(row => row.rating)),
      up: history.filter(row => row.index >= minIndex).reduce((sum, row) => sum + Math.max(0, row.rating - row.old), 0),
      down: history.filter(row => row.index >= minIndex).reduce((sum, row) => sum + Math.max(0, row.old - row.rating), 0), eligible: history.some(row => row.index >= minIndex) }))
      .filter(row => !['up', 'down'].includes(mode) || row.eligible).sort((a, b) => b[mode] - a[mode] || a.uid - b.uid);
    rows.forEach((row, i) => { row.rank = i && row[mode] === rows[i - 1][mode] ? rows[i - 1].rank : i + 1; }); return rows;
  }
  function openUserRanking(mode = 'current') {
    if (!['current', 'max', 'up', 'down'].includes(mode)) throw workError('排行榜类型无效');
    const body = userToolBody('本地 Rating 排行榜'); for (const [key, title] of [['current', '当前 Rating'], ['max', '历史最高'], ['up', '近 20 场上分'], ['down', '近 20 场下分']]) body.append(button(title, 'user-ranking', { 'data-mode': key, ...(key === mode ? { disabled: '' } : {}) }));
    body.append(el('p', {}, ['up', 'down'].includes(mode) ? '按比赛列表最后 20 场的变化量累计；只显示参与过这些比赛的用户。' : '仅显示有结算记录的用户，同分并列。'));
    const table = el('table'), head = el('tr'); for (const title of ['排名', '用户', '数值', '历史']) head.append(el('th', {}, title)); table.append(head);
    const rows = userRanking(mode); for (const row of rows) { const tr = el('tr'), who = el('td'), value = el('td'), history = el('td'); who.append(localUserLink(row.uid)); value.append(['current', 'max'].includes(mode) ? ratingNode(row[mode]) : el('span', {}, row[mode])); history.append(button('查看', 'user-history', { 'data-uid': row.uid })); tr.append(el('td', {}, row.rank), who, value, history); table.append(tr); }
    body.append(table, el('p', {}, `${rows.length} 名用户`));
  }
  function ratedContestPath(value, strict = true) {
    const parts = String(value).split('/');
    if (parts.length === 2 && /^[\p{L}\p{N}_-]{1,80}$/u.test(parts[0]) && /^(?:[\da-f]{24}|\d+)$/i.test(parts[1])) return contestURL(parts[0], 'contest', parts[1]);
    if (strict) throw workError('Rated 比赛格式应为 域ID/比赛ID'); return '';
  }
  function openUserRated() {
    const body = userToolBody('Rated 比赛 · 本地结算'), area = el('textarea', { id: 'exhloj-user-commands', spellcheck: 'false' }), { ratings } = userStore(); area.value = ratings.commands;
    body.append(el('p', { id: 'exhloj-rating-summary' }, ratingSummary()),
      el('p', {}, '普通结算沿用已保存的分数和历史，只追加新比赛；已结算的比赛自动跳过。比赛页可直接加入并结算。需要重新开始时，使用时间轴结算。'),
      button('时间轴结算', 'user-timeline'), button('Rating 排行榜', 'user-ranking'),
      el('pre', {}, 'version:2\ncontest:域ID/比赛ID,比赛标题,1\nrating:域ID/比赛ID'),
      el('p', {}, 'version:1 只结算正分选手；version:2 结算所有有提交且有排名的选手。权重范围 0–10。contest 行可在第四项附上 [[UID,排名],...]，使用已有名次时无需读取 OJ。# 开头的行是注释。'), area,
      button('保存命令草稿', 'user-commands-save'), button('结算新增比赛并保存', 'user-calculate'), button('导出用户数据', 'user-export'));
    workProgress(body, 'user'); showWorkErrors(workStates.user);
  }
  function ratingSummary() {
    const { ratings } = userStore(); return `已保存 ${ratings.contests.length} 场比赛、${ratings.records.length} 条 Rating 记录。`;
  }
  function ratedCommandTitle(title) { return String(title || '').replace(/[,\r\n]/g, ' ').slice(0, 250); }
  function ratedCommand(id, title, weight = 1, version = 2) {
    return `version:${version}\ncontest:${id},${ratedCommandTitle(title)},${weight}\nrating:${id}`;
  }
  async function rateCurrentContest() {
    if (!['contest_detail', 'contest_scoreboard'].includes(pageName())) throw workError('请在比赛详情或榜单页操作');
    const context = contestContext(), id = `${context.domain}/${context.id}`; ratedContestPath(id);
    const doc = current('tdoc'), sameDoc = String(doc?.docId || doc?._id || '') === context.id;
    if (sameDoc && new Date(doc.endAt).getTime() > Date.now()) throw workError('比赛尚未结束，请结束后再结算');
    const { ratings } = userStore();
    if (ratings.contests.some(row => row[0] === id)) { openUserRated(); notify('这场比赛已结算，已保留原记录'); return; }
    let text = ratings.commands.trim(), plan = text && !text.split(/\r?\n/).every(line => !line.trim() || line.trim().startsWith('#')) ? parseRatedCommands(text, true) : { contests: [], groups: [] };
    const index = plan.contests.findIndex(row => row.id === id);
    if (index < 0) text += `${text ? '\n' : ''}${ratedCommand(id, sameDoc ? doc.title : context.id)}`;
    else if (!plan.groups.some(group => group.includes(index))) text += `\nrating:${id}`;
    openUserRated(); $('#exhloj-user-commands').value = text;
    await calculateUserRatings(text);
  }
  let ratingTimeline;
  function localDateInput(date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; }
  function openRatingTimeline() {
    ratingTimeline = undefined;
    const body = userToolBody('时间轴结算'), form = el('form', { id: 'exhloj-rating-timeline-form' }), today = new Date(), from = new Date(today); from.setDate(from.getDate() - 30);
    body.append(el('p', {}, ratingSummary()), el('p', {}, '按比赛开始日期筛选已结束的比赛，日期包含首尾两天，使用当前浏览器时区。勾选后按开始时间从早到晚结算，每场独立更新一次。'),
      el('p', {}, '从 1800 重新开始；全部成功后，用所选比赛替换当前全部 Rating 历史。未勾选的比赛不保留。失败或取消时保留原数据。'));
    for (const [name, title, type, value] of [['domain', '域 ID', 'text', domainId()], ['from', '开始日期', 'date', localDateInput(from)], ['to', '结束日期', 'date', localDateInput(today)]]) {
      const label = el('label', {}, title + ' '); label.append(el('input', { name, type, value, required: true })); form.append(label);
    }
    const weight = el('label', {}, '比赛权重 '); weight.append(el('input', { type: 'number', name: 'weight', min: 0, max: 10, step: 0.1, value: 1 })); form.append(weight);
    const label = el('label', {}, '参赛选手 '), version = el('select', { name: 'version' }); version.append(el('option', { value: '2' }, '有提交且有名次'), el('option', { value: '1' }, '有正分成绩')); label.append(version); form.append(label);
    body.append(form, button('读取时间范围内的比赛', 'user-timeline-scan'),
      el('div', { id: 'exhloj-rating-timeline-results', class: 'exhloj-work-results' }),
      button('全选', 'user-timeline-select', { 'data-checked': 'true' }), button('全不选', 'user-timeline-select', { 'data-checked': 'false' }),
      button('从 1800 重新结算所选比赛', 'user-timeline-calculate', { disabled: '' }), button('导出当前用户数据', 'user-export'));
    workProgress(body, 'user');
  }
  function ratingTimelineRange() {
    const form = $('#exhloj-rating-timeline-form'); if (!form) throw workError('请重新打开时间轴');
    const domains = domainList(form.elements.domain.value);
    if (domains.length !== 1) throw workError('请填写一个域 ID');
    const from = form.elements.from.value, to = form.elements.to.value;
    const start = new Date(`${from}T00:00:00`), end = new Date(`${to}T00:00:00`); end.setDate(end.getDate() + 1);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || !Number.isFinite(+start) || !Number.isFinite(+end) || +start >= +end) throw workError('请选择有效的起止日期，结束日期不能早于开始日期');
    return { domain: domains[0], from, to, start: +start, end: +end };
  }
  async function scanRatingTimeline() {
    const range = ratingTimelineRange(), form = $('#exhloj-rating-timeline-form'), box = $('#exhloj-rating-timeline-results');
    ratingTimeline = undefined; box.replaceChildren(); $('[data-exh-action="user-timeline-calculate"]').disabled = true;
    await runWork('user', async (job, state) => {
      const docs = await listPages(job, `/d/${seg(range.domain)}/contest`, 'tdocs'), rows = [], seen = new Set();
      for (let doc of docs) {
        const id = `${range.domain}/${doc.docId || doc._id || ''}`; ratedContestPath(id); if (seen.has(id)) continue; seen.add(id);
        let begin = Date.parse(doc.beginAt), end = Date.parse(doc.endAt);
        if (Number.isFinite(begin) && (begin < range.start || begin >= range.end)) continue;
        if (!Number.isFinite(begin) || !Number.isFinite(end)) {
          doc = (await jobJSON(job, ratedContestPath(id))).tdoc;
          begin = Date.parse(doc?.beginAt); end = Date.parse(doc?.endAt);
        }
        if (!Number.isFinite(begin) || !Number.isFinite(end) || end < begin) throw workError(`无法读取 ${id} 的比赛时间，请稍后重试`);
        if (begin < range.start || begin >= range.end || end > Date.now()) continue;
        rows.push({ id, title: localText(doc.title, 250) || id, begin, end });
      }
      checkJob(job);
      if (!form.isConnected || JSON.stringify(ratingTimelineRange()) !== JSON.stringify(range)) throw workError('时间范围已变化，请重新读取');
      rows.sort((a, b) => a.begin - b.begin || a.id.localeCompare(b.id));
      ratingTimeline = { range, rows, owner: job.owner, epoch: job.epoch, address: job.address, pageName: job.pageName, baseline: JSON.stringify(userStore().ratings) };
      const table = el('table'), head = el('tr'); for (const text of ['选择', '开始时间', '比赛', '状态']) head.append(el('th', {}, text)); table.append(head);
      const saved = new Set(userStore().ratings.contests.map(row => row[0]));
      for (const row of rows) {
        const tr = el('tr'), cell = el('td'), input = el('input', { type: 'checkbox', 'data-rating-id': row.id, 'aria-label': row.title }); input.checked = true; cell.append(input);
        const title = el('td'); title.append(el('a', { href: ratedContestPath(row.id), target: '_blank', rel: 'noopener noreferrer' }, row.title));
        tr.append(cell, el('td', {}, new Date(row.begin).toLocaleString()), title, el('td', {}, saved.has(row.id) ? '已结算，将重算' : '未结算')); table.append(tr);
      }
      box.replaceChildren(el('p', {}, `共 ${rows.length} 场已结束比赛；一次最多选择 200 场。`), table);
      $('[data-exh-action="user-timeline-calculate"]').disabled = !rows.length;
      state.message = `已读取 ${rows.length} 场比赛，请勾选后结算`;
    });
  }
  function selectedRatingTimeline() {
    const scan = ratingTimeline;
    if (!scan || scan.owner !== +user()._id || scan.epoch !== routeEpoch || scan.address !== location.href || scan.pageName !== pageName() || JSON.stringify(scan.range) !== JSON.stringify(ratingTimelineRange())) throw workError('比赛列表已过期，请重新读取时间范围');
    if (scan.baseline !== JSON.stringify(userStore().ratings)) throw workError('本地 Rating 数据或命令草稿已变化，请重新读取后核对');
    const selected = new Set($$('[data-rating-id]:checked').map(input => input.dataset.ratingId)), rows = scan.rows.filter(row => selected.has(row.id));
    if (!rows.length || rows.length > 200) throw workError('请选择 1–200 场比赛');
    const form = $('#exhloj-rating-timeline-form'), weight = localNumber(form.elements.weight.value, 'Rating 权重', 0, 10), version = +form.elements.version.value;
    if (![1, 2].includes(version)) throw workError('参赛选手筛选方式无效');
    return rows.map(row => ratedCommand(row.id, row.title, weight, version)).join('\n');
  }
  async function calculateRatingTimeline() {
    const text = selectedRatingTimeline();
    await calculateUserRatings(text, { restart: true, verify: () => {
      if (selectedRatingTimeline() !== text) throw workError('所选比赛或参数已变化，请重新结算');
    } });
    if (!workStates.user.errors?.length) ratingTimeline = undefined;
  }
  function parseRatedCommands(text, allowDraft = false) {
    const contests = [], groups = [], ids = new Map(); let version = 1;
    for (const [offset, raw] of String(text).split(/\r?\n/).entries()) {
      const line = raw.trim(); if (!line || line.startsWith('#')) continue;
      const split = line.indexOf(':'), op = line.slice(0, split), rest = line.slice(split + 1).trim();
      try {
        if (op === 'version') { if (!['1', '2'].includes(rest)) throw workError('仅支持 version:1 或 version:2'); version = +rest; }
        else if (op === 'contest') {
          const match = rest.match(/^([^,]+),([^,]*),([^,]+)(?:,(.*))?$/); if (!match) throw workError('比赛行格式不正确');
          const [, rawId, title, weight, participants] = match, id = rawId.trim(); ratedContestPath(id);
          if (ids.has(id)) throw workError('比赛不能重复定义');
          let users = null; if (participants?.trim()) { try { users = JSON.parse(participants); } catch { users = JSON.parse(participants.replace(/-/g, ',')); } users = validateRatedUsers(users); }
          ids.set(id, contests.length); contests.push({ id, title: title.trim(), weight: localNumber(weight, 'Rating 权重', 0, 10), users, version });
        } else if (op === 'rating') {
          const group = rest.split(',').map(id => id.trim()); if (!group.length || new Set(group).size !== group.length || group.some(id => !ids.has(id))) throw workError('结算引用了未定义或重复的比赛'); groups.push(group.map(id => ids.get(id)));
        } else throw workError('未知命令');
      } catch (error) { throw workError(`第 ${offset + 1} 行：${error.message}`); }
    }
    if (!allowDraft && (!contests.length || !groups.length)) throw workError('请至少定义一场比赛及一条 rating 结算命令');
    if (contests.length > 200) throw workError('一次至多结算 200 场比赛');
    const used = groups.flat(); if (new Set(used).size !== used.length) throw workError('同一比赛不能重复结算'); return { contests, groups };
  }
  function validateRatedUsers(rows) {
    if (!Array.isArray(rows) || !rows.length || rows.length > 1000) throw workError('每场比赛需要 1–1000 名选手');
    const seen = new Set(); return rows.map(row => {
      if (!Array.isArray(row) || row.length < 2) throw workError('名次格式应为 [[UID,排名],...]'); const uid = localUid(row[0]), rank = Number(row[1]);
      if (!Number.isInteger(rank) || rank < 1 || rank > rows.length || seen.has(uid)) throw workError('名次无效或用户重复'); seen.add(uid); return [uid, rank];
    });
  }
  function ratedUsersFromBoard(body, version) {
    if (!Array.isArray(body.rows)) throw workError('榜单未返回 rows，可能无查看权限');
    const result = [];
    for (const row of body.rows) {
      if (!Array.isArray(row)) continue; const uid = +row.find(cell => cell?.type === 'user')?.raw, rank = Number(textOnly(row.find(cell => cell?.type === 'rank')?.value));
      if (!(uid > 0) || !(rank > 0)) continue;
      const records = row.filter(cell => ['record', 'records'].includes(cell?.type)).flatMap(cell => cell.type === 'records' && Array.isArray(cell.raw) ? cell.raw.slice(0, 1) : [cell]);
      const submitted = records.some(cell => !!objectId(cell.raw)), scored = records.some(cell => cell.score !== undefined ? +cell.score > 0 : parseFloat(textOnly(cell.value)) > 0 || boardAccepts(cell, body.tdoc?.rule, 100).length);
      if (version === 1 ? scored : submitted) result.push([uid, rank]);
    }
    return validateRatedUsers(result);
  }
  async function calculateUserRatings(text, { restart = false, verify = () => {} } = {}) {
    if (!settings.userModule) throw workError('请先启用 user 模块');
    const plan = parseRatedCommands(text), original = userStore().ratings, baseline = JSON.stringify(original);
    if (userLoadError) throw workError(`本地数据格式异常，请先修复：${userLoadError}`);
    const saved = new Set(restart ? [] : original.contests.map(row => row[0])), allGroups = plan.groups.length;
    plan.groups = plan.groups.filter(group => {
      const count = group.filter(index => saved.has(plan.contests[index].id)).length;
      if (count && count !== group.length) throw workError('同一并行结算组含有已结算和未结算的比赛，请分开结算或使用时间轴重算');
      return !count;
    });
    const active = new Set(plan.groups.flat()), area = $('#exhloj-user-commands'), draft = area?.value;
    verify();
    return runWork('user', async (job, state) => {
      if (!plan.groups.length) { state.message = '命令中的比赛均已结算，保留原分数和历史；未重复读取榜单'; notify('没有需要新增结算的比赛'); return; }
      for (const index of active) {
        const contest = plan.contests[index]; if (contest.users) continue;
        const body = await jobJSON(job, ratedContestPath(contest.id) + '/scoreboard'); contest.users = ratedUsersFromBoard(body, contest.version);
      }
      const contests = restart ? [] : clone(original.contests), records = restart ? [] : clone(original.records), indices = new Map();
      const oldCount = records.length, currentRatings = new Map(records.map(row => [row[0], row[3]])), sum = values => values.reduce((a, b) => a + b, 0);
      for (const index of active) { const row = plan.contests[index]; indices.set(index, contests.length); contests.push([row.id, row.title, row.weight]); }
      const expected = (rows, uid, rating) => sum(rows.map(other => other.uid === uid ? 1 : 1 / (1 + 10 ** ((rating - other.old) / 400))));
      const search = (rows, uid, target, left, right) => { while (right - left > 0.1) { const mid = (left + right) / 2; if (expected(rows, uid, mid) > target) left = mid; else right = mid; } return (left + right) / 2; };
      for (const [groupIndex, group] of plan.groups.entries()) {
        checkJob(job); const chosen = new Map();
        for (const index of group) {
          const contest = plan.contests[index], rows = contest.users.map(([uid, rank]) => ({ uid, rank, old: currentRatings.get(uid) ?? USER_INITIAL_RATING }));
          const low = Math.min(...rows.map(row => row.old)) - 400, high = Math.max(...rows.map(row => row.old)) + 400;
          for (const [i, row] of rows.entries()) {
            if (i % 8 === 0) { state.message = `结算 ${groupIndex + 1}/${plan.groups.length} 组 · ${contest.title || contest.id} · ${i}/${rows.length}`; updateWorkProgress('user'); await pauseWork(0, job.controller.signal); checkJob(job); }
            const target = Math.sqrt(expected(rows, row.uid, row.old) * row.rank), diff = (search(rows, row.uid, target, -5000, 10000) - row.old) / 2,
              performance = Math.round(search(rows, row.uid, row.rank, low, high)), candidate = { ...row, index, diff, performance, weight: contest.weight }, prior = chosen.get(row.uid);
            if (!prior || prior.diff * prior.weight < diff * contest.weight) chosen.set(row.uid, candidate);
          }
        }
        const values = [...chosen.values()], correction = 1 - sum(values.map(row => row.diff)) / values.length;
        for (const row of values) { const rating = row.old + Math.round((row.diff + correction) * row.weight); currentRatings.set(row.uid, rating); records.push([row.uid, indices.get(row.index), row.rank, rating, row.performance]); }
      }
      checkJob(job); const store = userStore();
      if (JSON.stringify(store.ratings) !== baseline) throw workError('本地 Rating 数据或命令草稿已变化，未覆盖新数据；请核对后重新结算');
      if (area?.isConnected && area.value !== draft) throw workError('命令草稿已变化，未保存本次结果；请核对后重新结算');
      verify();
      writeUserStore(store.users, { contests, records, commands: text });
      const summary = $('#exhloj-rating-summary'); if (summary) summary.textContent = ratingSummary();
      state.message = `已${restart ? '从 1800 重新' : '追加'}结算 ${active.size} 场比赛、${records.length - oldCount} 条记录${allGroups > plan.groups.length ? `；跳过 ${allGroups - plan.groups.length} 个已结算组` : ''}。${ratingSummary()}`; notify('Rating 已在本机保存');
    }, true);
  }
  function importPracticeToUsers() {
    const result = workStates.juan.result; if (!result?.complete) throw workError('请先在卷王监视器完成一次完整统计');
    const { users, ratings } = userStore(), next = clone(users); for (const row of result.rows) next.practice[row.uid] = row.total;
    writeUserStore(next, ratings); notify(`已更新 ${result.rows.length} 人的本地题目分`);
  }
  const localUserAPI = Object.freeze({ getData: () => clone(userExportData()), getRating: userRating, open: openUserTools,
    edit: openUserEditor, history: openUserHistory, ranking: mode => clone(userRanking(mode)), calculate: calculateUserRatings });


  // 下面的权限位与描述取自原 Extend HLOJ 1.16.1，不改变站点权限。
  const PERMISSIONS = [
  {
    "name": "PERM_VIEW",
    "bit": 0,
    "description": "View this domain"
  },
  {
    "name": "PERM_VIEW_DISPLAYNAME",
    "bit": 67,
    "description": "View domain user displayname"
  },
  {
    "name": "PERM_EDIT_DOMAIN",
    "bit": 1,
    "description": "Edit domain settings"
  },
  {
    "name": "PERM_MOD_BADGE",
    "bit": 2,
    "description": "Show MOD badge"
  },
  {
    "name": "PERM_CREATE_PROBLEM",
    "bit": 4,
    "description": "Create problems"
  },
  {
    "name": "PERM_EDIT_PROBLEM",
    "bit": 5,
    "description": "Edit problems"
  },
  {
    "name": "PERM_EDIT_PROBLEM_SELF",
    "bit": 6,
    "description": "Edit own problems"
  },
  {
    "name": "PERM_VIEW_PROBLEM",
    "bit": 7,
    "description": "View problems"
  },
  {
    "name": "PERM_VIEW_PROBLEM_HIDDEN",
    "bit": 8,
    "description": "View hidden problems"
  },
  {
    "name": "PERM_SUBMIT_PROBLEM",
    "bit": 9,
    "description": "Submit problem"
  },
  {
    "name": "PERM_READ_PROBLEM_DATA",
    "bit": 10,
    "description": "Read data of problem"
  },
  {
    "name": "PERM_VIEW_RECORD",
    "bit": 70,
    "description": "View other's records"
  },
  {
    "name": "PERM_READ_RECORD_CODE",
    "bit": 12,
    "description": "Read all record codes"
  },
  {
    "name": "PERM_READ_RECORD_CODE_ACCEPT",
    "bit": 66,
    "description": "Read record codes after accept"
  },
  {
    "name": "PERM_REJUDGE_PROBLEM",
    "bit": 13,
    "description": "Rejudge problems"
  },
  {
    "name": "PERM_REJUDGE",
    "bit": 14,
    "description": "Rejudge records"
  },
  {
    "name": "PERM_VIEW_PROBLEM_SOLUTION",
    "bit": 15,
    "description": "View problem solutions"
  },
  {
    "name": "PERM_VIEW_PROBLEM_SOLUTION_ACCEPT",
    "bit": 65,
    "description": "View problem solutions after accept"
  },
  {
    "name": "PERM_CREATE_PROBLEM_SOLUTION",
    "bit": 16,
    "description": "Create problem solutions"
  },
  {
    "name": "PERM_VOTE_PROBLEM_SOLUTION",
    "bit": 17,
    "description": "Vote problem solutions"
  },
  {
    "name": "PERM_EDIT_PROBLEM_SOLUTION",
    "bit": 18,
    "description": "Edit problem solutions"
  },
  {
    "name": "PERM_EDIT_PROBLEM_SOLUTION_SELF",
    "bit": 19,
    "description": "Edit own problem solutions"
  },
  {
    "name": "PERM_DELETE_PROBLEM_SOLUTION",
    "bit": 20,
    "description": "Delete problem solutions"
  },
  {
    "name": "PERM_DELETE_PROBLEM_SOLUTION_SELF",
    "bit": 21,
    "description": "Delete own problem solutions"
  },
  {
    "name": "PERM_REPLY_PROBLEM_SOLUTION",
    "bit": 22,
    "description": "Reply problem solutions"
  },
  {
    "name": "PERM_EDIT_PROBLEM_SOLUTION_REPLY_SELF",
    "bit": 24,
    "description": "Edit own problem solution replies"
  },
  {
    "name": "PERM_DELETE_PROBLEM_SOLUTION_REPLY",
    "bit": 25,
    "description": "Delete problem solution replies"
  },
  {
    "name": "PERM_DELETE_PROBLEM_SOLUTION_REPLY_SELF",
    "bit": 26,
    "description": "Delete own problem solution replies"
  },
  {
    "name": "PERM_VIEW_DISCUSSION",
    "bit": 27,
    "description": "View discussions"
  },
  {
    "name": "PERM_CREATE_DISCUSSION",
    "bit": 28,
    "description": "Create discussions"
  },
  {
    "name": "PERM_HIGHLIGHT_DISCUSSION",
    "bit": 29,
    "description": "Highlight discussions"
  },
  {
    "name": "PERM_PIN_DISCUSSION",
    "bit": 61,
    "description": "Pin discussions"
  },
  {
    "name": "PERM_EDIT_DISCUSSION",
    "bit": 30,
    "description": "Edit discussions"
  },
  {
    "name": "PERM_EDIT_DISCUSSION_SELF",
    "bit": 31,
    "description": "Edit own discussions"
  },
  {
    "name": "PERM_LOCK_DISCUSSION",
    "bit": 64,
    "description": "Lock discussions"
  },
  {
    "name": "PERM_DELETE_DISCUSSION",
    "bit": 32,
    "description": "Delete discussions"
  },
  {
    "name": "PERM_DELETE_DISCUSSION_SELF",
    "bit": 33,
    "description": "Delete own discussions"
  },
  {
    "name": "PERM_REPLY_DISCUSSION",
    "bit": 34,
    "description": "Reply discussions"
  },
  {
    "name": "PERM_ADD_REACTION",
    "bit": 62,
    "description": "React to discussion"
  },
  {
    "name": "PERM_EDIT_DISCUSSION_REPLY_SELF",
    "bit": 36,
    "description": "Edit own discussion replies"
  },
  {
    "name": "PERM_DELETE_DISCUSSION_REPLY",
    "bit": 38,
    "description": "Delete discussion replies"
  },
  {
    "name": "PERM_DELETE_DISCUSSION_REPLY_SELF",
    "bit": 39,
    "description": "Delete own discussion replies"
  },
  {
    "name": "PERM_DELETE_DISCUSSION_REPLY_SELF_DISCUSSION",
    "bit": 40,
    "description": "Delete discussion replies of own discussion"
  },
  {
    "name": "PERM_VIEW_CONTEST",
    "bit": 41,
    "description": "View contests"
  },
  {
    "name": "PERM_VIEW_CONTEST_SCOREBOARD",
    "bit": 42,
    "description": "View contest scoreboard"
  },
  {
    "name": "PERM_VIEW_CONTEST_HIDDEN_SCOREBOARD",
    "bit": 43,
    "description": "View hidden contest submission status and scoreboard"
  },
  {
    "name": "PERM_CREATE_CONTEST",
    "bit": 44,
    "description": "Create contests"
  },
  {
    "name": "PERM_ATTEND_CONTEST",
    "bit": 45,
    "description": "Attend contests"
  },
  {
    "name": "PERM_EDIT_CONTEST",
    "bit": 50,
    "description": "Edit any contests"
  },
  {
    "name": "PERM_EDIT_CONTEST_SELF",
    "bit": 51,
    "description": "Edit own contests"
  },
  {
    "name": "PERM_VIEW_HIDDEN_CONTEST",
    "bit": 68,
    "description": "View all contests"
  },
  {
    "name": "PERM_VIEW_HOMEWORK",
    "bit": 52,
    "description": "View homework"
  },
  {
    "name": "PERM_VIEW_HOMEWORK_SCOREBOARD",
    "bit": 53,
    "description": "View homework scoreboard"
  },
  {
    "name": "PERM_VIEW_HOMEWORK_HIDDEN_SCOREBOARD",
    "bit": 54,
    "description": "View hidden homework submission status and scoreboard"
  },
  {
    "name": "PERM_CREATE_HOMEWORK",
    "bit": 55,
    "description": "Create homework"
  },
  {
    "name": "PERM_ATTEND_HOMEWORK",
    "bit": 56,
    "description": "Claim homework"
  },
  {
    "name": "PERM_EDIT_HOMEWORK",
    "bit": 57,
    "description": "Edit any homework"
  },
  {
    "name": "PERM_EDIT_HOMEWORK_SELF",
    "bit": 58,
    "description": "Edit own homework"
  },
  {
    "name": "PERM_VIEW_HIDDEN_HOMEWORK",
    "bit": 69,
    "description": "View all homework"
  },
  {
    "name": "PERM_VIEW_TRAINING",
    "bit": 46,
    "description": "View training plans"
  },
  {
    "name": "PERM_CREATE_TRAINING",
    "bit": 47,
    "description": "Create training plans"
  },
  {
    "name": "PERM_EDIT_TRAINING",
    "bit": 48,
    "description": "Edit training plans"
  },
  {
    "name": "PERM_PIN_TRAINING",
    "bit": 63,
    "description": "Pin training plans"
  },
  {
    "name": "PERM_EDIT_TRAINING_SELF",
    "bit": 49,
    "description": "Edit own training plans"
  },
  {
    "name": "PERM_VIEW_RANKING",
    "bit": 59,
    "description": "View ranking"
  }
];
  function permissionValue(doc) {
    const value = doc?.perm;
    if (typeof value === 'number' && !Number.isSafeInteger(value)) return null;
    if (!['number', 'bigint', 'string'].includes(typeof value)) return null;
    const text = String(value).replace(/^BigInt::/, '').trim();
    if (!text) return null;
    try { return BigInt(text); } catch { return null; }
  }
  function renderProfilePermissions(view, doc, bits, expanded) {
    const box = el('details', { id: 'exhloj-profile-permissions' }); box.open = expanded;
    const has = p => (bits & (1n << BigInt(p.bit))) !== 0n;
    const count = bits === null ? null : PERMISSIONS.filter(has).length;
    box.append(el('summary', {}, '拥有权限' + (count === null ? '（未知）' : '（' + count + '）')));
    view.append(box);
    if (doc?.role) box.append(el('p', {}, '当前域角色：' + doc.role));
    if (bits === null) { box.append(el('p', {}, '原站未提供此用户完整的当前域权限，无法判断。')); return; }
    const table = el('table'), head = el('tr'); head.append(el('th', {}, '权限'), el('th', {}, '状态')); table.append(head);
    for (const p of [...PERMISSIONS.filter(has), ...PERMISSIONS.filter(p => !has(p))]) {
      const row = el('tr'); row.append(el('td', { title: p.name }, translate(p.description)), el('td', {}, has(p) ? '✓' : '—')); table.append(row);
    }
    box.append(table);
  }

  const busyActions = new Set();
  document.addEventListener('click', event => {
    const control = event.target.closest?.('[data-exh-action]');
    if (!control) return;
    event.preventDefault();
    const action = control.dataset.exhAction;
    const profileView = control.closest('#exhloj-profile-view');
    if (profileView) {
      syncPageContext();
      if (!profileView.closest('dialog[open]') || +profileView.dataset.uid !== userProfileId() || pageName() !== 'user_detail') return;
    }
    if (titlePopup?.contains(control) || control.closest('#exhloj-local-remote')) {
      const epoch = routeEpoch; syncPageContext();
      if (epoch !== routeEpoch && action !== 'problem-copy') { schedule(); return; }
      if (titlePopup?.contains(control)) closeTitleMenu(true);
    }
    if (busyActions.has(action)) return;
    busyActions.add(action);
    task(async () => {
      switch (action) {
        case 'settings': openHome(); break;
        case 'panel-tab': openPanelSection(control.dataset.panelTab); break;
        case 'panel-settings': openSettings(); break;
        case 'panel-data': openDataTools(); break;
        case 'panel-remote': openRemoteTools(); break;
        case 'panel-attend': openSettings('attendance'); break;
        case 'editor-settings': openSettings('editors'); break;
        case 'close': $('#exhloj-local-dialog')?.close(); break;
        case 'reload': location.reload(); break;
        case 'save-settings': {
          const form = $('#exhloj-local-settings');
          if (!form.reportValidity()) return;
          const value = { ...settings, ui: form.elements.ui.checked, options: { ...settings.options } };
          for (const key of ['cphPort', 'editorPort']) if (!form.elements[key].disabled) value[key] = +form.elements[key].value;
          for (const key of ['captcha', 'remote', 'captchaHide', 'captchaRemember', 'remoteAuto', 'contestHelper', 'homeworkPlanner', 'juanMonitor', 'autoAttend', 'userModule']) value[key] = form.elements[key].checked;
          for (const key of ['helperDelay', 'helperPageLimit', 'helperRequestLimit', 'autoAttendInterval']) value[key] = +form.elements[key].value;
          for (const key of ['autoAttendTargets', 'autoAttendTitle', 'autoAttendRules']) value[key] = form.elements[key].value;
          value.remoteContest = form.elements.remoteContest.value; value.remoteColor = form.elements.remoteColor.value;
          for (const key of Object.keys(OPTIONS)) if (!Object.hasOwn(RANKING_OPTIONS, key)) value.options[key] = form.elements[key].checked;
          const next = normalizeSettings(value); save(SETTINGS_KEY, next); settings = next;
          refresh();
          notify('设置已保存，刷新页面后完整生效'); break;
        }
        case 'export': download('exhloj-backup.json', JSON.stringify(exportData(), null, 2)); break;
        case 'import': importData($('#exhloj-local-import').value); notify('导入成功，刷新页面后完整生效'); break;
        case 'legacy': {
          const value = {};
          for (const key of LEGACY_KEYS) { const data = stored(key, null); if (data !== null) value[key] = data; }
          if (!Object.keys(value).length) throw new Error('此脚本的存储中没有旧版缓存；请从旧脚本导出 JSON 后导入');
          save(CACHE_KEY, { ...validateCache(stored(CACHE_KEY, {})), ...value }); notify('已保留旧版缓存'); break;
        }
        case 'view-cache': { const body = modal('备份内容', 'data'); body.append(el('pre', {}, JSON.stringify(exportData(), null, 2))); break; }
        case 'problem-copy': await copyText(markdownContent((await problemDocument()).content)); break;
        case 'solution-copy': await copySolution(control); break;
        case 'cph': case 'editor': {
          if (!enabled(action)) break;
          const payload = await cphPayload();
          if (!enabled(action)) break;
          await sendLocal(action === 'cph' ? settings.cphPort : settings.editorPort, payload);
          notify(`已发送到 ${action === 'cph' ? 'CPH' : 'CP Editor'}（${payload.tests.length} 组样例）`); break;
        }
        case 'avatar-save': await saveAvatar(); break;
        case 'profile-info': openProfileInfo(control); break;
        case 'user-open': openUserTools(); break;
        case 'user-edit': openUserEditor(control.dataset.uid || $('#exhloj-user-id')?.value); break;
        case 'user-history': openUserHistory(control.dataset.uid || $('#exhloj-user-id')?.value); break;
        case 'user-ranking': openUserRanking(control.dataset.mode || 'current'); break;
        case 'user-rate-current': await rateCurrentContest(); break;
        case 'user-timeline': openRatingTimeline(); break;
        case 'user-timeline-scan': await scanRatingTimeline(); break;
        case 'user-timeline-calculate': await calculateRatingTimeline(); break;
        case 'user-timeline-select': for (const input of $$('[data-rating-id]')) input.checked = control.dataset.checked === 'true'; break;
        case 'user-save': saveUserEditor(); break;
        case 'user-oier-quick-open': openQuickOIerImport(); break;
        case 'user-oier-quick-scan': await scanQuickOIerImport(); break;
        case 'user-oier-quick-apply': applyQuickOIerImport(control.dataset.uid ? localUid(control.dataset.uid) : undefined); break;
        case 'user-oier-quick-select': case 'user-oier-quick-remove': case 'user-oier-quick-page': changeQuickOIerQueue(action, control); break;
        case 'user-oier-import': await fillUserFromOIerLink($('#exhloj-user-editor')); break;
        case 'user-oier-refresh': await refreshOIerUsers(localUid(control.dataset.uid), control); break;
        case 'user-oier-refresh-all': await refreshOIerUsers(undefined, control); break;
        case 'user-clear': saveUserEditor(true); break;
        case 'user-fetch-name': {
          const form = $('#exhloj-user-editor'), uid = localUid(form.dataset.uid), data = await requestJSON(`/user/${uid}`);
          if (!data.udoc?.uname) throw workError('OJ 没有返回用户名');
          if (form.isConnected) form.elements.uname.value = data.udoc.uname; notify('已读取用户名，点击保存后写入本地'); break;
        }
        case 'user-options-save': {
          const form = $('#exhloj-user-options'), next = normalizeSettings({ ...settings, userDisplay: form.elements.display.value, userCCF: form.elements.ccf.checked });
          save(SETTINGS_KEY, next); settings = next; refreshUserNames(); notify('名字显示设置已保存'); break;
        }
        case 'user-json': openUserJSON(); break;
        case 'user-json-save': importUserJSON($('#exhloj-user-json').value); break;
        case 'user-export': download('exhloj-user-data.json', JSON.stringify(userExportData(), null, 2)); break;
        case 'user-rated': openUserRated(); break;
        case 'user-commands-save': {
          const { users, ratings } = userStore(); writeUserStore(users, { ...ratings, commands: $('#exhloj-user-commands').value }); notify('结算命令草稿已保存'); break;
        }
        case 'user-calculate': await calculateUserRatings($('#exhloj-user-commands').value); break;
        case 'user-practice': importPracticeToUsers(); break;
        case 'captcha-history': showCaptchaHistory(); break;
        case 'captcha-clear': save(CAPTCHA_KEY, []); showCaptchaHistory(); break;
        case 'captcha-retry': runCaptcha(true); break;
        case 'captcha-toggle': {
          const state = [...$$('input[name="captcha"]')].map(input => captchaStates.get(input)).find(state => state?.tools === control.closest('.exhloj-captcha-tools'));
          if (state) captchaVisible(state, state.collapsed); break;
        }
        case 'remote-meta': {
          const state = stateFor(control); await loadRemoteMeta(state, true);
          if (state.local && state === remoteState) notify(state.messages.join('；'), state.metaError);
          break;
        }
        case 'remote-config': configureOrigin(); break;
        case 'remote-search': openSemanticSearch(); break;
        case 'remote-search-run': await runSemanticSearch(); break;
        case 'remote-search-cancel': semanticPanel?.controller?.abort(); break;
        case 'remote-search-copy': assertSearchPanel(semanticPanel); await copyText($('#exhloj-search-query').value); break;
        case 'remote-search-fill': await fillSearchStatement(); break;
        case 'remote-search-select': selectSearchCandidate(control); break;
        case 'remote-save-origin': saveOrigin(); break;
        case 'remote-reset-origin': saveOrigin(true); break;
        case 'luogu-tool': openLuoguTool($('#exhloj-luogu-id').value); break;
        case 'remote-statement': {
          const state = stateFor(control);
          if (!state.problem) state.problem = await luoguProblem(state.origin.luoguId);
          state.showStatement = !state.showStatement; renderRemote(state); break;
        }
        case 'remote-solutions': {
          const state = stateFor(control);
          if (!state.solutionPage) await loadRemoteSolutions(state);
          else { state.showSolutions = !state.showSolutions; renderRemote(state); } break;
        }
        case 'remote-more': await loadRemoteSolutions(stateFor(control)); break;
        case 'remote-export': await exportRemote(stateFor(control)); break;
        case 'remote-copy-statement': await copyText(stateFor(control).problem?.statement); break;
        case 'remote-copy-solution': await copyText(stateFor(control).solutions[+control.dataset.index]?.content); break;
        case 'remote-code': await loadSubmissionCode(control); break;
        case 'contest-helper': openContestHelper(); break;
        case 'homework-plan-open': if (pageName() === 'homework_main' && settings.homeworkPlanner) openHomeworkPlanner(); break;
        case 'contest-statements': await exportContestStatements(contestInput()); break;
        case 'contest-records-csv': await exportContestRecords(contestInput(), 'csv'); break;
        case 'contest-records-json': await exportContestRecords(contestInput(), 'json'); break;
        case 'contest-ghost': await exportContestRecords(contestInput(), 'ghost'); break;
        case 'work-cancel': workJobs.get(control.dataset.kind)?.controller.abort(); break;
        case 'attend-preview': await checkAttendance(); break;
        case 'attend-one': {
          const candidate = workStates.auto.candidates?.[+control.dataset.index]; if (!candidate) throw workError('报名列表已变化，请重新检查');
          await runWork('auto', async (job, state) => { await attendOne(job, candidate); state.candidates = state.candidates.filter(x => x.key !== candidate.key); state.message = `已报名 ${candidate.title}`; renderAttendCandidates(); }); break;
        }
        case 'juan-open': openJuanMonitor(); break;
        case 'juan-start': await scanJuan(monitorFormSettings()); break;
        case 'juan-domains': {
          const result = await requestJSON('/home/domain'); if (!Array.isArray(result.ddocs)) throw workError('接口未返回可访问域');
          const selected = new Set(domainList($('#exhloj-juan-form').elements.domains.value)); const box = $('#exhloj-juan-domains'); box.replaceChildren();
          for (const doc of result.ddocs) { const label = el('label'), input = el('input', { type: 'checkbox', 'data-juan-domain': doc._id }); input.checked = selected.has(doc._id); label.append(input, `${doc.name || doc._id} (${doc._id})`); box.append(label); } break;
        }
        case 'juan-csv': { const result = juanResult(); download('exhloj-practice.csv', csvContent(['uid', 'name', 'totalAC', 'periodAC', 'newSinceSnapshot'], result.rows.map(row => [row.uid, row.name, row.total, row.recent, row.added])), 'text/csv;charset=utf-8'); break; }
        case 'juan-json': download('exhloj-practice.json', JSON.stringify(juanResult(), null, 2)); break;
        case 'juan-copy': { const result = juanResult(); await copyText(`卷王榜（${result.complete ? '完整扫描' : '部分数据'}，${result.period} 天内 AC）\n` + result.rows.slice(0, 100).map((row, i) => `${i + 1}. ${row.name}：区间 ${row.recent}，累计 ${row.total}${row.added === null ? '' : `，新增 ${row.added}`}`).join('\n')); break; }
      }
    }).finally(() => busyActions.delete(action));
  });
  document.addEventListener('change', event => {
    if (event.target.matches?.('[data-juan-domain]')) {
      const form = $('#exhloj-juan-form'); if (form) form.elements.domains.value = $$('[data-juan-domain]:checked').map(input => input.dataset.juanDomain).join('\n'); return;
    }
    if (event.target.id !== 'exhloj-local-import-file') return;
    const file = event.target.files[0]; if (!file) return;
    task(async () => {
      if (file.size > LIMIT) throw new Error('导入文件超过 2 MiB');
      $('#exhloj-local-import').value = await file.text(); notify('文件已读取，点击“导入 JSON”应用');
    });
  });
  document.addEventListener('keydown', event => {
    if (settings.remote && settings.remoteContest === 'shortcut' && pageName() === 'contest_detail_problem' && event.ctrlKey && event.key.toLowerCase() === 'q' && !event.target.closest?.('input,textarea,[contenteditable]')) {
      event.preventDefault(); contestRevealed = !contestRevealed;
      clearLocalRemote(); remoteProblem(); syncTitleTools();
    }
  });

  // Only validated planner projections are cached; raw Hydro pages can contain session/user details.
  const HOMEWORK_PLAN_CACHE_TTL = 10 * 60 * 1000;
  const HOMEWORK_PLAN_CACHE_KEY = 'exhloj.local.homework-plan.responses.v1';
  const HOMEWORK_PLAN_CACHE_CHARS = 1024 * 1024, HOMEWORK_PLAN_CACHE_ITEMS = 256;
  const homeworkPlanCache = (() => {
    let memory = [];
    const inflight = new Map(), localMarks = new Map();
    const fresh = (stamp, now) => Number.isFinite(stamp) && stamp <= now && now - stamp < HOMEWORK_PLAN_CACHE_TTL;
    const markerKey = scope => HOMEWORK_PLAN_CACHE_KEY + '.reset.' + scope;
    function revision(scope) {
      const local = localMarks.get(scope);
      try {
        const rawMark = GM_getValue(markerKey(scope), ''), storedMark = typeof rawMark === 'string' ? rawMark : '';
        // A failed marker write must still invalidate local requests. A newer marker from
        // another tab supersedes our local fallback.
        return local && storedMark === local.previous ? local.mark : storedMark;
      } catch { return local?.mark || ''; }
    }
    function load() {
      try {
        const raw = GM_getValue(HOMEWORK_PLAN_CACHE_KEY, '');
        if (typeof raw !== 'string' || !raw || raw.length > HOMEWORK_PLAN_CACHE_CHARS) return [];
        const rows = JSON.parse(raw);
        return Array.isArray(rows) ? rows.filter(r => Array.isArray(r) && r.length === 5 &&
          typeof r[0] === 'string' && typeof r[1] === 'string' && typeof r[2] === 'string' && typeof r[4] === 'string') : [];
      } catch { return []; }
    }
    // Newest first. Bound the actual encoded storage size as well as the number of URLs.
    function bounded(rows, now) {
      let size = 2; const kept = [];
      for (const r of rows) {
        if (!fresh(r[3], now) || r[4].length > HOMEWORK_PLAN_CACHE_CHARS) continue;
        const cost = JSON.stringify(r).length + 1;
        if (size + cost > HOMEWORK_PLAN_CACHE_CHARS) continue;
        kept.push(r); size += cost;
        if (kept.length === HOMEWORK_PLAN_CACHE_ITEMS) break;
      }
      return kept;
    }
    function write(rows) { GM_setValue(HOMEWORK_PLAN_CACHE_KEY, JSON.stringify(rows)); }
    function remember(row) {
      const now = Date.now(), other = r => r[0] !== row[0] || r[1] !== row[1];
      memory = bounded([row, ...memory.filter(other)], now);
      // A full/disabled persistent store must not turn a successful request into an error.
      try { write(bounded([row, ...load().filter(other)], now)); } catch {}
    }
    function reset(scope) {
      const mark = `${Date.now()}:${Math.random()}`;
      let previous = ''; try { previous = GM_getValue(markerKey(scope), '') || ''; } catch {}
      localMarks.set(scope, { previous, mark });
      for (const [id, flight] of inflight) if (flight.scope === scope) { flight.dead = true; inflight.delete(id); }
      memory = memory.filter(r => r[0] !== scope);
      // A separate per-scope marker prevents an earlier request in a different tab from repopulating
      // a reset cache. Even if the old payload temporarily survives, its generation cannot be read.
      let marked = false;
      try { GM_setValue(markerKey(scope), mark); marked = true; } catch {}
      try { write(bounded(load().filter(r => r[0] !== scope), Date.now())); }
      catch { if (!marked) throw workError('无法清除持久缓存，请检查脚本存储后重试'); }
    }
    function cached(scope, key, mark) {
      const now = Date.now(), match = r => r[0] === scope && r[1] === key && r[2] === mark && fresh(r[3], now);
      const r = memory.find(match) || load().find(match);
      if (r) { try { return { data: JSON.parse(r[4]), json: r[4] }; } catch { /* corrupted projection: refetch */ } }
    }
    async function read(scope, key, guard, fetchProjection, signal) {
      guard();
      const mark = revision(scope), hit = cached(scope, key, mark);
      if (hit) {
        await Promise.resolve(); guard();
        if (revision(scope) !== mark) throw workError('补题缓存已重置，请重新查找');
        return hit.data;
      }
      const id = JSON.stringify([scope, key, mark]);
      let flight = inflight.get(id);
      if (!flight) {
        flight = { scope, dead: false };
        const verify = () => {
          guard();
          if (flight.dead || revision(scope) !== mark) throw workError('补题缓存已重置，请重新查找');
        };
        const compute = async (recheck = false) => {
          verify();
          // Another tab may have filled this entry while this tab was waiting for its lock.
          const ready = recheck && cached(scope, key, mark); if (ready) return ready.json;
          const value = await fetchProjection();
          verify();
          const json = JSON.stringify(value);
          if (typeof json !== 'string') throw workError('作业接口数据不完整，未缓存');
          remember([scope, key, mark, Date.now(), json]); return json;
        };
        flight.result = Promise.resolve().then(async () => {
          let entered = false;
          try {
            const locks = globalThis.navigator?.locks;
            if (locks?.request) return await locks.request(HOMEWORK_PLAN_CACHE_KEY + ':' + id, signal ? { signal } : {},
              () => { entered = true; return compute(true); });
          } catch (error) { if (entered || signal?.aborted) throw error; }
          return compute();
        }).finally(() => { if (inflight.get(id) === flight) inflight.delete(id); });
        inflight.set(id, flight);
      }
      const result = await flight.result;
      guard();
      if (flight.dead || revision(scope) !== mark) throw workError('补题缓存已重置，请重新查找');
      return JSON.parse(result);
    }
    return { read, reset, revision };
  })();

  function homeworkPlanCacheScope(domain) {
    const uid = +user()._id;
    if (!Number.isSafeInteger(uid) || uid <= 0) throw workError('请先登录 OJ');
    if (typeof domain !== 'string' || !domain || domain !== domainId()) throw workError('当前域已变化，请重新查找');
    return JSON.stringify([location.origin, domain, uid]);
  }
  function resetHomeworkPlanCache(domain = domainId()) { homeworkPlanCache.reset(homeworkPlanCacheScope(domain)); }
  function homeworkPlanCacheRevision(domain = domainId()) { return homeworkPlanCache.revision(homeworkPlanCacheScope(domain)); }
  function homeworkPlanCachePath(domain, path, uid) {
    const u = new URL(path, location.origin), parts = u.pathname.replace(/\/$/, '').split('/');
    const allowedPage = v => /^[1-9]\d{0,5}$/.test(v);
    const id = v => /^(?:[\da-f]{24}|[1-9]\d{0,15})$/i.test(v);
    if (u.origin !== location.origin || u.username || u.password || u.hash || parts[1] !== 'd' || decodeURIComponent(parts[2] || '') !== domain)
      throw workError('补题查询只允许读取当前域');
    const [kind, arg, suffix] = parts.slice(3);
    // Reading a homework detail can start a timed assignment. Only its list and scoreboard are read.
    const hw = kind === 'homework' && (parts.length === 4 || (parts.length === 6 && id(arg) && suffix === 'scoreboard'));
    const profile = parts.length === 5 && kind === 'user' && arg === String(uid);
    const problem = parts.length === 5 && kind === 'p' && /^[\p{L}\p{N}_.-]{1,100}$/u.test(decodeURIComponent(arg));
    if (!hw && !profile && !problem) throw workError('不支持的补题查询地址');
    for (const [k, v] of u.searchParams) {
      if (u.searchParams.getAll(k).length !== 1 || !(hw && k === 'page' && allowedPage(v)))
        throw workError('不支持的补题查询参数');
    }
    u.searchParams.sort(); return u.pathname + u.search;
  }
  async function homeworkPlanRead(job, domain, path, view, project) {
    const scope = homeworkPlanCacheScope(domain), keyPath = homeworkPlanCachePath(domain, path, job.owner);
    if (typeof view !== 'string' || !/^[a-zA-Z][\w.-]{0,63}$/.test(view) || typeof project !== 'function') throw workError('补题缓存数据类型无效');
    const guard = () => {
      checkJob(job);
      if (scope !== homeworkPlanCacheScope(domain)) throw workError('账号或域已变化，请重新查找');
    };
    return homeworkPlanCache.read(scope, JSON.stringify([view, keyPath]), guard,
      async () => { const body = await jobJSON(job, keyPath); guard(); return project(body); }, job.controller?.signal);
  }

  // The reader stores only the validated projection, scoped to this domain and account.
  const scanHomeworkPlan = (() => {
    const obj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
    const own = (v, k) => Object.prototype.hasOwnProperty.call(v || {}, k);
    const fail = message => { throw new Error(message); };
    const trim = v => typeof v === 'string' ? v.trim().slice(0, 250) : '';
    const nat = v => (typeof v === 'number' || typeof v === 'string' && /^\d+$/.test(v)) && Number.isSafeInteger(+v) && +v >= 0;
    const id = v => {
      if (obj(v)) v = v.docId ?? v.$oid ?? v.pid;
      const s = String(v ?? '').replace(/^ObjectId::/, '');
      return /^[\w-]{1,100}$/.test(s) ? s : '';
    };
    function date(v) {
      if (obj(v)) v = v.$date;
      if (v === '' || v == null) return null;
      const n = typeof v === 'number' ? (v < 1e11 ? v * 1000 : v) : Date.parse(v);
      return Number.isFinite(n) ? n : null;
    }
    function confirmDomain(v, domain) {
      if (v?.domainId != null && String(v.domainId) !== domain) fail('返回的数据不属于当前域');
    }
    function homework(doc, domain, expected) {
      if (!obj(doc)) fail('缺少作业信息');
      const key = id(doc.docId ?? doc._id);
      if (!key || expected && key !== expected || doc.rule && doc.rule !== 'homework') fail('作业标识或类型不符');
      confirmDomain(doc, domain);
      return { id: key, title: trim(doc.title) || key, begin: date(doc.beginAt) };
    }
    function pageInfo(v, page, list = false) {
      if (v.page != null && (!nat(v.page) || +v.page !== page)) fail('返回了错误的页码');
      const count = v.pageCount ?? (list ? v.tpcount : v.spcount) ?? v.totalPages;
      if (count == null) return null;
      if (!nat(count) || +count < page && !(page === 1 && +count === 0)) fail('分页信息无效');
      return +count;
    }
    function profile(body, uid, domain) {
      // Hydro user_detail.pdocs is the list of accepted problems. pdict/psdocs on this page are editorials.
      const who = body.udoc?._id ?? body.udoc?.uid;
      if (body.isSelfProfile === false || who != null && (!nat(who) || +who !== uid)) throw Object.assign(new Error('登录身份与当前账号不符，已停止查询'), { accountMismatch:true });
      if (!nat(who) || !Array.isArray(body.pdocs)) fail('无法确认当前账号的通过列表');
      const solved = new Set();
      for (const p of body.pdocs) {
        const pid = id(p?.docId ?? p?.pid);
        if (!pid) fail('通过列表有无法识别的题号');
        confirmDomain(p, domain); solved.add(pid);
      }
      // The profile's nAccept counts practice ACs only; equality cannot certify coverage of hidden or contest ACs.
      // Positive pdocs prove the account can view problems. This covers visible problems only, on the native, unpaged profile.
      const visible = body.isSelfProfile === true && solved.size > 0 && !body.hasMore && !body.truncated && !(body.pageCount > 1) &&
        !(body.page > 1) && !(nat(body.udoc.nAccept) && +body.udoc.nAccept > solved.size);
      return { solved: [...solved], visible, selfVerified:body.isSelfProfile === true };
    }
    function problemStatus(body, pid, uid, domain) {
      if (!obj(body.pdoc) || id(body.pdoc.docId ?? body.pdoc.pid) !== pid || body.tdoc || (body.mode && body.mode !== 'normal') || !own(body, 'psdoc')) fail('题库未返回可核实的本人状态');
      confirmDomain(body.pdoc, domain);
      const ps = body.psdoc;
      if (ps === null) return { ac: false, ownerVerified:false };
      if (!obj(ps) || ps.uid != null && +ps.uid !== uid || ps.docId != null && id(ps.docId) !== pid) fail('个人题目状态与请求不符');
      confirmDomain(ps, domain);
      if (ps.status == null) {
        // A star-only document has no submissions. An unknown record must not become an unsolved problem.
        if (typeof ps.star === 'boolean' && !ps.rid) return { ac: false, ownerVerified:+ps.uid === uid };
        fail('个人题目状态缺少评测结果');
      }
      if (!nat(ps.status)) fail('无法识别个人评测结果');
      return { ac: +ps.status === 1, ownerVerified:+ps.uid === uid };
    }
    function verdict(cell) {
      if (cell == null || obj(cell) && !Object.keys(cell).length) return false;
      if (!obj(cell)) return null;
      if (cell.type === 'records' && Array.isArray(cell.raw)) {
        const parts = cell.raw.map(verdict);
        return parts.includes(true) ? true : parts.includes(null) ? null : false;
      }
      const raw = obj(cell.raw) ? cell.raw : {};
      const status = raw.status ?? cell.status;
      if (status != null) return nat(status) ? +status === 1 : null;
      const score = cell.score ?? raw.score;
      if (score != null && score !== '' && Number.isFinite(+score)) return +score === 100;
      // Homework displays penalized score / original score followed by elapsed time. Only original score indicates AC.
      const first = String(cell.value ?? '').trim().split(/\r?\n/)[0].trim();
      if (!first || /^[-–—]$/.test(first)) return cell.raw == null ? false : null;
      const m = /^(\d+(?:\.\d+)?)(?:\s*\/\s*(\d+(?:\.\d+)?))?$/.exec(first);
      return m ? +(m[2] ?? m[1]) === 100 : null;
    }
    function explicitAC(cell) {
      if (cell?.type === 'records' && Array.isArray(cell.raw)) return cell.raw.some(explicitAC);
      return +(cell?.raw?.status ?? cell?.status) === 1;
    }
    function boardPage(body, task, page, domain, uid) {
      const doc = body.tdoc;
      if (!obj(doc) || doc.rule && doc.rule !== 'homework' || doc.docId != null && id(doc.docId) !== task.id) fail('不是所请求作业的榜单');
      confirmDomain(doc, domain);
      if (!Array.isArray(body.rows) || !Array.isArray(body.rows[0])) fail('榜单缺少表头或不可见');
      const pages = pageInfo(body, page), header = body.rows[0], columns = [];
      const seen = new Set(), roster = new Set();
      for (const [i, cell] of header.entries()) if (cell?.type === 'problem') {
        const pid = id(cell.raw);
        if (!pid || seen.has(pid)) fail('榜单题号不完整或重复');
        seen.add(pid); const p = body.pdict?.[pid] || {}; confirmDomain(p, domain);
        if (p.docId != null && id(p.docId) !== pid) fail('榜单题号与题目详情不一致');
        // On a Hydro homework scoreboard (only here), nAccept counts distinct students with an actual AC in their journal.
        const official = doc.rule === 'homework' && nat(p.nAccept) ? +p.nAccept : null;
        columns.push({ i, pid, title: trim(p.title) || trim(cell.title) || trim(p.pid) || pid,
          official, public: p.hidden === false, hidden: p.hidden === true, counted: new Set(), self: false, exact: true });
      }
      if (Array.isArray(doc.pids) && (doc.pids.length !== seen.size || doc.pids.some(p => !seen.has(id(p))))) fail('榜单题目列不全');
      if (!columns.length && (!Array.isArray(doc.pids) || doc.pids.length)) fail('无法识别榜单题目列');
      const ui = header.findIndex(c => c?.type === 'user');
      if (columns.length && ui < 0) fail('榜单没有用户列');
      for (const row of body.rows.slice(1)) {
        if (!Array.isArray(row)) fail('榜单行格式无效');
        const raw = row[ui]?.raw, who = obj(raw) ? raw._id ?? raw.uid : raw;
        if (!nat(who) || +who === 0) fail('榜单行没有可核实的用户 ID');
        roster.add(+who);
        for (const col of columns) {
          const result = col.i >= row.length ? null : verdict(row[col.i]);
          if (result === null) col.exact = false;
          if (result === true) col.counted.add(+who);
          if (+who === uid && explicitAC(row[col.i])) col.self = true;
        }
      }
      const paged = pages > 1;
      return { pages, begin:date(doc.beginAt), roster: paged ? [...roster] : [], problems: columns.map(c => {
        if (!paged && c.official === null && !c.exact) fail('无法核实题目 '+c.pid+' 的通过人数');
        return { pid:c.pid, title:c.title, public:c.public, hidden:c.hidden, self:c.self, exact:c.exact, official:paged ? c.official : null,
          passed:c.official ?? c.counted.size, solvers:paged ? [...c.counted] : [] };
      }) };
    }
    return async function ({ domain, uid, start, end, threshold, read, pageLimit = 100, check = () => {}, onProgress = () => {} }) {
      uid = Number(uid); threshold = Number(threshold); pageLimit = Number(pageLimit);
      if (!domain || !Number.isSafeInteger(uid) || uid <= 0 || !Number.isFinite(start) || !Number.isFinite(end) || start >= end ||
          !Number.isSafeInteger(pageLimit) || pageLimit < 1 || pageLimit > 1000 || !Number.isSafeInteger(threshold) || threshold < 1 || typeof read !== 'function') fail('请输入有效日期、正整数人数阈值，并登录当前域');
      const base = '/d/' + encodeURIComponent(domain), home = base + '/homework', warnings = [];
      const docs = new Map(), selfAC = new Set(), candidates = new Map(); let scanned = 0, matched = 0;
      const link = (p, tid) => base + '/p/' + encodeURIComponent(p) + (tid ? '?tid='+encodeURIComponent(tid) : '');
      const warn = (label, error) => {
        check(); if (error?.budget || error?.accountMismatch || error?.name === 'AbortError') throw error;
        warnings.push(label+'：'+(error?.message || '读取失败'));
      };
      const get = async (path, view, project) => { check(); const v = await read(path, view, project); check(); return v; };
      let listPages;
      for (let n = 1; ; n++) {
        try {
          if (n > pageLimit) fail('已达到 '+pageLimit+' 页上限，列表不完整');
          onProgress('正在读取作业列表，第 '+n+' 页');
          const page = await get(home+'?page='+n,'list-v1', b => {
            if (!Array.isArray(b?.tdocs)) fail('作业列表未返回');
            return { pages:pageInfo(b,n,true), docs:b.tdocs.map(d => homework(d,domain)) };
          });
          if (n === 1) listPages = page.pages;
          if (listPages !== page.pages) fail('分页总数在读取中发生变化');
          if (!page.docs.length) {
            if (listPages != null && (n < listPages || n > 1)) fail('分页中出现意外的空页');
            break;
          }
          if (listPages === 0) fail('非空列表的页数为 0');
          const before = docs.size;
          for (const d of page.docs) if (!docs.has(d.id)) docs.set(d.id,d);
          if (before === docs.size) fail('列表重复返回上一页');
          if (listPages != null && n >= listPages) break;
        } catch(e) { warn('作业列表第 '+n+' 页',e); break; }
      }
      for (let task of docs.values()) {
        const url = home + '/' + encodeURIComponent(task.id);
        try {
          // The homework detail GET may set startAt on a claimed timed assignment. Only inspect its scoreboard.
          if (task.begin !== null && (task.begin < start || task.begin >= end)) continue;
          if (task.begin !== null) matched++;
          onProgress('正在读取作业榜单：'+task.title);
          const first = await get(url+'/scoreboard','board-v1',b=>boardPage(b,task,1,domain,uid));
          if (task.begin === null) {
            if (first.begin === null) fail('榜单和列表均未返回开始时间');
            if (first.begin < start || first.begin >= end) continue;
            matched++;
          }
          const probs = first.problems.map(p=>({...p}));
          if (first.pages > 1) {
            const known = new Set(first.roster), counts = probs.map(p=>new Set(p.solvers));
            const stats = probs.map(p=>({values:[p.official], agrees:p.official===null ? p.exact : p.official===p.solvers.length}));
            let disjoint=true, maxPage=first.roster.length; const pageSizes=[maxPage];
            for (let n=2;n<=first.pages;n++) {
              if (n>pageLimit) fail('榜单超过 '+pageLimit+' 页上限');
              const pg=await get(url+'/scoreboard?page='+n,'board-v1',b=>boardPage(b,task,n,domain,uid));
              if (pg.pages!==first.pages || pg.problems.length!==probs.length || pg.problems.some((p,j)=>p.pid!==probs[j].pid)) fail('榜单分页发生变化');
              if (!pg.roster.some(u=>!known.has(u))) fail('榜单分页重复或为空');
              if (pg.roster.some(u=>known.has(u))) disjoint=false;
              pg.roster.forEach(u=>known.add(u)); maxPage=Math.max(maxPage,pg.roster.length); pageSizes.push(pg.roster.length);
              pg.problems.forEach((p,j)=>{ p.solvers.forEach(u=>counts[j].add(u)); probs[j].self ||= p.self;
                stats[j].values.push(p.official); stats[j].agrees &&= p.official===null ? p.exact : p.official===p.solvers.length;
              });
            }
            probs.forEach((p,j)=>{
              const {values,agrees}=stats[j], same=values[0]!==null && values.every(x=>x===values[0]);
              if (same && values[0]>maxPage && values[0]<=known.size) p.passed=values[0]; // necessarily a whole-board total
              else if (agrees) p.passed=counts[j].size; // confirmed per-page ACs with known user IDs
              else if (disjoint && !same && values.every(v=>v!==null) && values.every((v,i)=>v<=pageSizes[i])) p.passed=values.reduce((a,b)=>a+b,0);
              else fail('分页榜单无法核实题目 '+p.pid+' 的逐人状态');
            });
          }
          scanned++;
          for (const p of probs) {
            if (p.self) selfAC.add(p.pid);
            if (p.passed < threshold) continue;
            let found = candidates.get(p.pid);
            if (!found) { found={pid:p.pid,title:p.title,public:p.public,hidden:p.hidden,homeworks:[]}; candidates.set(p.pid,found); }
            found.public ||= p.public; found.hidden ||= p.hidden;
            found.homeworks.push({id:task.id,title:task.title,href:url,passed:p.passed});
          }
        } catch(e) { warn('作业 '+task.title,e); }
      }
      for (const pid of selfAC) candidates.delete(pid);
      let mine;
      if (candidates.size) {
        onProgress('正在核对当前账号在本域通过的题目');
        try { mine = await get(base+'/user/'+uid,'solved-v1',b=>profile(b,uid,domain)); }
        catch(e) { warn('个人通过列表',e); }
      }
      const seenAC = new Set(mine?.solved || []), rows = [];
      for (const [pid,p] of candidates) {
        if (seenAC.has(pid)) continue;
        let standalone = p.public;
        if (!mine?.visible || !p.public) {
          try { onProgress('正在核对本人题库状态：'+p.title);
            const ps = await get(link(pid),'problem-v1', b=>problemStatus(b,pid,uid,domain)); if (!mine?.selfVerified && !ps.ownerVerified) fail('缺少本人身份依据');
            if (ps.ac) continue; standalone = p.public || !p.hidden;
          } catch(e) { warn('跳过无法核实本人状态的题目 '+pid,e); continue; }
        }
        p.homeworks.sort((a,b)=>b.passed-a.passed || a.id.localeCompare(b.id));
        rows.push({pid,title:p.title,passed:p.homeworks[0].passed,href:link(pid,standalone ? null : p.homeworks[0].id),homeworks:p.homeworks});
      }
      check(); rows.sort((a,b)=>b.passed-a.passed || a.pid.localeCompare(b.pid, 'en', {numeric:true}));
      return {rows,scanned,matched,warnings,complete:!warnings.length};
    };
  })();

  // This module is included inside the userscript IIFE by scripts/build.cjs.
  function openHomeworkPlanner() {
    syncPageContext();
    if (!settings.homeworkPlanner || pageName() !== 'homework_main') throw workError('请在作业首页启用并打开补题计划');
    const body = modal('作业补题计划', 'contest'), dialog = body.closest('dialog');
    dialog.dataset.exhHomeworkPlan = '1';
    const domain = String(domainId()), uid = +user()._id, epoch = routeEpoch, address = location.href;
    if (!Number.isSafeInteger(uid) || uid <= 0) { body.append(el('p', {}, '请先登录 OJ，再查找自己尚未通过的题目。')); return; }
    const key = 'exhloj.local.homework-plan.last.v1:' + JSON.stringify([location.origin, domain, uid]);
    const today = new Date(), month = new Date(today); month.setDate(month.getDate() - 29);
    const defaults = { from: localDateInput(month), to: localDateInput(today), threshold: 3 };
    const previous = stored(key, null);
    let saved = previous?.schema === 1 && previous.uid === uid && previous.domain === domain &&
      previous.origin === location.origin && previous.filters && Number.isFinite(previous.time) &&
      Array.isArray(previous.rows) && previous.rows.every(r => r && Array.isArray(r.homeworks)) ? previous : null;
    const form = el('form', { id: 'exhloj-homework-plan-form' }), filters = saved?.filters || defaults;
    body.append(el('p', {}, '按作业开始日期查找，包含首尾两天。只列出你在本域尚未通过、且在至少一份作业中达到通过人数的题目。'));
    for (const [name, label, type] of [['from', '开始日期', 'date'], ['to', '结束日期', 'date'], ['threshold', '至少通过人数', 'number']]) {
      const wrap = el('label', {}, label + ' ');
      wrap.append(el('input', { name, type, value: filters[name], required: '', ...(name === 'threshold' ? { min: 1, step: 1 } : {}) })); form.append(wrap);
    }
    const start = el('button', { id: 'exhloj-homework-plan-scan', type: 'submit', class: 'button exhloj-local-button' }, '查找补题');
    const reset = el('button', { id: 'exhloj-homework-plan-reset', type: 'button', class: 'button exhloj-local-button' }, '重置请求缓存');
    const results = el('div', { id: 'exhloj-homework-plan-results', class: 'exhloj-work-results' });
    form.append(start, reset); body.append(form, el('p', {}, '同一账号、同一域的查询结果会复用 ' +
      (HOMEWORK_PLAN_CACHE_TTL / 60000) + ' 分钟。重置后，下次查找会重新读取；上次完整计划仍保留。'));
    const state = workStates.planner; if (!state.running) Object.assign(state, { status: '', message: '', errors: [], job: null });
    workProgress(body, 'planner'); showWorkErrors(state); body.append(results);
    const cancel = $('[data-exh-action="work-cancel"]', body); cancel.disabled = true;
    let generation = 0, activeJob;
    function assertPage() {
      if (!dialog.open || !body.isConnected || epoch !== routeEpoch || address !== location.href || pageName() !== 'homework_main' ||
          uid !== +user()._id || domain !== String(domainId()) || !settings.homeworkPlanner) throw workError('页面、账号或域已变化，请重新打开补题计划');
    }
    function resultLink(label, href, kind) {
      // Only link to the two local routes the data module emits, including when restoring saved results.
      try {
        const url = new URL(href, location.origin);
        if (url.origin === location.origin && url.pathname.startsWith('/d/' + seg(domain) + '/' + kind + '/'))
          return el('a', { href: url.pathname + url.search, target: '_blank', rel: 'noopener noreferrer' }, label);
      } catch { /* Render unreadable links as plain text. */ }
      return el('span', {}, label);
    }
    function render(record, mode) {
      results.replaceChildren();
      if (!record) { results.append(el('p', {}, '还没有保存的补题计划。')); return; }
      const f = record.filters, cached = mode === 'saved', partial = mode === 'partial';
      const title = cached ? '上次保存的计划' : partial ? '部分结果（未保存）' : '本次补题计划';
      results.append(el('h3', {}, title + ' · ' + record.rows.length + ' 道题'),
        el('p', {}, f.from + ' 至 ' + f.to + ' · 至少 ' + f.threshold + ' 人通过 · 已读取 ' + record.scanned + '/' + record.matched +
          ' 份匹配作业的榜单 · ' + new Date(record.time).toLocaleString()));
      if (partial) results.append(el('p', {}, '有数据未能核实，只展示已确认的题目。' + (saved ? '上次完整计划仍保留。' : '')));
      if (!record.rows.length) { results.append(el('p', {}, partial ? '已核实的数据中没有符合条件的题目。' : '此范围内没有符合条件的题目。')); return; }
      const table = el('table'), head = el('thead'), th = el('tr'), list = el('tbody');
      for (const label of ['题目', '最多通过人数', '来源作业（通过人数）']) th.append(el('th', { scope: 'col' }, label));
      head.append(th); table.append(head, list); results.append(table);
      let at = 0; const more = el('button', { type: 'button', class: 'button exhloj-local-button' });
      function appendPage() {
        const fragment = document.createDocumentFragment(), end = Math.min(at + 100, record.rows.length);
        for (; at < end; at++) {
          const row = record.rows[at], tr = el('tr'), problem = el('td'), source = el('td');
          const pid = String(row.pid), title = String(row.title || pid);
          problem.append(resultLink(title === pid || title.startsWith(pid + ' ') ? title : pid + ' · ' + title, row.href, 'p'));
          for (const [i, hw] of row.homeworks.entries()) {
            if (!hw) continue;
            if (i) source.append('、'); source.append(resultLink(String(hw.title || hw.id), hw.href, 'homework'), '（' + hw.passed + '）');
          }
          tr.append(problem, el('td', {}, row.passed), source); fragment.append(tr);
        }
        list.append(fragment); more.hidden = at >= record.rows.length;
        more.textContent = '显示更多（已显示 ' + at + '/' + record.rows.length + '）';
      }
      more.addEventListener('click', appendPage); results.append(more); appendPage();
    }
    render(saved, 'saved');
    const busy = value => { start.disabled = value; cancel.disabled = !value; for (const input of $$('input', form)) input.disabled = value; };
    dialog.addEventListener('close', () => { generation++; activeJob?.controller.abort(); }, { once: true });
    reset.addEventListener('click', () => task(async () => {
      assertPage(); generation++; activeJob?.controller.abort();
      resetHomeworkPlanCache(domain); render(saved, 'saved');
      if (!activeJob) Object.assign(state, { job: null, status: '就绪', errors: [], message: '已重置本域当前账号的请求缓存。' });
      updateWorkProgress('planner'); showWorkErrors(state); notify('已重置补题计划缓存，可按当前条件重新查找');
    }));
    form.addEventListener('submit', event => {
      event.preventDefault();
      task(async () => {
        assertPage(); if (activeJob || workJobs.has('planner')) throw workError('补题查找仍在结束，请稍后再试');
        const from = form.elements.from.value, to = form.elements.to.value, threshold = Number(form.elements.threshold.value);
        const first = new Date(from + 'T00:00:00'), last = new Date(to + 'T00:00:00');
        if (localDateInput(first) !== from || localDateInput(last) !== to || first > last) throw workError('请选择有效的起止日期，结束日期不能早于开始日期');
        if (!Number.isSafeInteger(threshold) || threshold < 1) throw workError('通过人数须为正整数');
        last.setDate(last.getDate() + 1);
        const token = ++generation, revision = homeworkPlanCacheRevision(domain);
        busy(true); render(saved, 'saved');
        try { await runWork('planner', async (job, work) => {
          activeJob = job;
          const check = () => { checkJob(job); assertPage(); if (generation !== token) throw workError('本次查找已取消'); };
          const onProgress = message => { check(); work.message = message; updateWorkProgress('planner'); };
          const plan = await scanHomeworkPlan({ domain, uid, start: +first, end: +last, threshold, pageLimit: settings.helperPageLimit, check, onProgress,
            read: (path, view, project) => { check(); return homeworkPlanRead(job, domain, path, view, project); } });
          check(); if (homeworkPlanCacheRevision(domain) !== revision) throw workError('补题缓存已重置，请重新查找');
          const record = { schema: 1, revision, domain, uid, origin: location.origin, time: Date.now(), filters: { from, to, threshold },
            rows: plan.rows, scanned: plan.scanned, matched: plan.matched };
          if (plan.complete) {
            try {
              if (new Blob([JSON.stringify(record)]).size > LIMIT) throw new Error('too large');
              save(key, record); saved = record; work.message = '已保存这次完整的补题计划。';
            } catch { work.message = '本次结果可在这里查看，但未能写入本地存储。'; }
          } else { work.status = '完成，部分结果'; work.message = '未核实的数据不会加入计划。'; }
          work.errors.push(...plan.warnings); render(record, plan.complete ? 'fresh' : 'partial');
        }); } finally {
          activeJob = null; busy(false);
          if (token !== generation && state.root === body && dialog.open) {
            Object.assign(state, { job: null, status: '就绪', errors: [], message: '已重置本域当前账号的请求缓存。' });
            updateWorkProgress('planner'); showWorkErrors(state);
          }
        }
      });
    });
  }

  function abandonPlannerView() {
    workJobs.get('planner')?.controller.abort();
    workStates.planner = {};
    const dialog = $('dialog[data-exh-homework-plan]');
    if (dialog) { dialog.close(); dialog.remove(); }
  }
  function syncPageContext() {
    const owner = String(user()._id || 0), name = pageName(), domain = domainId();
    if (location.href !== route || owner !== routeOwner || name !== routeName || domain !== routeDomain) {
      const accountChanged = owner !== routeOwner;
      route = location.href; routeOwner = owner; routeName = name; routeDomain = domain;
      routeEpoch++; contextBody = {}; pageRequest = undefined;
      abandonPlannerView();
      if ($('#exhloj-contest-files, #exhloj-profile-view')) $('#exhloj-local-dialog')?.close();
      semanticPanel?.controller?.abort();
      if (semanticPanel?.body.isConnected) renderSearchResults(semanticPanel);
      if (accountChanged) for (const job of workJobs.values()) job.controller.abort();
      workJobs.get('user')?.controller.abort(); ratingTimeline = undefined;
      if (workJobs.get('oier')?.quick) workJobs.get('oier').controller.abort();
      oierQuickQueue = undefined;
      lastPageError = ''; homeworkStarted = recordStarted = solutionStarted = false;
      clearLocalRemote(); removeTitleTools(); remotePending = false; contestRevealed = false;
      lastEvents.delete('homework_detail.prepare'); lastEvents.delete('record_detail.prepare');
      for (const id of ['exhloj-local-avatar', 'exhloj-local-origin-code', 'exhloj-profile-entry']) $(`#${id}`)?.remove();
    }
  }
  function refresh() {
    syncPageContext();
    if (!settings.homeworkPlanner && (workJobs.has('planner') || $('dialog[data-exh-homework-plan]'))) abandonPlannerView();
    document.documentElement.classList.toggle('exhloj-local-rounded', enabled('rounded'));
    document.documentElement.classList.toggle('exhloj-local-ui', settings.ui);
    installMenu(); syncMenuVisibility(); syncRankingLayout();
    try {
      if (page.UiContext) {
        if (!page.UiContext.exhloj) page.UiContext.exhloj = {};
        page.UiContext.exhloj.core = core;
        page.UiContext.exhloj.getTimeByObjectId = core.getTimeByObjectId;
        if (settings.userModule) page.UiContext.exhloj.user = localUserAPI;
        else delete page.UiContext.exhloj.user;
      }
    } catch { /* 部分站点可能将上下文设为只读。 */ }
    const name = pageName();
    if (enabled('homework') && name === 'homework_detail') homework();
    if (enabled('scoreboard') && name.endsWith('scoreboard')) scoreboard();
    if (enabled('markdown') && name === 'problem_solution') solutionTools();
    if (enabled('avatar') && name === 'home_account') avatarTools();
    if (settings.captcha) runCaptcha();
    if (isProblemPage(name)) remoteProblem();
    if (settings.remote && name === 'record_detail') remoteSubmissionTools();
    syncTitleTools(); syncNativeFileSections(); configureAutoAttend(); refreshUserModule();
    if (settings.ui && name === 'record_detail' && !recordStarted && current('rdoc')) {
      recordStarted = true; broadcast('record_detail.prepare', current('rdoc'));
    }
  }
  let refreshTimer;
  function schedule() { clearTimeout(refreshTimer); refreshTimer = setTimeout(() => task(refresh), 120); }
  const menuAttributes = ['class', 'href', 'title', 'aria-label', 'aria-disabled', 'disabled', 'data-count', 'data-can-access', 'data-can-view-similarity', 'data-permission-status'];
  const observer = new MutationObserver(records => {
    let menuChanged = false;
    if (records.some(record => {
      const target = record.target.nodeType === Node.ELEMENT_NODE ? record.target : record.target.parentElement;
      if (target?.closest('#exhloj-local-dialog, #exhloj-local-toast, #exhloj-title-popup')) return false;
      if (record.type === 'attributes' && menuAttributes.includes(record.attributeName)) {
        menuChanged ||= !!target?.closest(mainNav + ',' + sideMenus + ',[data-exh-menu-hidden]');
        return false;
      }
      // 仅监听 DOM 内容、页面名称和上下文脚本变化，避免自身样式修改形成循环。
      return true;
    })) schedule();
    else if (menuChanged) syncMenuVisibility();
  });
  observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['src', ...menuAttributes] });
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-page'] });
  for (const event of ['pjax:end', 'vjContentNew', 'popstate', 'pageshow']) window.addEventListener(event, schedule);
  // Hydro 的部分版本通过 jQuery 触发 vjContentNew，原生监听器无法接收。
  try { (page.jQuery || page.$)?.(document).on('vjContentNew.exhlojLocal pjax:end.exhlojLocal', schedule); } catch {}
  if (typeof GM_registerMenuCommand === 'function') GM_registerMenuCommand('Extend HLOJ', openHome);
  refresh();
  // 为晚于 userscript 初始化的 UiContext 提供有界重试，不产生网络轮询。
  for (const delay of [300, 1000, 3000, 8000]) setTimeout(schedule, delay);
})();


/* THIRD-PARTY LICENSE NOTICES
marked 18.1.1
# License information

## Contribution License Agreement

If you contribute code to this project, you are implicitly allowing your code
to be distributed under the MIT license. You are also implicitly verifying that
all code is your original work. `</legalese>`

## Marked

Copyright (c) 2018+, MarkedJS (https://github.com/markedjs/)
Copyright (c) 2011-2018, Christopher Jeffrey (https://github.com/chjj/)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

## Markdown

Copyright © 2004, John Gruber
http://daringfireball.net/
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* Neither the name “Markdown” nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

This software is provided by the copyright holders and contributors “as is” and any express or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed. In no event shall the copyright owner or contributors be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.


dompurify 3.4.17

                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.


katex 0.18.10
The MIT License (MIT)

Copyright (c) 2013-2020 Khan Academy and other contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


marked-katex-extension 5.1.13
MIT License

Copyright (c) 2021 @markedjs

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


pinyin-pro 3.29.5
MIT License

Copyright (c) 2022-present zh-lx

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


*/
